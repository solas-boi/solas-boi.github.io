# React Native icons

React Native components for the `@boi/icons` files.

## Installation

```console
npm i react-native-svg
npm i @boi/react-native-icons
```

## Usage

```jsx
import { CloseIcon, ErrorIcon } from "@boi/react-native-icons";
```

To change the color of standard icons, use the `color` prop:

```jsx
<CloseIcon color={modal.icons.close.color} />
```

To change the color of multicolor icons, use the `primaryColor` and `secondaryColor` props:

```jsx
<ErrorIcon
  primaryColor={modal.icons.error.primaryColor}
  secondaryColor={modal.icons.error.secondaryColor}
/>
```
