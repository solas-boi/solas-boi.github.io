export {
  default as StandardModalWithFooter,
  type StandardModalWithFooterProps,
} from "./StandardModalWithFooter";
