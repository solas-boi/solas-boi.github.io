import { Modal, type ModalProps } from "../Modal";
import {
  StandardModalBase,
  type StandardModalBaseProps,
} from "../StandardModalBase";

export type StandardModalWithFooterProps = ModalProps &
  Omit<StandardModalBaseProps, "footer"> & {
    footer: StandardModalBaseProps["footer"];
  };

function StandardModalWithFooter(props: StandardModalWithFooterProps) {
  const {
    title,
    headingLevel,
    accessibilityLabel,
    accessibilityHint,
    footer,
    children,
    testID = "standard-modal-with-footer",
    ...modalProps
  } = props;

  return (
    <Modal
      {...modalProps}
      accessibilityLabel={accessibilityLabel || title}
      accessibilityHint={accessibilityHint}
      testID={testID}
    >
      <StandardModalBase
        testID={testID}
        title={title}
        headingLevel={headingLevel}
        onRequestClose={modalProps.onRequestClose}
        footer={footer}
      >
        {children}
      </StandardModalBase>
    </Modal>
  );
}

export default StandardModalWithFooter;
