import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import {
  CoreAlertModal,
  HEADING_LEVELS,
  ALERT_SEVERITIES,
} from "@boi/components-core";

import AlertModal from "./AlertModal";
import { Button } from "../Button";

const meta = {
  title: "Surfaces/AlertModal",
  component: AlertModal,
  render: function Render(args) {
    const [{ isOpen }, updateArgs] = useArgs();

    function openModalPressHandler() {
      updateArgs({ isOpen: true });
      action("openModal")();
    }

    function modalClosedHandler() {
      updateArgs({ isOpen: false });
      action("modalClosed")();
    }

    return (
      <>
        <Button
          testID="OPEN_MODAL_BUTTON"
          variant="primary"
          text="Open Modal"
          disabled={isOpen}
          onPress={openModalPressHandler}
        />

        <AlertModal
          {...args}
          isOpen={isOpen}
          primaryButtonsProps={[
            {
              text: "Login",
              onPress: modalClosedHandler,
            },
          ]}
          secondaryButtonsProps={[
            {
              text: "Contact us",
              onPress: modalClosedHandler,
            },
          ]}
        />
      </>
    );
  },
  argTypes: {
    heading: { control: { type: "text" } },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
    severity: {
      control: { type: "select" },
      options: ALERT_SEVERITIES,
    },
    primaryButtonsProps: { control: { disable: true } },
    secondaryButtonsProps: { control: { disable: true } },
    footerLayout: {
      control: { type: "select" },
      options: CoreAlertModal.FOOTER_LAYOUTS,
    },
    hasStickyFooter: { control: { type: "boolean" } },
    tabletWidth: { control: { type: "number" } },
    children: { control: { disable: true } },
  },
  args: {
    isOpen: false,
    severity: CoreAlertModal.DEFAULT_SEVERITY,
    footerLayout: CoreAlertModal.DEFAULT_FOOTER_LAYOUT,
    hasStickyFooter: false,
  },
} satisfies Meta<typeof AlertModal>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    heading: "We cannot complete your request just now",
    children: (
      <AlertModal.Typography variant="bodyM">
        Sorry about that. You could try again later or you can access your
        account through 365 phone banking by contacting us.
      </AlertModal.Typography>
    ),
  },
};

export const LongContent: Story = {
  args: {
    heading: "We cannot complete your request just now",
    children: (
      <AlertModal.Typography variant="bodyM">
        Sorry about that. You could try again later or you can access your
        account through 365 phone banking by contacting us. Sorry about that.
        You could try again later or you can access your account through 365
        phone banking by contacting us. Sorry about that. You could try again
        later or you can access your account through 365 phone banking by
        contacting us. Sorry about that. You could try again later or you can
        access your account through 365 phone banking by contacting us. Sorry
        about that. You could try again later or you can access your account
        through 365 phone banking by contacting us. Sorry about that. You could
        try again later or you can access your account through 365 phone banking
        by contacting us. You could try again later or you can access your
        account through 365 phone banking by contacting us. Sorry about that.
        You could try again later or you can access your account through 365
        phone banking by contacting us. You could try again later or you can
        access your account through 365 phone banking by contacting us. Sorry
        about that. You could try again later or you can access your account
        through 365 phone banking by contacting us. You could try again later or
        you can access your account through 365 phone banking by contacting us.
        Sorry about that. You could try again later or you can access your
        account through 365 phone banking by contacting us. You could try again
        later or you can access your account through 365 phone banking by
        contacting us. Sorry about that. You could try again later or you can
        access your account through 365 phone banking by contacting us. You
        could try again later or you can access your account through 365 phone
        banking by contacting us. Sorry about that. You could try again later or
        you can access your account through 365 phone banking by contacting us.
      </AlertModal.Typography>
    ),
  },
};
