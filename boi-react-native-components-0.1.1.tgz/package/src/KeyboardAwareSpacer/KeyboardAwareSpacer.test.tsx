import { Keyboard } from "react-native";

import { act, render } from "@testing-library/react-native";

import { KeyboardAwareSpacer } from "./KeyboardAwareSpacer";

jest.mock("react-native/Libraries/Utilities/Platform", () => ({
  default: {
    OS: "android",
    select: (obj: Record<string, unknown>) => obj.android ?? obj.default,
  },
}));

describe("KeyboardAwareSpacer", () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it("renders a spacer when keyboard shows and hides on Android", () => {
    const listeners: Record<string, (event?: any) => void> = {};
    const removeMocks = {
      keyboardDidShow: jest.fn(),
      keyboardDidChangeFrame: jest.fn(),
      keyboardDidHide: jest.fn(),
    };

    jest
      .spyOn(Keyboard, "addListener")
      .mockImplementation((...args: unknown[]) => {
        const [eventName, callback] = args as [string, (event?: any) => void];
        listeners[eventName] = callback;
        return {
          remove: removeMocks[eventName as keyof typeof removeMocks],
        } as any;
      });

    const { toJSON, unmount } = render(<KeyboardAwareSpacer />);

    expect(Keyboard.addListener).toHaveBeenCalledTimes(3);
    expect(toJSON()).toBeNull();

    act(() => {
      listeners.keyboardDidShow?.({ endCoordinates: { height: 180 } });
    });

    expect(toJSON()).toMatchObject({
      type: "View",
      props: {
        style: { height: 180 },
      },
    });

    act(() => {
      listeners.keyboardDidChangeFrame?.({ endCoordinates: { height: 110 } });
    });

    expect(toJSON()).toMatchObject({
      type: "View",
      props: {
        style: { height: 110 },
      },
    });

    act(() => {
      listeners.keyboardDidHide?.();
    });

    expect(toJSON()).toBeNull();

    unmount();

    expect(removeMocks.keyboardDidShow).toHaveBeenCalled();
    expect(removeMocks.keyboardDidChangeFrame).toHaveBeenCalled();
    expect(removeMocks.keyboardDidHide).toHaveBeenCalled();
  });
});
