import { useEffect, useState } from "react";
import { Keyboard, Platform, View } from "react-native";

const IS_IOS = Platform.OS === "ios";

export const KeyboardAwareSpacer = () => {
  const [keyboardHeight, setKeyboardHeight] = useState(0);

  useEffect(() => {
    if (IS_IOS) {
      return;
    }

    const show = Keyboard.addListener("keyboardDidShow", (e) =>
      setKeyboardHeight(e.endCoordinates.height)
    );
    const change = Keyboard.addListener("keyboardDidChangeFrame", (e) =>
      setKeyboardHeight(e.endCoordinates.height)
    );
    const hide = Keyboard.addListener("keyboardDidHide", () =>
      setKeyboardHeight(0)
    );

    return () => {
      show.remove();
      change.remove();
      hide.remove();
    };
  }, []);

  if (IS_IOS || keyboardHeight === 0) {
    return null;
  }

  return <View style={{ height: keyboardHeight }} />;
};
