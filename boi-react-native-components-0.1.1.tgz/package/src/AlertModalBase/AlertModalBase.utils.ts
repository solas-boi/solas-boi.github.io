import { type AlertModalBaseProps } from "./AlertModalBase";

export function useOrderedButtonsProps(
  footerLayout: AlertModalBaseProps["footerLayout"],
  primaryButtonsProps?: AlertModalBaseProps["primaryButtonsProps"],
  secondaryButtonsProps?: AlertModalBaseProps["secondaryButtonsProps"]
) {
  const isStacked = footerLayout === "stacked";
  const updatedPrimaryButtonsProps = (primaryButtonsProps || []).map(
    (buttonProps) => {
      return {
        ...buttonProps,
        variant: "primary",
        fullWidth: isStacked,
      } as const;
    }
  );

  const updatedSecondaryButtonsProps = (secondaryButtonsProps || []).map(
    (buttonProps) => {
      return {
        ...buttonProps,
        variant: "secondary",
        fullWidth: isStacked,
      } as const;
    }
  );

  const orderedButtonsProps = [];

  if (footerLayout === "stacked") {
    orderedButtonsProps.push(
      ...updatedPrimaryButtonsProps.reverse(),
      ...updatedSecondaryButtonsProps.reverse()
    );
  } else {
    orderedButtonsProps.push(
      ...updatedSecondaryButtonsProps,
      ...updatedPrimaryButtonsProps
    );
  }

  return { orderedButtonsProps };
}
