export {
  default as MultiSelectModalBase,
  type MultiSelectModalBaseProps,
} from "./MultiSelectModalBase";
