import { useEffect, useRef } from "react";
import { FlatList, Platform, ViewToken } from "react-native";
import { CoreMultiSelect } from "@boi/components-core";

import { MultiSelectItem } from "./MultiSelectItem";
import { MULTI_SELECT_ITEM_HEIGHT } from "./MultiSelectItem/MultiSelectItem.styles";
import { StandardModal } from "../StandardModal";
import { useStandardModalContext } from "../StandardModalBase/StandardModalBase.hooks";

export type MultiSelectModalBaseProps<
  T extends CoreMultiSelect.MultiSelectItem
> = {
  selectedItems?: (T | null | undefined)[];
  updatedSelectedItems: (T | null | undefined)[];
  setUpdatedSelectedItems: (selectedItems: (T | null | undefined)[]) => void;
  items: T[];
  disabledKeys?: string[];
  readyToInteract: boolean;
};

function MultiSelectModalBase<T extends CoreMultiSelect.MultiSelectItem>(
  props: MultiSelectModalBaseProps<T>
) {
  const {
    selectedItems,
    updatedSelectedItems,
    setUpdatedSelectedItems,
    items,
    disabledKeys,
    readyToInteract,
  } = props;

  const { headingHeight } = useStandardModalContext();
  const ref = useRef<FlatList>(null);
  const flatlistViewableInfoRef = useRef<{ viewableItems: ViewToken<T>[] }>(
    null
  );
  const didInitialScroll = useRef(false);

  useEffect(() => {
    if (
      Platform.OS === "android" &&
      readyToInteract &&
      !didInitialScroll.current &&
      selectedItems &&
      selectedItems[0] &&
      ref.current
    ) {
      ref.current.scrollToItem({
        item: selectedItems[0],
      });
      didInitialScroll.current = true;
    }
  }, [selectedItems, readyToInteract]);

  function handlePress(item: T) {
    setUpdatedSelectedItems(
      updatedSelectedItems.includes(item)
        ? updatedSelectedItems.filter((updatedSelectedItem) => {
            return updatedSelectedItem !== item;
          })
        : [...updatedSelectedItems, item]
    );
  }

  return (
    <StandardModal.FlatList
      flatlistRef={ref}
      paddingBottom={8}
      role="list"
      accessibilityRole="list"
      alwaysBounceVertical={false}
      initialScrollIndex={
        Platform.OS === "ios" && selectedItems && selectedItems[0]
          ? items.indexOf(selectedItems[0])
          : undefined
      }
      data={items}
      keyExtractor={(item: T) => item.id}
      snapToInterval={MULTI_SELECT_ITEM_HEIGHT}
      getItemLayout={(_data, index) => {
        return {
          length: MULTI_SELECT_ITEM_HEIGHT,
          offset: headingHeight + MULTI_SELECT_ITEM_HEIGHT * index,
          index,
        };
      }}
      onViewableItemsChanged={(info) => {
        flatlistViewableInfoRef.current = info;
      }}
      viewabilityConfig={{
        viewAreaCoveragePercentThreshold: 1,
      }}
      renderItem={({ item, index }) => {
        const isSelected = updatedSelectedItems.includes(item);
        const isDisabled = disabledKeys
          ? disabledKeys.includes(item.id)
          : false;

        return (
          <MultiSelectItem
            flatlistRef={ref}
            flatlistViewableInfoRef={flatlistViewableInfoRef}
            isSelected={isSelected}
            isDisabled={isDisabled}
            item={item}
            isFirst={index === 0}
            isLast={index === items.length - 1}
            onPress={() => handlePress(item)}
          />
        );
      }}
    />
  );
}

export default MultiSelectModalBase;
