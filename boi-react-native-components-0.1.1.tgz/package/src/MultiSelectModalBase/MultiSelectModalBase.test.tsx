import React, { PropsWithChildren } from "react";
import { Platform, View } from "react-native";
import type { FlatList as RNFlatList } from "react-native";
import { render, screen, userEvent } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreMultiSelect, PropsWithTestID } from "@boi/components-core";

import MultiSelectModalBase, {
  MultiSelectModalBaseProps,
} from "./MultiSelectModalBase";
import * as StandardModal from "../StandardModal";
import { MULTI_SELECT_ITEM_HEIGHT } from "./MultiSelectItem/MultiSelectItem.styles";

type MultiSelectItemLike = { id: string };
type StandardModalFlatListProps = React.ComponentProps<
  typeof StandardModal.StandardModal.FlatList
>;

jest.useFakeTimers();

jest.mock("../StandardModalBase/StandardModalBase.hooks", () => ({
  useStandardModalContext: () => ({ headingHeight: 50 }),
}));

jest
  .spyOn(StandardModal.StandardModal, "FlatList")
  .mockImplementation((props: StandardModalFlatListProps) => {
    const {
      data,
      renderItem,
      flatlistRef,
      testID = "multi-select-modal-flatlist",
      ...rest
    } = props;
    const fakeRef = { scrollToItem: jest.fn() };

    if (flatlistRef) {
      if (typeof flatlistRef === "function") {
        flatlistRef(fakeRef as unknown as RNFlatList<unknown>);
      } else {
        (
          flatlistRef as React.MutableRefObject<RNFlatList<unknown> | null>
        ).current = fakeRef as unknown as RNFlatList<unknown>;
      }
    }

    const items = (data ?? []) as MultiSelectItemLike[];
    const TestView = View as React.ComponentType<any>;

    return (
      <TestView testID={testID} flatlistRef={{ current: fakeRef }} {...rest}>
        {items.map((item, index) => {
          const wrapper =
            typeof renderItem === "function"
              ? (
                  renderItem as (info: {
                    item: MultiSelectItemLike;
                    index: number;
                  }) => React.ReactElement
                )({ item, index })
              : null;

          if (!wrapper) {
            return null;
          }

          const wrapperProps = wrapper.props as PropsWithChildren;

          const inner = (
            wrapperProps.children
              ? React.Children.only(wrapperProps.children)
              : wrapper
          ) as React.ReactElement<PropsWithTestID>;

          return React.cloneElement(inner, {
            ...inner.props,
            key: item.id,
            testID: "multi-select-item",
          });
        })}
      </TestView>
    );
  });

const setPlatform = (os: "ios" | "android") => {
  Object.defineProperty(Platform, "OS", {
    value: os,
    configurable: true,
  });
};

const WrappedMultiSelectModalBase = <T extends CoreMultiSelect.MultiSelectItem>(
  props: MultiSelectModalBaseProps<T>
) => (
  <DesignTokensProvider>
    <MultiSelectModalBase {...props} />
  </DesignTokensProvider>
);

describe("MultiSelectModalBase", () => {
  type Item = CoreMultiSelect.MultiSelectItem;

  const items: Item[] = [
    { id: "1", title: "Item 1", value: "1" },
    { id: "2", title: "Item 2", value: "2" },
    { id: "3", title: "Item 3", value: "3" },
  ];
  const setUpdatedSelectedItems = jest.fn();
  const baseProps: MultiSelectModalBaseProps<Item> = {
    items,
    selectedItems: [items[1]],
    updatedSelectedItems: [items[1]],
    setUpdatedSelectedItems,
    disabledKeys: [],
    readyToInteract: true,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    setPlatform("ios");
  });

  const getItems = () => screen.getAllByTestId("multi-select-item");

  it("should render all list items", () => {
    render(<WrappedMultiSelectModalBase {...baseProps} />);
    expect(getItems().length).toBe(3);
  });

  it("should mark the selected item as selected", () => {
    render(<WrappedMultiSelectModalBase {...baseProps} />);
    expect(getItems()[1]?.props.accessibilityState.selected).toBe(true);
  });

  it("should mark disabled items as disabled", () => {
    render(<WrappedMultiSelectModalBase {...baseProps} disabledKeys={["2"]} />);
    expect(getItems()[1]?.props.accessibilityState.disabled).toBe(true);
  });

  it("should add an unselected item to updatedSelectedItems when pressed", async () => {
    const user = userEvent.setup();
    render(<WrappedMultiSelectModalBase {...baseProps} />);

    await user.press(getItems()[0]!);

    expect(setUpdatedSelectedItems).toHaveBeenCalledWith([items[1], items[0]]);
  });

  it("should remove a selected item from updatedSelectedItems when pressed", async () => {
    const user = userEvent.setup();
    render(<WrappedMultiSelectModalBase {...baseProps} />);

    await user.press(getItems()[1]!);

    expect(setUpdatedSelectedItems).toHaveBeenCalledWith([]);
  });

  describe("initial scroll behavior", () => {
    it("should set initialScrollIndex on iOS", () => {
      setPlatform("ios");
      render(<WrappedMultiSelectModalBase {...baseProps} />);

      expect(
        screen.getByTestId("multi-select-modal-flatlist").props
          .initialScrollIndex
      ).toBe(1);
    });

    it("should NOT set initialScrollIndex on Android", () => {
      setPlatform("android");
      render(<WrappedMultiSelectModalBase {...baseProps} />);

      expect(
        screen.getByTestId("multi-select-modal-flatlist").props
          .initialScrollIndex
      ).toBeUndefined();
    });

    it("should scroll to selected item on Android after readyToInteract", () => {
      setPlatform("android");
      render(<WrappedMultiSelectModalBase {...baseProps} />);

      const list = screen.getByTestId("multi-select-modal-flatlist");
      const scrollSpy = list.props.flatlistRef.current.scrollToItem;

      expect(scrollSpy).toHaveBeenCalledWith({ item: items[1] });
    });

    it("should NOT scroll when selectedItems is undefined", () => {
      setPlatform("android");
      render(
        <WrappedMultiSelectModalBase {...baseProps} selectedItems={undefined} />
      );

      const list = screen.getByTestId("multi-select-modal-flatlist");
      const scrollSpy = list.props.flatlistRef.current.scrollToItem;

      expect(scrollSpy).not.toHaveBeenCalled();
    });
  });

  it("should NOT scroll when selectedItems array is empty", () => {
    setPlatform("android");
    render(<WrappedMultiSelectModalBase {...baseProps} selectedItems={[]} />);

    const list = screen.getByTestId("multi-select-modal-flatlist");
    const scrollSpy = list.props.flatlistRef.current.scrollToItem;

    expect(scrollSpy).not.toHaveBeenCalled();
  });

  it("should use correct getItemLayout", () => {
    render(<WrappedMultiSelectModalBase {...baseProps} />);

    const list = screen.getByTestId("multi-select-modal-flatlist");
    const layout = list.props.getItemLayout(undefined, 2);

    expect(layout).toEqual({
      length: MULTI_SELECT_ITEM_HEIGHT,
      offset: 50 + MULTI_SELECT_ITEM_HEIGHT * 2,
      index: 2,
    });
  });
});
