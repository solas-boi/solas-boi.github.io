import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

export const MULTI_SELECT_ITEM_HEIGHT = 48;

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { multiSelect } = tokens;

  return StyleSheet.create({
    container: {
      minHeight: multiSelect.menu.option.minHeight,
      padding: multiSelect.menu.option.padding,
      backgroundColor: multiSelect.menu.option.backgroundColor.base,
      borderWidth: multiSelect.menu.stroke.width,
      borderStyle: multiSelect.menu.stroke.style,
      borderColor: multiSelect.menu.stroke.color,
      borderRadius: multiSelect.menu.radius,
    },
    containerNotFirst: {
      borderTopWidth: 0,
      borderTopLeftRadius: 0,
      borderTopRightRadius: 0,
    },
    containerNotLast: {
      borderBottomLeftRadius: 0,
      borderBottomRightRadius: 0,
    },
    contentWrapper: {
      display: "flex",
      justifyContent: "center",
      flex: 1,
      paddingTop: multiSelect.menu.option.inner.padding.top,
      paddingLeft: multiSelect.menu.option.inner.padding.left,
      paddingRight: multiSelect.menu.option.inner.padding.right,
      paddingBottom: multiSelect.menu.option.inner.padding.bottom,
      borderRadius: multiSelect.menu.option.inner.radius,
      backgroundColor: multiSelect.menu.option.inner.backgroundColor.base,
    },
    contentWrapperPressed: {
      backgroundColor: multiSelect.menu.option.inner.backgroundColor.active,
    },
    content: {
      display: "flex",
      flexDirection: "row",
      gap: multiSelect.menu.option.inner.gap,
    },
    text: {
      color: multiSelect.menu.option.inner.color.base,
    },
    textDisabled: {
      color: multiSelect.menu.option.inner.color.disabled,
    },
    checkboxWrapper: {
      display: "flex",
      justifyContent: "center",
      width: multiSelect.menu.option.inner.checkboxWrapper.width,
      height: parseSizeToken(
        multiSelect.menu.option.inner.checkboxWrapper.height,
        fontScale
      ),
    },
    typographyWrapper: {
      flexShrink: 1,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  isFirst: boolean,
  isLast: boolean,
  isDisabled: boolean
) {
  const styles = useStyles();

  return {
    container: [
      styles.container,
      !isFirst ? styles.containerNotFirst : undefined,
      !isLast ? styles.containerNotLast : undefined,
    ],
    contentWrapper: (pressed: boolean) => [
      styles.contentWrapper,
      pressed ? styles.contentWrapperPressed : undefined,
    ],
    text: [styles.text, isDisabled && styles.textDisabled],
  };
}

export default useStyles;
