import { memo, RefObject, useLayoutEffect, useRef, useState } from "react";
import { type FlatList, View, ViewToken } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreMultiSelect } from "@boi/components-core";

import useStyles, { useStateStyles } from "./MultiSelectItem.styles";
import { Checkbox } from "../../Checkbox";
import { Typography } from "../../Typography";

const TAB_KEYCODE = 61;

export type MultiSelectItemProps = {
  item: CoreMultiSelect.MultiSelectItem;
  isFirst: boolean;
  isLast: boolean;
  onPress: () => void;
  isSelected: boolean;
  isDisabled: boolean;
  flatlistRef: RefObject<FlatList | null>;
  flatlistViewableInfoRef: RefObject<{
    viewableItems: ViewToken<unknown>[];
  } | null>;
};

const MultiSelectItem = memo((props: MultiSelectItemProps) => {
  const {
    item,
    onPress,
    isSelected,
    isDisabled,
    isFirst,
    isLast,
    flatlistRef,
    flatlistViewableInfoRef,
  } = props;

  const { tokens } = useDesignTokens();
  const { multiSelect } = tokens;

  const styles = useStyles();
  const stateStyles = useStateStyles(isFirst, isLast, isDisabled);

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  // TODO: This workaround was added to fix the issue CP-82975. Ideally we should use the <Pressable /> component provided either by the "react-native" or "react-native-gesture-handler"
  // But the one provided by "react-native" was causing the issue reported on CP-82975
  // On the other hand, the one provided by "react-native-gesture-handler" had some layout problems and was not behaving as expected on Android by never returning the state `pressed` as true.
  // We should come back to this after a react-native version upgrade, revert the workaround changes and check it is still an issue. Last seen at version 0.74.5
  const [pressed, setPressed] = useState(false);
  const ref = useRef<View>(null);
  useLayoutEffect(() => {
    if (isSelected) {
      ref.current?.focus();
    }
  }, [isSelected]);

  return (
    <KeyboardPressable
      ref={ref}
      accessible
      enableA11yFocus
      style={stateStyles.container}
      accessibilityRole="checkbox"
      role="checkbox"
      accessibilityLabel={item.ariaLabel || item.title}
      accessibilityHint={!isSelected ? "Selects the item" : undefined}
      accessibilityState={{ selected: isSelected, disabled: isDisabled }}
      disabled={isDisabled}
      onAccessibilityTap={isDisabled ? undefined : onPress}
      onFocusChange={handleKeyboardFocusChange}
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onKeyDownPress={(e) => {
        if (e.nativeEvent.keyCode === TAB_KEYCODE) {
          if (isLast) {
            // Scrolls to the top of the list as the focus will move to the close button
            flatlistRef?.current?.scrollToIndex({
              index: 0,
              animated: true,
            });
          } else if (flatlistViewableInfoRef?.current) {
            const secondLastRenderedItem =
              flatlistViewableInfoRef.current.viewableItems.slice(-2)[0];

            const isSecondLastRenderedItem =
              secondLastRenderedItem?.item === item;

            // If the TAB key is pressed while the focus is on the second last item rendered on screen
            // Then scroll to it so more items are rendered below, hence ensuring the focus order using the TAB key is correct
            // This fixes ticked CP-98327
            if (isSecondLastRenderedItem && secondLastRenderedItem.index) {
              flatlistRef?.current?.scrollToIndex({
                index: secondLastRenderedItem.index,
                animated: true,
              });
            }
          }
        }
      }}
      testID="multi-select-item"
    >
      <View style={stateStyles.contentWrapper(pressed || hasKeyboardFocus)}>
        <View style={styles.content}>
          <View style={styles.checkboxWrapper}>
            <Checkbox
              labelProps={{
                "aria-label": item.ariaLabel || item.title,
              }}
              focusable={false}
              accessible={false}
              pointerEvents="none"
              importantForAccessibility="no"
              isChecked={isSelected}
              disabled={isDisabled}
            />
          </View>

          <View style={styles.typographyWrapper}>
            <Typography
              variant={multiSelect.menu.option.inner.text.typography.variant}
              fontFamily={
                multiSelect.menu.option.inner.text.typography.fontFamily
              }
              style={stateStyles.text}
            >
              {item.title}
            </Typography>
          </View>
        </View>
      </View>
    </KeyboardPressable>
  );
});

export default MultiSelectItem;
