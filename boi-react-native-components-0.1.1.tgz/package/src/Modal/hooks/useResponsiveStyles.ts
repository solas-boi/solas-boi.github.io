import { Platform, useWindowDimensions } from "react-native";
import { ModalStyleProps } from "../Modal.types";
import { useModalStyles } from "./useModalStyles";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { useKeyboard } from "@react-native-community/hooks";

const IS_ANDROID = Platform.OS === "android";

export const useResponsiveStyles = (
  isTablet: boolean,
  { tabletWidth }: Pick<ModalStyleProps, "tabletWidth">
) => {
  const styles = useModalStyles();
  const { tokens } = useDesignTokens();
  const { modal } = tokens;

  const windowDimensions = useWindowDimensions();
  const keyboard = useKeyboard();
  const keyboardPaddingStyles = {
    paddingBottom:
      IS_ANDROID && keyboard.keyboardShown ? keyboard.keyboardHeight : 0,
  };

  const maxTabletScreenWidth =
    windowDimensions.width - parseInt(modal.padding.tablet, 10) * 2;

  const sheetDeviceStyle = isTablet
    ? [
        styles.sheet,
        styles.sheetTablet,
        tabletWidth && tabletWidth < maxTabletScreenWidth
          ? {
              width: tabletWidth,
            }
          : undefined,
      ]
    : [styles.sheet, styles.sheetMobile];

  return {
    sheetDeviceStyle,
    container: [
      styles.container,
      isTablet ? styles.containerTablet : styles.containerMobile,
      isTablet && keyboard.keyboardShown ? keyboardPaddingStyles : undefined,
    ],
  };
};
