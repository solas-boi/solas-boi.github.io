import { useEffect, useRef } from "react";
import { FlatList, Platform, ViewToken } from "react-native";
import { CoreSelect } from "@boi/components-core";
import { SelectItem } from "./SelectItem";
import { SELECT_ITEM_HEIGHT } from "./SelectItem/SelectItem.styles";
import { StandardModal } from "../StandardModal";
import { useStandardModalContext } from "../StandardModalBase/StandardModalBase.hooks";

export type SelectModalBaseProps<T extends CoreSelect.SelectItem> = {
  selectedItem?: T | null | undefined;
  items: T[];
  disabledKeys?: string[];
  readyToInteract: boolean;
  onChange: (selectedItem: T | null | undefined) => void;
  onRequestClose: () => void;
};

function SelectModalBase<T extends CoreSelect.SelectItem>(
  props: SelectModalBaseProps<T>
) {
  const {
    selectedItem,
    items,
    disabledKeys,
    readyToInteract,
    onChange,
    onRequestClose,
  } = props;

  const { headingHeight } = useStandardModalContext();
  const ref = useRef<FlatList>(null);
  const flatlistViewableInfoRef = useRef<{ viewableItems: ViewToken<T>[] }>(undefined);
  const didInitialScroll = useRef(false);

  useEffect(() => {
    if (
      Platform.OS === "android" &&
      readyToInteract &&
      !didInitialScroll.current &&
      selectedItem &&
      ref.current
    ) {
      ref.current.scrollToItem({
        item: selectedItem,
      });
      didInitialScroll.current = true;
    }
  }, [selectedItem, readyToInteract]);

  return (
    <StandardModal.FlatList
      flatlistRef={ref}
      role="list"
      accessibilityRole="list"
      alwaysBounceVertical={false}
      initialScrollIndex={
        Platform.OS === "ios" && selectedItem
          ? items.indexOf(selectedItem)
          : undefined
      }
      data={items}
      keyExtractor={(item: T) => item.id}
      snapToInterval={SELECT_ITEM_HEIGHT}
      getItemLayout={(_data, index) => {
        return {
          length: SELECT_ITEM_HEIGHT,
          offset: headingHeight + SELECT_ITEM_HEIGHT * index,
          index,
        };
      }}
      onViewableItemsChanged={(info) => {
        flatlistViewableInfoRef.current = info;
      }}
      viewabilityConfig={{
        viewAreaCoveragePercentThreshold: 1,
      }}
      renderItem={({ item, index }) => {
        const isSelected = item === selectedItem;
        const isDisabled = disabledKeys
          ? disabledKeys.includes(item.id)
          : false;

        return (
          <SelectItem
            flatlistRef={ref}
            flatlistViewableInfoRef={flatlistViewableInfoRef}
            isSelected={isSelected}
            isDisabled={isDisabled}
            item={item}
            isFirst={index === 0}
            isLast={index === items.length - 1}
            onPress={() => {
              onChange(item);
              onRequestClose();
            }}
          />
        );
      }}
    />
  );
}

export default SelectModalBase;
