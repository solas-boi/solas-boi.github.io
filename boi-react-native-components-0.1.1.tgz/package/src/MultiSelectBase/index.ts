export {
  default as MultiSelectBase,
  type MultiSelectBaseProps,
} from "./MultiSelectBase";
