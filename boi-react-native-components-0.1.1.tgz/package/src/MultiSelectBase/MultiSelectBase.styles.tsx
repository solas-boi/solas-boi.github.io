import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { multiSelect } = tokens;

  return StyleSheet.create({
    button: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      minHeight: multiSelect.button.minHeight,
      paddingTop: multiSelect.button.padding.top,
      paddingLeft: multiSelect.button.padding.left,
      paddingRight: multiSelect.button.padding.right,
      paddingBottom: multiSelect.button.padding.bottom,
    },
    buttonText: {
      color: multiSelect.button.text.color.base,
      flexShrink: 1,
    },
    buttonTextDisabled: {
      color: multiSelect.button.text.color.disabled,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
