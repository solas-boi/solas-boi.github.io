import { Ref, useEffect, useRef, useState } from "react";
import {
  FlatList,
  Platform,
  View,
  type AccessibilityProps,
} from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

import {
  CoreMultiSelect,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { formatList } from "@boi/js-utils";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { ChevronDownIcon } from "@boi/react-native-icons";
import { useMergeRefs } from "@boi/react-utils";

import { OuterField } from "../OuterField";
import { Typography } from "../Typography";
import { ModalProps } from "../Modal";
import { MultiSelectModal } from "../MultiSelectModal";
import { InputLabelTopProps } from "../InputLabelTop";
import { type InputAlertsProps } from "../InputAlerts";

import useStyles from "./MultiSelectBase.styles";
import { useA11yRoleWorkaround } from "../hooks";

const isAndroid = Platform.OS === "android";
const isOlderThanAndroid16 = isAndroid && Number(Platform.Version) < 36;

export type MultiSelectBaseProps<T extends CoreMultiSelect.MultiSelectItem> =
  PropsWithOptionalTestID &
    Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
    AccessibilityProps & {
      labelProps: InputLabelTopProps;
      isOpen: boolean;
      selectedItems?: (T | null | undefined)[];
      items: T[];
      disabledKeys?: string[];
      hasError?: boolean;
      isDisabled?: boolean;
      onChange: (selectedItems: (T | null | undefined)[]) => void;
      onFocus: () => void;
      onBlur: () => void;
      pressableRef?: Ref<View>;
      alertProps?:
        | InputAlertsProps["alerts"][number]
        | InputAlertsProps["alerts"];
    };

function MultiSelectBase<T extends CoreMultiSelect.MultiSelectItem>(
  props: MultiSelectBaseProps<T>
) {
  const {
    items,
    disabledKeys,
    isDisabled,
    hasError,
    isOpen,
    selectedItems,
    labelProps,
    onChange,
    onFocus,
    onBlur,
    supportedOrientations,
    onCloseAnimationComplete,
    testID = "multi-select-base",
    pressableRef,
    role,
    accessibilityRole,
    alertProps,
    ...accessibilityProps
  } = props;

  const { tokens } = useDesignTokens();
  const { multiSelect } = tokens;

  const localPressableRef = useRef<View>(null);
  const mergedRefs = useMergeRefs([localPressableRef, pressableRef]);
  const flatlistRef = useRef<FlatList>(null);
  const styles = useStyles();

  useEffect(() => {
    if (isOpen && selectedItems && selectedItems[0]) {
      flatlistRef.current?.scrollToItem({
        item: selectedItems[0],
        animated: true,
      });
    }
  }, [isOpen, selectedItems]);

  const filteredSelectedItems = (selectedItems || []).filter(
    (item) => item !== null && item !== undefined
  );

  function getMultiSelectAriaLabel() {
    if (filteredSelectedItems.length === 0) {
      return "None";
    }

    if (items.length === filteredSelectedItems.length) {
      return "All";
    }

    return formatList(
      filteredSelectedItems.map((item) => item.ariaLabel || item.title)
    );
  }

  function getMultiSelectTitle() {
    if (filteredSelectedItems.length === 0) {
      return "None";
    }

    if (items.length === filteredSelectedItems.length) {
      return "All";
    }

    return formatList(filteredSelectedItems.map((item) => item.title));
  }

  const a11yLabelWithAlerts =
    useA11yRoleWorkaround(
      role || accessibilityRole || "combobox",
      accessibilityProps.accessibilityLabel || labelProps.label || ""
    ) + ".";

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <>
      <OuterField
        isDisabled={isDisabled}
        hasFocus={hasKeyboardFocus}
        isActive={isOpen}
        hasError={hasError}
      >
        <KeyboardPressable
          ref={mergedRefs}
          onPress={onFocus}
          onFocusChange={handleKeyboardFocusChange}
          enableA11yFocus
          tintType="none"
          pointerEvents={isDisabled ? "none" : "auto"}
          style={styles.button}
          testID={testID}
          accessibilityValue={{
            text: `${
              (!isAndroid || isOlderThanAndroid16) && !isOpen
                ? "collapsed, "
                : ""
            }${getMultiSelectAriaLabel()}`,
          }}
          accessibilityState={{
            expanded: isAndroid && !isOlderThanAndroid16 ? isOpen : undefined,
            disabled: Boolean(isDisabled),
          }}
          accessibilityHint={labelProps.labelHint}
          {...accessibilityProps}
          accessibilityLabel={a11yLabelWithAlerts}
        >
          <Typography
            variant={multiSelect.button.text.typography.variant}
            fontFamily={multiSelect.button.text.typography.fontFamily}
            style={[styles.buttonText, isDisabled && styles.buttonTextDisabled]}
            noWrap
          >
            {getMultiSelectTitle()}
          </Typography>

          <MultiSelectChevron isOpen={isOpen} isDisabled={isDisabled} />
        </KeyboardPressable>
      </OuterField>
      <MultiSelectModal
        testID={`${testID}-modal`}
        isOpen={isOpen}
        title={labelProps.label || labelProps["aria-label"] || ""}
        items={items}
        disabledKeys={disabledKeys}
        selectedItems={selectedItems}
        onChange={onChange}
        onRequestClose={onBlur}
        supportedOrientations={supportedOrientations}
        onCloseAnimationComplete={() => {
          localPressableRef.current?.focus();
          onCloseAnimationComplete?.();
        }}
      />
    </>
  );
}

function MultiSelectChevron(props: { isOpen: boolean; isDisabled?: boolean }) {
  const { tokens } = useDesignTokens();
  const { width, height, color } = tokens.select.button.icon;

  return (
    <ChevronDownIcon
      width={width}
      height={height}
      color={props.isDisabled ? color.disabled : color.base}
      style={props.isOpen && { transform: [{ rotate: "180deg" }] }}
    />
  );
}

export default MultiSelectBase;
