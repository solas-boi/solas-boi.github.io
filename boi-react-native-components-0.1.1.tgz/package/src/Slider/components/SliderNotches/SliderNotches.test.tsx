import React from "react";
import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import SliderNotches from "./SliderNotches";

function Wrapped(props: React.ComponentProps<typeof SliderNotches>) {
  return (
    <DesignTokensProvider>
      <SliderNotches {...props} />
    </DesignTokensProvider>
  );
}

const baseProps = {
  minValue: 0,
  maxValue: 100,
  testID: "slider",
};

describe("SliderNotches", () => {
  it("renders nothing when notches are not provided", () => {
    expect(
      render(<Wrapped {...baseProps} notches={undefined} />).toJSON()
    ).toBeNull();
    expect(render(<Wrapped {...baseProps} notches={[]} />).toJSON()).toBeNull();
  });

  it("renders valid notches and filters boundary values", () => {
    // 0 and 100 are at boundaries — filtered out; 25, 50, 75 survive
    render(<Wrapped {...baseProps} notches={[0, 25, 50, 75, 100]} />);

    expect(screen.getByTestId("slider-notch-0")).toBeDefined();
    expect(screen.getByTestId("slider-notch-1")).toBeDefined();
    expect(screen.getByTestId("slider-notch-2")).toBeDefined();
    expect(screen.queryByTestId("slider-notch-3")).toBeNull();
  });

  it("accepts tooltip notch objects", () => {
    render(
      <Wrapped
        {...baseProps}
        notches={[
          { startValue: 25, tooltip: "Low" },
          { startValue: 75, tooltip: "High" },
        ]}
      />
    );

    expect(screen.getByTestId("slider-notch-0")).toBeDefined();
    expect(screen.getByTestId("slider-notch-1")).toBeDefined();
  });
});
