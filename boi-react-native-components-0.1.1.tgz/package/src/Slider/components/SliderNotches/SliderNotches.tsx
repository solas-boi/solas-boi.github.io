import { memo, useMemo } from "react";
import { View } from "react-native";

import useStyles from "./SliderNotches.styles";
import { notchesToPercents } from "../../utils";
import type { SliderNotches as SliderNotchesType } from "../../Slider.types";

type SliderNotchesProps = {
  notches: SliderNotchesType | undefined;
  minValue: number;
  maxValue: number;
  testID: string;
};

const SliderNotches = memo(
  ({ notches, minValue, maxValue, testID }: SliderNotchesProps) => {
    const styles = useStyles();

    const percents = useMemo(
      () =>
        notches?.length ? notchesToPercents(notches, minValue, maxValue) : null,
      [notches, minValue, maxValue]
    );

    if (!percents) {
      return null;
    }

    return (
      <View style={styles.container}>
        {percents.map((pct, index) => (
          <View
            key={index}
            testID={`${testID}-notch-${index}`}
            style={[styles.notch, { width: `${pct}%` }]}
          />
        ))}
      </View>
    );
  }
);

SliderNotches.displayName = "SliderNotches";

export default SliderNotches;
