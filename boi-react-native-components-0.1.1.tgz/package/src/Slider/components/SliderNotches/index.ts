export { default as SliderNotches } from "./SliderNotches";
