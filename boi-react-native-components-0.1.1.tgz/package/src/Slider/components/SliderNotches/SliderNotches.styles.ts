import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../../../themedStylesheet";

export default createThemedStyleSheet(({ slider }) =>
  StyleSheet.create({
    container: {
      position: "absolute",
      flexDirection: "row",
      left: slider.track.padding,
      right: slider.track.padding,
      top: (slider.thumb.size - slider.track.size) / 2,
      height: slider.track.size,
    },
    notch: {
      height: slider.track.size,
      borderRightWidth: slider.notch.size,
      borderRightColor: slider.notch.color,
    },
  })
);
