import { render } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import SliderTooltipArrow from "./SliderTooltipArrow";

describe("SliderTooltipArrow", () => {
  it("renders without crashing", () => {
    const { toJSON } = render(
      <DesignTokensProvider>
        <SliderTooltipArrow />
      </DesignTokensProvider>
    );
    expect(toJSON()).not.toBeNull();
  });
});
