import { memo } from "react";
import { View } from "react-native";
import Animated, { type AnimatedStyle } from "react-native-reanimated";
import type { ViewStyle } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { Typography } from "../../../Typography";
import useStyles from "./SliderTooltip.styles";

export type SliderTooltipProps = {
  text: string;
  maxWidth: number;
  containerStyle: AnimatedStyle<ViewStyle>;
  leftSpacerStyle: AnimatedStyle<ViewStyle>;
  rightSpacerStyle: AnimatedStyle<ViewStyle>;
  testID: string;
};

const SliderTooltip = memo(
  ({
    text,
    maxWidth,
    containerStyle,
    leftSpacerStyle,
    rightSpacerStyle,
    testID,
  }: SliderTooltipProps) => {
    const styles = useStyles();
    const { tokens } = useDesignTokens();

    return (
      <Animated.View
        testID={`${testID}-tooltip`}
        pointerEvents="none"
        style={[styles.wrapper, containerStyle]}
      >
        <Animated.View style={leftSpacerStyle} />
        <View style={[styles.bubble, maxWidth > 0 ? { maxWidth } : undefined]}>
          <Typography
            variant={tokens.tooltip.typography.variant}
            fontFamily={tokens.tooltip.typography.fontFamily}
            color={tokens.tooltip.color}
            testID={`${testID}-tooltip-text`}
          >
            {text}
          </Typography>
        </View>
        <Animated.View style={rightSpacerStyle} />
      </Animated.View>
    );
  }
);

SliderTooltip.displayName = "SliderTooltip";

export default SliderTooltip;
