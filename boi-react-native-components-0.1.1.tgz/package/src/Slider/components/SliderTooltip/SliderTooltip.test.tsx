import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import SliderTooltip from "./SliderTooltip";
import type { SliderTooltipProps } from "./SliderTooltip";

function Wrapped(props: SliderTooltipProps) {
  return (
    <DesignTokensProvider>
      <SliderTooltip {...props} />
    </DesignTokensProvider>
  );
}

const baseProps: SliderTooltipProps = {
  text: "Low rate",
  maxWidth: 200,
  containerStyle: {},
  leftSpacerStyle: {},
  rightSpacerStyle: {},
  testID: "slider",
};

describe("SliderTooltip", () => {
  it("renders the text content", () => {
    render(<Wrapped {...baseProps} text="High rate" />);
    expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
      "children",
      "High rate"
    );
  });
});
