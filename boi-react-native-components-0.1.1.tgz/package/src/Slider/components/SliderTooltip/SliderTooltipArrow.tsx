import { memo } from "react";
import { View } from "react-native";
import useStyles from "./SliderTooltip.styles";

const SliderTooltipArrow = memo(() => {
  const styles = useStyles();
  return <View style={styles.arrow} />;
});

SliderTooltipArrow.displayName = "SliderTooltipArrow";

export default SliderTooltipArrow;
