import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../../../themedStylesheet";

export default createThemedStyleSheet(({ slider, tooltip }) =>
  StyleSheet.create({
    wrapper: {
      flexDirection: "row",
      alignSelf: "stretch",
    },
    bubble: {
      backgroundColor: tooltip.backgroundColor,
      borderRadius: tooltip.radius,
      paddingTop: tooltip.padding.top,
      paddingBottom: tooltip.padding.bottom,
      paddingLeft: tooltip.padding.left,
      paddingRight: tooltip.padding.right.default,
    },
    arrow: {
      position: "absolute",
      left: (slider.thumb.size - slider.tooltip.arrowWidth * 2) / 2,
      top: slider.thumb.size,
      width: 0,
      height: 0,
      borderLeftWidth: slider.tooltip.arrowWidth,
      borderRightWidth: slider.tooltip.arrowWidth,
      borderBottomWidth: slider.tooltip.arrowWidth,
      borderLeftColor: "transparent",
      borderRightColor: "transparent",
      borderBottomColor: tooltip.backgroundColor,
    },
  })
);
