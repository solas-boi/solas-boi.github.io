import { memo } from "react";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { SliderHandleIcon } from "@boi/react-native-icons";

type SliderThumbProps = {
  isActive?: boolean;
};

const SliderThumb = memo(({ isActive = false }: SliderThumbProps) => {
  const {
    tokens: { slider },
  } = useDesignTokens();
  const primaryColor = isActive
    ? slider.thumb.primaryColor.active
    : slider.thumb.primaryColor.base;

  return (
    <SliderHandleIcon
      width={slider.thumb.size}
      height={slider.thumb.size}
      primaryColor={primaryColor}
      secondaryColor={slider.thumb.secondaryColor.base}
    />
  );
});

SliderThumb.displayName = "SliderThumb";

export default SliderThumb;
