import { Platform } from "react-native";

export const DRAG_THROTTLE_MS = 42;

export const THUMB_LOCK_FOCUS_DIRECTIONS: ("left" | "right")[] | undefined =
  Platform.OS === "android" ? ["left", "right"] : undefined;

export const ACCESSIBILITY_ACTIONS = [
  { name: "increment" },
  { name: "decrement" },
] as const;
