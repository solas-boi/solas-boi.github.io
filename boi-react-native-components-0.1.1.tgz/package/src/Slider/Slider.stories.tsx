import { useState } from "react";
import { View } from "react-native";

import type { Meta, StoryObj } from "@storybook/react";
import { CoreSlider } from "@boi/components-core";

import Slider, { type SliderProps, type SliderTooltipNotch } from "./Slider";
import { Button } from "../Button";
import { Typography } from "../Typography";

const meta = {
  title: "Inputs/Slider",
  component: Slider,
  argTypes: {
    value: {
      control: { type: "number", min: 0, max: 100 },
    },
    minValue: {
      control: { type: "number" },
    },
    maxValue: {
      control: { type: "number" },
    },
    step: {
      control: { type: "number", min: 1 },
    },
    disabled: { control: { type: "boolean" } },
  },
  args: {
    value: 50,
    minValue: CoreSlider.DEFAULT_MIN_VALUE,
    maxValue: CoreSlider.DEFAULT_MAX_VALUE,
    step: CoreSlider.DEFAULT_STEP,
    disabled: false,
    "aria-label": "Slider",
  },
  render: function Render(args) {
    const [value, setValue] = useState(args.value);

    function handleChange(newValue: number) {
      setValue(newValue);
    }

    return (
      <View style={{ gap: 10 }}>
        <Typography>Value: {value}</Typography>
        <Slider {...args} value={value} onChange={handleChange} />
        <Button text="Set to 75" onPress={() => setValue(75)} />
      </View>
    );
  },
} satisfies Meta<SliderProps>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const WithMinAndMax: Story = {
  args: {
    value: 2,
    minValue: 1,
    maxValue: 5,
    "aria-label": "Label for min / max Slider",
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    "aria-label": "Disabled slider",
  },
};

export const WithNotches: Story = {
  args: {
    step: 1000,
    value: 10000,
    minValue: 2000,
    maxValue: 64000,
    notches: [15000, 25000, 58000],
    "aria-label": "Label for 'notched' Slider",
  },
};

const MORTGAGE_NOTCHES: SliderTooltipNotch[] = [
  {
    startValue: 2000,
    tooltip: "APR of 6.5%  (subject to terms and conditions)",
  },
  {
    startValue: 15000,
    tooltip: "APR of 6%",
  },
  {
    startValue: 25000,
    tooltip: "APR of 5%",
  },
  {
    startValue: 58000,
    tooltip: "APR of 3%  (subject to terms and conditions)",
  },
];

export const WithTooltipNotches: Story = {
  args: {
    step: 1000,
    value: 10000,
    minValue: 2000,
    maxValue: 64000,
    notches: MORTGAGE_NOTCHES,
    "aria-label": "Mortgage rate slider",
  },
};

export const WithVariableSteps: Story = {
  args: {
    step: 500,
    value: 1,
    minValue: 1,
    maxValue: 64999,
    "aria-label": "Label for 'variable stepped' Slider",
  },
};
