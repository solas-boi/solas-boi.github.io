import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../themedStylesheet";

export default createThemedStyleSheet(({ slider }) =>
  StyleSheet.create({
    container: {
      alignSelf: "stretch",
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      alignSelf: "stretch",
      overflow: "visible",
      minHeight: slider.thumb.size,
    },
    trackWrapper: {
      flex: 1,
    },
    trackContainer: {
      flex: 1,
      height: slider.thumb.size,
      justifyContent: "center",
    },
    track: {
      height: slider.track.size,
      marginHorizontal: slider.track.padding,
      backgroundColor: slider.track.color,
      borderRadius: slider.track.size,
    },
    thumb: {
      position: "absolute",
      top: 0,
      left: 0,
      width: slider.thumb.size,
      height: slider.thumb.size,
    },
    thumbFocusStyle: {
      borderWidth: slider.thumb.focusRing.width,
      borderColor: slider.thumb.focusRing.color,
      borderRadius: slider.thumb.size / 2,
      alignItems: "center",
      justifyContent: "center",
    },
  })
);
