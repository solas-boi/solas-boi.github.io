import { forwardRef, useMemo } from "react";
import { useLatestRef } from "../hooks";
import { Platform, View } from "react-native";
import { GestureDetector } from "react-native-gesture-handler";
import Animated from "react-native-reanimated";
import {
  BaseKeyboardView,
  KeyboardFocusView,
} from "react-native-external-keyboard";

import { A11yContainerView } from "react-native-a11y-container";

import { CoreSlider } from "@boi/components-core";
import { MinusIcon, PlusIcon } from "@boi/react-native-icons";

import { IconButton } from "../IconButton";
import useStyles from "./Slider.styles";
import { useSlider } from "./motions";
import {
  SliderThumb,
  SliderNotches,
  SliderTooltip,
  SliderTooltipArrow,
} from "./components";
import {
  useSliderTooltip,
  useSliderHandlers,
  useAccessibilitySliderInfo,
} from "./Slider.hooks";
import {
  THUMB_LOCK_FOCUS_DIRECTIONS,
  ACCESSIBILITY_ACTIONS,
} from "./Slider.constants";
import type { SliderProps } from "./Slider.types";
import { A11yLiveRegion } from "../A11yLiveRegion";

const IS_ANDROID = Platform.OS === "android";

export type {
  SliderTooltipNotch,
  SliderNotches,
  SliderProps,
} from "./Slider.types";

const Slider = forwardRef<View, SliderProps>((props, ref) => {
  const {
    value,
    onChange,
    minValue = CoreSlider.DEFAULT_MIN_VALUE,
    maxValue = CoreSlider.DEFAULT_MAX_VALUE,
    step = CoreSlider.DEFAULT_STEP,
    disabled = false,
    notches,
    testID = "slider",
    "aria-label": ariaLabel,
    decrementButtonProps,
    incrementButtonProps,
  } = props;

  const styles = useStyles();
  const valueRef = useLatestRef(value);

  const { safeNotches, tooltipText } = useSliderTooltip(
    notches,
    value,
    minValue,
    maxValue
  );

  const announcementText = tooltipText
    ? `${value}, ${tooltipText}`
    : value.toString();

  const {
    gesture,
    thumbStyle,
    tooltipContainerStyle,
    tooltipLeftSpacerStyle,
    tooltipRightSpacerStyle,
    onTrackLayout,
    onContainerLayout,
    tooltipMaxWidth,
    isActive,
  } = useSlider({
    value,
    valueRef,
    onChange,
    minValue,
    maxValue,
    step,
    disabled,
  });

  const { decrement, increment } = useSliderHandlers(props, valueRef);

  const { onAccessibilityAction, onKeyPressHandler } =
    useAccessibilitySliderInfo({ decrement, increment });

  const accessibilityValue = useMemo(
    () => ({ min: minValue, max: maxValue, text: announcementText }),
    [minValue, maxValue, announcementText]
  );

  return (
    <A11yContainerView
      collapsable={false}
      testID={testID}
      ref={ref}
      accessible={false}
      style={styles.container}
      accessibilityLabel={ariaLabel}
      accessibilityValue={IS_ANDROID ? accessibilityValue : undefined}
    >
      <A11yLiveRegion testID={testID} announcement={announcementText} />
      <View style={styles.row} onLayout={onContainerLayout}>
        <IconButton
          testID={`${testID}-decrement-button`}
          {...decrementButtonProps}
          aria-label={"Decrease value"}
          accessibilityValue={accessibilityValue}
          variant="contained"
          onPress={decrement}
          disabled={disabled}
        >
          <MinusIcon />
        </IconButton>

        <BaseKeyboardView
          accessible
          accessibilityRole="adjustable"
          accessibilityLabel={ariaLabel}
          accessibilityHint=""
          accessibilityValue={accessibilityValue}
          accessibilityActions={ACCESSIBILITY_ACTIONS}
          style={styles.trackWrapper}
          onAccessibilityAction={onAccessibilityAction}
          focusable={false}
        >
          <GestureDetector gesture={gesture}>
            <Animated.View
              testID={`${testID}-track-container`}
              style={styles.trackContainer}
              onLayout={onTrackLayout}
            >
              <View style={styles.track} />
              <SliderNotches
                notches={safeNotches}
                minValue={minValue}
                maxValue={maxValue}
                testID={testID}
              />
              <Animated.View style={[styles.thumb, thumbStyle]}>
                {tooltipText && <SliderTooltipArrow />}
                <KeyboardFocusView
                  accessible
                  accessibilityRole="adjustable"
                  accessibilityLabel={ariaLabel}
                  importantForAccessibility="no"
                  accessibilityHint=""
                  haloEffect={false}
                  tintType="none"
                  lockFocus={THUMB_LOCK_FOCUS_DIRECTIONS}
                  focusStyle={styles.thumbFocusStyle}
                  onKeyDownPress={onKeyPressHandler}
                  accessibilityValue={accessibilityValue}
                  accessibilityActions={ACCESSIBILITY_ACTIONS}
                  onAccessibilityAction={onAccessibilityAction}
                >
                  <SliderThumb isActive={isActive} />
                </KeyboardFocusView>
              </Animated.View>
            </Animated.View>
          </GestureDetector>
        </BaseKeyboardView>

        <IconButton
          testID={`${testID}-increment-button`}
          {...incrementButtonProps}
          aria-label="Increase value"
          accessibilityValue={accessibilityValue}
          variant="contained"
          onPress={increment}
          disabled={disabled}
        >
          <PlusIcon />
        </IconButton>
      </View>

      {tooltipText && (
        <SliderTooltip
          testID={testID}
          text={tooltipText}
          maxWidth={tooltipMaxWidth}
          containerStyle={tooltipContainerStyle}
          leftSpacerStyle={tooltipLeftSpacerStyle}
          rightSpacerStyle={tooltipRightSpacerStyle}
        />
      )}
    </A11yContainerView>
  );
});

Slider.displayName = "Slider";

export default Slider;
