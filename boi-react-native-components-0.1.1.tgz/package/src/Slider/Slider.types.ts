import type { PropsWithOptionalTestID } from "@boi/components-core";
import type { IconButtonProps } from "../IconButton";

export type SliderTooltipNotch = {
  startValue: number;
  tooltip: string;
};

export type SliderNotches = number[] | SliderTooltipNotch[];

export type SliderProps = PropsWithOptionalTestID & {
  value: number;
  onChange: (value: number) => void;
  minValue?: number;
  maxValue?: number;
  step?: number;
  disabled?: boolean;
  notches?: SliderNotches;
  "aria-label": string;
  decrementButtonProps?: Omit<
    IconButtonProps,
    "variant" | "onPress" | "aria-label" | "children"
  >;
  incrementButtonProps?: Omit<
    IconButtonProps,
    "variant" | "onPress" | "aria-label" | "children"
  >;
};

export type UseAccessibilitySliderInfo = {
  increment: () => void;
  decrement: () => void;
};
