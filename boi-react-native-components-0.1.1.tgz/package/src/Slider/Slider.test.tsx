import {
  fireEvent,
  render,
  screen,
  userEvent,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Slider, { type SliderProps, type SliderTooltipNotch } from "./Slider";

function WrappedSlider(props: SliderProps) {
  return (
    <DesignTokensProvider>
      <Slider {...props} />
    </DesignTokensProvider>
  );
}

describe("Slider", () => {
  let baseProps: SliderProps;

  beforeEach(() => {
    baseProps = {
      value: 50,
      onChange: jest.fn(),
      "aria-label": "Volume",
    };
  });

  it("should render with adjustable role", () => {
    render(<WrappedSlider {...baseProps} />);

    expect(screen.getAllByRole("adjustable").length).toBeGreaterThan(0);
  });

  it("should render with correct accessibility value", () => {
    render(<WrappedSlider {...baseProps} />);

    expect(screen.getAllByRole("adjustable")[0]).toHaveProp(
      "accessibilityValue",
      {
        min: 0,
        max: 100,
        text: "50",
      }
    );
  });

  it("should render with default testID", () => {
    render(<WrappedSlider {...baseProps} />);

    expect(screen.getByTestId("slider")).toBeDefined();
  });

  it("should render with custom testID", () => {
    render(<WrappedSlider {...baseProps} testID="volume-slider" />);

    expect(screen.getByTestId("volume-slider")).toBeDefined();
  });

  it("should render decrement and increment buttons", () => {
    render(<WrappedSlider {...baseProps} />);

    expect(screen.getByTestId("slider-decrement-button")).toBeDefined();
    expect(screen.getByTestId("slider-increment-button")).toBeDefined();
  });

  it("should call onChange with decremented value when decrement button is pressed", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={50} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(49);
  });

  it("should call onChange with incremented value when increment button is pressed", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={50} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).toHaveBeenCalledWith(51);
  });

  it("should not call onChange when decrement pressed at minimum value", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={0} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it("should not call onChange when increment pressed at maximum value", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider {...baseProps} value={100} onChange={mockOnChange} />
    );

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it("should respect custom step for decrement", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={50}
        step={5}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(45);
  });

  it("should respect custom step for increment", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={50}
        step={5}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).toHaveBeenCalledWith(55);
  });

  it("should clamp decrement to minValue", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={2}
        step={5}
        minValue={0}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(0);
  });

  it("should clamp increment to maxValue", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={98}
        step={5}
        maxValue={100}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).toHaveBeenCalledWith(100);
  });

  it("should not call onChange when disabled", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} disabled onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));
    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  describe("notches", () => {
    function fireLayout(width = 300) {
      fireEvent(screen.getByTestId("slider-track-container"), "layout", {
        nativeEvent: { layout: { width, height: 48 } },
      });
    }

    it("should not render notches when notches prop is not provided", () => {
      render(<WrappedSlider {...baseProps} />);
      fireLayout();

      expect(screen.queryByTestId("slider-notch-0")).toBeNull();
    });

    it("should render notches after layout", () => {
      render(<WrappedSlider {...baseProps} notches={[25, 50, 75]} />);
      fireLayout();

      expect(screen.getByTestId("slider-notch-0")).toBeDefined();
      expect(screen.getByTestId("slider-notch-1")).toBeDefined();
      expect(screen.getByTestId("slider-notch-2")).toBeDefined();
    });

    it("should filter out notches at minValue boundary", () => {
      render(
        <WrappedSlider
          {...baseProps}
          notches={[0, 25, 50]}
          minValue={0}
          maxValue={100}
        />
      );
      fireLayout();

      // 0 is at minValue — filtered out, so indices start at 0 for 25
      expect(screen.getByTestId("slider-notch-0")).toBeDefined();
      expect(screen.getByTestId("slider-notch-1")).toBeDefined();
      expect(screen.queryByTestId("slider-notch-2")).toBeNull();
    });

    it("should filter out notches at maxValue boundary", () => {
      render(
        <WrappedSlider
          {...baseProps}
          notches={[25, 50, 100]}
          minValue={0}
          maxValue={100}
        />
      );
      fireLayout();

      expect(screen.getByTestId("slider-notch-0")).toBeDefined();
      expect(screen.getByTestId("slider-notch-1")).toBeDefined();
      expect(screen.queryByTestId("slider-notch-2")).toBeNull();
    });

    it("should use custom testID prefix for notches", () => {
      render(
        <WrappedSlider {...baseProps} notches={[50]} testID="volume-slider" />
      );
      fireEvent(screen.getByTestId("volume-slider-track-container"), "layout", {
        nativeEvent: { layout: { width: 300, height: 48 } },
      });

      expect(screen.getByTestId("volume-slider-notch-0")).toBeDefined();
    });
  });

  describe("tooltip notches", () => {
    const tooltipNotches: SliderTooltipNotch[] = [
      { startValue: 0, tooltip: "Low rate" },
      { startValue: 50, tooltip: "Mid rate" },
      { startValue: 75, tooltip: "High rate" },
    ];

    it("should not render tooltip when using plain number notches", () => {
      render(<WrappedSlider {...baseProps} notches={[25, 50, 75]} />);

      expect(screen.queryByTestId("slider-tooltip")).toBeNull();
    });

    it("should not render tooltip when value is below first notch startValue", () => {
      const notches: SliderTooltipNotch[] = [
        { startValue: 20, tooltip: "Some rate" },
      ];
      render(<WrappedSlider {...baseProps} value={10} notches={notches} />);

      expect(screen.queryByTestId("slider-tooltip")).toBeNull();
    });

    it("should render tooltip with correct text for the current range", () => {
      render(
        <WrappedSlider {...baseProps} value={60} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip")).toBeDefined();
      expect(screen.getByTestId("slider-tooltip-text")).toBeDefined();
    });

    it("should show the first range tooltip when value equals first startValue", () => {
      render(
        <WrappedSlider {...baseProps} value={0} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "Low rate"
      );
    });

    it("should show mid range tooltip when value is between 50 and 75", () => {
      render(
        <WrappedSlider {...baseProps} value={60} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "Mid rate"
      );
    });

    it("should show last tooltip when value equals last startValue", () => {
      render(
        <WrappedSlider {...baseProps} value={75} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "High rate"
      );
    });

    it("should show last tooltip when value exceeds last startValue", () => {
      render(
        <WrappedSlider {...baseProps} value={90} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "High rate"
      );
    });

    it("should use custom testID prefix for tooltip", () => {
      render(
        <WrappedSlider
          {...baseProps}
          value={50}
          notches={tooltipNotches}
          testID="rate-slider"
        />
      );

      expect(screen.getByTestId("rate-slider-tooltip")).toBeDefined();
      expect(screen.getByTestId("rate-slider-tooltip-text")).toBeDefined();
    });
  });
});
