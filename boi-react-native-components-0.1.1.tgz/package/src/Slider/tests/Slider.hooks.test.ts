import { renderHook, act } from "@testing-library/react-native";

import {
  useSliderTooltip,
  useSliderHandlers,
  useAccessibilitySliderInfo,
} from "../Slider.hooks";
import type { SliderProps } from "../Slider.types";

jest.useFakeTimers();

describe("useSliderTooltip", () => {
  it("returns undefined for both when no notches provided", () => {
    const { result } = renderHook(() =>
      useSliderTooltip(undefined, 50, 0, 100)
    );

    expect(result.current.safeNotches).toBeUndefined();
    expect(result.current.tooltipText).toBeUndefined();
  });

  it("returns safeNotches and undefined tooltipText for number notches", () => {
    const { result } = renderHook(() =>
      useSliderTooltip([25, 50, 75], 50, 0, 100)
    );

    expect(result.current.safeNotches).toEqual([25, 50, 75]);
    expect(result.current.tooltipText).toBeUndefined();
  });

  it("returns resolved tooltipText for tooltip notches", () => {
    const notches = [
      { startValue: 0, tooltip: "Low" },
      { startValue: 50, tooltip: "High" },
    ];
    const { result } = renderHook(() => useSliderTooltip(notches, 60, 0, 100));

    expect(result.current.tooltipText).toBe("High");
  });

  it("returns empty string when value is below first tooltip startValue", () => {
    const { result } = renderHook(() =>
      useSliderTooltip([{ startValue: 30, tooltip: "Some" }], 10, 0, 100)
    );

    expect(result.current.tooltipText).toBe("");
  });
});

describe("useSliderHandlers", () => {
  function makeProps(overrides: Partial<SliderProps> = {}): SliderProps {
    return {
      value: 50,
      onChange: jest.fn(),
      "aria-label": "test",
      ...overrides,
    };
  }

  describe("decrement", () => {
    it("calls onChange with value minus step", () => {
      const onChange = jest.fn();
      const valueRef = { current: 50 };
      const { result } = renderHook(() =>
        useSliderHandlers(makeProps({ value: 50, onChange }), valueRef)
      );

      act(() => result.current.decrement());

      expect(onChange).toHaveBeenCalledWith(49);
    });

    it("does not call onChange when value is at minValue", () => {
      const onChange = jest.fn();
      const valueRef = { current: 0 };
      const { result } = renderHook(() =>
        useSliderHandlers(makeProps({ value: 0, onChange }), valueRef)
      );

      act(() => result.current.decrement());

      expect(onChange).not.toHaveBeenCalled();
    });

    it("clamps to minValue when step would overshoot", () => {
      const onChange = jest.fn();
      const valueRef = { current: 2 };
      const { result } = renderHook(() =>
        useSliderHandlers(
          makeProps({ value: 2, step: 5, minValue: 0, onChange }),
          valueRef
        )
      );

      act(() => result.current.decrement());

      expect(onChange).toHaveBeenCalledWith(0);
    });
  });

  describe("increment", () => {
    it("calls onChange with value plus step", () => {
      const onChange = jest.fn();
      const valueRef = { current: 50 };
      const { result } = renderHook(() =>
        useSliderHandlers(makeProps({ value: 50, onChange }), valueRef)
      );

      act(() => result.current.increment());

      expect(onChange).toHaveBeenCalledWith(51);
    });

    it("does not call onChange when value is at maxValue", () => {
      const onChange = jest.fn();
      const valueRef = { current: 100 };
      const { result } = renderHook(() =>
        useSliderHandlers(makeProps({ value: 100, onChange }), valueRef)
      );

      act(() => result.current.increment());

      expect(onChange).not.toHaveBeenCalled();
    });

    it("clamps to maxValue when step would overshoot", () => {
      const onChange = jest.fn();
      const valueRef = { current: 98 };
      const { result } = renderHook(() =>
        useSliderHandlers(
          makeProps({ value: 98, step: 5, maxValue: 100, onChange }),
          valueRef
        )
      );

      act(() => result.current.increment());

      expect(onChange).toHaveBeenCalledWith(100);
    });
  });
});

describe("useAccessibilitySliderInfo", () => {
  function makeHandlers() {
    return { increment: jest.fn(), decrement: jest.fn() };
  }

  it("returns accessibility handlers", () => {
    const { result } = renderHook(() =>
      useAccessibilitySliderInfo(makeHandlers())
    );

    expect(result.current.onAccessibilityAction).toEqual(expect.any(Function));
  });

  it("calls increment handler on increment action", () => {
    const handlers = makeHandlers();
    const { result } = renderHook(() => useAccessibilitySliderInfo(handlers));

    act(() => {
      result.current.onAccessibilityAction({
        nativeEvent: { actionName: "increment" },
      });
    });

    expect(handlers.increment).toHaveBeenCalledTimes(1);
    expect(handlers.decrement).not.toHaveBeenCalled();
  });

  it("calls decrement handler on decrement action", () => {
    const handlers = makeHandlers();
    const { result } = renderHook(() => useAccessibilitySliderInfo(handlers));

    act(() => {
      result.current.onAccessibilityAction({
        nativeEvent: { actionName: "decrement" },
      });
    });

    expect(handlers.decrement).toHaveBeenCalledTimes(1);
    expect(handlers.increment).not.toHaveBeenCalled();
  });

  it("does not call any handler on unknown action", () => {
    const handlers = makeHandlers();
    const { result } = renderHook(() => useAccessibilitySliderInfo(handlers));

    act(() => {
      result.current.onAccessibilityAction({
        nativeEvent: { actionName: "unknown" },
      });
    });

    expect(handlers.increment).not.toHaveBeenCalled();
    expect(handlers.decrement).not.toHaveBeenCalled();
  });
});
