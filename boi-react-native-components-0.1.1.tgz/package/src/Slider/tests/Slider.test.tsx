import { render, screen, userEvent } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Slider, { type SliderProps, type SliderTooltipNotch } from "../Slider";

jest.useFakeTimers();

function WrappedSlider(props: SliderProps) {
  return (
    <DesignTokensProvider>
      <Slider {...props} />
    </DesignTokensProvider>
  );
}

describe("Slider", () => {
  let baseProps: SliderProps;

  beforeEach(() => {
    baseProps = {
      value: 50,
      onChange: jest.fn(),
      "aria-label": "Volume",
    };
  });

  it("should render with adjustable role and correct accessibility value", () => {
    render(<WrappedSlider {...baseProps} />);

    expect(screen.getAllByRole("adjustable")[0]).toHaveProp(
      "accessibilityValue",
      {
        min: 0,
        max: 100,
        text: "50",
      }
    );
  });

  it("should spread decrementButtonProps and incrementButtonProps", () => {
    render(
      <WrappedSlider
        {...baseProps}
        decrementButtonProps={{ testID: "custom-decrement" }}
        incrementButtonProps={{ testID: "custom-increment" }}
      />
    );

    expect(screen.getByTestId("custom-decrement")).toBeDefined();
    expect(screen.getByTestId("custom-increment")).toBeDefined();
  });

  it("should call onChange with decremented value when decrement button is pressed", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={50} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(49);
  });

  it("should call onChange with incremented value when increment button is pressed", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={50} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).toHaveBeenCalledWith(51);
  });

  it("should not call onChange when decrement pressed at minimum value", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} value={0} onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it("should not call onChange when increment pressed at maximum value", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider {...baseProps} value={100} onChange={mockOnChange} />
    );

    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it("should respect custom step", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={50}
        step={5}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(45);
  });

  it("should clamp to minValue when step overshoots", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(
      <WrappedSlider
        {...baseProps}
        value={2}
        step={5}
        minValue={0}
        onChange={mockOnChange}
      />
    );

    await user.press(screen.getByTestId("slider-decrement-button"));

    expect(mockOnChange).toHaveBeenCalledWith(0);
  });

  it("should not call onChange when disabled", async () => {
    const mockOnChange = jest.fn();
    const user = userEvent.setup();

    render(<WrappedSlider {...baseProps} disabled onChange={mockOnChange} />);

    await user.press(screen.getByTestId("slider-decrement-button"));
    await user.press(screen.getByTestId("slider-increment-button"));

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  describe("notches", () => {
    it("should not render notches when notches prop is not provided", () => {
      render(<WrappedSlider {...baseProps} />);

      expect(screen.queryByTestId("slider-notch-0")).toBeNull();
    });

    it("should render notches when provided", () => {
      render(<WrappedSlider {...baseProps} notches={[25, 50, 75]} />);

      expect(screen.getByTestId("slider-notch-0")).toBeDefined();
      expect(screen.getByTestId("slider-notch-1")).toBeDefined();
      expect(screen.getByTestId("slider-notch-2")).toBeDefined();
    });

    it("should filter out notches at min and max boundaries", () => {
      render(
        <WrappedSlider
          {...baseProps}
          notches={[0, 25, 100]}
          minValue={0}
          maxValue={100}
        />
      );

      expect(screen.getByTestId("slider-notch-0")).toBeDefined();
      expect(screen.queryByTestId("slider-notch-1")).toBeNull();
    });
  });

  describe("tooltip notches", () => {
    const tooltipNotches: SliderTooltipNotch[] = [
      { startValue: 0, tooltip: "Low rate" },
      { startValue: 50, tooltip: "Mid rate" },
      { startValue: 75, tooltip: "High rate" },
    ];

    it("should not render tooltip when using plain number notches", () => {
      render(<WrappedSlider {...baseProps} notches={[25, 50, 75]} />);

      expect(screen.queryByTestId("slider-tooltip")).toBeNull();
    });

    it("should not render tooltip when value is below first notch startValue", () => {
      render(
        <WrappedSlider
          {...baseProps}
          value={10}
          notches={[{ startValue: 20, tooltip: "Some rate" }]}
        />
      );

      expect(screen.queryByTestId("slider-tooltip")).toBeNull();
    });

    it("should show the correct tooltip text for the current range", () => {
      render(
        <WrappedSlider {...baseProps} value={0} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "Low rate"
      );
    });

    it("should show the last tooltip when value exceeds the last startValue", () => {
      render(
        <WrappedSlider {...baseProps} value={90} notches={tooltipNotches} />
      );

      expect(screen.getByTestId("slider-tooltip-text")).toHaveProp(
        "children",
        "High rate"
      );
    });
  });
});
