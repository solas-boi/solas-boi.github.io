import { useAnimatedStyle, useDerivedValue } from "react-native-reanimated";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import type { SliderSharedState } from "./Slider.state";

export function useSliderAnimatedStyles(state: SliderSharedState) {
  const { tokens } = useDesignTokens();

  const { thumbX, containerWidth, containerHeight, trackWidth } = state;

  const thumbSize = tokens.slider.thumb.size;
  const tooltipArrowWidth = tokens.slider.tooltip.arrowWidth;

  const thumbStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: thumbX.value }],
  }));

  const tooltipContainerStyle = useAnimatedStyle(() => {
    const marginTop = (thumbSize - containerHeight.value) / 2 + tooltipArrowWidth;
    return { marginTop };
  });

  const thumbRatio = useDerivedValue(() => {
    if (containerWidth.value <= 0) {
      return 0;
    }
    const trackInset = (containerWidth.value - trackWidth.value) / 2;
    const thumbCenterX = thumbX.value + trackInset + thumbSize / 2;
    return Math.min(1, Math.max(0, thumbCenterX / containerWidth.value));
  });

  const tooltipLeftSpacerStyle = useAnimatedStyle(() => ({
    flexGrow: thumbRatio.value,
  }));

  const tooltipRightSpacerStyle = useAnimatedStyle(() => ({
    flexGrow: 1 - thumbRatio.value,
  }));

  return {
    thumbStyle,
    tooltipContainerStyle,
    tooltipLeftSpacerStyle,
    tooltipRightSpacerStyle,
  };
}
