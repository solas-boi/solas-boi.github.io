import { snapToStep } from "../utils/sliderStep";

export function xToValue(
  x: number,
  trackRange: number,
  minVal: number,
  maxVal: number,
  stepVal: number
): number {
  "worklet";
  const clamped = Math.min(Math.max(0, x), trackRange);
  const raw = minVal + (clamped / trackRange) * (maxVal - minVal);
  return snapToStep(raw, minVal, maxVal, stepVal);
}

export function valueToX(
  val: number,
  trackRange: number,
  minVal: number,
  maxVal: number
): number {
  "worklet";
  const valueSpan = maxVal - minVal;
  if (valueSpan === 0) {
    return 0;
  }
  const clamped = Math.min(Math.max(minVal, val), maxVal);
  return ((clamped - minVal) / valueSpan) * trackRange;
}
