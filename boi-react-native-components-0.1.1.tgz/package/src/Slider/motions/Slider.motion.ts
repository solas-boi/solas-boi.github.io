import { useCallback, useEffect, useState } from "react";
import type { LayoutChangeEvent } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { type SliderSharedState, useSliderState } from "./Slider.state";
import { useSliderGesture } from "./Slider.gesture";
import { useSliderAnimatedStyles } from "./Slider.animation";
import { valueToX } from "./Slider.math";

export type UseSliderOptions = {
  value: number;
  valueRef: React.MutableRefObject<number>;
  onChange: (value: number) => void;
  minValue: number;
  maxValue: number;
  step: number;
  disabled: boolean;
};

function useSliderControlledSync(
  state: SliderSharedState,
  options: UseSliderOptions,
  thumbSize: number,
  isActive: boolean
) {
  const { value, onChange, minValue, maxValue } = options;
  const { thumbX, trackWidth } = state;

  useEffect(() => {
    if (value < minValue) {
      onChange(minValue);
    } else if (value > maxValue) {
      onChange(maxValue);
    }
  }, [minValue, maxValue, value, onChange]);

  useEffect(() => {
    if (isActive) {
      return;
    }
    const trackRange = trackWidth.value - thumbSize;
    if (trackRange <= 0) {
      return;
    }
    thumbX.value = valueToX(value, trackRange, minValue, maxValue);
  }, [value, minValue, maxValue, isActive, trackWidth, thumbX, thumbSize]);
}

export function useSlider(options: UseSliderOptions) {
  const { valueRef, minValue, maxValue } = options;
  const { tokens } = useDesignTokens();
  const thumbSize = tokens.slider.thumb.size;

  const state = useSliderState();
  const { thumbX, trackWidth, containerWidth, containerHeight } = state;
  const { gesture, isActive } = useSliderGesture(state, options);
  const {
    thumbStyle,
    tooltipContainerStyle,
    tooltipLeftSpacerStyle,
    tooltipRightSpacerStyle,
  } = useSliderAnimatedStyles(state);

  const [tooltipMaxWidth, setTooltipMaxWidth] = useState(0);

  useSliderControlledSync(state, options, thumbSize, isActive);

  const onTrackLayout = useCallback(
    ({ nativeEvent }: LayoutChangeEvent) => {
      const width = nativeEvent.layout.width;
      trackWidth.value = width;
      const trackRange = width - thumbSize;
      if (trackRange <= 0) {
        return;
      }
      thumbX.value = valueToX(valueRef.current, trackRange, minValue, maxValue);
    },
    [minValue, maxValue, thumbSize, thumbX, trackWidth, valueRef]
  );

  const onContainerLayout = useCallback(
    ({ nativeEvent }: LayoutChangeEvent) => {
      const { width, height } = nativeEvent.layout;
      containerWidth.value = width;
      containerHeight.value = height;
      setTooltipMaxWidth(width);
    },
    [containerWidth, containerHeight]
  );

  return {
    gesture,
    thumbStyle,
    tooltipContainerStyle,
    tooltipLeftSpacerStyle,
    tooltipRightSpacerStyle,
    onTrackLayout,
    onContainerLayout,
    tooltipMaxWidth,
    isActive,
  };
}
