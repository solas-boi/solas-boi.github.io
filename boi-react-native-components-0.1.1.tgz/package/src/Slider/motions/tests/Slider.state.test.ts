import { renderHook } from "@testing-library/react-native";

import { useSliderState } from "../Slider.state";

describe("useSliderState", () => {
  it("initialises all shared values to their defaults", () => {
    const { result } = renderHook(() => useSliderState());
    const state = result.current;

    expect(state.thumbX.value).toBe(0);
    expect(state.trackWidth.value).toBe(0);
    expect(state.containerWidth.value).toBe(0);
    expect(state.containerHeight.value).toBe(0);
  });
});
