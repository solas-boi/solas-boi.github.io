import React from "react";
import { renderHook } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { useSliderState } from "../Slider.state";
import { useSliderAnimatedStyles } from "../Slider.animation";

function Wrapper({ children }: { children: React.ReactNode }) {
  return <DesignTokensProvider>{children}</DesignTokensProvider>;
}

describe("useSliderAnimatedStyles", () => {
  it("returns thumbStyle and tooltip animated styles", () => {
    const { result } = renderHook(
      () => {
        const state = useSliderState();
        return useSliderAnimatedStyles(state);
      },
      { wrapper: Wrapper }
    );

    expect(result.current.thumbStyle).toBeDefined();
    expect(result.current.tooltipContainerStyle).toBeDefined();
    expect(result.current.tooltipLeftSpacerStyle).toBeDefined();
    expect(result.current.tooltipRightSpacerStyle).toBeDefined();
  });
});
