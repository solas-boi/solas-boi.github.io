import React from "react";
import { renderHook } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { useSliderState } from "../Slider.state";
import { useSliderGesture, type SliderGestureOptions } from "../Slider.gesture";

jest.useFakeTimers();

function Wrapper({ children }: { children: React.ReactNode }) {
  return <DesignTokensProvider>{children}</DesignTokensProvider>;
}

function makeOptions(
  overrides: Partial<SliderGestureOptions> = {}
): SliderGestureOptions {
  return {
    onChange: jest.fn(),
    minValue: 0,
    maxValue: 100,
    step: 1,
    disabled: false,
    ...overrides,
  };
}

describe("useSliderGesture", () => {
  it("returns the expected initial shape", () => {
    const { result } = renderHook(
      () => {
        const state = useSliderState();
        return useSliderGesture(state, makeOptions());
      },
      { wrapper: Wrapper }
    );

    expect(result.current.gesture).toBeDefined();
    expect(result.current.isActive).toBe(false);
  });
});
