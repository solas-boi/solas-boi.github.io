import React from "react";
import { renderHook, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { useSlider, type UseSliderOptions } from "../Slider.motion";

jest.useFakeTimers();

function Wrapper({ children }: { children: React.ReactNode }) {
  return <DesignTokensProvider>{children}</DesignTokensProvider>;
}

function makeOptions(
  overrides: Partial<UseSliderOptions> = {}
): UseSliderOptions {
  const initialValue = overrides.value ?? 50;

  return {
    value: initialValue,
    valueRef: { current: initialValue },
    onChange: jest.fn(),
    minValue: 0,
    maxValue: 100,
    step: 1,
    disabled: false,
    ...overrides,
  };
}

describe("useSlider", () => {
  it("returns the expected initial shape", () => {
    const { result } = renderHook(() => useSlider(makeOptions()), {
      wrapper: Wrapper,
    });

    expect(result.current.tooltipMaxWidth).toBe(0);
    expect(result.current.isActive).toBe(false);
    expect(result.current.gesture).toBeDefined();
    expect(result.current.thumbStyle).toBeDefined();
    expect(result.current.tooltipContainerStyle).toBeDefined();
    expect(result.current.tooltipLeftSpacerStyle).toBeDefined();
    expect(result.current.tooltipRightSpacerStyle).toBeDefined();
    expect(result.current.onTrackLayout).toBeInstanceOf(Function);
    expect(result.current.onContainerLayout).toBeInstanceOf(Function);
  });

  it("onContainerLayout updates tooltipMaxWidth", () => {
    const { result } = renderHook(() => useSlider(makeOptions()), {
      wrapper: Wrapper,
    });

    act(() => {
      result.current.onContainerLayout({
        nativeEvent: { layout: { x: 0, y: 0, width: 400, height: 100 } },
      } as any);
    });

    expect(result.current.tooltipMaxWidth).toBe(400);
  });
});
