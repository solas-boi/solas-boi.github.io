import { xToValue, valueToX } from "../Slider.math";

describe("xToValue", () => {
  const trackRange = 300;
  const min = 0;
  const max = 100;

  it("converts x to value linearly", () => {
    expect(xToValue(150, trackRange, min, max, 1)).toBe(50);
  });

  it("clamps x outside [0, trackRange]", () => {
    expect(xToValue(-50, trackRange, min, max, 1)).toBe(min);
    expect(xToValue(400, trackRange, min, max, 1)).toBe(max);
  });

  it("snaps to the nearest step", () => {
    // raw ≈ 51.67 → snaps to 50
    expect(xToValue(155, trackRange, min, max, 10)).toBe(50);
  });

  it("applies the minValue offset correctly", () => {
    // x=50, range=100, min=10, max=20 → raw = 10 + (50/100)*10 = 15
    expect(xToValue(50, 100, 10, 20, 1)).toBe(15);
  });
});

describe("valueToX", () => {
  const trackRange = 300;
  const min = 0;
  const max = 100;

  it("maps min and max values to track boundaries", () => {
    expect(valueToX(min, trackRange, min, max)).toBe(0);
    expect(valueToX(max, trackRange, min, max)).toBe(trackRange);
  });

  it("clamps values outside [min, max]", () => {
    expect(valueToX(-10, trackRange, min, max)).toBe(0);
    expect(valueToX(110, trackRange, min, max)).toBe(trackRange);
  });

  it("returns 0 when min equals max", () => {
    expect(valueToX(50, trackRange, 50, 50)).toBe(0);
  });

  it("is the inverse of xToValue", () => {
    const value = 35;
    expect(xToValue(valueToX(value, trackRange, min, max), trackRange, min, max, 1)).toBe(value);
  });
});
