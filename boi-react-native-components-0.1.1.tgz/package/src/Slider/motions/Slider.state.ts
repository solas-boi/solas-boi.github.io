import { useSharedValue, type SharedValue } from "react-native-reanimated";

export type SliderSharedState = {
  thumbX: SharedValue<number>;
  trackWidth: SharedValue<number>;
  containerWidth: SharedValue<number>;
  containerHeight: SharedValue<number>;
};

export function useSliderState(): SliderSharedState {
  const thumbX = useSharedValue(0);
  const trackWidth = useSharedValue(0);
  const containerWidth = useSharedValue(0);
  const containerHeight = useSharedValue(0);

  return {
    thumbX,
    trackWidth,
    containerWidth,
    containerHeight,
  };
}
