export { useSlider } from "./Slider.motion";
export type { UseSliderOptions } from "./Slider.motion";
