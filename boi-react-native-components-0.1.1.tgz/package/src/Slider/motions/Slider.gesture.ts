import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { runOnJS, useSharedValue } from "react-native-reanimated";
import { Gesture } from "react-native-gesture-handler";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { DRAG_THROTTLE_MS } from "../Slider.constants";
import type { SliderSharedState } from "./Slider.state";
import { xToValue, valueToX } from "./Slider.math";

export type SliderGestureOptions = {
  onChange: (value: number) => void;
  minValue: number;
  maxValue: number;
  step: number;
  disabled: boolean;
};

function useGestureBounds({ minValue, maxValue, step }: SliderGestureOptions) {
  const minSV = useSharedValue(minValue);
  const maxSV = useSharedValue(maxValue);
  const stepSV = useSharedValue(step);

  useEffect(() => {
    minSV.value = minValue;
  }, [minValue, minSV]);

  useEffect(() => {
    maxSV.value = maxValue;
  }, [maxValue, maxSV]);

  useEffect(() => {
    stepSV.value = step;
  }, [step, stepSV]);

  return { minSV, maxSV, stepSV };
}

function useGestureDispatch(onChange: (value: number) => void) {
  const stableOnChange = useRef(onChange);
  useEffect(() => {
    stableOnChange.current = onChange;
  }, [onChange]);

  const lastDispatchTime = useRef(0);

  const dispatchDuringDrag = useCallback((newValue: number) => {
    const now = Date.now();
    if (now - lastDispatchTime.current >= DRAG_THROTTLE_MS) {
      lastDispatchTime.current = now;
      stableOnChange.current(newValue);
    }
  }, []);

  const dispatchOnRelease = useCallback((newValue: number) => {
    lastDispatchTime.current = 0;
    stableOnChange.current(newValue);
  }, []);

  return { dispatchDuringDrag, dispatchOnRelease };
}

export function useSliderGesture(
  state: SliderSharedState,
  options: SliderGestureOptions
) {
  const { tokens } = useDesignTokens();
  const thumbSize = tokens.slider.thumb.size;

  const { thumbX, trackWidth } = state;
  const { onChange, disabled } = options;

  const { minSV, maxSV, stepSV } = useGestureBounds(options);
  const { dispatchDuringDrag, dispatchOnRelease } =
    useGestureDispatch(onChange);

  const startOffset = useSharedValue(thumbSize / 2);
  const [isActive, setIsActive] = useState(false);

  const gesture = useMemo(
    () =>
      Gesture.Pan()
        .enabled(!disabled)
        .onBegin(({ x }) => {
          runOnJS(setIsActive)(true);

          const trackRange = trackWidth.value - thumbSize;
          const isOnThumb = x >= thumbX.value && x <= thumbX.value + thumbSize;

          if (isOnThumb) {
            startOffset.value = x - thumbX.value;
          } else {
            startOffset.value = thumbSize / 2;
            if (trackRange > 0) {
              const rawThumbX = Math.min(
                Math.max(0, x - thumbSize / 2),
                trackRange
              );
              const jumpedValue = xToValue(
                rawThumbX,
                trackRange,
                minSV.value,
                maxSV.value,
                stepSV.value
              );
              thumbX.value = valueToX(
                jumpedValue,
                trackRange,
                minSV.value,
                maxSV.value
              );
              runOnJS(dispatchOnRelease)(jumpedValue);
            }
          }
        })
        .onUpdate(({ x }) => {
          const trackRange = trackWidth.value - thumbSize;
          if (trackRange <= 0) {
            return;
          }
          const rawThumbX = Math.min(
            Math.max(0, x - startOffset.value),
            trackRange
          );
          const newValue = xToValue(
            rawThumbX,
            trackRange,
            minSV.value,
            maxSV.value,
            stepSV.value
          );
          thumbX.value = valueToX(
            newValue,
            trackRange,
            minSV.value,
            maxSV.value
          );
          runOnJS(dispatchDuringDrag)(newValue);
        })
        .onEnd(() => {
          const trackRange = trackWidth.value - thumbSize;
          if (trackRange <= 0) {
            return;
          }
          runOnJS(dispatchOnRelease)(
            xToValue(
              thumbX.value,
              trackRange,
              minSV.value,
              maxSV.value,
              stepSV.value
            )
          );
        })
        .onFinalize(() => {
          runOnJS(setIsActive)(false);
        }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [disabled, thumbSize, dispatchOnRelease, dispatchDuringDrag]
  );

  return { gesture, isActive };
}
