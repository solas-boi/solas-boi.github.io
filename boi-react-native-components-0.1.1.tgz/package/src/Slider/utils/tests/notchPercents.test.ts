import { notchesToPercents } from "../notchPercents";

describe("notchesToPercents", () => {
  it("returns null for an empty array", () => {
    expect(notchesToPercents([], 0, 100)).toBeNull();
  });

  it("returns null when all notches are filtered out at boundaries", () => {
    expect(notchesToPercents([0, 100], 0, 100)).toBeNull();
  });

  it("returns null when the only notch is at minValue", () => {
    expect(notchesToPercents([0], 0, 100)).toBeNull();
  });

  it("returns null when the only notch is at maxValue", () => {
    expect(notchesToPercents([100], 0, 100)).toBeNull();
  });

  it("returns relative percent for a single notch", () => {
    expect(notchesToPercents([50], 0, 100)).toEqual([50]);
  });

  it("returns relative percents for evenly spaced notches", () => {
    expect(notchesToPercents([25, 50, 75], 0, 100)).toEqual([25, 25, 25]);
  });

  it("returns relative percents for unevenly spaced notches", () => {
    expect(notchesToPercents([20, 60], 0, 100)).toEqual([20, 40]);
  });

  it("sorts unsorted notches before computing percents", () => {
    expect(notchesToPercents([75, 25], 0, 100)).toEqual([25, 50]);
  });

  it("filters notches exactly at min and max boundaries", () => {
    expect(notchesToPercents([0, 50, 100], 0, 100)).toEqual([50]);
  });

  it("accepts tooltip notch objects and uses startValue", () => {
    const notches = [{ startValue: 25 }, { startValue: 75 }];
    expect(notchesToPercents(notches, 0, 100)).toEqual([25, 50]);
  });

  it("works with non-zero minValue", () => {
    expect(notchesToPercents([3], 1, 5)).toEqual([50]);
  });
});
