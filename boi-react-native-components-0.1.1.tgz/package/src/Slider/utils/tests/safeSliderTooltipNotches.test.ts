import {
  safeSliderTooltipNotches,
  resolveTooltipForValue,
} from "../safeSliderTooltipNotches";
import type { SliderTooltipNotch } from "../../Slider.types";

describe("safeSliderTooltipNotches", () => {
  it("returns undefined for an empty array", () => {
    expect(safeSliderTooltipNotches([], 0, 100)).toBeUndefined();
  });

  it("returns sorted notches and filters out-of-range values", () => {
    const notches: SliderTooltipNotch[] = [
      { startValue: 110, tooltip: "Above" },
      { startValue: 50, tooltip: "Mid" },
      { startValue: -10, tooltip: "Below" },
    ];
    expect(safeSliderTooltipNotches(notches, 0, 100)).toEqual([
      { startValue: 50, tooltip: "Mid" },
    ]);
  });

  it("keeps notches exactly at min and max boundaries", () => {
    const notches: SliderTooltipNotch[] = [
      { startValue: 0, tooltip: "Start" },
      { startValue: 100, tooltip: "End" },
    ];
    expect(safeSliderTooltipNotches(notches, 0, 100)).toHaveLength(2);
  });

  it("deduplicates notches with the same startValue", () => {
    const notches: SliderTooltipNotch[] = [
      { startValue: 50, tooltip: "Beta" },
      { startValue: 50, tooltip: "Alpha" },
    ];
    const result = safeSliderTooltipNotches(notches, 0, 100);
    expect(result).toHaveLength(1);
    expect(result![0]!.tooltip).toBe("Alpha");
  });
});

describe("resolveTooltipForValue", () => {
  const notches: SliderTooltipNotch[] = [
    { startValue: 0, tooltip: "Low" },
    { startValue: 50, tooltip: "Mid" },
    { startValue: 75, tooltip: "High" },
  ];

  it("returns empty string when value is below the first startValue", () => {
    expect(resolveTooltipForValue(10, [{ startValue: 20, tooltip: "Some" }])).toBe("");
  });

  it("returns the first tooltip when value equals the first startValue", () => {
    expect(resolveTooltipForValue(0, notches)).toBe("Low");
  });

  it("returns the range tooltip when value is between two notches", () => {
    expect(resolveTooltipForValue(60, notches)).toBe("Mid");
  });

  it("returns the last tooltip when value exceeds the last startValue", () => {
    expect(resolveTooltipForValue(99, notches)).toBe("High");
  });
});
