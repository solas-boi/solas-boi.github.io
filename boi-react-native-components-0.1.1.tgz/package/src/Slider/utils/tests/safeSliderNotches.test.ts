import { safeSliderNotches, isTooltipNotches } from "../safeSliderNotches";

describe("isTooltipNotches", () => {
  it("returns false for a number array", () => {
    expect(isTooltipNotches([1, 2, 3])).toBe(false);
  });

  it("returns true for a tooltip notch array", () => {
    expect(isTooltipNotches([{ startValue: 1, tooltip: "x" }])).toBe(true);
  });
});

describe("safeSliderNotches", () => {
  it("returns undefined when notches is undefined or empty", () => {
    expect(safeSliderNotches(undefined, 0, 100)).toBeUndefined();
    expect(safeSliderNotches([], 0, 100)).toBeUndefined();
  });

  it("filters boundaries and out-of-range, sorts, and deduplicates number notches", () => {
    expect(safeSliderNotches([-10, 0, 75, 50, 50, 100, 110], 0, 100)).toEqual([
      50, 75,
    ]);
  });

  it("delegates tooltip notches and keeps boundary startValues", () => {
    const notches = [
      { startValue: 0, tooltip: "Start" },
      { startValue: 50, tooltip: "Mid" },
      { startValue: 100, tooltip: "End" },
    ];
    expect(safeSliderNotches(notches, 0, 100)).toHaveLength(3);
  });
});
