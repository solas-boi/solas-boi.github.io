export function notchesToPercents(
  notches: Array<number | { startValue: number }>,
  minValue: number,
  maxValue: number
): number[] | null {
  const range = maxValue - minValue;
  let prevPct = 0;

  const result = notches
    .map((n) => (typeof n === "number" ? n : n.startValue))
    .filter((v) => v > minValue && v < maxValue)
    .sort((a, b) => a - b)
    .map((v) => {
      const absPct = ((v - minValue) / range) * 100;
      const relPct = absPct - prevPct;
      prevPct = absPct;
      return relPct;
    });

  return result.length ? result : null;
}
