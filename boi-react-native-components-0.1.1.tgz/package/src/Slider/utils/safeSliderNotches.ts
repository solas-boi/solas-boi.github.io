import type { SliderNotches, SliderTooltipNotch } from "../Slider.types";
import { safeSliderTooltipNotches } from "./safeSliderTooltipNotches";

export function isTooltipNotches(notches: SliderNotches): notches is SliderTooltipNotch[] {
  return notches.length > 0 && typeof notches[0] !== "number";
}

function safeNumberNotches(
  notches: number[],
  minValue: number,
  maxValue: number
): number[] {
  const sorted = [...notches].sort((a, b) => a - b);
  const withinRange = sorted.filter((v) => v > minValue && v < maxValue);
  return Array.from(new Set(withinRange));
}

export function safeSliderNotches(
  notches: SliderNotches | undefined,
  minValue: number,
  maxValue: number
): SliderNotches | undefined {
  if (!notches?.length) {
    return undefined;
  }

  return isTooltipNotches(notches)
    ? safeSliderTooltipNotches(notches, minValue, maxValue)
    : safeNumberNotches(notches as number[], minValue, maxValue);
}
