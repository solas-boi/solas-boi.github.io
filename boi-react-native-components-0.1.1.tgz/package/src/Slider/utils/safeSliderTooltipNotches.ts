import type { SliderTooltipNotch } from "../Slider.types";

export function safeSliderTooltipNotches(
  notches: SliderTooltipNotch[],
  minValue: number,
  maxValue: number
): SliderTooltipNotch[] | undefined {
  if (!notches.length) {
    return undefined;
  }

  const sorted = [...notches].sort((a, b) => {
    const byStartValue = a.startValue - b.startValue;
    return byStartValue !== 0
      ? byStartValue
      : a.tooltip.localeCompare(b.tooltip);
  });

  const withinRange = sorted.filter(
    (n) => n.startValue >= minValue && n.startValue <= maxValue
  );

  const seen = new Set<string>();
  const unique = withinRange.filter((n) => {
    const key = `${n.startValue}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });

  return unique.length > 0 ? unique : undefined;
}

export function resolveTooltipForValue(
  value: number,
  notches: SliderTooltipNotch[]
): string {
  if (value < notches[0]!.startValue) {
    return "";
  }

  for (let i = 1; i < notches.length; i++) {
    if (notches[i]!.startValue > value) {
      return notches[i - 1]!.tooltip;
    }
  }

  return notches[notches.length - 1]!.tooltip;
}
