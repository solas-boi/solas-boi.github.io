import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { createThemedStyleSheet } from "../../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { spacing } = tokens;

  return StyleSheet.create({
    container: {
      gap: spacing.s12,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
