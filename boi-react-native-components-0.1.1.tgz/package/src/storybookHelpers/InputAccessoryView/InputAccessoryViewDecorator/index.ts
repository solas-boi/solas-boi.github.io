export { InputAccessoryViewDecorator } from "./InputAccessoryViewDecorator";
