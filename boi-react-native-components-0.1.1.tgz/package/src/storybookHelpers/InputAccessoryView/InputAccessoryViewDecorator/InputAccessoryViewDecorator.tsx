import { Decorator } from "@storybook/react";
import { InlineAlert } from "../../../InlineAlert";
import { View } from "react-native";
import useStyles from "./InputAccessoryViewDecorator.styles";

export const InputAccessoryViewDecorator: Decorator = (Story) => {
  const styles = useStyles();

  return (
    <View style={styles.container}>
      <InlineAlert severity="warning">
        The Input Accessory View is only supported on iOS
      </InlineAlert>
      <Story />
    </View>
  );
};
