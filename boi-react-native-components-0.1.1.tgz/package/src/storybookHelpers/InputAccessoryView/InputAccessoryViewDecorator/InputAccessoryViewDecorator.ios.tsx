import { useId } from "react";
import { AccessoryBar } from "../AccessoryBar";
import { Decorator } from "@storybook/react";

export const InputAccessoryViewDecorator: Decorator = (Story, { args }) => {
  const inputAccessoryViewID = useId();

  return (
    <>
      <Story args={{ ...args, inputAccessoryViewID }} />
      <AccessoryBar nativeID={inputAccessoryViewID} />
    </>
  );
};
