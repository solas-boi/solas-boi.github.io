import { InputAccessoryView } from "react-native";
import { Typography } from "../../../Typography";
import { AccessoryBarProps } from "./AccessoryBar.types";
import useStyles from "./AccessoryBar.styles";

export const AccessoryBar = ({ nativeID }: AccessoryBarProps) => {
  const styles = useStyles();

  return (
    <InputAccessoryView nativeID={nativeID}>
      <Typography style={styles.accessoryBar} variant="bodyM">
        Keyboard accessory view
      </Typography>
    </InputAccessoryView>
  );
};
