import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { createThemedStyleSheet } from "../../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { themeColor, spacing } = tokens;

  return StyleSheet.create({
    accessoryBar: {
      flex: 1,
      width: "100%",
      alignSelf: "center",
      textAlign: "center",
      backgroundColor: themeColor.base150,
      borderTopColor: themeColor.base200,
      borderTopWidth: 1,
      paddingVertical: spacing.s12,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
