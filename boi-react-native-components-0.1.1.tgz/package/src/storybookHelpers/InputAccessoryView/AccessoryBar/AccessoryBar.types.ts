import { InputAccessoryViewProps } from "react-native";

export type AccessoryBarProps = Pick<InputAccessoryViewProps, "nativeID">;
