import type { MenuItem } from "../Menu";

import type { JSX } from "react";

export type IconButtonMenuItem = MenuItem & {
  text: string;
  icon?: JSX.Element;
};
