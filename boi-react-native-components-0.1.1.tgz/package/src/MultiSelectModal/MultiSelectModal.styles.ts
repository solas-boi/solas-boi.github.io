import { StyleSheet } from "react-native";
import { isTablet } from "react-native-device-info";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { multiSelect } = tokens;
  const screenType = isTablet() ? "tablet" : "mobile";
  return StyleSheet.create({
    footer: {
      paddingTop: multiSelect.footer[screenType].padding.top,
      paddingLeft: multiSelect.footer[screenType].padding.left,
      paddingRight: multiSelect.footer[screenType].padding.right,
      paddingBottom: multiSelect.footer[screenType].padding.bottom,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
