import { useState, useEffect, useCallback } from "react";
import { View } from "react-native";
import { CoreMultiSelect } from "@boi/components-core";

import useStyles from "./MultiSelectModal.styles";
import { MultiSelectModalBase } from "../MultiSelectModalBase";
import {
  StandardModalWithFooter,
  StandardModalWithFooterProps,
} from "../StandardModalWithFooter";
import { Button } from "../Button";

export type MultiSelectModalProps<T extends CoreMultiSelect.MultiSelectItem> =
  Omit<StandardModalWithFooterProps, "footer" | "children"> & {
    selectedItems?: (T | null | undefined)[];
    items: T[];
    disabledKeys?: string[];
    onChange: (selectedItems: (T | null | undefined)[]) => void;
  };

function MultiSelectModal<T extends CoreMultiSelect.MultiSelectItem>(
  props: MultiSelectModalProps<T>
) {
  const {
    selectedItems,
    items,
    disabledKeys,
    onChange,
    testID = "multi-select-modal",
    onOpenAnimationComplete,
    onCloseAnimationComplete,
    ...modalProps
  } = props;

  const { isOpen, onRequestClose } = props;

  const styles = useStyles();

  const [updatedSelectedItems, setUpdatedSelectedItems] = useState([
    ...(selectedItems || []),
  ]);

  useEffect(() => {
    setUpdatedSelectedItems([...(selectedItems || [])]);
  }, [isOpen, selectedItems]);

  function handleConfirmPress() {
    onChange(updatedSelectedItems);
    onRequestClose();
  }

  const [openAnimationFinished, setOpenAnimationFinished] = useState(false);

  const handleOpenAnimationComplete = useCallback(() => {
    setOpenAnimationFinished(true);
    onOpenAnimationComplete?.();
  }, [onOpenAnimationComplete]);

  const handleCloseAnimationComplete = useCallback(() => {
    setOpenAnimationFinished(false);
    onCloseAnimationComplete?.();
  }, [onCloseAnimationComplete]);

  return (
    <StandardModalWithFooter
      {...modalProps}
      testID={testID}
      onOpenAnimationComplete={handleOpenAnimationComplete}
      onCloseAnimationComplete={handleCloseAnimationComplete}
      footer={
        <View style={styles.footer}>
          <Button fullWidth text="Confirm" onPress={handleConfirmPress} />
        </View>
      }
    >
      <MultiSelectModalBase
        readyToInteract={modalProps.isOpen && openAnimationFinished}
        items={items}
        disabledKeys={disabledKeys}
        selectedItems={selectedItems}
        updatedSelectedItems={updatedSelectedItems}
        setUpdatedSelectedItems={setUpdatedSelectedItems}
      />
    </StandardModalWithFooter>
  );
}

export default MultiSelectModal;
