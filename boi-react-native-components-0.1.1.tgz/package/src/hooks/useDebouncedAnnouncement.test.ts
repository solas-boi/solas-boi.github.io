import { renderHook } from "@testing-library/react-native";
import { AccessibilityInfo, Platform } from "react-native";

import useDebouncedAnnouncement from "./useDebouncedAnnouncement";
import useDebounce from "./useDebounce";
import useScreenReaderEnabled from "./useScreenReaderEnabled";

jest.mock("./useDebounce", () => jest.fn());
jest.mock("./useScreenReaderEnabled", () => jest.fn());
jest.mock("react-native", () => ({
  AccessibilityInfo: {
    announceForAccessibility: jest.fn(),
  },
  Platform: {
    OS: "ios",
  },
}));

describe("useDebouncedAnnouncement", () => {
  const mockedUseDebounce = jest.mocked(useDebounce);
  const mockedUseScreenReaderEnabled = jest.mocked(useScreenReaderEnabled);
  const mockedAccessibilityInfo = AccessibilityInfo as jest.Mocked<
    typeof AccessibilityInfo
  >;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.replaceProperty(Platform, "OS", "ios");

    mockedUseScreenReaderEnabled.mockReturnValue(true);
    mockedUseDebounce.mockImplementation((value) => value);
  });

  it("announces debounced text when screen reader is enabled and platform matches", () => {
    renderHook(() => useDebouncedAnnouncement("hello", 300));

    expect(mockedUseDebounce).toHaveBeenCalledWith("hello", 300);
    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledWith("hello");
  });

  it("does not announce when screen reader is disabled", () => {
    mockedUseScreenReaderEnabled.mockReturnValue(false);

    renderHook(() => useDebouncedAnnouncement("hello", 300));

    expect(mockedUseDebounce).toHaveBeenCalledWith(null, 300);
    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).not.toHaveBeenCalled();
  });

  it("does not announce when selected platform does not match current platform", () => {
    jest.replaceProperty(Platform, "OS", "android");

    renderHook(() =>
      useDebouncedAnnouncement("hello", 300, { platform: "ios" })
    );

    expect(mockedUseDebounce).toHaveBeenCalledWith(null, 300);
    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).not.toHaveBeenCalled();
  });

  it("announces on any platform when platform option is all", () => {
    jest.replaceProperty(Platform, "OS", "android");

    renderHook(() =>
      useDebouncedAnnouncement("hello", 300, { platform: "all" })
    );

    expect(mockedUseDebounce).toHaveBeenCalledWith("hello", 300);
    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledWith("hello");
  });

  it("does not re-announce same debounced text by default", () => {
    const { rerender } = renderHook(
      ({ value }: { value: string }) => useDebouncedAnnouncement(value),
      {
        initialProps: { value: "same" },
      }
    );

    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledTimes(1);

    rerender({ value: "same" });

    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledTimes(1);
  });

  it("re-announces same debounced text when allowRepeat is enabled", () => {
    const { rerender } = renderHook(
      ({ value, allowRepeat }: { value: string; allowRepeat: boolean }) =>
        useDebouncedAnnouncement(value, 500, { allowRepeat }),
      {
        initialProps: { value: "same", allowRepeat: false },
      }
    );

    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledTimes(1);

    rerender({ value: "same", allowRepeat: true });

    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).toHaveBeenCalledTimes(2);
  });

  it("does not announce empty or null debounced values", () => {
    renderHook(() => useDebouncedAnnouncement(""));
    renderHook(() => useDebouncedAnnouncement(null));

    expect(
      mockedAccessibilityInfo.announceForAccessibility
    ).not.toHaveBeenCalled();
  });
});
