// hooks/useScreenReaderEnabled.ts
import { useEffect, useState } from "react";
import { AccessibilityInfo } from "react-native";

export default function useScreenReaderEnabled(): boolean {
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    let active = true;

    AccessibilityInfo.isScreenReaderEnabled().then((val) => {
      if (active) {
        setEnabled(val);
      }
    });

    const sub = AccessibilityInfo.addEventListener(
      "screenReaderChanged",
      setEnabled
    );
    return () => {
      active = false;
      sub.remove();
    };
  }, []);

  return enabled;
}
