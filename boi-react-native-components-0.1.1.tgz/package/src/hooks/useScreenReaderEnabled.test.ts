import { act, renderHook, waitFor } from "@testing-library/react-native";
import { AccessibilityInfo } from "react-native";

import useScreenReaderEnabled from "./useScreenReaderEnabled";

jest.mock("react-native", () => ({
  AccessibilityInfo: {
    isScreenReaderEnabled: jest.fn(),
    addEventListener: jest.fn(),
  },
}));

describe("useScreenReaderEnabled", () => {
  const mockedAccessibilityInfo = AccessibilityInfo as jest.Mocked<
    typeof AccessibilityInfo
  >;
  const removeListener = jest.fn();
  let onScreenReaderChanged: ((enabled: boolean) => void) | undefined;

  beforeEach(() => {
    jest.clearAllMocks();
    onScreenReaderChanged = undefined;

    mockedAccessibilityInfo.isScreenReaderEnabled.mockResolvedValue(false);
    (mockedAccessibilityInfo.addEventListener.mockImplementation as any)(
      (_eventName: any, callback: any) => {
        onScreenReaderChanged = callback;
        return { remove: removeListener };
      }
    );
  });

  it("returns false initially and then updates from isScreenReaderEnabled", async () => {
    mockedAccessibilityInfo.isScreenReaderEnabled.mockResolvedValue(true);

    const { result } = renderHook(() => useScreenReaderEnabled());

    expect(result.current).toBe(false);

    await waitFor(() => {
      expect(result.current).toBe(true);
    });

    expect(mockedAccessibilityInfo.addEventListener).toHaveBeenCalledWith(
      "screenReaderChanged",
      expect.any(Function)
    );
  });

  it("updates when screenReaderChanged event is emitted", async () => {
    const { result } = renderHook(() => useScreenReaderEnabled());

    await waitFor(() => {
      expect(result.current).toBe(false);
    });

    act(() => {
      onScreenReaderChanged?.(true);
    });

    expect(result.current).toBe(true);
  });

  it("removes the screenReaderChanged listener on unmount", () => {
    const { unmount } = renderHook(() => useScreenReaderEnabled());

    unmount();

    expect(removeListener).toHaveBeenCalledTimes(1);
  });
});
