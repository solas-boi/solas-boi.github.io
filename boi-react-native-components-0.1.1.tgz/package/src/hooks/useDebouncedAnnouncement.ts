// hooks/useDebouncedAnnouncement.ts
import { useCallback, useEffect, useRef } from "react";
import { AccessibilityInfo, Platform } from "react-native";
import useDebounce from "./useDebounce";
import useScreenReaderEnabled from "./useScreenReaderEnabled";

export type AnnouncementPlatform = "ios" | "android" | "all";

export type UseDebouncedAnnouncementOptions = {
  /** @default 'ios' */
  platform?: AnnouncementPlatform;
  /**
   * When true, the same text CAN be re-announced if the component
   * re-renders with an identical string (e.g. a retry counter reset).
   * @default false
   */
  allowRepeat?: boolean;
};

export default function useDebouncedAnnouncement(
  value: string | null | undefined,
  delay = 500,
  options: UseDebouncedAnnouncementOptions = {}
): void {
  const { platform = "ios", allowRepeat = false } = options;
  const isScreenReaderEnabled = useScreenReaderEnabled();

  const shouldRun =
    isScreenReaderEnabled && (platform === "all" || Platform.OS === platform);

  const debouncedValue = useDebounce(shouldRun ? value ?? null : null, delay);
  const lastAnnounced = useRef<string | null>(null);

  const announce = useCallback((text: string) => {
    AccessibilityInfo.announceForAccessibility(text);
  }, []);

  useEffect(() => {
    if (!debouncedValue) {
      return;
    }
    if (!allowRepeat && debouncedValue === lastAnnounced.current) {
      return;
    }

    lastAnnounced.current = debouncedValue;
    announce(debouncedValue);
  }, [debouncedValue, announce, allowRepeat]);
}
