import { act, renderHook } from "@testing-library/react-native";

import useDebounce from "./useDebounce";

describe("useDebounce", () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  it("returns the initial value immediately", () => {
    const { result } = renderHook(() => useDebounce("initial", 200));

    expect(result.current).toBe("initial");
  });

  it("updates to a new value only after the delay", () => {
    const { result, rerender } = renderHook(
      ({ value, delay }: { value: string; delay: number }) =>
        useDebounce(value, delay),
      {
        initialProps: { value: "first", delay: 200 },
      }
    );

    rerender({ value: "second", delay: 200 });

    expect(result.current).toBe("first");

    act(() => {
      jest.advanceTimersByTime(199);
    });

    expect(result.current).toBe("first");

    act(() => {
      jest.advanceTimersByTime(1);
    });

    expect(result.current).toBe("second");
  });

  it("uses only the latest value when updated multiple times before delay", () => {
    const { result, rerender } = renderHook(
      ({ value }: { value: string }) => useDebounce(value, 200),
      {
        initialProps: { value: "A" },
      }
    );

    rerender({ value: "B" });

    act(() => {
      jest.advanceTimersByTime(100);
    });

    rerender({ value: "C" });

    act(() => {
      jest.advanceTimersByTime(100);
    });

    expect(result.current).toBe("A");

    act(() => {
      jest.advanceTimersByTime(100);
    });

    expect(result.current).toBe("C");
  });

  it("restarts the timer when delay changes", () => {
    const { result, rerender } = renderHook(
      ({ value, delay }: { value: string; delay: number }) =>
        useDebounce(value, delay),
      {
        initialProps: { value: "A", delay: 300 },
      }
    );

    rerender({ value: "B", delay: 300 });

    act(() => {
      jest.advanceTimersByTime(100);
    });

    rerender({ value: "B", delay: 500 });

    act(() => {
      jest.advanceTimersByTime(399);
    });

    expect(result.current).toBe("A");

    act(() => {
      jest.advanceTimersByTime(101);
    });

    expect(result.current).toBe("B");
  });
});
