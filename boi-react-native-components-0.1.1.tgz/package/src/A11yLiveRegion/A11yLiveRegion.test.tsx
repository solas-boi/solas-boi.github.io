import React from "react";
import { render, screen } from "@testing-library/react-native";
import { ViewProps } from "react-native";

import A11yLiveRegion from "./A11yLiveRegion";

import { useDebouncedAnnouncement } from "../hooks";

type RenderA11yLiveRegionParams = {
  props: {
    testID: string;
    announcement: string | null | undefined;
    accessibilityLiveRegion?: ViewProps["accessibilityLiveRegion"];
    iosDelay?: number;
    assertiveDelay?: number;
  };
};

jest.mock("../hooks", () => ({
  useDebouncedAnnouncement: jest.fn(),
}));

const renderA11yLiveRegion = ({ props }: RenderA11yLiveRegionParams) => {
  render(<A11yLiveRegion {...props} />);
  return {
    mockedUseDebouncedAnnouncement: jest.mocked(useDebouncedAnnouncement),
  };
};

describe("A11yLiveRegion", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("wires default polite delay to the debounced announcement hook", () => {
    const { mockedUseDebouncedAnnouncement } = renderA11yLiveRegion({
      props: {
        testID: "slider",
        announcement: "Current value 10",
      },
    });

    expect(screen.queryByTestId("slider-live-region")).toBeNull();

    expect(mockedUseDebouncedAnnouncement).toHaveBeenCalledWith(
      "Current value 10",
      100,
      { platform: "ios" }
    );
  });

  it("uses assertiveDelay for assertive live regions", () => {
    const { mockedUseDebouncedAnnouncement } = renderA11yLiveRegion({
      props: {
        testID: "slider",
        announcement: "Current value 20",
        accessibilityLiveRegion: "assertive",
        iosDelay: 250,
        assertiveDelay: 10,
      },
    });

    expect(screen.queryByTestId("slider-live-region")).toBeNull();
    expect(mockedUseDebouncedAnnouncement).toHaveBeenCalledWith(
      "Current value 20",
      10,
      { platform: "ios" }
    );
  });

  it("passes null announcement through to the hook", () => {
    const { mockedUseDebouncedAnnouncement } = renderA11yLiveRegion({
      props: {
        testID: "slider",
        announcement: null,
      },
    });

    expect(screen.queryByTestId("slider-live-region")).toBeNull();
    expect(mockedUseDebouncedAnnouncement).toHaveBeenCalledWith(null, 100, {
      platform: "ios",
    });
  });

  it("uses iosDelay for non-assertive live regions", () => {
    const { mockedUseDebouncedAnnouncement } = renderA11yLiveRegion({
      props: {
        testID: "slider",
        announcement: "Current value 30",
        accessibilityLiveRegion: "polite",
        iosDelay: 350,
        assertiveDelay: 5,
      },
    });

    expect(screen.queryByTestId("slider-live-region")).toBeNull();
    expect(mockedUseDebouncedAnnouncement).toHaveBeenCalledWith(
      "Current value 30",
      350,
      { platform: "ios" }
    );
  });
});
