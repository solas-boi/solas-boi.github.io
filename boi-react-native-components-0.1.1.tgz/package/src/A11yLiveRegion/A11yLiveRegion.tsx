// components/A11yLiveRegion.tsx
import React from "react";
import { AccessibilityValue, Platform, View, ViewProps } from "react-native";
import { useDebouncedAnnouncement } from "../hooks";

export type A11yLiveRegionProps = {
  testID: string;
  announcement: string | null | undefined;
  accessibilityLiveRegion?: ViewProps["accessibilityLiveRegion"];
  iosDelay?: number;
  assertiveDelay?: number;
};

const IS_ANDROID = Platform.OS === "android";

const A11yLiveRegion: React.FC<A11yLiveRegionProps> = ({
  testID,
  announcement,
  accessibilityLiveRegion = "polite",
  iosDelay = 100,
  assertiveDelay = 0,
}) => {
  const iosEffectiveDelay =
    accessibilityLiveRegion === "assertive" ? assertiveDelay : iosDelay;

  useDebouncedAnnouncement(announcement, iosEffectiveDelay, {
    platform: "ios",
  });

  if (!IS_ANDROID) {
    return null;
  }

  return (
    <View
      testID={`${testID}-live-region`}
      accessibilityLiveRegion={accessibilityLiveRegion}
      accessibilityValue={
        { text: announcement ?? "" } satisfies AccessibilityValue
      }
    />
  );
};

export default A11yLiveRegion;
