export {
  default as A11yLiveRegion,
  type A11yLiveRegionProps,
} from "./A11yLiveRegion";
