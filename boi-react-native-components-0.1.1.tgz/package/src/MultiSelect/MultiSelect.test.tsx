import {
  render,
  screen,
  userEvent,
  fireEvent,
} from "@testing-library/react-native";
import { Keyboard } from "react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreMultiSelect } from "@boi/components-core";

import MultiSelect, { type MultiSelectProps } from "./MultiSelect";

jest.useFakeTimers();

function WrappedMultiSelect(
  props: MultiSelectProps<CoreMultiSelect.MultiSelectItem>
) {
  return (
    <DesignTokensProvider>
      <MultiSelect {...props} />
    </DesignTokensProvider>
  );
}

describe("MultiSelect", () => {
  let baseProps: MultiSelectProps<CoreMultiSelect.MultiSelectItem>;
  const isVisibleSpy = jest.spyOn(Keyboard, "isVisible");
  const dismissSpy = jest.spyOn(Keyboard, "dismiss");

  beforeEach(() => {
    baseProps = {
      items: CoreMultiSelect.mockItems,
      onChange: jest.fn(),
      labelProps: {
        "aria-label": "Label",
      },
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should render the correct number of multi-select options", async () => {
    const user = userEvent.setup();
    const items = CoreMultiSelect.mockItems.slice(0, 2);

    render(<WrappedMultiSelect {...baseProps} items={items} />);

    const combobox = await screen.findByTestId("multi-select");

    await user.press(combobox);

    const options = screen.getAllByRole("checkbox");
    expect(options).toHaveLength(items.length);
  });

  it("should trigger the onChange event when the confirm button is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedMultiSelect {...baseProps} onChange={mockOnChange} />);

    const combobox = await screen.findByTestId("multi-select");

    await user.press(combobox);

    const firstOption = screen.getAllByRole("checkbox")[0]!;

    await user.press(firstOption);

    const confirmButton = screen.getByRole("button", {
      name: "Confirm",
    });

    await user.press(confirmButton);

    await screen.findByTestId("multi-select-modal", { hidden: true });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith([CoreMultiSelect.mockItems[0]]);
  });

  it("should render with a default testID", () => {
    render(<WrappedMultiSelect {...baseProps} />);

    expect(screen.getByTestId("multi-select")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-multi-select";

    render(<WrappedMultiSelect {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  describe("keyboard dismiss", () => {
    it("should dismiss the keyboard when it is visible and the multi-select is opened", async () => {
      isVisibleSpy.mockReturnValue(true);

      render(<WrappedMultiSelect {...baseProps} />);

      const combobox = await screen.findByTestId("multi-select");
      fireEvent.press(combobox);

      expect(dismissSpy).toHaveBeenCalledTimes(1);
    });

    it("should not dismiss the keyboard when it is not visible and the multi-select is opened", async () => {
      isVisibleSpy.mockReturnValue(false);

      render(<WrappedMultiSelect {...baseProps} />);

      const combobox = await screen.findByTestId("multi-select");
      fireEvent.press(combobox);

      expect(dismissSpy).not.toHaveBeenCalled();
    });
  });
});
