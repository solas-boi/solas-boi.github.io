import type { CoreMultiSelect } from "@boi/components-core";

export type MultiSelectItem = CoreMultiSelect.MultiSelectItem;
