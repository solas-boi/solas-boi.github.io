import { useState } from "react";
import { Keyboard, View } from "react-native";
import { CoreMultiSelect } from "@boi/components-core";

import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { InputWrapper } from "../InputWrapper";
import { MultiSelectBase, type MultiSelectBaseProps } from "../MultiSelectBase";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type MultiSelectProps<
  T extends CoreMultiSelect.MultiSelectItem = CoreMultiSelect.MultiSelectItem
> = Omit<MultiSelectBaseProps<T>, "isOpen" | "onFocus" | "onBlur"> & {
  labelProps: InputLabelTopProps;
  selectedItems?: (T | null | undefined)[];
  onChange: (selectedItems: (T | null | undefined)[]) => void;
  alertProps?: InputAlertsProps["alerts"][number] | InputAlertsProps["alerts"];
};

function MultiSelect<
  T extends CoreMultiSelect.MultiSelectItem = CoreMultiSelect.MultiSelectItem
>(props: MultiSelectProps<T>) {
  const {
    labelProps,
    alertProps,
    testID = "multi-select",
    ...multiSelectBaseProps
  } = props;

  const [isOpen, setOpen] = useState(false);

  const handleFocus = () => {
    Keyboard.isVisible() && Keyboard.dismiss();
    setOpen(true);
  };

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <ScreenReaderAlertNotifier alert={alertProps}>
          <MultiSelectBase
            {...multiSelectBaseProps}
            labelProps={labelProps}
            alertProps={alertProps}
            isOpen={isOpen}
            onFocus={handleFocus}
            onBlur={() => setOpen(false)}
            testID={testID}
          />
        </ScreenReaderAlertNotifier>
      </InputLabelTop>
    </InputWrapper>
  );
}

export default MultiSelect;
