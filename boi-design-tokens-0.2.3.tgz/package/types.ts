import {
  BRANDS,
  BOI_THEMES,
  NEW_IRELAND_THEMES,
  DAVY_THEMES,
} from "./constants.js";

export type Brand = (typeof BRANDS)[number];

export type BoiTheme = (typeof BOI_THEMES)[number];
export type BoiThemeTokens = { [key in BoiTheme]: ThemeTokens };

export type NewIrelandTheme = (typeof NEW_IRELAND_THEMES)[number];
export type NewIrelandThemeTokens = { [key in NewIrelandTheme]: ThemeTokens };

export type DavyTheme = (typeof DAVY_THEMES)[number];
export type DavyThemeTokens = { [key in DavyTheme]: ThemeTokens };

export type ScalableSizeToken<V = number | string> = {
  size: V;
  minSize?: V;
  maxSize?: V;
};

type AccordionTokens = {
  background: {
    default: any;
    nested: any;
  };
  stroke: {
    width: any;
    style: any;
    radius: any;
    color: any;
  };
  header: {
    minHeight: {
      default: any;
      nested: any;
    };
    padding: any;
    text: {
      typography: {
        variant: {
          default: any;
          nested: any;
        };
        fontFamily: any;
      };
      color: {
        base: any;
        hover: any;
        active: any;
      };
      decoration: {
        line: {
          base: any;
          hover: any;
          active: any;
        };
        offset: any;
      };
    };
    icon: {
      width: any;
      height: any;
      color: {
        base: any;
        hover: any;
        active: any;
      };
    };
    focusRing: {
      width: any;
      style: any;
      color: any;
      offset: any;
      radius: any;
    };
    inner: {
      gap: any;
      radius: any;
      padding: {
        top: {
          default: any;
          nested: any;
        };
        left: any;
        right: any;
        bottom: {
          default: any;
          nested: any;
        };
      };
      backgroundColor: {
        base: any;
        hover: any;
        active: {
          default: any;
          nested: any;
        };
      };
    };
  };
  separator: {
    margin: {
      left: any;
      right: any;
    };
    stroke: {
      width: any;
      style: any;
      color: any;
    };
  };
  content: {
    padding: any;
  };
};

type AccordionGroupTokens = {
  gap: {
    default: any;
    nested: any;
  };
};

type AlertTokens = {
  radius: any;
  stroke: {
    width: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
    style: any;
    color: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
  };
  background: {
    error: any;
    warning: any;
    success: any;
    info: any;
  };
  padding: {
    top: any;
    left: any;
    right: any;
    bottom: any;
  };
  gap: any;
  contentContainer: {
    padding: {
      top: any;
      left: any;
      right: {
        default: any;
        dismissible: any;
      };
      bottom: any;
    };
    gap: any;
  };
  iconWrapper: {
    height: ScalableSizeToken;
  };
  icon: {
    width: any;
    height: any;
    primaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
    secondaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
  };
  heading: {
    typography: {
      color: any;
      variant: any;
      fontFamily: any;
    };
  };
  body: {
    typography: {
      color: any;
      variant: any;
      fontFamily: any;
    };
  };
};

type AlertModalTokens = {
  stroke: {
    top: {
      width: any;
      style: any;
      color: {
        error: any;
        warning: any;
        success: any;
        info: any;
      };
    };
  };
  padding: {
    mobile: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
    tablet: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
  };
  icon: {
    width: {
      mobile: any;
      tablet: any;
    };
    height: {
      mobile: any;
      tablet: any;
    };
    primaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
    secondaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
  };
  header: {
    gap: any;
    padding: {
      bottom: any;
    };
  };
  heading: {
    typography: {
      variant: any;
      fontFamily: any;
    };
  };
  body: {
    color: any;
    padding: {
      default: {
        bottom: any;
      };
      withStickyFooter: {
        bottom: any;
      };
    };
  };
  footer: {
    gap: any;
    sticky: {
      padding: {
        top: any;
        bottom: any;
      };
    };
  };
};

type AlphaTokens = {
  a0: number;
  a16: number;
  a24: number;
  a32: number;
  a48: number;
  a64: number;
  a100: number;
};

type BreakpointTokens = {
  mobile: any;
  tablet: any;
  desktop: any;
};

type ButtonTokens = {
  height: any;
  minWidth: any;
  opacity: {
    disabled: any;
  };
  topLayer: {
    height: {
      primary: any;
      secondary: any;
    };
    padding: {
      primary: {
        left: any;
        right: any;
      };
      secondary: {
        left: any;
        right: any;
      };
    };
    color: {
      primary: {
        base: any;
        hover: any;
        active: any;
      };
      secondary: {
        base: any;
        hover: any;
        active: any;
      };
    };
    backgroundColor: {
      primary: {
        base: any;
        hover: any;
        active: any;
      };
      secondary: {
        base: any;
        hover: any;
        active: any;
      };
    };
    text: {
      typography: {
        variant: any;
        fontFamily: any;
      };
    };
    icon: {
      width: ScalableSizeToken;
      height: ScalableSizeToken;
    };
    stroke: {
      width: any;
      style: any;
      radius: any;
      color: {
        primary: {
          base: any;
          hover: any;
          active: any;
        };
        secondary: {
          base: any;
          hover: any;
          active: any;
        };
      };
    };
    translateY: {
      primary: {
        base: any;
        hover: any;
        active: any;
      };
      secondary: {
        base: any;
        hover: any;
        active: any;
      };
    };
    animationDuration: number;
  };
  bottomLayer: {
    height: any;
    radius: any;
    backgroundColor: {
      primary: {
        base: any;
        hover: any;
        active: any;
      };
      secondary: {
        base: any;
        hover: any;
        active: any;
      };
    };
    shadow: {
      blur: any;
      offsetY: any;
      color: any;
    };
  };
  focusRing: {
    width: any;
    style: any;
    color: {
      primary: any;
      secondary: any;
    };
    offset: any;
  };
};

type ButtonAltTokens = {
  radius: any;
  stroke: {
    width: {
      base: any;
      error: any;
    };
    style: any;
    color: {
      base: any;
      error: any;
      active: any;
      disabled: any;
    };
  };
  minWidth: any;
  minHeight: {
    md: any;
    lg: any;
  };
  padding: {
    top: any;
    left: any;
    right: any;
    bottom: any;
  };
  backgroundColor: {
    base: any;
    hover: any;
    active: any;
    disabled: any;
  };
  color: {
    base: any;
    hover: any;
    active: any;
    disabled: any;
  };
  typography: {
    fontFamily: any;
  };
  focusRing: {
    width: any;
    style: any;
    color: any;
    offset: any;
    radius: any;
  };
};

type ButtonGroupTokens = {
  maxWidth: {
    stretch: any;
    left: any;
    center: any;
    stacked: any;
  };
  items: {
    gap: any;
  };
  panel: {
    focusRing: {
      width: any;
      style: any;
      color: any;
    };
  };
};

type ButtonTabsTokens = {
  items: {
    gap: any;
  };
  panel: {
    focusRing: {
      width: any;
      style: any;
      color: any;
    };
  };
};

type CharactersCounterTokens = {
  typography: {
    variant: any;
    fontFamily: any;
  };
  color: any;
  textAlign: any;
};

type CheckboxTokens = {
  width: any;
  height: any;
  backgroundColor: {
    unchecked: {
      base: any;
      hover: any;
      disabled: any;
    };
    checked: {
      base: any;
      hover: any;
      disabled: any;
    };
  };
  stroke: {
    radius: any;
    width: {
      unchecked: {
        base: any;
        hover: any;
        disabled: any;
        error: any;
      };
      checked: {
        base: any;
        hover: any;
        disabled: any;
        error: any;
      };
    };
    color: {
      base: any;
      hover: any;
      disabled: any;
      error: any;
    };
  };
  icon: {
    width: any;
    height: any;
    color: {
      base: any;
    };
  };
};

type CheckboxGroupTokens = {
  gap: any;
  list: {
    gap: any;
  };
  nestedList: {
    paddingLeft: any;
  };
};

type ColorTokens = {
  black?: any;
  darkGrey?: any;
  mediumGrey?: any;
  lightGrey?: any;
  groundGrey?: any;
  white?: any;
  dmPrimary?: any;
  dmSecondary?: any;
  ragRed?: any;
  dmRagRed?: any;
  lightRagRed?: any;
  dmDarkRagRed?: any;
  ragAmber?: any;
  lightRagAmber?: any;
  dmDarkRagAmber?: any;
  ragGreen?: any;
  lightRagGreen?: any;
  dmDarkRagGreen?: any;

  // Bank of Ireland colours
  digitalBlue?: any;
  darkDigitalBlue?: any;
  navyBlue?: any;
  dmSkyBlue?: any;
  dmDarkSkyBlue?: any;
  dmCelestialBlue?: any;
  blue?: any;
  lightBlue?: any;
  darkBlue?: any;
  teal?: any;
  lightTeal?: any;
  darkTeal?: any;
  lime?: any;
  lightLime?: any;
  darkLime?: any;
  honey?: any;
  lightHoney?: any;
  darkHoney?: any;

  // New Ireland colours
  sandGrey?: any;
  forestGreen?: any;
  dmForestGreen?: any;
  darkForestGreen?: any;
  dmDarkForestGreen?: any;
  forestFloorGreen?: any;
  dmForestFloorGreen?: any;
  emerald?: any;
  lightEmerald?: any;
  darkEmerald?: any;
  sky?: any;
  lightSky?: any;
  darkSky?: any;
  grass?: any;
  lightGrass?: any;
  darkGrass?: any;
  sun?: any;
  lightSun?: any;
  darkSun?: any;

  // Davy colours
  digitalRed?: any;
  darkDigitalRed?: any;
  darkRed?: any;
  dmDigitalRed?: any;
  dmDarkDigitalRed?: any;
  dmDarkRed?: any;
  warmGrey?: any;
  green?: any;
  lightGreen?: any;
  darkGreen?: any;
  turquoise?: any;
  lightTurquoise?: any;
  darkTurquoise?: any;
  lightNavy?: any;
  darkNavy?: any;
};

type DatePickerTokens = {
  gap: any;
  input: {
    radius: any;
    minHeight: any;
    padding: {
      left: any;
      right: any;
    };
    backgroundColor: any;
    stroke: {
      width: {
        base: any;
        error: any;
        active: any;
      };
      style: any;
      color: {
        base: any;
        error: any;
        active: any;
      };
      offset: {
        base: any;
        error: any;
        active: any;
      };
    };
    segment: {
      radius: any;
      padding: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
      typography: {
        variant: any;
        fontFamily: any;
      };
      placeholderColor: any;
      separatorColor: any;
      color: {
        base: any;
        focus: any;
        hover: any;
        disabled: any;
      };
      backgroundColor: {
        base: any;
        focus: any;
        hover: any;
      };
    };
    button: {
      radius: any;
      padding: any;
      backgroundColor: {
        base: any;
        focus: any;
        hover: any;
      };
      icon: {
        width: any;
        height: any;
        color: {
          base: any;
          focus: any;
          hover: any;
        };
        opacity: {
          base: any;
          disabled: any;
        };
      };
    };
  };
  calendar: {
    gap: any;
    radius: any;
    padding: any;
    backgroundColor: any;
    stroke: {
      width: any;
      style: any;
      color: any;
    };
    header: {
      margin: {
        left: any;
        right: any;
      };
    };
    heading: {
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
      };
    };
    button: {
      radius: any;
      padding: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
      backgroundColor: {
        base: any;
        focus: any;
        hover: any;
      };
      focusRing: {
        width: any;
        style: any;
        color: any;
        offset: any;
      };
      icon: {
        width: any;
        height: any;
        color: {
          base: any;
          focus: any;
          hover: any;
        };
      };
    };
    headerCell: {
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
      };
    };
    cell: {
      minWidth: any;
      radius: any;
      margin: any;
      padding: any;
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
      };
      backgroundColor: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
      };
      focusRing: {
        width: any;
        style: any;
        color: any;
        offset: any;
      };
    };
    shadow: {
      outer: {
        color: any;
      };
    };
    zIndex: any;
  };
};

type FieldsetTokens = {
  gap: any;
  legend: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    color: any;
  };
  legendHint: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    color: any;
  };
};

type FontFamilyTokens = {
  OpenSansItalic: any;
  OpenSansRegular: any;
  OpenSansSemiBold: any;
  OpenSansSemiBoldItalic: any;
  OpenSansBold: any;
  BrandHeading: any;
};

type IconButtonTokens = {
  padding: {
    default: any;
    default16: any;
    default20: any;
    default32: any;
    contained: any;
  };
  inner: {
    radius: {
      default: any;
      default16: any;
      default20: any;
      default32: any;
      contained: any;
    };
    stroke: {
      contained: {
        width: any;
        style: any;
        color: {
          base: any;
          hover: any;
          active: any;
        };
        offset: any;
      };
    };
    backgroundColor: {
      default: {
        base: any;
        hover: any;
        active: any;
      };
      default16: {
        base: any;
        hover: any;
        active: any;
      };
      default20: {
        base: any;
        hover: any;
        active: any;
      };
      default32: {
        base: any;
        hover: any;
        active: any;
      };
      contained: {
        base: any;
        hover: any;
        active: any;
      };
    };
    padding: {
      default: any;
      default16: any;
      default20: any;
      default32: any;
      contained: any;
    };
    opacity: {
      base: any;
      disabled: any;
    };
    icon: {
      width: {
        default: any;
        default16: any;
        default20: any;
        default32: any;
        contained: any;
      };
      height: {
        default: any;
        default16: any;
        default20: any;
        default32: any;
        contained: any;
      };
      color: {
        base: any;
        hover: any;
        active: any;
      };
    };
    focusRing: {
      width: any;
      style: any;
      color: any;
      offset: {
        default: any;
        default16: any;
        default20: any;
        default32: any;
        contained: any;
      };
    };
  };
};

type IconButtonMenuTokens = {
  menu: {
    item: {
      content: {
        gap: any;
        padding: {
          top: any;
          left: any;
          right: any;
          bottom: any;
        };
        iconWrapper: {
          height: any;
        };
        icon: {
          width: any;
          height: any;
        };
        text: {
          typography: {
            variant: any;
            fontFamily: any;
          };
        };
      };
    };
  };
};

type IllustrationTokens = {
  hueA: {
    highlight: string;
    stroke: string;
    fill: string;
  };
  hueB: {
    highlight: string;
    stroke: string;
    fill: string;
  };
  hueC: {
    highlight: string;
    stroke: string;
    fill: string;
  };
  hueD: {
    highlight: string;
    stroke: string;
    fill: string;
  };
};

type InlineAlertTokens = {
  gap: any;
  color: {
    error: any;
    warning: any;
    success: any;
    info: any;
  };
  iconWrapper: {
    height: ScalableSizeToken;
  };
  icon: {
    width: any;
    height: any;
    primaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
    secondaryColor: {
      error: any;
      warning: any;
      success: any;
      info: any;
    };
  };
};

type InputLabelRightTokens = {
  gap: any;
  inputWrapper: {
    height: any;
  };
  label: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    color: {
      base: any;
      disabled: any;
    };
  };
  focusRing: {
    width: any;
    style: any;
    color: any;
    offset: any;
    radius: any;
  };
};

type InputLabelTopTokens = {
  gap: any;
  label: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    color: any;
  };
  labelHint: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    color: any;
  };
};

type LinkTokens = {
  typography: {
    variant: any;
    fontFamily: any;
  };
  color: {
    base: any;
    hover: any;
    active: any;
    visited: any;
  };
  backgroundColor: {
    base: any;
    active: any;
  };
  decoration: {
    line: {
      base: any;
      focus: any;
    };
    thickness: {
      base: any;
      hover: any;
      active: any;
    };
    style: {
      solid: any;
      dashed: any;
    };
    offset: any;
  };
  focusRing: {
    width: any;
    style: any;
    color: any;
    offset: any;
    radius: any;
  };
  withIcon: {
    gap: any;
    size: {
      bodyM: ScalableSizeToken;
      bodyS: ScalableSizeToken;
    };
  };
};

type ModalTokens = {
  breakpoints: {
    mobile: any;
    tablet: any;
  };
  backdrop: {
    backgroundColor: any;
  };
  width: {
    mobile: any;
    tablet: any;
  };
  minWidth: {
    mobile: any;
    tablet: any;
  };
  maxWidth: {
    mobile: any;
    tablet: any;
  };
  minHeight: {
    mobile: any;
    tablet: any;
  };
  maxHeight: {
    mobile: any;
    tablet: any;
  };
  radius: any;
  padding: {
    mobile: any;
    tablet: any;
  };
  backgroundColor: any;
};

type MenuTokens = {
  radius: any;
  stroke: {
    width: any;
    style: any;
    color: any;
    offset: any;
  };
  maxWidth: any;
  backgroundColor: {
    base: any;
  };
  option: {
    minHeight: any;
    padding: any;
    backgroundColor: {
      base: any;
    };
    inner: {
      padding: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
      radius: any;
      stroke: {
        width: any;
        style: any;
        color: {
          base: any;
          hover: any;
          active: any;
          selected: any;
        };
        offset: any;
      };
      color: {
        base: any;
      };
      backgroundColor: {
        base: any;
        hover: any;
        active: any;
        selected: any;
      };
    };
  };
  separator: {
    width: any;
    style: any;
    color: any;
  };
  shadow: {
    outer: {
      color: any;
    };
  };
  zIndex: any;
};

type MultiSelectTokens = {
  button: {
    headingText: {
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
        disabled: any;
      };
    };
    selectedText: {
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
        disabled: any;
      };
    };
    gap: any;
    padding: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
  };
  menu: {
    option: {
      minHeight: any;
      padding: any;
      backgroundColor: {
        base: any;
      };
      inner: {
        gap: any;
        padding: {
          top: any;
          left: any;
          right: any;
          bottom: any;
        };
        radius: any;
        color: {
          base: any;
        };
        backgroundColor: {
          base: any;
          hover: any;
          active: any;
          selected: any;
        };
        checkboxWrapper: {
          height: ScalableSizeToken;
        };
        text: {
          typography: {
            variant: any;
            fontFamily: any;
          };
        };
      };
    };
  };
};

type OuterFieldTokens = {
  radius: any;
  minHeight: any;
  backgroundColor: any;
  gap: any;
  focusRing: {
    color: any;
    width: {
      base: any;
      focus: any;
    };
    offset: {
      base: any;
      focus: any;
    };
    style: any;
  };
  stroke: {
    width: {
      base: any;
      error: any;
      hover: any;
      active: any;
    };
    offset: {
      base: any;
      hover: any;
      active: any;
      error: any;
    };
    style: any;
    color: {
      base: any;
      disabled: any;
      error: any;
      active: any;
      hover: any;
      readOnly: any;
    };
  };
  column01: {
    gap: any;
    padding: {
      left: any;
      right: {
        base: any;
        withButton: any;
      };
    };
    startSlot: {
      width: any;
      height: any;
      color: any;
    };
    innerButtonSlot: {
      margin: any;
    };
    endSlot: {
      width: any;
      height: any;
      color: any;
    };
  };
  column02: {
    padding: {
      right: any;
    };
  };
};

type ProgressIndicatorTokens = {
  label: {
    text: {
      color: any;
      typography: {
        variant: {
          mobile: any;
          tablet: any;
        };
        fontFamily: any;
      };
    };
    marginBottom: any;
  };
  segments: {
    gap: {
      mobile: any;
      tablet: any;
    };
    segment: {
      radius: any;
      borderTopLeftRadius: {
        first: any;
      };
      borderBottomLeftRadius: {
        first: any;
      };
      borderTopRightRadius: {
        last: any;
      };
      borderBottomRightRadius: {
        last: any;
      };
      height: {
        mobile: any;
        tablet: any;
      };
      background: {
        filled: any;
        notFilled: any;
        notFilledAlt: any;
      };
    };
  };
};

type RadioTokens = {
  width: any;
  height: any;
  backgroundColor: {
    base: any;
  };
  stroke: {
    width: {
      base: any;
      error: any;
      hover: any;
      disabled: any;
    };
    style: {
      base: any;
    };
    color: {
      base: any;
      error: any;
      hover: any;
      disabled: any;
    };
  };
  icon: {
    width: any;
    height: any;
    color: {
      base: any;
      hover: any;
      disabled: any;
    };
  };
};

type RadioGroupTokens = {
  gap: any;
  list: {
    gap: any;
  };
};

type RadiusTokens = {
  r0: any;
  r4: any;
  r8: any;
  r16: any;
  r24: any;
};

type ScrollBarTokens = {
  thumbColor: any;
  trackColor: any;
  radius: any;
};

type ScrollShadowContainerTokens = {
  shadow: {
    color: any;
  };
  focusRing: {
    width: any;
    style: any;
    color: any;
    offset: any;
  };
};

type SearchInput = {
  icon: {
    width: any;
    height: any;
  };
};

type SelectTokens = {
  gap: any;
  button: {
    minHeight: any;
    gap: any;
    padding: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
    backgroundColor: {
      base: any;
    };
    stroke: {
      width: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
        error: any;
      };
      style: any;
      color: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
        error: any;
      };
      offset: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
        error: any;
      };
      radius: any;
    };
    focusRing: {
      width: any;
      style: any;
      color: any;
      offset: any;
      radius: any;
    };
    placeholder: {
      color: {
        base: any;
        disabled: any;
      };
    };
    text: {
      typography: {
        variant: any;
        fontFamily: any;
      };
      color: {
        base: any;
        disabled: any;
      };
    };
    icon: {
      width: any;
      height: any;
      color: {
        base: any;
        hover: any;
        active: any;
        disabled: any;
      };
    };
  };
  menu: {
    radius: any;
    stroke: {
      width: any;
      style: any;
      color: any;
      offset: any;
    };
    backgroundColor: {
      base: any;
    };
    option: {
      minHeight: any;
      padding: any;
      backgroundColor: {
        base: any;
      };
      inner: {
        gap: any;
        padding: {
          top: any;
          left: any;
          right: any;
          bottom: any;
        };
        radius: any;
        stroke: {
          width: any;
          style: any;
          color: {
            base: any;
            hover: any;
            active: any;
            selected: any;
          };
          offset: any;
        };
        color: {
          base: any;
          disabled: any;
        };
        backgroundColor: {
          base: any;
          hover: any;
          active: any;
          selected: any;
        };
        tickIconWrapper: {
          width: any;
          height: ScalableSizeToken;
        };
        tickIcon: {
          width: any;
          height: any;
          color: any;
        };
        iconWrapper: {
          height: ScalableSizeToken;
        };
        icon: {
          width: any;
          maxHeight: any;
          color: any;
          opacity: {
            base: any;
            disabled: any;
          };
        };
        text: {
          typography: {
            variant: any;
            fontFamily: any;
          };
        };
      };
    };
    separator: {
      width: any;
      style: any;
      color: any;
    };
    shadow: {
      outer: {
        color: any;
      };
    };
    zIndex: any;
  };
};

type SliderTokens = {
  track: {
    padding: any;
    color: any;
    size: any;
  };
  notch: {
    size: any;
    color: any;
  };
  tooltip: {
    minWidth: any;
    arrowWidth: any;
  };
  thumb: {
    size: any;
    primaryColor: {
      base: any;
      hover: any;
      active: any;
    };
    secondaryColor: {
      base: any;
      hover: any;
      active: any;
    };
    focusRing: {
      color: any;
      width: any;
      offset: any;
    };
  };
};

type SpacingTokens = {
  s0: any;
  s2: any;
  s4: any;
  s8: any;
  s12: any;
  s16: any;
  s24: any;
  s32: any;
  s40: any;
  s48: any;
  s56: any;
  s64: any;
  s72: any;
  s80: any;
  s88: any;
  s96: any;
  s104: any;
  s112: any;
  s120: any;
  s128: any;
  s136: any;
};

type SpinnerTokens = {
  borderRatio: any;
  backgroundOpacity: any;
  variants: {
    default: {
      size: any;
      color: any;
    };
    buttonPrimary: {
      size: any;
      color: any;
    };
    buttonSecondary: {
      size: any;
      color: any;
    };
  };
};

type StandardModalTokens = {
  header: {
    stroke: {
      bottom: {
        width: any;
        style: any;
        color: any;
      };
    };
    padding: {
      mobile: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
      tablet: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
    };
    gap: any;
    heading: {
      typography: {
        variant: any;
        fontFamily: any;
      };
    };
    closeButton: {
      width: any;
      height: any;
      variant: any;
    };
  };
  content: {
    padding: {
      mobile: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
      tablet: {
        top: any;
        left: any;
        right: any;
        bottom: any;
      };
    };
    gap: any;
    heading: {
      typography: {
        variant: any;
        fontFamily: any;
      };
    };
  };
  footer: {
    height: {
      mobile: any;
      tablet: any;
    };
  };
};

type TableTokens = {
  stroke: {
    bottom: {
      width: any;
      style: any;
      color: any;
    };
  };
  head: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    backgroundColor: any;
    stroke: {
      bottom: {
        width: any;
        style: any;
        color: any;
      };
    };
    cell: {
      padding: {
        top: any;
        left: {
          base: any;
          first: any;
          last: any;
        };
        right: {
          base: any;
          first: any;
          last: any;
        };
        bottom: any;
      };
    };
  };
  body: {
    typography: {
      variant: any;
      fontFamily: any;
    };
    row: {
      backgroundColor: {
        odd: any;
        even: any;
      };
    };
    cell: {
      padding: {
        top: any;
        left: {
          base: any;
          first: any;
          last: any;
        };
        right: {
          base: any;
          first: any;
          last: any;
        };
        bottom: any;
      };
    };
  };
};

type TabsTokens = {
  mobile: {
    radius: {
      topLeft: any;
      topRight: any;
    };
    padding: {
      top: any;
      left: any;
      right: any;
      bottom: any;
    };
    backgroundColor: any;
    strokeTop: {
      width: any;
      style: any;
      color: any;
    };
  };
  desktop: {
    heading: {
      typography: {
        variant: any;
        fontFamily: any;
      };
    };
    container: {
      gap: any;
      padding: {
        right: any;
      };
    };
    tab: {
      radius: {
        topLeft: any;
        topRight: any;
      };
      padding: {
        top: any;
        bottom: any;
        left: {
          base: any;
          withIcon: any;
        };
        right: {
          base: any;
          withIcon: any;
        };
      };
      backgroundColor: {
        base: any;
        hover: any;
        active: any;
      };
      label: {
        typography: {
          variant: any;
          fontFamily: any;
        };
        color: {
          base: any;
          hover: any;
          active: any;
          disabled: any;
        };
      };
      secondaryLabel: {
        typography: {
          variant: any;
          fontFamily: any;
        };
        color: {
          base: any;
          disabled: any;
        };
      };
      icon: {
        width: any;
        height: any;
        color: {
          base: any;
          hover: any;
          active: any;
          disabled: any;
        };
      };
      strokeTop: {
        width: any;
        style: any;
        color: {
          base: any;
          active: any;
        };
      };
      activeRing: {
        width: any;
        style: any;
        color: any;
        offset: any;
      };
      focusRing: {
        radius: {
          topLeft: any;
          topRight: any;
          bottomLeft: any;
          bottomRight: any;
        };
        width: any;
        style: any;
        color: any;
        offset: any;
      };
      separator: {
        marginTop: any;
        width: any;
        color: any;
      };
    };
  };
  panel: {
    padding: {
      top: any;
      bottom: any;
      left: {
        base: any;
        withIcon: any;
      };
      right: {
        base: any;
        withIcon: any;
      };
    };
    backgroundColor: any;
    strokeTop: {
      width: any;
      style: any;
      color: any;
    };
    focusRing: {
      width: any;
      style: any;
      color: any;
    };
  };
};

type TextAreaTokens = {
  charactersCounter: CharactersCounterTokens;
  outerField: OuterFieldTokens;
  scrollBar: ScrollBarTokens;
  minHeight: any;
  paddingHorizontal: any;
  paddingVertical: any;
  typography: {
    variant: any;
    fontFamily: any;
  };
  color: {
    base: any;
    disabled: any;
    placeholder: any;
    readOnly: any;
  };
  selectionColor: any;
  innerShadow: {
    color: any;
    height: any;
    opacity: {
      inactive: any;
      active: any;
    };
  };
};

type TextInputTokens = {
  charactersCounter: CharactersCounterTokens;
  outerField: OuterFieldTokens;
  height: any;
  paddingLeft: any;
  paddingRight: any;
  typography: {
    variant: any;
    fontFamily: any;
  };
  color: {
    base: any;
    disabled: any;
    placeholder: any;
    readOnly: any;
  };
  selectionColor: any;
  prefix: {
    color: any;
    marginRight: any;
    typography: {
      variant: any;
      fontFamily: any;
    };
  };
  icon: {
    marginLeft: any;
  };
};

type ThemeColorTokens = {
  core100: any;
  core125: any;
  core150: any;
  base100: any;
  base150: any;
  base200: any;
  base200e: any;
  base400: any;
  base500: any;
  base700: any;
  hueA100: any;
  hueA300: any;
  hueA500: any;
  hueB100: any;
  hueB300: any;
  hueB500: any;
  hueC100: any;
  hueC300: any;
  hueC500: any;
  hueD100: any;
  hueD300: any;
  hueD500: any;
  ragRed: any;
  ragRedText: any;
  ragRedBase: any;
  ragAmber: any;
  ragAmberBase: any;
  ragGreen: any;
  ragGreenBase: any;
};

type ToggleTokens = {
  size: {
    small: {
      width: ScalableSizeToken;
      height: any;
    };
    default: {
      width: ScalableSizeToken;
      height: any;
    };
  };
  focusRing: {
    color: any;
    width: any;
    offset: any;
  };
  backgroundColor: {
    unchecked: {
      base: any;
      hover: any;
      disabled: any;
    };
    checked: {
      base: any;
      hover: any;
      disabled: any;
    };
  };
  text: {
    color: {
      base: any;
      disabled: any;
    };
    size: {
      small: {
        typography: {
          variant: any;
          fontFamily: any;
        };
      };
      default: {
        typography: {
          variant: any;
          fontFamily: any;
        };
      };
    };
  };
  thumb: {
    padding: any;
    size: {
      small: any;
      default: any;
    };
    backgroundColor: {
      base: any;
      disabled: any;
    };
    shadowColor: any;
  };
};

type TooltipTokens = {
  radius: any;
  maxWidth: any;
  padding: {
    top: any;
    bottom: any;
    left: any;
    right: {
      default: any;
      large: any;
    };
  };
  backgroundColor: any;
  typography: {
    variant: any;
    fontFamily: any;
  };
  color: any;
  closeButton: {
    width: any;
    height: any;
    icon: {
      width: any;
      height: any;
      radius: any;
      color: {
        base: any;
        hover: any;
        active: any;
      };
      backgroundColor: {
        base: any;
        hover: any;
        active: any;
      };
      focusRing: {
        width: any;
        style: any;
        color: any;
      };
    };
  };
  arrow: {
    width: any;
    height: any;
  };
  zIndex: any;
};

type TooltipIconButtonTokens = {
  icon: {
    primaryColor: {
      base: any;
      hover: any;
    };
    secondaryColor: {
      base: any;
      hover: any;
    };
  };
  iconFilled: {
    primaryColor: {
      base: any;
      hover: any;
    };
    secondaryColor: {
      base: any;
    };
  };
};

type TypographyTokens = {
  fontSize: {
    displayXL: string | number;
    displayL: string | number;
    displayM: string | number;
    displayS: string | number;
    headlineL: string | number;
    headlineM: string | number;
    headlineS: string | number;
    headlineXS: ScalableSizeToken;
    titleL: string | number;
    titleM: string | number;
    titleS: string | number;
    titleXS: ScalableSizeToken;
    bodyL: ScalableSizeToken;
    bodyM: ScalableSizeToken;
    bodyS: ScalableSizeToken;
    labelM: ScalableSizeToken;
    labelS: ScalableSizeToken;
  };
  color: {
    displayXL: any;
    displayL: any;
    displayM: any;
    displayS: any;
    headlineL: any;
    headlineM: any;
    headlineS: any;
    headlineXS: any;
    titleL: any;
    titleM: any;
    titleS: any;
    titleXS: any;
    bodyL: any;
    bodyM: any;
    bodyS: any;
    labelM: any;
    labelS: any;
  };
  lineHeight: {
    displayXL: string | number;
    displayL: string | number;
    displayM: string | number;
    displayS: string | number;
    headlineL: string | number;
    headlineM: string | number;
    headlineS: string | number;
    headlineXS: ScalableSizeToken;
    titleL: string | number;
    titleM: string | number;
    titleS: string | number;
    titleXS: ScalableSizeToken;
    bodyL: ScalableSizeToken;
    bodyM: ScalableSizeToken;
    bodyS: ScalableSizeToken;
    labelM: ScalableSizeToken;
    labelS: ScalableSizeToken;
  };
  fontFamily: {
    displayXL: any;
    displayL: any;
    displayM: any;
    displayS: any;
    headlineL: any;
    headlineM: any;
    headlineS: any;
    headlineXS: any;
    titleL: any;
    titleM: any;
    titleS: any;
    titleXS: any;
    bodyL: any;
    bodyM: any;
    bodyS: any;
    labelM: any;
    labelS: any;
  };
};

type ZIndexTokens = {
  modal: number;
  drawer: number;
  navigation: number;
  formMenu: number;
  tooltip: number;
  base: number;
};

export type ThemeTokens = {
  accordion: AccordionTokens;
  accordionGroup: AccordionGroupTokens;
  alert: AlertTokens;
  alertModal: AlertModalTokens;
  alpha: AlphaTokens;
  breakpoint: BreakpointTokens;
  button: ButtonTokens;
  buttonAlt: ButtonAltTokens;
  buttonGroup: ButtonGroupTokens;
  buttonTabs: ButtonTabsTokens;
  charactersCounter: CharactersCounterTokens;
  checkbox: CheckboxTokens;
  checkboxGroup: CheckboxGroupTokens;
  color: ColorTokens;
  datePicker: DatePickerTokens;
  fieldset: FieldsetTokens;
  fontFamily: FontFamilyTokens;
  iconButton: IconButtonTokens;
  iconButtonMenu: IconButtonMenuTokens;
  illustration: IllustrationTokens;
  inlineAlert: InlineAlertTokens;
  inputLabelRight: InputLabelRightTokens;
  inputLabelTop: InputLabelTopTokens;
  link: LinkTokens;
  modal: ModalTokens;
  menu: MenuTokens;
  multiSelect: MultiSelectTokens;
  outerField: OuterFieldTokens;
  progressIndicator: ProgressIndicatorTokens;
  radio: RadioTokens;
  radioGroup: RadioGroupTokens;
  radius: RadiusTokens;
  scrollBar: ScrollBarTokens;
  scrollShadowContainer: ScrollShadowContainerTokens;
  searchInput: SearchInput;
  select: SelectTokens;
  slider: SliderTokens;
  spacing: SpacingTokens;
  spinner: SpinnerTokens;
  standardModal: StandardModalTokens;
  table: TableTokens;
  tabs: TabsTokens;
  textArea: TextAreaTokens;
  textInput: TextInputTokens;
  themeColor: ThemeColorTokens;
  toggle: ToggleTokens;
  tooltip: TooltipTokens;
  tooltipIconButton: TooltipIconButtonTokens;
  typography: TypographyTokens;
  zIndex: ZIndexTokens;
};
