# React Native Patches

Collection of patches applied to react-native and its ecosystem dependencies.
The change in each patch is described in the corresponding md file.

## Installation

```console
npm i @boi/react-native-patches
```

## Usage

After installing. Add the postinstall script to your `package.json`

```json
"postinstall": "patch-package --patch-dir ./node_modules/@boi/react-native-patches/src",
```
