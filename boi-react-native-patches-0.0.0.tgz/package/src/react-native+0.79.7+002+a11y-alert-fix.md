# Patch Keyboard Focus for Alert Components: MAT-41529

A patch for `react-native` to ensure proper focus behavior on Alert buttons.

---

## Description

This patch modifies the `show:animated:completion:` method to handle Keyboard Accessibility (FKA) updates more selectively:

- **For iOS 16 and below:** The patch retains the manual focus update logic to ensure proper keyboard focus behavior.
- **For iOS 17 and above:** UIKit now manages accessibility focus automatically, making custom `customFocusView` and `setNeedsFocusUpdate` calls unnecessary. These calls are skipped to prevent conflicts and redundant updates.

This change ensures compatibility with older iOS versions while leveraging the system's built-in focus handling on newer versions, reducing potential glitches.

---

## Links

- [Bitbucket Pull Request](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/4391/overview)
- [JIRA Task: MAT-41529](https://bitbucket.devops.boicssp.net/plugins/servlet/jira-integration/issues/MAT-41529)
