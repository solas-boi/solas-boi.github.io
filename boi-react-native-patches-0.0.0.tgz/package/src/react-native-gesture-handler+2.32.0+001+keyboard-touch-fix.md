# Update `react-native-gesture-handler` for Integration with RNEK: MAT-45501

A patch for `react-native-gesture-handler` to ensure proper keyboard focus functionality.

---

### See More

- [Patch for `react-native-external-keyboard`](./react-native-external-keyboard+0.6.6+001+rngh-keyboard-touch-fix.md)
