# Keyboard Focus Restore Fix: MAT-36488

A patch for `react-native` to ensure proper restoration of keyboard focus when closing modals.

---

### See More

- [Patch for `@react-navigation/elements`](./@react-navigation+elements+1.3.31+001+keyboard-focus.md)
- [Patch for `@react-navigation/native-stack`](./@react-navigation+native-stack+6.9.13+001+keyboard-focus.md)
