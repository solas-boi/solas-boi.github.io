# Restore Accessibility Focus for Modals on iOS: MAT-36710

A patch for `react-native` to ensure proper focus restoration when closing modals or switching screens.

---

## Description

By default, iOS does not support accessibility focus recovery when switching screens or dismissing modals. This patch addresses the issue for older versions of React Native by implementing a custom focus restoration behavior.

The solution is inspired by the implementation introduced in [React Native Pull Request #52970](https://github.com/facebook/react-native/pull/52970) for newer React Native versions, ensuring consistent behavior across legacy projects.

---

## Links

- [React Native Pull Request](https://github.com/facebook/react-native/pull/52970)
- [Bitbucket Pull Request](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/4611/overview)
- [JIRA Task: MAT-36710](https://bitbucket.devops.boicssp.net/plugins/servlet/jira-integration/issues/MAT-36710)
