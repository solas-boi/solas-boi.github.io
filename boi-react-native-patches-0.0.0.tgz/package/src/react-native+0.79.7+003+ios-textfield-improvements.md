# VoiceOver Patch for TextInput: MAT-40224, MAT-50692

A patch for `react-native` to ensure proper focus behavior on iOS.

---

## Description

This patch modifies the `TextInput` component in `react-native` to address issues with VoiceOver focus. It ensures that the focus is restored to the initial component once the SoftKeyboard is dismissed and that the `TextInput.focus()` functionality moves VoiceOver focus to the input as expected.

This patch resolves the following issues:

1. **[MAT-40224]** Ensure VoiceOver focus is restored to the appropriate component after the SoftKeyboard is dismissed.
2. **[MAT-50692]** Ensure that calling `ref.focus()` not only makes the `TextInput` the first responder but also correctly shifts VoiceOver focus to the input.

---

## Links

- [Bitbucket Pull Request: MAT-40224](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/4657/overview)
- [Bitbucket Pull Request: MAT-50692](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/5319/overview)
- [JIRA Task: MAT-40224](https://jira.boigroup.net/browse/MAT-40224)
- [JIRA Task: MAT-50692](https://jira.boigroup.net/browse/MAT-50692)
