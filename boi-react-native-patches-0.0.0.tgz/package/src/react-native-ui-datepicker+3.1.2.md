# DatePickerV2 Calendar Accessibility and Focus Order: CP-94066, CP-103025

A patch for `react-native-ui-datepicker` to improve keyboard and screen reader accessibility in DatePickerV2, including explicit tab focus order for calendar navigation and skipping disabled days during TalkBack and external-keyboard navigation.

---

## Description

### What the Patch Does

- Replaces React Native `Pressable` usage with `react-native-external-keyboard` `Pressable` in calendar day, header, month/year selector, and time-period components to support advanced keyboard focus handling.
- Keeps accessibility labels explicit for navigation buttons:
  - Previous button: `Previous month`
  - Next button: `Next month`
- Adds explicit focus link order for calendar navigation in single-date mode:
  - Initial focus starts on the left navigation arrow (`btn-prev`) when calendar opens.
  - Pressing Tab from the left arrow moves focus to selected day (or today if no selected day).
  - Pressing Tab again moves focus to the right navigation arrow (`btn-next`).
- Accessibility focus-order updates are also tracked under CP-95582.
- Adds stable focus IDs to day cells based on date (`datepicker-day-YYYY-MM-DD`) and links them to nav buttons (`datepicker-nav-prev`, `datepicker-nav-next`).
- Keeps disabled calendar days out of TalkBack and external-keyboard focus so disabled dates are skipped during navigation.
- Preserves keyboard-compatible styling by using `containerStyle` where needed for external keyboard `Pressable`.
- Retains prior typography accessibility tweaks (`allowFontScaling={false}`) for month/year selector labels.

### Files Updated in Patched Dependency

- `src/components/day.tsx`
- `src/components/header/prev-button.tsx`
- `src/components/header/next-button.tsx`
- `src/components/header/month-button.tsx`
- `src/components/header/time-button.tsx`
- `src/components/header/year-button.tsx`
- `src/components/months.tsx`
- `src/components/time-picker/period-web.tsx`
- `src/components/years.tsx`

---

## Links

- [Bitbucket Pull Request](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/4229/overview)
- [JIRA Task: CP-94066](https://jira.boigroup.net/browse/CP-94066)
- [Related JIRA Task (A11y Focus Order): CP-103025](https://jira.boigroup.net/browse/CP-103025)
