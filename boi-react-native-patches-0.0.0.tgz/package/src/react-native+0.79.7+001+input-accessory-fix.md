# Input Accessory Recycle Dependency Patch: MAT-39735

A patch for `react-native` to resolve modal display issues caused by the `accessoryInputView` recycling problem.

---

## Description

This patch addresses an issue in `react-native` where the `accessoryInputView` component is not properly recycled. This bug results in extra space appearing between the keyboard and the modal, causing layout inconsistencies.

---

## Notes

- This patch can be removed once the project is upgraded to `react-native` version `v0.82.0`.

---

## Additional References

- [React Native Commit](https://github.com/facebook/react-native/commit/eb08f545948de9e2eca91ab3cb7569670c553b15)

---

## Links

- [Bitbucket Pull Request](https://bitbucket.devops.boicssp.net/projects/BOI-FRONT-END-LIBRARIES/repos/boi-monorepo/pull-requests/3914/overview)
- [JIRA Task: MAT-39735](https://jira.boigroup.net/browse/MAT-39735)
