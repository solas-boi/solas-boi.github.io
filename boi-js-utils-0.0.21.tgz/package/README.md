# JS utils

Set of JavaScript utility functions used for Bank of Ireland.

## Installation

```console
npm i @boi/js-utils
```

## Usage

```jsx
import { getEnvFromString } from "@boi/js-utils";
```
