import { StyleSheet, type PressableStateCallbackType } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { CoreAccordion } from "@boi/components-core";

import { type AccordionProps } from "./Accordion";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { accordion } = tokens;

  return StyleSheet.create({
    container: {
      borderWidth: accordion.stroke.width,
      borderStyle: accordion.stroke.style,
      borderColor: accordion.stroke.color,
      borderRadius: accordion.stroke.radius,
    },
    containerVariantDefault: {
      backgroundColor: accordion.background.default,
    },
    containerVariantNested: {
      backgroundColor: accordion.background.nested,
    },
    header: {
      position: "relative",
      padding: accordion.header.padding,
    },
    headerVariantDefault: {
      minHeight: accordion.header.minHeight.default,
    },
    headerVariantNested: {
      minHeight: accordion.header.minHeight.nested,
    },
    headerInner: {
      display: "flex",
      flexDirection: "row",
      flexGrow: 1,
      gap: accordion.header.inner.gap,
      alignItems: "center",
      paddingLeft: accordion.header.inner.padding.left,
      paddingRight: accordion.header.inner.padding.right,
      borderRadius: accordion.header.inner.radius,
      backgroundColor: accordion.header.inner.backgroundColor.base,
    },
    headerInnerPressedVariantDefault: {
      backgroundColor: accordion.header.inner.backgroundColor.active.default,
    },
    headerInnerPressedVariantNested: {
      backgroundColor: accordion.header.inner.backgroundColor.active.nested,
    },
    headerInnerVariantDefault: {
      paddingTop: accordion.header.inner.padding.top.default,
      paddingBottom: accordion.header.inner.padding.bottom.default,
    },
    headerInnerVariantNested: {
      paddingTop: accordion.header.inner.padding.top.nested,
      paddingBottom: accordion.header.inner.padding.bottom.nested,
    },
    headerTextWrapper: {
      flex: 1,
    },
    headerText: {
      color: accordion.header.text.color.base,
    },
    headerTextPressed: {
      color: accordion.header.text.color.active,
    },
    headerIconWrapper: {
      transform: [{ rotate: "0deg" }],
    },
    headerIconWrapperOpen: {
      transform: [{ rotate: "180deg" }],
    },
    headerIcon: {
      width: accordion.header.icon.width,
      height: accordion.header.icon.height,
    },
    separator: {
      position: "absolute",
      bottom: -1,
      left: 0,
      right: 0,
      display: "none",
      height: accordion.separator.stroke.width,
      marginLeft: accordion.separator.margin.left,
      marginRight: accordion.separator.margin.right,
      borderTopWidth: accordion.separator.stroke.width,
      borderStyle: accordion.separator.stroke.style,
      borderTopColor: accordion.separator.stroke.color,
    },
    separatorOpen: {
      display: "flex",
    },
    content: {
      display: "none",
      padding: accordion.content.padding,
    },
    contentVisible: {
      display: "flex",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant = CoreAccordion.DEFAULT_VARIANT,
  isOpen,
}: Pick<AccordionProps, "variant" | "isOpen">) {
  const styles = useStyles();

  const containerVariantStyles = {
    default: styles.containerVariantDefault,
    nested: styles.containerVariantNested,
  };

  const headerVariantStyles = {
    default: styles.headerVariantDefault,
    nested: styles.headerVariantNested,
  };

  const headerInnerVariantStyles = {
    default: styles.headerInnerVariantDefault,
    nested: styles.headerInnerVariantNested,
  };

  const headerInnerPressedVariantStyles = {
    default: styles.headerInnerPressedVariantDefault,
    nested: styles.headerInnerPressedVariantNested,
  };

  return {
    container: [styles.container, containerVariantStyles[variant]],
    header: [styles.header, headerVariantStyles[variant]],
    headerInner: ({ pressed }: PressableStateCallbackType) => [
      styles.headerInner,
      headerInnerVariantStyles[variant],
      pressed && headerInnerPressedVariantStyles[variant],
    ],
    headerText: ({ pressed }: PressableStateCallbackType) => [
      styles.headerText,
      pressed && styles.headerTextPressed,
    ],
    headerIconWrapper: [
      styles.headerIconWrapper,
      isOpen && styles.headerIconWrapperOpen,
    ],
    separator: [styles.separator, isOpen && styles.separatorOpen],
    content: [styles.content, isOpen && styles.contentVisible],
  };
}

export default useStyles;
