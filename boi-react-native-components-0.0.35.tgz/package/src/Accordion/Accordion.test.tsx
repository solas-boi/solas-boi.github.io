import {
  render,
  screen,
  within,
  userEvent,
  act,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Accordion, { type AccordionProps } from "./Accordion";
import { Typography } from "../Typography";

jest.useFakeTimers();

function WrappedAccordion(props: AccordionProps) {
  return (
    <DesignTokensProvider>
      <Accordion {...props} />
    </DesignTokensProvider>
  );
}

describe("Accordion", () => {
  let baseProps: AccordionProps;

  beforeEach(() => {
    baseProps = {
      title: "Accordion title",
      content: <Typography>Accordion content</Typography>,
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedAccordion {...baseProps} initialOpen />);

    const accordion = screen.getByTestId("accordion");
    const header = within(accordion).getByRole("button");

    expect(header).toBeDefined();
  });

  it("should be closed by default", () => {
    render(<WrappedAccordion {...baseProps} />);

    const accordion = screen.getByTestId("accordion");
    const content = within(accordion).getByTestId("accordion-content", {
      hidden: true,
    });

    expect(content).not.toBeVisible();
  });

  it("should be open when initialOpen is set", () => {
    render(<WrappedAccordion {...baseProps} initialOpen />);

    const accordion = screen.getByTestId("accordion");
    const content = within(accordion).getByTestId("accordion-content");

    expect(content).toBeVisible();
  });

  it("should open when the header button is clicked", async () => {
    const user = userEvent.setup();

    render(<WrappedAccordion {...baseProps} />);

    const accordion = screen.getByTestId("accordion");
    const header = within(accordion).getByRole("button");

    await act(async () => {
      await user.press(header);
    });

    const content = within(accordion).getByTestId("accordion-content");

    expect(content).toBeDefined();
  });

  it("should render the correct title", () => {
    render(<WrappedAccordion {...baseProps} />);

    const accordion = screen.getByTestId("accordion");
    const heading = within(accordion).getByRole("heading");

    expect(heading.props["aria-level"]).toBe(3);
    expect(heading).toHaveTextContent(baseProps.title);
  });

  it("should render the correct content", () => {
    render(<WrappedAccordion {...baseProps} initialOpen />);

    const accordion = screen.getByTestId("accordion");
    const content = within(accordion).getByTestId("accordion-content");

    expect(content).toHaveTextContent("Accordion content");
  });

  it("should allow for different heading levels", () => {
    render(<WrappedAccordion {...baseProps} headingLevel={5} />);

    const accordion = screen.getByTestId("accordion");
    const heading = within(accordion).getByRole("heading");

    expect(heading.props["aria-level"]).toBe(5);
    expect(heading).toHaveTextContent(baseProps.title);
  });

  it("should function as a controlled component", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    const isOpen = false;

    render(
      <WrappedAccordion
        {...baseProps}
        isOpen={isOpen}
        onChange={mockOnChange}
      />
    );

    const accordion = screen.getByTestId("accordion");
    const button = within(accordion).getByRole("button");

    await act(async () => {
      await user.press(button);
    });

    expect(mockOnChange).toHaveBeenCalledWith(!isOpen);
  });

  it("should render with a default testID", () => {
    render(<WrappedAccordion {...baseProps} />);

    expect(screen.getByTestId("accordion")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-accordion";

    render(<WrappedAccordion {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
