import type { Meta, StoryObj } from "@storybook/react";
import { CoreAccordion, HEADING_LEVELS } from "@boi/components-core";

import Accordion from "./Accordion";
import { Typography } from "../Typography";

const meta = {
  title: "Surfaces/Accordion",
  component: Accordion,
  argTypes: {
    content: { control: { disable: true } },
    variant: {
      control: { type: "select" },
      options: CoreAccordion.VARIANTS,
    },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
  },
  args: {
    title: "How do I apply for a loan?",
    headingLevel: CoreAccordion.DEFAULT_HEADING_LEVEL,
    content: (
      <Typography>
        You can apply online, over the phone or in your branch.
      </Typography>
    ),
  },
} satisfies Meta<typeof Accordion>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
