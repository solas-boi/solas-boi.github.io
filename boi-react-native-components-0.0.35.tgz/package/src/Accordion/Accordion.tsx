import { useId, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import {
  CoreAccordion,
  type HeadingLevel,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { ChevronDownIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./Accordion.styles";
import { Typography } from "../Typography";

export type AccordionProps = PropsWithOptionalTestID & {
  title: string;
  content: JSX.Element;
  isOpen?: boolean;
  initialOpen?: boolean;
  onChange?: (isOpen: boolean) => void;
  variant?: CoreAccordion.Variant;
  headingLevel?: HeadingLevel;
};

function Accordion(props: AccordionProps) {
  const {
    title,
    content,
    isOpen: controlledOpen,
    initialOpen = false,
    onChange: setControlledOpen,
    variant = CoreAccordion.DEFAULT_VARIANT,
    headingLevel = CoreAccordion.DEFAULT_HEADING_LEVEL,
    testID = "accordion",
  } = props;

  const headerID = useId();

  const { tokens } = useDesignTokens();
  const { accordion } = tokens;

  const [uncontrolledOpen, setUncontrolledOpen] = useState(initialOpen);

  const isOpen = controlledOpen ?? uncontrolledOpen;
  const onChange = setControlledOpen ?? setUncontrolledOpen;

  const styles = useStyles();
  const stateStyles = useStateStyles({ variant, isOpen });

  function handlePress() {
    onChange(!isOpen);
  }

  function getIconColor(pressed: boolean) {
    return accordion.header.icon.color[pressed ? "active" : "base"];
  }

  return (
    <View
      collapsable={false}
      importantForAccessibility="no"
      style={stateStyles.container}
      testID={testID}
    >
      <KeyboardPressable
        id={headerID}
        nativeID={headerID}
        role="button"
        enableA11yFocus
        accessibilityRole="button"
        onPress={handlePress}
        style={stateStyles.header}
        aria-expanded={isOpen}
        testID={`${testID}-header`}
      >
        {({ pressed }) => (
          <>
            <View style={stateStyles.headerInner({ pressed })}>
              <View style={styles.headerTextWrapper}>
                <Typography
                  component={`h${headingLevel}`}
                  variant={accordion.header.text.typography.variant[variant]}
                  fontFamily={accordion.header.text.typography.fontFamily}
                  style={stateStyles.headerText({ pressed })}
                >
                  {title}
                </Typography>
              </View>
              <View style={stateStyles.headerIconWrapper}>
                <ChevronDownIcon
                  color={getIconColor(pressed)}
                  style={styles.headerIcon}
                />
              </View>
            </View>
            <View style={stateStyles.separator} />
          </>
        )}
      </KeyboardPressable>

      <View
        role="region"
        style={stateStyles.content}
        aria-labelledby={headerID}
        testID={`${testID}-content`}
      >
        {content}
      </View>
    </View>
  );
}

export default Accordion;
