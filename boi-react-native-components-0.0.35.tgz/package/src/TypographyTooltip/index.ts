export {
  default as TypographyTooltip,
  type TypographyTooltipProps,
} from "./TypographyTooltip";
