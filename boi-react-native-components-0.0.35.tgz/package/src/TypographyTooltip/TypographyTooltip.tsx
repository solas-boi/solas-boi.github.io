import { useState, type PropsWithChildren } from "react";
import { View } from "react-native";
import { CoreTypography } from "@boi/components-core";

import type { TypographyVariant } from "./TypographyTooltip.types";
import useStyles, { useStateStyles } from "./TypographyTooltip.styles";
import {
  Tooltip,
  TooltipIconButton,
  type TooltipProps,
  type TooltipIconButtonProps,
} from "../Tooltip";

export type TypographyTooltipProps = PropsWithChildren & {
  typographyVariant: TypographyVariant;
  iconButtonProps: Omit<
    TooltipIconButtonProps,
    "variant" | "isOpen" | "onPress"
  >;
  otherIconButtonProps: Pick<TooltipIconButtonProps, "variant">;
  tooltipProps: Pick<TooltipProps, "heading" | "text" | "testID">;
};

function TypographyTooltip(props: TypographyTooltipProps) {
  const {
    typographyVariant = CoreTypography.DEFAULT_VARIANT,
    iconButtonProps,
    otherIconButtonProps,
    tooltipProps,
    children,
  } = props;

  const iconButtonVariant = otherIconButtonProps.variant || "default";

  const [open, setOpen] = useState(false);

  const styles = useStyles();
  const stateStyles = useStateStyles({
    typographyVariant,
    iconButtonVariant,
  });

  function handlePress() {
    setOpen(!open);
  }

  return (
    <View style={styles.container} importantForAccessibility="yes">
      <View style={styles.typographyContainer}>{children}</View>
      <View style={stateStyles.tooltipContainer}>
        <View>
          <Tooltip
            {...tooltipProps}
            isOpen={open}
            onOpenChange={setOpen}
            reference={
              <TooltipIconButton
                {...iconButtonProps}
                {...otherIconButtonProps}
                isOpen={open}
                onPress={handlePress}
              />
            }
          />
        </View>
      </View>
    </View>
  );
}

export default TypographyTooltip;
