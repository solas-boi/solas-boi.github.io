import { CoreTypography } from "@boi/components-core";

export const TYPOGRAPHY_VARIANTS = [
  "bodyL",
  "bodyM",
  "bodyS",
] as const satisfies CoreTypography.Variant[];
