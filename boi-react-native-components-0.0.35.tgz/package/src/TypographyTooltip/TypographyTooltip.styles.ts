import { StyleSheet } from "react-native";
import { CoreTooltipIconButton } from "@boi/components-core";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import type { TypographyVariant } from "./TypographyTooltip.types";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { spacing, typography, iconButton } = tokens;

  return StyleSheet.create({
    container: {
      flexDirection: "row",
      alignItems: "flex-end",
      gap: spacing.s8,
    },
    typographyContainer: {
      flexShrink: 1,
    },
    tooltipContainer: {
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    },
    tooltipContainerIconButtonVariantDefault: {
      width: iconButton.inner.icon.width.default,
    },
    tooltipContainerIconButtonVariantDefault16: {
      width: iconButton.inner.icon.width.default16,
    },
    tooltipContainerIconButtonVariantDefault20: {
      width: iconButton.inner.icon.width.default20,
    },
    tooltipContainerTypographyVariantBodyL: {
      height: parseSizeToken(typography.lineHeight.bodyL, fontScale),
    },
    tooltipContainerTypographyVariantBodyM: {
      height: parseSizeToken(typography.lineHeight.bodyM, fontScale),
    },
    tooltipContainerTypographyVariantBodyS: {
      height: parseSizeToken(typography.lineHeight.bodyS, fontScale),
    },
  });
}

export function useStateStyles({
  typographyVariant,
  iconButtonVariant,
}: {
  typographyVariant: TypographyVariant;
  iconButtonVariant: CoreTooltipIconButton.Variant;
}) {
  const styles = useStyles();

  const tooltipContainerTypographyVariantStyles = {
    bodyL: styles.tooltipContainerTypographyVariantBodyL,
    bodyM: styles.tooltipContainerTypographyVariantBodyM,
    bodyS: styles.tooltipContainerTypographyVariantBodyS,
  };

  const tooltipContainerIconButtonVariantStyles = {
    default: styles.tooltipContainerIconButtonVariantDefault,
    default16: styles.tooltipContainerIconButtonVariantDefault16,
    default20: styles.tooltipContainerIconButtonVariantDefault20,
  };

  return {
    tooltipContainer: [
      styles.tooltipContainer,
      tooltipContainerTypographyVariantStyles[typographyVariant],
      tooltipContainerIconButtonVariantStyles[iconButtonVariant],
    ],
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
