import { TYPOGRAPHY_VARIANTS } from "./TypographyTooltip.constants";

export type TypographyVariant = (typeof TYPOGRAPHY_VARIANTS)[number];
