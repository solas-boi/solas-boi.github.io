import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

export const SELECT_ITEM_HEIGHT = 48;

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { select } = tokens;

  return StyleSheet.create({
    container: {
      minHeight: select.menu.option.minHeight,
      padding: select.menu.option.padding,
      backgroundColor: select.menu.option.backgroundColor.base,
      borderWidth: select.menu.stroke.width,
      borderColor: select.menu.stroke.color,
      borderRadius: select.menu.radius,
    },
    containerNotFirst: {
      borderTopWidth: 0,
      borderTopLeftRadius: 0,
      borderTopRightRadius: 0,
    },
    containerNotLast: {
      borderBottomLeftRadius: 0,
      borderBottomRightRadius: 0,
    },
    contentWrapper: {
      display: "flex",
      justifyContent: "center",
      flex: 1,
      paddingTop: select.menu.option.inner.padding.top,
      paddingLeft: select.menu.option.inner.padding.left,
      paddingRight: select.menu.option.inner.padding.right,
      paddingBottom: select.menu.option.inner.padding.bottom,
      borderRadius: select.menu.option.inner.radius,
      borderWidth: select.menu.option.inner.stroke.width,
      borderColor: select.menu.option.inner.stroke.color.base,
    },
    contentWrapperPressed: {
      backgroundColor: select.menu.option.inner.backgroundColor.active,
      borderColor: select.menu.option.inner.stroke.color.active,
    },
    content: {
      display: "flex",
      flexDirection: "row",
      gap: select.menu.option.inner.gap,
    },
    text: {
      color: select.menu.option.inner.color.base,
    },
    textDisabled: {
      color: select.menu.option.inner.color.disabled,
    },
    tickIconWrapper: {
      display: "flex",
      justifyContent: "center",
      width: select.menu.option.inner.tickIconWrapper.width,
      height: parseSizeToken(
        select.menu.option.inner.tickIconWrapper.height,
        fontScale
      ),
    },
    typographyWrapper: {
      flexShrink: 1,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  isFirst: boolean,
  isLast: boolean,
  isDisabled: boolean
) {
  const styles = useStyles();

  return {
    container: [
      styles.container,
      !isFirst ? styles.containerNotFirst : undefined,
      !isLast ? styles.containerNotLast : undefined,
    ],
    contentWrapper: (pressed: boolean) => [
      styles.contentWrapper,
      pressed ? styles.contentWrapperPressed : undefined,
    ],
    text: [styles.text, isDisabled && styles.textDisabled],
  };
}

export default useStyles;
