import React from "react";
import { Platform, View } from "react-native";
import type { FlatList as RNFlatList } from "react-native";
import { render, screen, act, userEvent } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreSelect } from "@boi/components-core";

import SelectModalBase, { SelectModalBaseProps } from "./SelectModalBase";
import * as StandardModal from "../StandardModal";
import { SELECT_ITEM_HEIGHT } from "./SelectItem/SelectItem.styles";

type SelectItemLike = { id: string };
type StandardModalFlatListProps = React.ComponentProps<
  typeof StandardModal.StandardModal.FlatList
>;

jest.useFakeTimers();

jest.mock("../StandardModalBase/StandardModalBase.hooks", () => ({
  useStandardModalContext: () => ({ headingHeight: 50 }),
}));

jest
  .spyOn(StandardModal.StandardModal, "FlatList")
  .mockImplementation((props: StandardModalFlatListProps) => {
    const {
      data,
      renderItem,
      flatlistRef,
      testID = "select-modal-flatlist",
      ...rest
    } = props;
    const fakeRef = { scrollToItem: jest.fn() };

    if (flatlistRef) {
      if (typeof flatlistRef === "function") {
        flatlistRef(fakeRef as unknown as RNFlatList<unknown>);
      } else {
        (
          flatlistRef as React.MutableRefObject<RNFlatList<unknown> | null>
        ).current = fakeRef as unknown as RNFlatList<unknown>;
      }
    }

    const items = (data ?? []) as SelectItemLike[];
    const TestView = View as React.ComponentType<any>;

    return (
      <TestView testID={testID} flatlistRef={{ current: fakeRef }} {...rest}>
        {items.map((item, index) => {
          const wrapper =
            typeof renderItem === "function"
              ? (
                  renderItem as (info: {
                    item: SelectItemLike;
                    index: number;
                  }) => React.ReactElement
                )({ item, index })
              : null;

          if (!wrapper) {
            return null;
          }

          const inner = wrapper.props.children
            ? React.Children.only(wrapper.props.children)
            : wrapper;

          return React.cloneElement(inner, {
            ...inner.props,
            key: item.id,
            testID: "select-item",
          });
        })}
      </TestView>
    );
  });

const setPlatform = (os: "ios" | "android") => {
  Object.defineProperty(Platform, "OS", {
    value: os,
    configurable: true,
  });
};

const WrappedSelectModalBase = <T extends CoreSelect.SelectItem>(
  props: SelectModalBaseProps<T>
) => (
  <DesignTokensProvider>
    <SelectModalBase {...props} />
  </DesignTokensProvider>
);

describe("SelectModalBase", () => {
  type Item = CoreSelect.SelectItem;

  const items: Item[] = [
    { id: "1", title: "Item 1", value: "1" },
    { id: "2", title: "Item 2", value: "2" },
    { id: "3", title: "Item 3", value: "3" },
  ];
  const onChange = jest.fn();
  const onRequestClose = jest.fn();
  const baseProps: SelectModalBaseProps<Item> = {
    items,
    selectedItem: items[1],
    disabledKeys: [],
    readyToInteract: true,
    onChange,
    onRequestClose,
  };

  beforeEach(() => {
    jest.clearAllMocks();
    setPlatform("ios");
  });

  const getItems = () => screen.getAllByTestId("select-item");

  it("should render all list items", () => {
    render(<WrappedSelectModalBase {...baseProps} />);
    expect(getItems().length).toBe(3);
  });

  it("should mark the selected item as selected", () => {
    render(<WrappedSelectModalBase {...baseProps} />);
    expect(getItems()[1]?.props.accessibilityState.selected).toBe(true);
  });

  it("should mark disabled items as disabled", () => {
    render(<WrappedSelectModalBase {...baseProps} disabledKeys={["2"]} />);
    expect(getItems()[1]?.props.accessibilityState.disabled).toBe(true);
  });

  it("should call onChange and onRequestClose when an item is pressed", async () => {
    const user = userEvent.setup();
    render(<WrappedSelectModalBase {...baseProps} />);

    await act(async () => {
      await user.press(getItems()[0]!);
    });

    expect(onChange).toHaveBeenCalledWith(items[0]);
    expect(onRequestClose).toHaveBeenCalled();
  });

  describe("initial scroll behavior", () => {
    it("should set initialScrollIndex on iOS", () => {
      setPlatform("ios");
      render(<WrappedSelectModalBase {...baseProps} />);

      expect(
        screen.getByTestId("select-modal-flatlist").props.initialScrollIndex
      ).toBe(1);
    });

    it("should NOT set initialScrollIndex on Android", () => {
      setPlatform("android");
      render(<WrappedSelectModalBase {...baseProps} />);

      expect(
        screen.getByTestId("select-modal-flatlist").props.initialScrollIndex
      ).toBeUndefined();
    });

    it("should scroll to selected item on Android after readyToInteract", () => {
      setPlatform("android");
      render(<WrappedSelectModalBase {...baseProps} />);

      const list = screen.getByTestId("select-modal-flatlist");
      const scrollSpy = list.props.flatlistRef.current.scrollToItem;

      expect(scrollSpy).toHaveBeenCalledWith({ item: items[1] });
    });

    it("should NOT scroll when no selectedItem", () => {
      setPlatform("android");
      render(
        <WrappedSelectModalBase {...baseProps} selectedItem={undefined} />
      );

      const list = screen.getByTestId("select-modal-flatlist");
      const scrollSpy = list.props.flatlistRef.current.scrollToItem;

      expect(scrollSpy).not.toHaveBeenCalled();
    });
  });

  it("should use correct getItemLayout", () => {
    render(<WrappedSelectModalBase {...baseProps} />);

    const list = screen.getByTestId("select-modal-flatlist");
    const layout = list.props.getItemLayout(undefined, 2);

    expect(layout).toEqual({
      length: SELECT_ITEM_HEIGHT,
      offset: 50 + SELECT_ITEM_HEIGHT * 2,
      index: 2,
    });
  });
});
