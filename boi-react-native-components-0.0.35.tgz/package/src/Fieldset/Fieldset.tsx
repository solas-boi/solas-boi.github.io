import { forwardRef, type PropsWithChildren } from "react";
import { type AccessibilityProps, View } from "react-native";
import { A11yContainerView } from "react-native-a11y-container";
import { type PropsWithOptionalTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./Fieldset.styles";
import { Typography } from "../Typography";
import {
  TypographyTooltip,
  type TypographyTooltipProps,
} from "../TypographyTooltip";

export type FieldsetProps = PropsWithOptionalTestID &
  PropsWithChildren &
  Pick<AccessibilityProps, "accessibilityLabel" | "accessibilityHint"> & {
    legend?: string;
    legendTooltipProps?: Omit<
      TypographyTooltipProps,
      "typographyVariant" | "otherIconButtonProps"
    >;
    legendHint?: string;
    legendHintTooltipProps?: Omit<
      TypographyTooltipProps,
      "typographyVariant" | "otherIconButtonProps"
    >;
    role: "checkboxgroup" | "radiogroup";
  };

const Fieldset = forwardRef<View, FieldsetProps>((props, ref) => {
  const {
    legend,
    legendHint,
    children,
    legendTooltipProps,
    legendHintTooltipProps,
    role,
    accessibilityLabel,
    accessibilityHint,
    testID = "fieldset",
  } = props;

  const { tokens } = useDesignTokens();
  const { fieldset } = tokens;

  const styles = useStyles();

  const roleLabel = role === "checkboxgroup" ? "Checkbox group" : "Radio Group";
  const accessibleLegend = accessibilityLabel
    ? `${accessibilityLabel}, ${roleLabel}`
    : roleLabel;
  const legendWithRole = legend ? `${legend}, ${roleLabel}` : accessibleLegend;

  return (
    <A11yContainerView
      ref={ref}
      accessibilityLabel={legendWithRole}
      accessibilityHint={legendHint ?? accessibilityHint}
      style={styles.container}
      testID={testID}
    >
      {(legend || legendHint) && (
        <View>
          {legend && (
            <LegendWrapper legendTooltipProps={legendTooltipProps}>
              <Typography
                importantForAccessibility="no"
                color={fieldset.legend.color}
                variant={fieldset.legend.typography.variant}
                fontFamily={fieldset.legend.typography.fontFamily}
              >
                {legend}
              </Typography>
            </LegendWrapper>
          )}

          {legendHint && (
            <LegendHintWrapper legendHintTooltipProps={legendHintTooltipProps}>
              <Typography
                importantForAccessibility="no"
                component="div"
                color={fieldset.legendHint.color}
                variant={fieldset.legendHint.typography.variant}
                fontFamily={fieldset.legendHint.typography.fontFamily}
              >
                {legendHint}
              </Typography>
            </LegendHintWrapper>
          )}
        </View>
      )}

      {children}
    </A11yContainerView>
  );
});

type LegendWrapperProps = Pick<
  FieldsetProps,
  "legendTooltipProps" | "children"
>;

function LegendWrapper(props: LegendWrapperProps) {
  const { legendTooltipProps, children } = props;

  const { tokens } = useDesignTokens();
  const { fieldset } = tokens;

  if (legendTooltipProps) {
    return (
      <TypographyTooltip
        {...legendTooltipProps}
        otherIconButtonProps={{
          variant: "default",
        }}
        typographyVariant={fieldset.legend.typography.variant}
      >
        {children}
      </TypographyTooltip>
    );
  }

  return children;
}

type LegendHintWrapperProps = Pick<
  FieldsetProps,
  "legendHintTooltipProps" | "children"
>;

function LegendHintWrapper(props: LegendHintWrapperProps) {
  const { legendHintTooltipProps, children } = props;

  const { tokens } = useDesignTokens();
  const { fieldset } = tokens;

  if (legendHintTooltipProps) {
    return (
      <View style={{ paddingBottom: 0 }}>
        <TypographyTooltip
          {...legendHintTooltipProps}
          otherIconButtonProps={{
            variant: "default20",
          }}
          typographyVariant={fieldset.legendHint.typography.variant}
        >
          {children}
        </TypographyTooltip>
      </View>
    );
  }

  return children;
}

Fieldset.displayName = "Fieldset";

export default Fieldset;
