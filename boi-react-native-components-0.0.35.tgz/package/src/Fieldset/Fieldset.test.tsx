import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Fieldset, { type FieldsetProps } from "./Fieldset";

jest.useFakeTimers();

function WrappedFieldset(props: FieldsetProps) {
  return (
    <DesignTokensProvider>
      <Fieldset {...props} />
    </DesignTokensProvider>
  );
}

describe("Fieldset", () => {
  let baseProps: FieldsetProps;

  beforeEach(() => {
    baseProps = {
      role: "checkboxgroup",
      legend: "Fieldset legend",
      legendHint: "Fieldset hint",
    };
  });

  it("should render with a legend and hint element", () => {
    render(<WrappedFieldset {...baseProps} />);

    const legend = screen.getByText("Fieldset legend");
    const hint = screen.getByText("Fieldset hint");

    expect(legend).toBeDefined();
    expect(hint).toBeDefined();
  });

  it("should render legend with tooltip button", () => {
    render(
      <WrappedFieldset
        {...baseProps}
        legendTooltipProps={{
          tooltipProps: { heading: "Test", text: "Lorem Ipsum" },
          iconButtonProps: { "aria-label": "Tooltip button label" },
        }}
      />
    );

    const tooltipButton = screen.getByLabelText("Tooltip button label");

    expect(tooltipButton).toBeDefined();
  });

  it("should render hint with tooltip button", () => {
    render(
      <WrappedFieldset
        {...baseProps}
        legendHintTooltipProps={{
          tooltipProps: { heading: "Test", text: "Lorem Ipsum" },
          iconButtonProps: { "aria-label": "Tooltip button label" },
        }}
      />
    );

    const tooltipButton = screen.getByLabelText("Tooltip button label");

    expect(tooltipButton).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedFieldset {...baseProps} />);

    expect(screen.getByTestId("fieldset")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-fieldset";

    render(<WrappedFieldset {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  describe("Fieldset accessibility props", () => {
    it("should use accessibilityLabel combined with role label when provided", () => {
      const props: FieldsetProps = {
        role: "checkboxgroup",
        accessibilityLabel: "Custom accessibility label",
        legendHint: "Fieldset hint",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset.props.accessibilityLabel).toBe(
        "Custom accessibility label, Checkbox group"
      );
    });

    it("should use accessibilityHint when provided", () => {
      const props: FieldsetProps = {
        role: "checkboxgroup",
        legend: "Fieldset legend",
        accessibilityHint: "Custom accessibility hint",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset).toHaveProp(
        "accessibilityHint",
        "Custom accessibility hint"
      );
    });

    it("should use both accessibilityLabel and accessibilityHint when provided", () => {
      const props: FieldsetProps = {
        role: "checkboxgroup",
        accessibilityLabel: "Custom accessibility label",
        accessibilityHint: "Custom accessibility hint",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset).toHaveProp(
        "accessibilityLabel",
        "Custom accessibility label, Checkbox group"
      );
      expect(fieldset).toHaveProp(
        "accessibilityHint",
        "Custom accessibility hint"
      );
    });

    it("should prioritize legendHint over accessibilityHint", () => {
      const props: FieldsetProps = {
        role: "checkboxgroup",
        legend: "Fieldset legend",
        legendHint: "Legend hint text",
        accessibilityHint: "Accessibility hint text",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset).toHaveProp("accessibilityHint", "Legend hint text");
    });

    it("should use accessibilityLabel with radiogroup role", () => {
      const props: FieldsetProps = {
        role: "radiogroup",
        accessibilityLabel: "Custom radio label",
        legendHint: "Fieldset hint",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset).toHaveProp(
        "accessibilityLabel",
        "Custom radio label, Radio Group"
      );
    });

    it("should combine legend with role label when both legend and accessibilityLabel are provided", () => {
      const props: FieldsetProps = {
        role: "checkboxgroup",
        legend: "Fieldset legend",
        legendHint: "Fieldset hint",
        accessibilityLabel: "Custom accessibility label",
      };

      render(<WrappedFieldset {...props} />);

      const fieldset = screen.getByTestId("fieldset");

      expect(fieldset).toHaveProp(
        "accessibilityLabel",
        "Fieldset legend, Checkbox group"
      );
    });
  });
});
