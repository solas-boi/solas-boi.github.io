import { render, screen, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import TooltipIconButton, {
  type TooltipIconButtonProps,
} from "./TooltipIconButton";
import { CoreTooltipIconButton } from "@boi/components-core";

jest.mock("react-native-external-keyboard", () => {
  const actual = jest.requireActual("react-native-external-keyboard");
  const { Pressable } = require("react-native");
  return {
    ...actual,
    Pressable,
  };
});

function WrappedTooltipIconButton(props: TooltipIconButtonProps) {
  return (
    <DesignTokensProvider>
      <TooltipIconButton {...props} />
    </DesignTokensProvider>
  );
}

describe("TooltipIconButton", () => {
  let baseProps: TooltipIconButtonProps;

  beforeEach(() => {
    baseProps = {
      isOpen: false,
      "aria-label": "Tooltip button",
    };
  });

  it("should render with the button role", () => {
    render(<WrappedTooltipIconButton {...baseProps} />);

    const button = screen.getByRole("button");

    expect(button).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedTooltipIconButton {...baseProps} />);

    expect(screen.getByTestId("tooltipIconButton")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-tooltip-button";

    render(<WrappedTooltipIconButton {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  it("should render with isOpen false", () => {
    render(<WrappedTooltipIconButton {...baseProps} isOpen={false} />);

    const button = screen.getByRole("button");

    expect(button).toBeDefined();
  });

  it("should render with isOpen true", () => {
    render(<WrappedTooltipIconButton {...baseProps} isOpen={true} />);

    const button = screen.getByRole("button");

    expect(button).toBeDefined();
  });

  it.each(CoreTooltipIconButton.VARIANTS)(
    "should render with variant %s",
    (variant) => {
      render(<WrappedTooltipIconButton {...baseProps} variant={variant} />);

      const button = screen.getByRole("button");

      expect(button).toBeDefined();
    }
  );

  it("should render with the correct aria-label", () => {
    const ariaLabel = "Custom tooltip label";

    render(<WrappedTooltipIconButton {...baseProps} aria-label={ariaLabel} />);

    const button = screen.getByLabelText(ariaLabel);

    expect(button).toBeDefined();
  });

  it("should call onFocusChange when focus changes", () => {
    const onFocusChange = jest.fn();

    render(
      <WrappedTooltipIconButton {...baseProps} onFocusChange={onFocusChange} />
    );

    const button = screen.getByRole("button");

    act(() => {
      button.props.onFocusChange?.(true);
    });

    expect(onFocusChange).toHaveBeenCalledWith(true);
  });

  it.each(["InteractiveInfoIcon", "InteractiveInfoFilledIcon"])(
    "should render %s icons correctly",
    (iconTestID) => {
      render(<WrappedTooltipIconButton {...baseProps} />);

      const icon = screen.getByTestId(iconTestID, {
        includeHiddenElements: true,
      });

      expect(icon).toBeDefined();
    }
  );
});
