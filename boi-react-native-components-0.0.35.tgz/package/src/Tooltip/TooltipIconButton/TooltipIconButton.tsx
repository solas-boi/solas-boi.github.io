import { forwardRef, useState } from "react";
import { View } from "react-native";
import {
  KeyboardFocus,
  Pressable as KeyboardPressable,
} from "react-native-external-keyboard";
import {
  CoreTooltipIconButton,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import {
  InteractiveInfoIcon,
  InteractiveInfoFilledIcon,
} from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./TooltipIconButton.styles";
import { KeyboardPressableProps } from "../../types";

export type TooltipIconButtonProps = PropsWithOptionalTestID &
  Omit<
    KeyboardPressableProps,
    "role" | "accessibilityRole" | "style" | "children"
  > & {
    isOpen: boolean;
    variant?: CoreTooltipIconButton.Variant;
    "aria-label": string;
  };

const TooltipIconButton = forwardRef<
  View | KeyboardFocus,
  TooltipIconButtonProps
>((props, ref) => {
  const {
    isOpen,
    variant = CoreTooltipIconButton.DEFAULT_VARIANT,
    testID = "tooltipIconButton",
    ...otherProps
  } = props;

  const { tokens } = useDesignTokens();
  const { iconButton, tooltipIconButton } = tokens;

  const stateStyles = useStateStyles({ isOpen, variant });
  const styles = useStyles();

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);

  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
    props.onFocusChange?.(isFocused);
  };

  return (
    <KeyboardPressable
      {...otherProps}
      ref={ref}
      enableA11yFocus
      role="button"
      accessibilityRole="button"
      containerStyle={stateStyles.wrapper}
      style={styles.__iOSFixForKeyboardOrder}
      testID={testID}
      onFocusChange={handleKeyboardFocusChange}
      tintType="none"
    >
      <View style={stateStyles.container}>
        {hasKeyboardFocus && (
          <View pointerEvents="none" style={stateStyles.focusRing} />
        )}

        <InteractiveInfoIcon
          testID="InteractiveInfoIcon"
          width={iconButton.inner.icon.width[variant]}
          height={iconButton.inner.icon.height[variant]}
          primaryColor={tooltipIconButton.icon.primaryColor.base}
          secondaryColor={tooltipIconButton.icon.secondaryColor.base}
          style={stateStyles.icon}
        />

        <InteractiveInfoFilledIcon
          testID="InteractiveInfoFilledIcon"
          width={iconButton.inner.icon.width[variant]}
          height={iconButton.inner.icon.height[variant]}
          primaryColor={tooltipIconButton.iconFilled.primaryColor.base}
          secondaryColor={tooltipIconButton.iconFilled.secondaryColor.base}
          style={stateStyles.iconFilled}
        />
      </View>
    </KeyboardPressable>
  );
});

TooltipIconButton.displayName = "TooltipIconButton";

export default TooltipIconButton;
