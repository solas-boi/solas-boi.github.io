import { cloneElement, useRef } from "react";
import { View } from "react-native";
import { type PropsWithOptionalTestID } from "@boi/components-core";

import { InformationModal } from "../InformationModal";

export type TooltipProps = PropsWithOptionalTestID & {
  heading: string;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  text: string;
  reference: JSX.Element;
};

function Tooltip(props: TooltipProps) {
  const {
    heading,
    isOpen,
    onOpenChange,
    text,
    reference,
    testID = "tooltip",
  } = props;

  const ref = useRef<View>(null);
  const clonedReference = cloneElement(reference, { ref });

  return (
    <>
      {clonedReference}

      <InformationModal
        onRequestClose={() => onOpenChange(false)}
        onCloseAnimationComplete={() => {
          ref?.current?.focus();
        }}
        heading={heading}
        secondaryButtonsProps={[
          {
            text: "Close",
            onPress: () => onOpenChange(false),
          },
        ]}
        isOpen={isOpen}
        testID={testID}
      >
        <InformationModal.Typography variant="bodyM">
          {text}
        </InformationModal.Typography>
      </InformationModal>
    </>
  );
}

export default Tooltip;
