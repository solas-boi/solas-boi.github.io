import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Tooltip, { type TooltipProps } from "./Tooltip";
import { TooltipIconButton } from "./TooltipIconButton";

jest.useFakeTimers();

function WrappedTooltip(props: TooltipProps) {
  return (
    <DesignTokensProvider>
      <Tooltip {...props} />
    </DesignTokensProvider>
  );
}

describe("Tooltip", () => {
  let baseProps: TooltipProps;

  beforeEach(() => {
    baseProps = {
      heading: "Tooltip heading",
      isOpen: true,
      onOpenChange: jest.fn(),
      reference: <TooltipIconButton isOpen={true} aria-label="Open tooltip" />,
      text: "Tooltip content",
    };
  });

  it("should render the reference element", () => {
    render(<WrappedTooltip {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Open tooltip",
    });

    expect(button).toBeDefined();
  });

  it("should be hidden when open is set to false", () => {
    render(<WrappedTooltip {...baseProps} isOpen={false} />);

    const tooltips = screen.queryByTestId("tooltip");
    expect(tooltips).toBeNull();
  });

  it("should be visible when open is set to true", () => {
    render(<WrappedTooltip {...baseProps} isOpen={true} />);

    const tooltip = screen.getByTestId("tooltip");
    expect(tooltip).toBeDefined();
  });

  it("should render the correct heading", () => {
    render(<WrappedTooltip {...baseProps} />);

    const tooltip = screen.getByTestId("tooltip-heading");
    expect(tooltip).toHaveTextContent(baseProps.heading);
  });

  it("should render the correct text", () => {
    render(<WrappedTooltip {...baseProps} />);

    const tooltip = screen.getByTestId("tooltip-body");
    expect(tooltip).toHaveTextContent(baseProps.text);
  });

  it("should trigger the onOpenChange event when the close button is pressed", async () => {
    const user = userEvent.setup();
    const mockOnOpenChange = jest.fn();

    render(<WrappedTooltip {...baseProps} onOpenChange={mockOnOpenChange} />);

    const button = screen.getByRole("button", {
      name: "Close",
    });

    await act(async () => {
      await user.press(button);
    });

    expect(mockOnOpenChange).toHaveBeenLastCalledWith(false);
  });

  it("should render with a default testID", () => {
    render(<WrappedTooltip {...baseProps} />);

    expect(screen.getByTestId("tooltip")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-tooltip";

    render(<WrappedTooltip {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
