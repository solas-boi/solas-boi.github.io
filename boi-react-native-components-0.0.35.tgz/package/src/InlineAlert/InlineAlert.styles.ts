import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { inlineAlert } = tokens;

  return StyleSheet.create({
    container: {
      display: "flex",
      flexDirection: "row",
      gap: inlineAlert.gap,
    },
    iconWrapper: {
      display: "flex",
      justifyContent: "center",
      height: parseSizeToken(inlineAlert.iconWrapper.height, fontScale),
    },
    textWrapper: {
      flexShrink: 1,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
