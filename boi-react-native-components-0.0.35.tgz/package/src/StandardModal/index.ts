export {
  default as StandardModal,
  type StandardModalProps,
} from "./StandardModal";
