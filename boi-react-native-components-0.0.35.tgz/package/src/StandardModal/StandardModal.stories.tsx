import { View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import { CoreSelect } from "@boi/components-core";

import StandardModal from "./StandardModal";
import { Button } from "../Button";
import { Typography } from "../Typography";
import { useRef } from "react";

const meta = {
  title: "Surfaces/StandardModal",
  component: StandardModal,
  decorators: [
    (Story) => (
      <GestureHandlerRootView>
        <Story />
      </GestureHandlerRootView>
    ),
  ],
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    const buttonRef = useRef<View>(null);

    function setIsOpen(isOpen: boolean) {
      updateArgs({ isOpen });
      action("setIsOpen")(isOpen);
    }

    const onRequestClose = () => setIsOpen(false);

    return (
      <>
        <View style={{ padding: 15 }}>
          <Button
            variant="primary"
            text="Open Modal"
            disabled={args.isOpen}
            onPress={() => setIsOpen(true)}
          />
        </View>
        <StandardModal
          {...args}
          supportedOrientations={["landscape", "portrait"]}
          onRequestClose={onRequestClose}
          focusReturnRef={buttonRef}
        />
      </>
    );
  },
  argTypes: {
    isOpen: { control: { type: "boolean" } },
    title: { control: { type: "text" } },
    tabletWidth: { control: { type: "number" } },
  },
  args: {
    isOpen: false,
  },
} satisfies Meta<typeof StandardModal>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    title: "Short content Modal",
    children: <Typography variant="bodyM">This is the content</Typography>,
  },
};

export const WithFlatlist: Story = {
  args: {
    title: "StandardModal with FlatList",
    children: (
      <StandardModal.FlatList
        data={CoreSelect.mockItems}
        ListHeaderComponent={<Typography>additional info</Typography>}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ borderWidth: 3 }}>
            <Typography variant="titleL">
              {item.id} - {item.value}
            </Typography>
          </View>
        )}
      />
    ),
  },
};

export const LongContent: Story = {
  args: {
    title: "Long content Modal",
    children: (
      <StandardModal.ScrollView>
        <Typography variant="bodyM" style={{ marginBottom: 12 }}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Id donec
          ultrices tincidunt arcu non sodales neque. Consectetur a erat nam at.
          Ornare arcu odio ut sem nulla pharetra diam. Diam sollicitudin tempor
          id eu nisl nunc mi. Vel turpis nunc eget lorem dolor sed viverra
          ipsum. Quam quisque id diam vel quam elementum. Sed viverra tellus in
          hac habitasse platea dictumst vestibulum. Ipsum nunc aliquet bibendum
          enim facilisis. Dapibus ultrices in iaculis nunc sed. Fermentum leo
          vel orci porta non. Ut placerat orci nulla pellentesque dignissim.
          Enim lobortis scelerisque fermentum dui faucibus in ornare quam.
        </Typography>

        <Typography variant="bodyM" style={{ marginBottom: 12 }}>
          Penatibus et magnis dis parturient montes nascetur. Purus in massa
          tempor nec feugiat nisl. Sed sed risus pretium quam. Enim nunc
          faucibus a pellentesque sit amet porttitor. At tempor commodo
          ullamcorper a lacus. Malesuada fames ac turpis egestas. Libero nunc
          consequat interdum varius sit amet mattis. Nunc id cursus metus
          aliquam eleifend mi in. Elit pellentesque habitant morbi tristique.
          Venenatis tellus in metus vulputate eu scelerisque felis. Adipiscing
          elit duis tristique sollicitudin nibh sit amet commodo. Vitae congue
          mauris rhoncus aenean vel elit scelerisque mauris pellentesque. In
          pellentesque massa placerat duis ultricies. Vestibulum lorem sed risus
          ultricies tristique nulla aliquet enim. Pharetra convallis posuere
          morbi leo urna molestie. Gravida arcu ac tortor dignissim convallis
          aenean et tortor. Egestas pretium aenean pharetra magna ac placerat.
          Iaculis nunc sed augue lacus viverra. Pretium aenean pharetra magna
          ac. Quis enim lobortis scelerisque fermentum dui faucibus in.
        </Typography>

        <Typography variant="bodyM" style={{ marginBottom: 12 }}>
          Nunc vel risus commodo viverra maecenas accumsan lacus. Morbi enim
          nunc faucibus a pellentesque. Vivamus at augue eget arcu dictum
          varius. Cras semper auctor neque vitae tempus quam pellentesque nec
          nam. Massa id neque aliquam vestibulum morbi blandit cursus. Sagittis
          nisl rhoncus mattis rhoncus. Nisl vel pretium lectus quam id. Proin
          sed libero enim sed faucibus. Nascetur ridiculus mus mauris vitae. Sit
          amet nulla facilisi morbi tempus iaculis urna. Aliquam ut porttitor
          leo a diam sollicitudin. Eu lobortis elementum nibh tellus molestie
          nunc non. Id neque aliquam vestibulum morbi blandit cursus. Amet
          aliquam id diam maecenas ultricies. A iaculis at erat pellentesque.
          Quisque sagittis purus sit amet volutpat consequat mauris. Nulla
          porttitor massa id neque aliquam.
        </Typography>

        <Typography variant="bodyM" style={{ marginBottom: 12 }}>
          Pellentesque elit eget gravida cum. Etiam tempor orci eu lobortis.
          Viverra aliquet eget sit amet tellus cras. Adipiscing elit ut aliquam
          purus sit amet luctus venenatis lectus. Pellentesque massa placerat
          duis ultricies lacus sed turpis tincidunt id. Enim tortor at auctor
          urna nunc id cursus. Turpis cursus in hac habitasse platea. Sodales
          neque sodales ut etiam sit amet nisl. Netus et malesuada fames ac
          turpis. Pharetra magna ac placerat vestibulum lectus mauris ultrices.
          Nisi scelerisque eu ultrices vitae auctor eu. Egestas sed sed risus
          pretium. Nulla facilisi morbi tempus iaculis. Donec enim diam
          vulputate ut pharetra. Viverra vitae congue eu consequat ac felis
          donec. Amet nisl purus in mollis. Eu augue ut lectus arcu bibendum at
          varius. Adipiscing elit duis tristique sollicitudin nibh sit. Magnis
          dis parturient montes nascetur ridiculus. Non quam lacus suspendisse
          faucibus interdum posuere lorem ipsum dolor.
        </Typography>

        <Typography variant="bodyM">
          Dui accumsan sit amet nulla facilisi. Sodales ut eu sem integer vitae
          justo eget magna. Aliquet sagittis id consectetur purus ut faucibus.
          Nunc sed id semper risus in hendrerit gravida rutrum quisque. Et
          malesuada fames ac turpis egestas. Nulla malesuada pellentesque elit
          eget gravida. Elementum facilisis leo vel fringilla est ullamcorper
          eget. Eu tincidunt tortor aliquam nulla. Posuere urna nec tincidunt
          praesent semper feugiat. Fusce id velit ut tortor pretium. Tristique
          magna sit amet purus gravida quis blandit.
        </Typography>
      </StandardModal.ScrollView>
    ),
  },
};
