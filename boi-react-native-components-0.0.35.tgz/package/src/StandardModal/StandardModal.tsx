import { Modal, type ModalProps } from "../Modal";
import {
  StandardModalBase,
  type StandardModalBaseProps,
} from "../StandardModalBase";
import { StandardModalBaseFlatList } from "../StandardModalBase/StandardModalBaseFlatList";
import { StandardModalBaseScrollView } from "../StandardModalBase/StandardModalBaseScrollView";

export type StandardModalProps = ModalProps & StandardModalBaseProps;

function StandardModal(props: StandardModalProps) {
  const {
    title,
    headingLevel,
    accessibilityLabel,
    accessibilityHint,
    children,
    testID = "standard-modal",
    ...modalProps
  } = props;

  return (
    <Modal
      {...modalProps}
      accessibilityLabel={accessibilityLabel || title}
      accessibilityHint={accessibilityHint}
      testID={testID}
    >
      <StandardModalBase
        testID={testID}
        title={title}
        headingLevel={headingLevel}
        onRequestClose={modalProps.onRequestClose}
      >
        {children}
      </StandardModalBase>
    </Modal>
  );
}

StandardModal.ScrollView = StandardModalBaseScrollView;
StandardModal.FlatList = StandardModalBaseFlatList;

export default StandardModal;
