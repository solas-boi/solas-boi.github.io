import { View } from "react-native";
import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreStandardModal } from "@boi/components-core";

import StandardModal, { type StandardModalProps } from "./StandardModal";

jest.useFakeTimers();

function WrappedStandardModal(props: StandardModalProps) {
  return (
    <DesignTokensProvider>
      <StandardModal {...props} />
    </DesignTokensProvider>
  );
}

describe("StandardModal", () => {
  let baseProps: StandardModalProps;

  beforeEach(() => {
    baseProps = {
      title: "Modal heading",
      children: (
        <StandardModal.ScrollView>
          <View testID="mock-children" />
        </StandardModal.ScrollView>
      ),
      isOpen: false,
      onRequestClose: () => {},
    };
  });

  it("should render with the correct heading", () => {
    render(<WrappedStandardModal {...baseProps} isOpen />);

    const heading = screen.getByTestId("standard-modal-heading");

    expect(heading.props["aria-level"]).toBe(
      CoreStandardModal.DEFAULT_HEADING_LEVEL
    );
    expect(heading).toHaveTextContent(baseProps.title);
  });

  it("should render with a custom heading level", () => {
    render(<WrappedStandardModal {...baseProps} isOpen headingLevel={5} />);

    const heading = screen.getByTestId("standard-modal-heading");

    expect(heading.props["aria-level"]).toBe(5);
    expect(heading).toHaveTextContent(baseProps.title);
  });

  it("should render with the correct children", () => {
    render(<WrappedStandardModal {...baseProps} isOpen />);

    const children = screen.getByTestId("mock-children");

    expect(children).toBeDefined();
  });

  it("should call onRequestClose if the close button is pressed", async () => {
    const user = userEvent.setup();
    const mockOnRequestClose = jest.fn();

    render(
      <WrappedStandardModal
        {...baseProps}
        isOpen
        onRequestClose={mockOnRequestClose}
      />
    );

    const closeButton = screen.getByRole("button", {
      name: "Close modal",
    });

    await act(async () => {
      await user.press(closeButton);
    });

    expect(mockOnRequestClose).toHaveBeenCalled();
  });

  it("should render as ScrollView by default", () => {
    render(<WrappedStandardModal {...baseProps} isOpen />);

    expect(screen.getByTestId("standard-modal-scrollview")).toBeDefined();
  });

  it("should render a FlatList as a child", () => {
    render(
      <WrappedStandardModal {...baseProps} isOpen>
        <StandardModal.FlatList data={[]} renderItem={() => <View />} />
      </WrappedStandardModal>
    );

    expect(screen.getByTestId("standard-modal-flatlist")).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedStandardModal {...baseProps} isOpen />);

    expect(screen.getByTestId("standard-modal")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-standard-modal";

    render(<WrappedStandardModal {...baseProps} isOpen testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
