import { forwardRef } from "react";
import { View } from "react-native";
import { A11y } from "react-native-a11y-order";
import { ScreenReaderAlertNotifierProps } from "./ScreenReaderAlertNotifier.types";
import { alertAnnouncementHandler } from "./ScreenReaderAlertNotifier.utils";

const ScreenReaderAlertNotifier = forwardRef<
  View,
  ScreenReaderAlertNotifierProps
>((props, ref) => {
  const { testID = "screen-reader-alert-notifier" } = props;

  const announceAlertOnFocus = alertAnnouncementHandler(props.alert);

  return (
    <A11y.View
      {...props}
      ref={ref}
      testID={testID}
      onScreenReaderDescendantFocusChanged={announceAlertOnFocus}
    />
  );
});

export default ScreenReaderAlertNotifier;
