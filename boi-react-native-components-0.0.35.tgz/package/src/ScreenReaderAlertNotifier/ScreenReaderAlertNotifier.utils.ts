import { AccessibilityInfo } from "react-native";
import { ScreenReaderAlertNotifierProps } from "./ScreenReaderAlertNotifier.types";
import { ScreenReaderDescendantFocusChangedEvent } from "react-native-a11y-order";

export const getAlertMessage = (
  alert: ScreenReaderAlertNotifierProps["alert"]
) => {
  if (!alert) {
    return undefined;
  }

  if (typeof alert === "string") {
    return alert;
  }

  const alertTexts = (
    Array.isArray(alert)
      ? `${alert.map((el) => el.children).join(" ")}`
      : alert
      ? `${alert?.children}`
      : ""
  ).trim();

  return alertTexts;
};

export const alertAnnouncementHandler =
  (alert: ScreenReaderAlertNotifierProps["alert"]) =>
  (e: ScreenReaderDescendantFocusChangedEvent) => {
    const message = getAlertMessage(alert);
    if (message && e.nativeEvent.status === "focused") {
      AccessibilityInfo.announceForAccessibilityWithOptions(message, {
        queue: true,
      });
    }
  };
