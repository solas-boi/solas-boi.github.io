import { ViewProps } from "react-native";
import { InputAlertsProps } from "../InputAlerts";

export type ScreenReaderAlertNotifierProps = ViewProps & {
  alert?:
    | string
    | InputAlertsProps["alerts"][number]
    | InputAlertsProps["alerts"]
    | undefined;
};
