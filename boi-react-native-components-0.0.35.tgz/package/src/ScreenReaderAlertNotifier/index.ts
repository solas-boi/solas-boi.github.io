export type { ScreenReaderAlertNotifierProps } from "./ScreenReaderAlertNotifier.types";
export { default as ScreenReaderAlertNotifier } from "./ScreenReaderAlertNotifier";
