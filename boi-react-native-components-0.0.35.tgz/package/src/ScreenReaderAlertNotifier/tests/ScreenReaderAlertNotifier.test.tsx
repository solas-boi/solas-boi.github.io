import { render, screen } from "@testing-library/react-native";
import { AccessibilityInfo, Text } from "react-native";

import ScreenReaderAlertNotifier from "../ScreenReaderAlertNotifier";

const mockAnnounceForAccessibilityWithOptions = jest.fn();

jest
  .spyOn(AccessibilityInfo, "announceForAccessibilityWithOptions")
  .mockImplementation(mockAnnounceForAccessibilityWithOptions);

describe("ScreenReaderAlertNotifier", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should render children", () => {
    render(
      <ScreenReaderAlertNotifier>
        <Text testID="notifier-child">Child</Text>
      </ScreenReaderAlertNotifier>
    );

    expect(screen.getByTestId("notifier-child")).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<ScreenReaderAlertNotifier />);

    expect(screen.getByTestId("screen-reader-alert-notifier")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-screen-reader-alert-notifier";

    render(<ScreenReaderAlertNotifier testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  it("should announce alert message when descendant gets focused", () => {
    render(
      <ScreenReaderAlertNotifier
        alert="Something went wrong"
        testID="notifier"
      />
    );

    const notifier = screen.getByTestId("notifier");

    notifier.props.onScreenReaderDescendantFocusChanged({
      nativeEvent: { status: "focused" },
    });

    expect(mockAnnounceForAccessibilityWithOptions).toHaveBeenCalledTimes(1);
    expect(mockAnnounceForAccessibilityWithOptions).toHaveBeenCalledWith(
      "Something went wrong",
      {
        queue: true,
      }
    );
  });

  it("should not announce alert message when descendant is not focused", () => {
    render(
      <ScreenReaderAlertNotifier
        alert="Something went wrong"
        testID="notifier"
      />
    );

    const notifier = screen.getByTestId("notifier");

    notifier.props.onScreenReaderDescendantFocusChanged({
      nativeEvent: { status: "blurred" },
    });

    expect(mockAnnounceForAccessibilityWithOptions).not.toHaveBeenCalled();
  });
});
