import { AccessibilityInfo } from "react-native";

import {
  alertAnnouncementHandler,
  getAlertMessage,
} from "../ScreenReaderAlertNotifier.utils";

const mockAnnounceForAccessibilityWithOptions = jest.fn();

jest
  .spyOn(AccessibilityInfo, "announceForAccessibilityWithOptions")
  .mockImplementation(mockAnnounceForAccessibilityWithOptions);

describe("ScreenReaderAlertNotifier.utils", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("getAlertMessage", () => {
    it("should return undefined when alert is undefined", () => {
      expect(getAlertMessage(undefined)).toBeUndefined();
    });

    it("should return the alert when alert is a string", () => {
      expect(getAlertMessage("Something went wrong")).toBe(
        "Something went wrong"
      );
    });

    it("should return children when alert is an object", () => {
      expect(
        getAlertMessage({ severity: "error", children: "Error message" })
      ).toBe("Error message");
    });

    it("should trim children when alert is an object", () => {
      expect(
        getAlertMessage({ severity: "error", children: "  Error message  " })
      ).toBe("Error message");
    });

    it("should join children when alert is an array", () => {
      expect(
        getAlertMessage([
          { severity: "error", children: "First message" },
          { severity: "warning", children: "Second message" },
        ])
      ).toBe("First message Second message");
    });

    it("should join and trim children when alert is an array", () => {
      expect(
        getAlertMessage([
          { severity: "error", children: "  First message" },
          { severity: "warning", children: "Second message  " },
        ])
      ).toBe("First message Second message");
    });
  });

  describe("alertAnnouncementHandler", () => {
    it("should announce alert when status is focused", () => {
      const onFocusChange = alertAnnouncementHandler("Something went wrong");

      onFocusChange({
        nativeEvent: { status: "focused" },
      } as never);

      expect(mockAnnounceForAccessibilityWithOptions).toHaveBeenCalledTimes(1);
      expect(mockAnnounceForAccessibilityWithOptions).toHaveBeenCalledWith(
        "Something went wrong",
        {
          queue: true,
        }
      );
    });

    it("should not announce alert when status is not focused", () => {
      const onFocusChange = alertAnnouncementHandler("Something went wrong");

      onFocusChange({
        nativeEvent: { status: "blurred" },
      } as never);

      expect(mockAnnounceForAccessibilityWithOptions).not.toHaveBeenCalled();
    });

    it("should not announce when there is no alert message", () => {
      const onFocusChange = alertAnnouncementHandler(undefined);

      onFocusChange({
        nativeEvent: { status: "focused" },
      } as never);

      expect(mockAnnounceForAccessibilityWithOptions).not.toHaveBeenCalled();
    });
  });
});
