import { View } from "react-native";
import {
  render,
  screen,
  within,
  userEvent,
  act,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import LinkWithIcon, { type LinkWithIconProps } from "./LinkWithIcon";

jest.useFakeTimers();

function WrappedLinkWithIcon(props: LinkWithIconProps) {
  return (
    <DesignTokensProvider>
      <LinkWithIcon {...props} />
    </DesignTokensProvider>
  );
}

function MockIcon() {
  return <View testID="mock-icon" />;
}

describe("LinkWithIcon", () => {
  let baseProps: LinkWithIconProps;

  beforeEach(() => {
    baseProps = {
      children: "Text link label",
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedLinkWithIcon {...baseProps} />);

    const text = screen.getByRole("text");
    expect(text).toBeDefined();
  });

  it("should render with the correct text", () => {
    render(<WrappedLinkWithIcon {...baseProps} />);

    const text = screen.getByRole("text");
    expect(text).toHaveTextContent(baseProps.children);
  });

  it("should render with a start icon when provided", () => {
    render(<WrappedLinkWithIcon {...baseProps} startIcon={<MockIcon />} />);

    const button = screen.getByRole("link");
    const iconWrapper = within(button).getByTestId("link-start-icon-wrapper");
    const icon = within(iconWrapper).getByTestId("mock-icon");

    expect(icon).toBeDefined();
  });

  it("should render with an end icon when provided", () => {
    render(<WrappedLinkWithIcon {...baseProps} endIcon={<MockIcon />} />);

    const button = screen.getByRole("link");
    const iconWrapper = within(button).getByTestId("link-end-icon-wrapper");
    const icon = within(iconWrapper).getByTestId("mock-icon");

    expect(icon).toBeDefined();
  });

  it("should trigger the onPress event when pressed", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(
      <WrappedLinkWithIcon onPress={mockOnPress}>
        Text link label
      </WrappedLinkWithIcon>
    );

    const button = screen.getByRole("link");
    expect(button).toBeDefined();

    await act(async () => {
      await user.press(button);
    });

    expect(mockOnPress).toHaveBeenCalled();
  });

  it("should render with a default testID", () => {
    render(<WrappedLinkWithIcon {...baseProps} />);

    expect(screen.getByTestId("link")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-link";

    render(<WrappedLinkWithIcon {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
