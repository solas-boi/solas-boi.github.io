import type { Meta, StoryObj } from "@storybook/react";
import { CoreLink } from "@boi/components-core";
import * as Icons from "@boi/react-native-icons";
import { getIconSelectArgType } from "@boi/react-utils";

import LinkWithIcon from "./LinkWithIcon";

const getIconSelectArg = getIconSelectArgType as unknown as (
  svg: object
) => object;

const meta = {
  title: "Inputs/LinkWithIcon",
  component: LinkWithIcon,
  argTypes: {
    variant: {
      control: { type: "select" },
      options: CoreLink.VARIANTS.filter((variant) =>
        ["bodyM", "bodyS"].includes(variant)
      ),
    },
    startIcon: {
      ...(getIconSelectArg(Icons) as {}),
      if: { arg: "endIcon", truthy: false },
    },
    endIcon: {
      ...(getIconSelectArg(Icons) as {}),
      if: { arg: "startIcon", truthy: false },
    },
  },
  args: {
    variant: CoreLink.DEFAULT_VARIANT,
  },
} satisfies Meta<typeof LinkWithIcon>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const StartIcon: Story = {
  args: {
    children: "Download report",
    startIcon: <Icons.DownloadIcon />,
  },
};

export const EndIcon: Story = {
  args: {
    children: "Log in",
    endIcon: <Icons.LoginIcon />,
  },
};
