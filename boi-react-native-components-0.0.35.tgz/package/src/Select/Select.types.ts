import type { CoreSelect } from "@boi/components-core";

export type SelectItem = CoreSelect.SelectItem;
