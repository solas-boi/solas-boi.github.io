import { useCallback, useEffect, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";
import { CoreSelect } from "@boi/components-core";

import Select, { type SelectProps } from "./Select";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const ControlledSelect = (props: SelectProps) => {
  const { onChange, selectedItem, ...rest } = props;

  const [item, setItem] = useState<SelectProps["selectedItem"]>(selectedItem);

  const handleChange: SelectProps["onChange"] = useCallback(
    (newSelectedItem) => {
      setItem(newSelectedItem);
      onChange(newSelectedItem);
    },
    [onChange]
  );

  useEffect(() => {
    setItem(selectedItem);
  }, [selectedItem]);

  return (
    <FocusControlWrapper {...rest}>
      {(ref) => (
        <Select
          pressableRef={ref}
          selectedItem={item}
          onChange={handleChange}
          {...rest}
        />
      )}
    </FocusControlWrapper>
  );
};

const meta = {
  title: "Inputs/Select",
  component: Select,
  render: function Render(args) {
    const [{ selectedItem }, updateArgs] = useArgs();

    function handleChange(newSelectedItem: any) {
      action("onChange")(newSelectedItem);
      updateArgs({ selectedItem: newSelectedItem });
    }

    return (
      <ControlledSelect
        {...args}
        selectedItem={selectedItem}
        onChange={handleChange}
        supportedOrientations={["landscape", "portrait"]}
      />
    );
  },
  argTypes: {
    hasError: { control: "boolean" },
  },
  args: {
    hasError: false,
    isDisabled: false,
    items: CoreSelect.mockItems,
    placeholder: "Select",
  },
} satisfies Meta<SelectProps>;

export default meta;
type Story = StoryObj<SelectProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "Select",
    },
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "Select with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "Select with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithError: Story = {
  args: {
    hasError: true,
    labelProps: {
      label: "Select with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const DisabledItems: Story = {
  args: {
    disabledKeys: CoreSelect.mockItems.slice(1, 3).map(({ id }) => id),
    labelProps: {
      label: "Select with Disabled Items",
    },
  },
};

export const ItemsWithCustomAriaLabel: Story = {
  args: {
    items: CoreSelect.mockItemsWithAriaLabel,
    placeholder: "Select",
    labelProps: {
      label: "Select with ariaLabel on items",
    },
  },
};
