import { useState } from "react";
import { View } from "react-native";
import { CoreSelect } from "@boi/components-core";

import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { InputWrapper } from "../InputWrapper";
import { SelectBase, type SelectBaseProps } from "../SelectBase";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type SelectProps<
  T extends CoreSelect.SelectItem = CoreSelect.SelectItem
> = Omit<SelectBaseProps<T>, "isOpen" | "onFocus" | "onBlur"> & {
  labelProps: InputLabelTopProps;
  placeholder?: string;
  selectedItem?: T | null | undefined;
  onChange: (selectedItem: T | null | undefined) => void;
  alertProps?: InputAlertsProps["alerts"][number] | InputAlertsProps["alerts"];
};

function Select<T extends CoreSelect.SelectItem = CoreSelect.SelectItem>(
  props: SelectProps<T>
) {
  const {
    labelProps,
    alertProps,
    testID = "select",
    ...selectBaseProps
  } = props;

  const [isOpen, setOpen] = useState(false);

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <ScreenReaderAlertNotifier alert={alertProps}>
          <SelectBase
            {...selectBaseProps}
            labelProps={labelProps}
            alertProps={alertProps}
            isOpen={isOpen}
            onFocus={() => setOpen(true)}
            onBlur={() => setOpen(false)}
            testID={testID}
          />
        </ScreenReaderAlertNotifier>
      </InputLabelTop>
    </InputWrapper>
  );
}

export default Select;
