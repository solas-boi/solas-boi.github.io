import type { Meta, StoryObj } from "@storybook/react";

import ProgressIndicator from "./ProgressIndicator";
import { CoreProgressIndicator } from "@boi/components-core";

const meta = {
  title: "Data Display/ProgressIndicator",
  component: ProgressIndicator,
  argTypes: {
    totalSteps: { control: "number" },
    currentStep: { control: "number" },
    backgroundVariant: {
      control: "select",
      options: CoreProgressIndicator.BACKGROUND_VARIANTS,
    },
  },
  args: {
    totalSteps: 5,
    currentStep: 3,
    backgroundVariant: "alt",
  },
} satisfies Meta<typeof ProgressIndicator>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {},
};
