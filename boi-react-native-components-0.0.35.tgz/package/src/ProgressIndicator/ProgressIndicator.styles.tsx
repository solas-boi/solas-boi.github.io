import { StyleSheet } from "react-native";

import { isTablet } from "react-native-device-info";

import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { progressIndicator } = tokens;

  return StyleSheet.create({
    container: {
      display: "flex",
      flexDirection: "row",
      gap: isTablet()
        ? progressIndicator.segments.gap.tablet
        : progressIndicator.segments.gap.mobile,
    },
    label: {
      color: progressIndicator.label.text.color,
      marginBottom: progressIndicator.label.marginBottom,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
