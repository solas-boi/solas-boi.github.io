import { StyleSheet } from "react-native";

import { isTablet } from "react-native-device-info";

import type { ThemeTokens } from "@boi/react-native-design-tokens";
import { CoreProgressIndicator } from "@boi/components-core";

import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { segment } = tokens.progressIndicator.segments;

  return StyleSheet.create({
    segment: {
      borderRadius: segment.radius,
      height: segment.height.mobile,
      flex: 1,
    },
    segmentTablet: {
      height: segment.height.tablet,
    },
    filled: {
      backgroundColor: segment.background.filled,
    },
    notFilled: {
      backgroundColor: segment.background.notFilled,
    },
    notFilledAlt: {
      backgroundColor: segment.background.notFilledAlt,
    },
    first: {
      borderTopLeftRadius: segment.borderTopLeftRadius.first,
      borderBottomLeftRadius: segment.borderBottomLeftRadius.first,
    },
    last: {
      borderTopRightRadius: segment.borderTopRightRadius.last,
      borderBottomRightRadius: segment.borderBottomRightRadius.last,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  backgroundVariant,
  isFilled,
  isFirst,
  isLast,
}: {
  backgroundVariant: CoreProgressIndicator.BackgroundVariant;
  isFilled: boolean;
  isFirst: boolean;
  isLast: boolean;
}) {
  const styles = useStyles();

  return {
    segment: [
      styles.segment,
      isTablet() && styles.segmentTablet,
      isFilled
        ? styles.filled
        : backgroundVariant === "alt"
        ? styles.notFilledAlt
        : styles.notFilled,
      isFirst && styles.first,
      isLast && styles.last,
    ],
  };
}
