import { View } from "react-native";
import { CoreProgressIndicator } from "@boi/components-core";
import { useStateStyles } from "./Step.styles";

export type StepProps = {
  backgroundVariant: CoreProgressIndicator.BackgroundVariant;
  isFilled: boolean;
  isFirst: boolean;
  isLast: boolean;
  testID?: string;
};

export const defaultTestID = "step";

export default function Step({
  backgroundVariant,
  isFilled,
  isFirst,
  isLast,
  testID = defaultTestID,
}: StepProps) {
  const style = useStateStyles({
    backgroundVariant,
    isFilled,
    isFirst,
    isLast,
  });

  return <View style={style.segment} testID={testID} />;
}
