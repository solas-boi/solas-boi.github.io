import { render, screen } from "@testing-library/react-native";

import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import {
  defaultTestID,
  default as ProgressIndicator,
} from "./ProgressIndicator";

describe(ProgressIndicator.name, () => {
  it("renders the label correctly", () => {
    render(
      <DesignTokensProvider>
        <ProgressIndicator totalSteps={5} currentStep={3} />
      </DesignTokensProvider>
    );
    const title = screen.getByTestId(`${defaultTestID}-label`);
    expect(title).toBeVisible();
    expect(title).toHaveTextContent("Step 3/5");
  });

  it("renders the content correctly", () => {
    const item = (step: number) =>
      screen.getByTestId(`${defaultTestID}-step-${step}`);

    render(
      <DesignTokensProvider>
        <ProgressIndicator totalSteps={5} currentStep={2} />
      </DesignTokensProvider>
    );

    const activeStyle = {
      backgroundColor: "#1b406d",
    };
    const inactiveStyle = {
      backgroundColor: "#eceef6",
    };

    expect(item(0)).toBeVisible();
    expect(item(1)).toBeVisible();
    expect(item(2)).toBeVisible();
    expect(item(3)).toBeVisible();
    expect(item(4)).toBeVisible();

    expect(item(0)).toHaveStyle(activeStyle);
    expect(item(1)).toHaveStyle(activeStyle);
    expect(item(2)).toHaveStyle(inactiveStyle);
    expect(item(3)).toHaveStyle(inactiveStyle);
    expect(item(4)).toHaveStyle(inactiveStyle);
  });
});
