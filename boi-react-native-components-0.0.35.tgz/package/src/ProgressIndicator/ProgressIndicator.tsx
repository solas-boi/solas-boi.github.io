import { useCallback, useMemo } from "react";
import { View } from "react-native";

import { isTablet } from "react-native-device-info";

import { Typography, TypographyProps } from "../Typography";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import {
  CoreProgressIndicator,
  PropsWithOptionalTestID,
} from "@boi/components-core";

import useStyles from "./ProgressIndicator.styles";
import Step from "./Step/Step";

export type ProgressIndicatorProps = PropsWithOptionalTestID & {
  totalSteps: number;
  currentStep: number;
  backgroundVariant?: CoreProgressIndicator.BackgroundVariant;
};

export const defaultTestID = "progress";

export default function ProgressIndicator({
  totalSteps,
  currentStep,
  backgroundVariant = CoreProgressIndicator.DEFAULT_VARIANT,
  testID = defaultTestID,
}: ProgressIndicatorProps) {
  const steps = useMemo(() => [...Array(totalSteps).keys()], [totalSteps]);
  const styles = useStyles();

  const renderStep = useCallback(
    (item: number, index: number) => {
      return (
        <Step
          key={item}
          testID={`${testID}-step-${item}`}
          backgroundVariant={backgroundVariant}
          isFirst={index === 0}
          isLast={index === steps.length - 1}
          isFilled={item < currentStep}
        />
      );
    },
    [currentStep, steps, backgroundVariant, testID]
  );

  return (
    <View testID={testID}>
      {/* eslint-disable-next-line react-native-a11y/has-accessibility-hint */}
      <ProgressIndicatorLabel
        role="progressbar"
        accessibilityRole="progressbar"
        accessibilityLabel={`Step ${currentStep} of ${totalSteps}`}
        testID={`${testID}-label`}
      >
        Step {currentStep}/{totalSteps}
      </ProgressIndicatorLabel>
      <View style={styles.container}>{steps.map(renderStep)}</View>
    </View>
  );
}

function ProgressIndicatorLabel(props: TypographyProps & { role: string }) {
  const { tokens } = useDesignTokens();
  const styles = useStyles();
  const variant = isTablet()
    ? tokens.progressIndicator.label.text.typography.variant.tablet
    : tokens.progressIndicator.label.text.typography.variant.mobile;
  return (
    <Typography
      style={styles.label}
      variant={variant}
      fontFamily={tokens.progressIndicator.label.text.typography.fontFamily}
      {...props}
      children={props.children}
    />
  );
}
