import { useCallback, useState } from "react";
import { CoreSelect } from "@boi/components-core";
import { SelectModalBase } from "../SelectModalBase";
import { StandardModal, StandardModalProps } from "../StandardModal";

export type SelectModalProps<T extends CoreSelect.SelectItem> = Omit<
  StandardModalProps,
  "children"
> & {
  selectedItem?: T | null | undefined;
  items: T[];
  disabledKeys?: string[];
  onChange: (selectedItem: T | null | undefined) => void;
};

function SelectModal<T extends CoreSelect.SelectItem>(
  props: SelectModalProps<T>
) {
  const {
    selectedItem,
    items,
    disabledKeys,
    onChange,
    testID = "select-modal",
    onOpenAnimationComplete,
    onCloseAnimationComplete,
    ...modalProps
  } = props;

  const [openAnimationFinished, setOpenAnimationFinished] = useState(false);

  const handleOpenAnimationComplete = useCallback(() => {
    setOpenAnimationFinished(true);
    onOpenAnimationComplete?.();
  }, [onOpenAnimationComplete]);

  const handleCloseAnimationComplete = useCallback(() => {
    setOpenAnimationFinished(false);
    onCloseAnimationComplete?.();
  }, [onCloseAnimationComplete]);

  return (
    <StandardModal
      {...modalProps}
      testID={testID}
      onOpenAnimationComplete={handleOpenAnimationComplete}
      onCloseAnimationComplete={handleCloseAnimationComplete}
    >
      <SelectModalBase
        readyToInteract={modalProps.isOpen && openAnimationFinished}
        onRequestClose={modalProps.onRequestClose}
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        onChange={onChange}
      />
    </StandardModal>
  );
}

export default SelectModal;
