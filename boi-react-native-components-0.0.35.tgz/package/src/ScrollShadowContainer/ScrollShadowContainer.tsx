import { PropsWithChildren } from "react";
import { View, ViewProps } from "react-native";
import { Shadow } from "react-native-shadow-2";

import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStateStyles from "./ScrollShadowContainer.styles";

export type ScrollShadowContainerProps = {
  topShadowVisible: boolean;
  bottomShadowVisible: boolean;
  contentWidth?: number;
  style?: ViewProps["style"];
};

function ScrollShadowContainer(
  props: PropsWithChildren<ScrollShadowContainerProps>
) {
  const { children, ...rest } = props;

  const { tokens } = useDesignTokens();
  const { scrollShadowContainer } = tokens;

  const styles = useStateStyles(rest);

  return (
    <View style={styles.scrollShadowContainer}>
      <View style={styles.shadowWrapperTop} pointerEvents="none">
        <Shadow
          style={styles.shadow}
          startColor={scrollShadowContainer.shadow.color}
          distance={4}
        />
      </View>

      {children}

      <View style={styles.shadowWrapperBottom} pointerEvents="none">
        <Shadow
          style={styles.shadow}
          startColor={scrollShadowContainer.shadow.color}
          distance={4}
        />
      </View>
    </View>
  );
}

export default ScrollShadowContainer;
