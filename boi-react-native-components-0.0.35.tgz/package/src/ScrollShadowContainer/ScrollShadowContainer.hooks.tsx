import { useRef, useState } from "react";
import {
  type LayoutChangeEvent,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from "react-native";

export type ScrollShadowContainerState = ReturnType<
  typeof useScrollShadowContainer
>;

export function useScrollShadowContainer() {
  const [topShadowVisible, setTopShadowVisible] = useState(false);
  const [bottomShadowVisible, setBottomShadowVisible] = useState(false);

  const [contentWidth, setContentWidth] = useState<number>(1);

  const contentHeight = useRef<number | undefined>(undefined);
  const layoutHeight = useRef<number | undefined>(undefined);
  const contentOffsetY = useRef(0);
  function determineShadows() {
    if (
      contentHeight.current === undefined ||
      layoutHeight.current === undefined
    ) {
      return;
    }

    // If content height is smaller or the same as scrollview size
    // reset contentOffsetY to 0
    if (contentHeight.current <= layoutHeight.current) {
      contentOffsetY.current = 0;
    }

    setTopShadowVisible(contentOffsetY.current > 0);
    setBottomShadowVisible(
      layoutHeight.current + contentOffsetY.current <
        Math.floor(contentHeight.current)
    );
  }
  function onScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
    const { layoutMeasurement, contentSize, contentOffset } = event.nativeEvent;

    contentHeight.current = contentSize.height;
    contentOffsetY.current = contentOffset.y;
    layoutHeight.current = layoutMeasurement.height;

    determineShadows();
  }

  function onLayout(event: LayoutChangeEvent) {
    const { width, height } = event.nativeEvent.layout;
    setContentWidth(width);

    layoutHeight.current = height;
    determineShadows();
  }
  function onContentChange(_width: number, height: number) {
    contentHeight.current = height;
    determineShadows();
  }

  return {
    contentHeight,
    layoutHeight,
    contentOffsetY,
    topShadowVisible,
    bottomShadowVisible,
    contentWidth,
    setTopShadowVisible,
    setBottomShadowVisible,
    setContentWidth,
    onScroll,
    onLayout,
    onContentChange,
  };
}
