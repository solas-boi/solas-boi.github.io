import { StyleSheet } from "react-native";
import { createThemedStyleSheet } from "../themedStylesheet";
import { ScrollShadowContainerProps } from "./ScrollShadowContainer";

function styleSheetFactory() {
  const styles = StyleSheet.create({
    scrollShadowContainer: {
      position: "relative",
      flexShrink: 1,
    },
    shadowWrapper: {
      opacity: 0,
      position: "absolute",
      left: 0,
      right: 0,
      height: 4,
      overflow: "hidden",
      zIndex: 1,
    },
    shadowWrapperVisible: {
      opacity: 1,
    },
    shadowWrapperTop: {
      top: 0,
      transform: [{ rotate: "0deg" }],
    },
    shadowWrapperBottom: {
      bottom: 0,
      transform: [{ rotate: "180deg" }],
    },
    shadow: {
      width: "100%",
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default function useStateStyles(props: ScrollShadowContainerProps) {
  const styles = useStyles();
  return {
    scrollShadowContainer: [styles.scrollShadowContainer, props.style],
    shadowWrapperTop: [
      styles.shadowWrapper,
      styles.shadowWrapperTop,
      props.topShadowVisible && styles.shadowWrapperVisible,
    ],
    shadowWrapperBottom: [
      styles.shadowWrapper,
      styles.shadowWrapperBottom,
      props.bottomShadowVisible && styles.shadowWrapperVisible,
    ],
    shadow: [
      styles.shadow,
      props.contentWidth ? { width: props.contentWidth } : undefined,
    ],
  };
}
