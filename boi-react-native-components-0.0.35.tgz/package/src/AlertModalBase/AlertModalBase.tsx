import { type PropsWithChildren } from "react";
import { View, ScrollView } from "react-native";
import { isTablet } from "react-native-device-info";
import {
  CoreAlertModal,
  PropsWithOptionalTestID,
  type AlertSeverity,
  type HeadingLevel,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import {
  ErrorIcon,
  WarningIcon,
  SuccessIcon,
  InfoIcon,
} from "@boi/react-native-icons";

import { useStateStyles } from "./AlertModalBase.styles";
import { useOrderedButtonsProps } from "./AlertModalBase.utils";
import { Typography } from "../Typography";
import { Button, type ButtonProps } from "../Button";
import {
  ScrollShadowContainer,
  useScrollShadowContainer,
} from "../ScrollShadowContainer";

export type AlertModalBaseProps = PropsWithOptionalTestID &
  PropsWithChildren & {
    heading: string;
    headingLevel?: HeadingLevel;
    severity?: AlertSeverity;
    primaryButtonsProps?: Omit<ButtonProps, "variant" | "fullWidth">[];
    secondaryButtonsProps?: Omit<ButtonProps, "variant" | "fullWidth">[];
    footerLayout?: CoreAlertModal.FooterLayout;
    hasStickyFooter?: boolean;
  };

const screenType = isTablet() ? "tablet" : "mobile";

function AlertModalBase(props: AlertModalBaseProps) {
  const {
    heading,
    headingLevel = CoreAlertModal.DEFAULT_HEADING_LEVEL,
    severity = CoreAlertModal.DEFAULT_SEVERITY,
    primaryButtonsProps,
    secondaryButtonsProps,
    hasStickyFooter,
    children,
    testID = "alert-modal",
    ...rest
  } = props;

  let { footerLayout = CoreAlertModal.DEFAULT_FOOTER_LAYOUT } = rest;
  if (screenType === "mobile") {
    footerLayout = "stacked";
  }

  const { tokens } = useDesignTokens();
  const { alertModal } = tokens;

  const state = useScrollShadowContainer();
  const {
    topShadowVisible,
    bottomShadowVisible,
    contentWidth,
    setContentWidth,
    onScroll,
    onLayout,
    onContentChange,
  } = state;

  const stateStyles = useStateStyles(severity, footerLayout, hasStickyFooter);

  const iconProps = {
    width: alertModal.icon.width[screenType],
    height: alertModal.icon.height[screenType],
    primaryColor: alertModal.icon.primaryColor[severity],
    secondaryColor: alertModal.icon.secondaryColor[severity],
  };

  const alertIcon = {
    error: <ErrorIcon {...iconProps} />,
    warning: <WarningIcon {...iconProps} />,
    success: <SuccessIcon {...iconProps} />,
    info: <InfoIcon {...iconProps} />,
  };

  const { orderedButtonsProps } = useOrderedButtonsProps(
    footerLayout,
    primaryButtonsProps,
    secondaryButtonsProps
  );

  const footer = (
    <View style={stateStyles.footer}>
      {orderedButtonsProps.map((buttonProps) => (
        <Button key={buttonProps.text} {...buttonProps} />
      ))}
    </View>
  );

  return (
    <>
      <View
        style={stateStyles.header}
        onLayout={(evt) => {
          setContentWidth(evt.nativeEvent.layout.width);
        }}
      >
        <View>{alertIcon[severity]}</View>

        <Typography
          component={`h${headingLevel}`}
          variant={alertModal.heading.typography.variant}
          fontFamily={alertModal.heading.typography.fontFamily}
          testID={`${testID}-heading`}
        >
          {heading}
        </Typography>
      </View>

      <ScrollShadowContainer
        topShadowVisible={topShadowVisible}
        bottomShadowVisible={bottomShadowVisible}
        contentWidth={contentWidth}
      >
        <ScrollView
          alwaysBounceVertical={false}
          bounces={false}
          overScrollMode="never"
          onScroll={onScroll}
          onLayout={onLayout}
          onContentSizeChange={onContentChange}
        >
          <View style={stateStyles.container}>
            <View style={stateStyles.body} testID={`${testID}-body`}>
              {children}
            </View>

            {!hasStickyFooter ? footer : undefined}
          </View>
        </ScrollView>
      </ScrollShadowContainer>

      {hasStickyFooter ? footer : undefined}
    </>
  );
}

export default AlertModalBase;
