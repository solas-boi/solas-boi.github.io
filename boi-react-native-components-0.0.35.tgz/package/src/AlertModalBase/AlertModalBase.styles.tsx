import { StyleSheet } from "react-native";
import { isTablet } from "react-native-device-info";
import { CoreAlertModal, type AlertSeverity } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { alertModal, modal } = tokens;
  const screenType = isTablet() ? "tablet" : "mobile";
  const styles = StyleSheet.create({
    header: {
      backgroundColor: modal.backgroundColor,
      borderTopWidth: alertModal.stroke.top.width,
      borderStyle: alertModal.stroke.top.style,
      paddingTop: alertModal.padding[screenType].top,
      paddingLeft: alertModal.padding[screenType].left,
      paddingRight: alertModal.padding[screenType].right,
      paddingBottom: alertModal.header.padding.bottom,
      gap: alertModal.header.gap,
    },
    container: {
      paddingLeft: alertModal.padding[screenType].left,
      paddingRight: alertModal.padding[screenType].right,
    },
    headerSeverityError: {
      borderTopColor: alertModal.stroke.top.color.error,
    },
    headerSeverityWarning: {
      borderTopColor: alertModal.stroke.top.color.warning,
    },
    headerSeveritySuccess: {
      borderTopColor: alertModal.stroke.top.color.success,
    },
    headerSeverityInfo: {
      borderTopColor: alertModal.stroke.top.color.info,
    },
    footer: {
      gap: alertModal.footer.gap,
      paddingBottom: alertModal.padding[screenType].bottom,
    },
    body: {
      paddingBottom: alertModal.body.padding.default.bottom,
    },
    bodyWithStickyFooter: {
      paddingBottom: alertModal.body.padding.withStickyFooter.bottom,
    },
    footerInline: {
      flexDirection: "row",
    },
    footerSticky: {
      paddingTop: alertModal.footer.sticky.padding.top,
      paddingBottom: alertModal.footer.sticky.padding.bottom,
      paddingLeft: alertModal.padding[screenType].left,
      paddingRight: alertModal.padding[screenType].right,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  severity: AlertSeverity,
  footerLayout: CoreAlertModal.FooterLayout,
  hasStickyFooter?: boolean
) {
  const styles = useStyles();

  const headerSeverityStyles = {
    error: styles.headerSeverityError,
    warning: styles.headerSeverityWarning,
    success: styles.headerSeveritySuccess,
    info: styles.headerSeverityInfo,
  };

  return {
    header: [styles.header, headerSeverityStyles[severity]],
    container: [styles.container],
    body: [
      styles.body,
      hasStickyFooter ? styles.bodyWithStickyFooter : undefined,
    ],
    footer: [
      styles.footer,
      footerLayout === "inline" ? styles.footerInline : undefined,
      hasStickyFooter ? styles.footerSticky : undefined,
    ],
  };
}

export default useStyles;
