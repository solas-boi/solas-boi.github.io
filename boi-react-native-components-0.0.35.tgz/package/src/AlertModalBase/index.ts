export {
  default as AlertModalBase,
  type AlertModalBaseProps,
} from "./AlertModalBase";
