import { CoreAlertModal } from "@boi/components-core";
import { type ButtonProps } from "../Button";

export function useOrderedButtonsProps(
  footerLayout: CoreAlertModal.FooterLayout,
  primaryButtonsProps?: ButtonProps[],
  secondaryButtonsProps?: ButtonProps[]
) {
  const isStacked = footerLayout === "stacked";
  const updatedPrimaryButtonsProps = (primaryButtonsProps || []).map(
    (buttonProps) => {
      return {
        ...buttonProps,
        variant: "primary",
        fullWidth: isStacked,
      } as const;
    }
  );

  const updatedSecondaryButtonsProps = (secondaryButtonsProps || []).map(
    (buttonProps) => {
      return {
        ...buttonProps,
        variant: "secondary",
        fullWidth: isStacked,
      } as const;
    }
  );

  const orderedButtonsProps = [];

  if (footerLayout === "stacked") {
    orderedButtonsProps.push(
      ...updatedPrimaryButtonsProps.reverse(),
      ...updatedSecondaryButtonsProps.reverse()
    );
  } else {
    orderedButtonsProps.push(
      ...updatedSecondaryButtonsProps,
      ...updatedPrimaryButtonsProps
    );
  }

  return { orderedButtonsProps };
}
