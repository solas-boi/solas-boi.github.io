import { RefObject } from "react";
import { AccessibilityInfo, findNodeHandle } from "react-native";
import { FocusableComponent } from "../types";

/**
 * Sets accessibility focus on a node handle (React tag) tied to a React ref.
 * @param ref - A React ref object pointing to a native element.
 */
export const setAccessibilityFocus = <T extends FocusableComponent>(
  ref?: RefObject<T>
) => {
  if (!ref?.current) {
    return;
  }

  try {
    ref.current.focus?.();
  } catch (e) {}

  try {
    const reactTag = findNodeHandle(ref.current);

    if (reactTag) {
      AccessibilityInfo.setAccessibilityFocus(reactTag);
    }
  } catch (e) {}
};
