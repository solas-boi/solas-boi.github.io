import { RefObject } from "react";
import { AccessibilityInfo, findNodeHandle } from "react-native";

import { setAccessibilityFocus } from "./setAccessibilityFocus";
import type { FocusableComponent } from "../types";

jest.mock("react-native", () => ({
  AccessibilityInfo: {
    setAccessibilityFocus: jest.fn(),
  },
  findNodeHandle: jest.fn(),
}));

const mockAccessibilityInfo = AccessibilityInfo as jest.Mocked<
  typeof AccessibilityInfo
>;
const mockFindNodeHandle = findNodeHandle as jest.MockedFunction<
  typeof findNodeHandle
>;

describe("setAccessibilityFocus", () => {
  let mockRef: RefObject<FocusableComponent>;
  let mockComponent: Partial<jest.Mocked<FocusableComponent>>;

  beforeEach(() => {
    jest.clearAllMocks();

    mockComponent = {
      focus: jest.fn(),
    };

    mockRef = {
      current: mockComponent as FocusableComponent,
    };
  });

  describe("when ref is valid", () => {
    it("should call focus method on the component if it exists", () => {
      const mockReactTag = 12345;
      mockFindNodeHandle.mockReturnValue(mockReactTag);

      setAccessibilityFocus(mockRef);

      expect(mockComponent.focus).toHaveBeenCalledTimes(1);
    });

    it("should call AccessibilityInfo.setAccessibilityFocus with the correct react tag", () => {
      const mockReactTag = 12345;
      mockFindNodeHandle.mockReturnValue(mockReactTag);

      setAccessibilityFocus(mockRef);

      expect(mockFindNodeHandle).toHaveBeenCalledWith(mockComponent);
      expect(mockAccessibilityInfo.setAccessibilityFocus).toHaveBeenCalledWith(
        mockReactTag
      );
    });

    it("should not call AccessibilityInfo.setAccessibilityFocus when findNodeHandle returns null", () => {
      mockFindNodeHandle.mockReturnValue(null);

      setAccessibilityFocus(mockRef);

      expect(mockFindNodeHandle).toHaveBeenCalledWith(mockComponent);
      expect(
        mockAccessibilityInfo.setAccessibilityFocus
      ).not.toHaveBeenCalled();
    });

    it("should handle focus method throwing an error gracefully", () => {
      const mockReactTag = 12345;
      mockComponent.focus = jest.fn().mockImplementation(() => {
        throw new Error("Focus failed");
      });
      mockFindNodeHandle.mockReturnValue(mockReactTag);

      expect(() => setAccessibilityFocus(mockRef)).not.toThrow();
      expect(mockAccessibilityInfo.setAccessibilityFocus).toHaveBeenCalledWith(
        mockReactTag
      );
    });

    it("should handle findNodeHandle throwing an error gracefully", () => {
      mockFindNodeHandle.mockImplementation(() => {
        throw new Error("findNodeHandle failed");
      });

      expect(() => setAccessibilityFocus(mockRef)).not.toThrow();
      expect(
        mockAccessibilityInfo.setAccessibilityFocus
      ).not.toHaveBeenCalled();
    });

    it("should work when component does not have focus method", () => {
      const componentWithoutFocus = {} as FocusableComponent;
      const refWithoutFocus = { current: componentWithoutFocus };
      const mockReactTag = 12345;
      mockFindNodeHandle.mockReturnValue(mockReactTag);

      expect(() => setAccessibilityFocus(refWithoutFocus)).not.toThrow();
      expect(mockAccessibilityInfo.setAccessibilityFocus).toHaveBeenCalledWith(
        mockReactTag
      );
    });
  });

  describe("when ref is invalid", () => {
    it("should return early when ref is undefined", () => {
      setAccessibilityFocus(undefined);

      expect(
        mockAccessibilityInfo.setAccessibilityFocus
      ).not.toHaveBeenCalled();
      expect(mockFindNodeHandle).not.toHaveBeenCalled();
    });

    it("should return early when ref.current is null", () => {
      const nullRef = { current: null };

      setAccessibilityFocus(nullRef);

      expect(
        mockAccessibilityInfo.setAccessibilityFocus
      ).not.toHaveBeenCalled();
      expect(mockFindNodeHandle).not.toHaveBeenCalled();
    });

    it("should return early when ref.current is undefined", () => {
      const undefinedRef: RefObject<FocusableComponent> = { current: null };

      setAccessibilityFocus(undefinedRef);

      expect(
        mockAccessibilityInfo.setAccessibilityFocus
      ).not.toHaveBeenCalled();
      expect(mockFindNodeHandle).not.toHaveBeenCalled();
    });
  });

  describe("error handling", () => {
    it("should handle AccessibilityInfo.setAccessibilityFocus throwing an error gracefully", () => {
      const mockReactTag = 12345;
      mockFindNodeHandle.mockReturnValue(mockReactTag);
      mockAccessibilityInfo.setAccessibilityFocus.mockImplementation(() => {
        throw new Error("setAccessibilityFocus failed");
      });

      expect(() => setAccessibilityFocus(mockRef)).not.toThrow();
      expect(mockComponent.focus).toHaveBeenCalledTimes(1);
      expect(mockAccessibilityInfo.setAccessibilityFocus).toHaveBeenCalledWith(
        mockReactTag
      );
    });
  });
});
