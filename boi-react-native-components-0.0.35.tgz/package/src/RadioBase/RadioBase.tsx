import { View, ViewProps } from "react-native";

import { useStateStyles } from "./RadioBase.styles";

export type RadioBaseProps = Omit<ViewProps, "style" | "children"> & {
  disabled?: boolean | null;
  isChecked?: boolean;
  hasError?: boolean;
  children?: (radioComponent: JSX.Element) => JSX.Element;
};

function RadioBase(props: RadioBaseProps) {
  const {
    isChecked,
    hasError,
    children,
    disabled,
    testID = "radio-base",
    ...viewProps
  } = props;

  const stateStyles = useStateStyles({ disabled, hasError });

  const jsx = (
    <View testID={testID} style={stateStyles.customRadio} {...viewProps}>
      {isChecked && <View style={stateStyles.icon} />}
    </View>
  );

  if (children) {
    return children(jsx);
  } else {
    return jsx;
  }
}

export default RadioBase;
