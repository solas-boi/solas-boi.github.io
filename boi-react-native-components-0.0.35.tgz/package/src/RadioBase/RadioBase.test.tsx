import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import RadioBase, { type RadioBaseProps } from "./RadioBase";

jest.useFakeTimers();

function WrappedRadioBase(props: RadioBaseProps) {
  return (
    <DesignTokensProvider>
      <RadioBase {...props} />
    </DesignTokensProvider>
  );
}

describe("RadioBase", () => {
  it("should render without any children", () => {
    render(<WrappedRadioBase />);

    const Radio = screen.getByTestId("radio-base");

    expect(Radio).toBeDefined();
  });
});
