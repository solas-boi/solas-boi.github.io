import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../themedStylesheet";
import { type RadioBaseProps } from "./RadioBase";

function styleSheetFactory(tokens: ThemeTokens) {
  const { radio } = tokens;

  return StyleSheet.create({
    customRadio: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: radio.width,
      height: radio.height,
      backgroundColor: radio.backgroundColor.base,
      borderRadius: Math.max(radio.width, radio.height),
      borderWidth: radio.stroke.width.base,
      borderStyle: radio.stroke.style.base,
      borderColor: radio.stroke.color.base,
    },
    customRadioError: {
      borderWidth: radio.stroke.width.error,
      borderColor: radio.stroke.color.error,
    },
    customRadioDisabled: {
      borderWidth: radio.stroke.width.disabled,
      borderColor: radio.stroke.color.disabled,
    },
    icon: {
      width: radio.icon.width,
      height: radio.icon.height,
      backgroundColor: radio.icon.color.base,
      borderRadius: Math.max(radio.icon.width, radio.icon.height),
    },
    iconDisabled: {
      backgroundColor: radio.icon.color.disabled,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  disabled,
  hasError,
}: Pick<RadioBaseProps, "disabled" | "hasError">) {
  const styles = useStyles();

  return {
    customRadio: [
      styles.customRadio,
      hasError && styles.customRadioError,
      disabled && styles.customRadioDisabled,
    ],
    icon: [styles.icon, disabled && styles.iconDisabled],
  };
}

export default useStyles;
