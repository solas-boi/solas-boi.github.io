import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { menu } = tokens;

  return StyleSheet.create({
    listItem: {
      minHeight: menu.option.minHeight,
      padding: menu.option.padding,
      backgroundColor: menu.option.backgroundColor.base,
    },
    listItemContentWrapper: {
      display: "flex",
      justifyContent: "center",
      flex: 1,
      paddingTop: menu.option.inner.padding.top,
      paddingLeft: menu.option.inner.padding.left,
      paddingRight: menu.option.inner.padding.right,
      paddingBottom: menu.option.inner.padding.bottom,
      borderRadius: menu.option.inner.radius,
      backgroundColor: menu.option.inner.backgroundColor.base,
      borderWidth: menu.option.inner.stroke.width,
      borderStyle: menu.option.inner.stroke.style,
      borderColor: menu.option.inner.stroke.color.base,
      overflow: "hidden",
    },
    listItemContentWrapperPressed: {
      backgroundColor: menu.option.inner.backgroundColor.active,
      borderColor: menu.option.inner.stroke.color.active,
    },
    listItemContentWrapperFocused: {
      backgroundColor: menu.option.inner.backgroundColor.hover,
      borderColor: menu.option.inner.stroke.color.hover,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles() {
  const styles = useStyles();

  return {
    listItemContentWrapper: (pressed: boolean, hasKeyboardFocus: boolean) => [
      styles.listItemContentWrapper,
      hasKeyboardFocus && styles.listItemContentWrapperFocused,
      pressed && styles.listItemContentWrapperPressed,
    ],
  };
}

export default useStyles;
