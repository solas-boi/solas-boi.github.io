import { View } from "react-native";

import useStyles from "./InputAlerts.styles";
import { InlineAlert, type InlineAlertProps } from "../InlineAlert";

export type InputAlertsProps = {
  alerts: InlineAlertProps[];
};

function InputAlerts(props: InputAlertsProps) {
  const { alerts } = props;

  const styles = useStyles();

  return (
    <View style={styles.container}>
      {alerts.map((alertProps) => (
        <InlineAlert key={alertProps.children} {...alertProps} />
      ))}
    </View>
  );
}

export default InputAlerts;
