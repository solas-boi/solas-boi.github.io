export { default as InputAlerts, type InputAlertsProps } from "./InputAlerts";
