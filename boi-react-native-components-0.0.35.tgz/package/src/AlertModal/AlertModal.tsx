import { useDesignTokens } from "@boi/react-native-design-tokens";
import { AlertModalBase, type AlertModalBaseProps } from "../AlertModalBase";
import { Modal, type ModalProps } from "../Modal";
import { Typography, type TypographyProps } from "../Typography";

export type AlertModalProps = AlertModalBaseProps &
  Omit<ModalProps, "onRequestClose" | "__useTalkBackWorkaround">;

function AlertModal(props: AlertModalProps) {
  const {
    heading,
    headingLevel,
    severity,
    primaryButtonsProps,
    secondaryButtonsProps,
    footerLayout,
    hasStickyFooter,
    accessibilityLabel,
    accessibilityHint,
    children,
    testID = "alert-modal",
    ...modalProps
  } = props;
  return (
    <Modal
      {...modalProps}
      accessibilityLabel={accessibilityLabel || heading}
      accessibilityHint={accessibilityHint}
      testID={testID}
    >
      <AlertModalBase
        testID={testID}
        heading={heading}
        headingLevel={headingLevel}
        severity={severity}
        primaryButtonsProps={primaryButtonsProps}
        secondaryButtonsProps={secondaryButtonsProps}
        footerLayout={footerLayout}
        hasStickyFooter={hasStickyFooter}
        children={children}
      />
    </Modal>
  );
}

AlertModal.Typography = function AlertModalTypography(props: TypographyProps) {
  const { tokens } = useDesignTokens();
  const { alertModal } = tokens;

  return <Typography color={alertModal.body.color} {...props} />;
};

export default AlertModal;
