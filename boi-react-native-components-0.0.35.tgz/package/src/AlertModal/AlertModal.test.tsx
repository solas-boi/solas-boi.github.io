import { View } from "react-native";
import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreAlertModal } from "@boi/components-core";

import AlertModal, { type AlertModalProps } from "./AlertModal";

function WrappedAlertModal(props: AlertModalProps) {
  return (
    <DesignTokensProvider>
      <AlertModal {...props} />
    </DesignTokensProvider>
  );
}

describe("AlertModal", () => {
  let baseProps: AlertModalProps;

  beforeEach(() => {
    baseProps = {
      heading: "Modal heading",
      children: <View testID="mock-children" />,
      isOpen: false,
    };
  });

  it("should render with the correct heading", () => {
    render(<WrappedAlertModal {...baseProps} isOpen />);

    const heading = screen.getByRole("heading");

    expect(heading.props["aria-level"]).toBe(
      CoreAlertModal.DEFAULT_HEADING_LEVEL
    );
    expect(heading).toHaveTextContent(baseProps.heading);
  });

  it("should render with a custom heading level", () => {
    render(<WrappedAlertModal {...baseProps} isOpen headingLevel={5} />);

    const heading = screen.getByRole("heading");

    expect(heading.props["aria-level"]).toBe(5);
    expect(heading).toHaveTextContent(baseProps.heading);
  });

  it("should render with the correct children", () => {
    render(<WrappedAlertModal {...baseProps} isOpen />);

    const children = screen.getByTestId("mock-children");

    expect(children).toBeDefined();
  });

  it("should render with the correct primary buttons", () => {
    render(
      <WrappedAlertModal
        {...baseProps}
        isOpen
        primaryButtonsProps={[
          {
            text: "Login",
            onPress: jest.fn(),
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Login",
    });

    expect(button).toBeDefined();
  });

  it("should render with the correct secondary buttons", () => {
    render(
      <WrappedAlertModal
        {...baseProps}
        isOpen
        secondaryButtonsProps={[
          {
            text: "Contact us",
            onPress: jest.fn(),
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Contact us",
    });

    expect(button).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedAlertModal {...baseProps} isOpen />);

    expect(screen.getByTestId("alert-modal")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-alert-modal";

    render(<WrappedAlertModal {...baseProps} isOpen testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
