export { default as AlertModal, type AlertModalProps } from "./AlertModal";
