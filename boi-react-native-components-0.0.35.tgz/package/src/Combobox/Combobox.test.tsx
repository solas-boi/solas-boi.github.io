import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreCombobox } from "@boi/components-core";

import Combobox, { type ComboboxProps } from "./Combobox";
import { mockItems } from "./Combobox.mocks";

jest.useFakeTimers();

function WrappedCombobox(props: ComboboxProps<CoreCombobox.ComboboxItem>) {
  return (
    <DesignTokensProvider>
      <Combobox {...props} />
    </DesignTokensProvider>
  );
}

describe("Combobox", () => {
  let baseProps: ComboboxProps<CoreCombobox.ComboboxItem>;

  beforeEach(() => {
    baseProps = {
      placeholder: "Combobox...",
      items: mockItems,
      onChange: jest.fn(),
      labelProps: {
        "aria-label": "Label",
      },
    };
  });

  it("should render with the correct role", async () => {
    render(<WrappedCombobox {...baseProps} />);

    const combobox = await screen.findByTestId("combobox");
    expect(combobox).toBeDefined();
  });

  it("should render the correct number of select options", async () => {
    const user = userEvent.setup();
    const items = mockItems.slice(0, 2);

    render(<WrappedCombobox {...baseProps} items={items} />);

    const combobox = await screen.findByTestId("combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const options = screen.getAllByRole("radio");
    expect(options).toHaveLength(items.length);
  }, 30000); // Increased timeout to 30 seconds

  it("should render the correct number of select options while filtering", async () => {
    const user = userEvent.setup();

    render(<WrappedCombobox {...baseProps} />);

    const combobox = await screen.findByTestId("combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const input = screen.getByTestId("combobox-modal-input");

    await act(async () => {
      await user.type(input, "9");
    });

    const options = screen.getAllByRole("radio");
    expect(options).toHaveLength(2);
  });

  it("should render a no results state if nothing is found while filtering", async () => {
    const user = userEvent.setup();

    render(<WrappedCombobox {...baseProps} />);

    const combobox = await screen.findByTestId("combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const input = screen.getByTestId("combobox-modal-input");

    await act(async () => {
      await user.type(input, "Value which does not exist");
    });

    expect(screen.getByTestId("combobox-modal-no-results")).toBeDefined();
  });

  it("should trigger the setInputValue event when user types on the input", async () => {
    const user = userEvent.setup();
    const mockOnInputChange = jest.fn();

    render(
      <WrappedCombobox {...baseProps} onInputChange={mockOnInputChange} />
    );

    const combobox = await screen.findByTestId("combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const input = screen.getByTestId("combobox-modal-input");
    const valueToBeInputted = "value";

    await act(async () => {
      await user.type(input, valueToBeInputted);
    });

    expect(mockOnInputChange).toHaveBeenCalledWith(valueToBeInputted);
  });

  it("should trigger the onChange event when a select option is clicked", async () => {
    const user = userEvent.setup();
    const mockOnInputChange = jest.fn();
    const mockOnChange = jest.fn();

    render(
      <WrappedCombobox
        {...baseProps}
        onChange={mockOnChange}
        onInputChange={mockOnInputChange}
      />
    );

    const combobox = await screen.findByTestId("combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const firstOption = screen.getAllByRole("radio")[0]!;

    await act(async () => {
      await user.press(firstOption);
    });

    await screen.findByTestId("combobox-modal", { hidden: true });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenLastCalledWith(mockItems[0]);
  });

  it("should render with a default testID", () => {
    render(<WrappedCombobox {...baseProps} />);

    expect(screen.getByTestId("combobox")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-combobox";

    render(<WrappedCombobox {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
