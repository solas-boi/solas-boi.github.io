import {
  Counter1Icon,
  Counter2Icon,
  Counter3Icon,
  Counter4Icon,
  Counter5Icon,
  Counter6Icon,
} from "@boi/react-native-icons";

export const mockItems = Array.from({ length: 20 }, (_, index) => {
  const indexString = `${index + 1}`.padStart(2, "0");

  return {
    id: `item-${indexString}`,
    title: `Item ${indexString}`,
    value: indexString,
  };
});

export const mockIconItems = Array.from({ length: 6 }, (_, index) => {
  const indexString = `${index + 1}`.padStart(2, "0");

  const ICONS = [
    <Counter1Icon width={24} height={24} />,
    <Counter2Icon width={24} height={24} />,
    <Counter3Icon width={24} height={24} />,
    <Counter4Icon width={24} height={24} />,
    <Counter5Icon width={24} height={24} />,
    <Counter6Icon width={24} height={24} />,
  ];

  return {
    id: `icon-item-${indexString}`,
    title: `Item ${indexString}`,
    value: indexString,
    icon: ICONS[index],
  };
});

export const mockPromotedItems = Array.from({ length: 20 }, (_, index) => {
  const indexString = `${index + 1}`.padStart(2, "0");

  return {
    id: `icon-item-${indexString}`,
    title: `Item ${indexString}`,
    value: indexString,
    isPromoted: [3, 4, 5].includes(index),
  };
});
