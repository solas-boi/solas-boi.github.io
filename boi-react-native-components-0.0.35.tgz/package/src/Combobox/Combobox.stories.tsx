import { forwardRef, useCallback, useEffect, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";

import Combobox, { type ComboboxProps } from "./Combobox";

import { mockIconItems, mockItems, mockPromotedItems } from "./Combobox.mocks";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";
import { View } from "react-native";

const ControlledCombobox = forwardRef<View, ComboboxProps>((props, ref) => {
  const { onChange, selectedItem, onInputChange, ...rest } = props;

  const [item, setItem] = useState<ComboboxProps["selectedItem"]>(selectedItem);

  const handleChange: ComboboxProps["onChange"] = useCallback(
    (newComboboxedItem) => {
      setItem(newComboboxedItem);
      onChange(newComboboxedItem);
    },
    [onChange]
  );

  const handleInputValueChange = (value: string) => {
    onInputChange?.(value);
  };

  useEffect(() => {
    setItem(selectedItem);
  }, [selectedItem]);

  return (
    <Combobox
      selectedItem={item}
      onInputChange={handleInputValueChange}
      onChange={handleChange}
      supportedOrientations={["landscape", "portrait"]}
      {...rest}
      pressableRef={ref}
    />
  );
});

const meta = {
  title: "Inputs/Combobox",
  component: Combobox,
  render: function Render(args) {
    const [{ selectedItem }, updateArgs] = useArgs();

    function handleChange(newComboboxedItem: any) {
      action("onChange")(newComboboxedItem);
      updateArgs({ selectedItem: newComboboxedItem });
    }

    function handleInputValueChange(inputValue: string) {
      action("onInputChange")(inputValue);
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => (
          <ControlledCombobox
            {...args}
            ref={ref}
            selectedItem={selectedItem}
            onChange={handleChange}
            onInputChange={handleInputValueChange}
          />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    hasError: { control: "boolean" },
    defaultInputValue: { control: "text" },
  },
  args: {
    hasError: false,
    isDisabled: false,
    items: mockItems,
    placeholder: "Search",
  },
} satisfies Meta<ComboboxProps>;

export default meta;
type Story = StoryObj<ComboboxProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "Combobox",
    },
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "Combobox with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "Combobox with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const IconItems: Story = {
  args: {
    items: mockIconItems,
    labelProps: {
      label: "Combobox with Icon Items",
    },
  },
};

export const PromotedItems: Story = {
  args: {
    items: mockPromotedItems,
    labelProps: {
      label: "Combobox with Promoted Items",
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    labelProps: {
      label: "Combobox with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const DisabledItems: Story = {
  args: {
    disabledKeys: mockItems.slice(1, 3).map(({ id }) => id),
    labelProps: {
      label: "Combobox with Disabled Items",
    },
  },
};
