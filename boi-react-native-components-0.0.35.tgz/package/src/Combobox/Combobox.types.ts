import type { CoreCombobox } from "@boi/components-core";

export type ComboboxItem = CoreCombobox.ComboboxItem;
