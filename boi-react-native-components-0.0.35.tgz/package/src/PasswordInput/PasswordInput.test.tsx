import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import PasswordInput, { type PasswordInputProps } from "./PasswordInput";

jest.useFakeTimers();

function WrappedPasswordInput(props: PasswordInputProps) {
  return (
    <DesignTokensProvider>
      <PasswordInput {...props} />
    </DesignTokensProvider>
  );
}

describe("PasswordInput", () => {
  let baseProps: PasswordInputProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        label: "PasswordInput label",
      },
    };
  });

  it("should render the correct label when provided", async () => {
    render(<WrappedPasswordInput {...baseProps} />);

    const textInput = screen.getByLabelText(/PasswordInput label/);

    expect(textInput).toBeDefined();
  });

  it("should render the correct label hint when provided", async () => {
    render(
      <WrappedPasswordInput
        {...baseProps}
        labelProps={{
          ...baseProps.labelProps,
          labelHint: "Additional information",
        }}
      />
    );

    const textInput = screen.getByHintText(/Additional information/);

    expect(textInput).toBeDefined();
  });

  it("should render the correct alerts when provided", async () => {
    render(
      <WrappedPasswordInput
        {...baseProps}
        alerts={[
          {
            severity: "error",
            children: "Something went wrong",
          },
        ]}
      />
    );

    const alerts = screen.getAllByTestId("inline-alert");

    expect(alerts.length).toBe(1);
  });

  it("should render the button by default", async () => {
    render(<WrappedPasswordInput {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Show password",
    });

    expect(button).toBeDefined();
  });

  it("should not render the button when disabled", async () => {
    render(<WrappedPasswordInput {...baseProps} disabled />);

    const button = screen.queryByRole("button", {
      name: "Show password",
    });

    expect(button).toBeNull();
  });

  it("should update the state when the button is clicked", async () => {
    const user = userEvent.setup({
      advanceTimers: jest.advanceTimersByTime,
    });

    render(<WrappedPasswordInput {...baseProps} />);

    const input = screen.getByTestId("password-input");
    const button = screen.getByRole("button", {
      name: "Show password",
    });

    expect(input).toHaveProp("secureTextEntry", true);

    await act(async () => {
      await user.press(button);
    });

    const updatedButton = await screen.findByRole("button", {
      name: "Hide password",
    });

    expect(input).toHaveProp("secureTextEntry", false);
    expect(updatedButton).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedPasswordInput {...baseProps} />);

    expect(screen.getByTestId("password-input")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-password-input";

    render(<WrappedPasswordInput {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
