import type { Meta, StoryObj } from "@storybook/react";

import PasswordInput from "./PasswordInput";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";
import { TextInput } from "react-native";

const meta = {
  title: "Inputs/PasswordInput",
  component: PasswordInput,
  render: function Render(args) {
    return (
      <FocusControlWrapper<TextInput> {...args}>
        {(ref) => <PasswordInput {...args} ref={ref} />}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    disabled: { control: "boolean" },
    hasError: { control: "boolean" },
  },
  args: {
    disabled: false,
    hasError: false,
  },
} satisfies Meta<typeof PasswordInput>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    "aria-label": "PasswordInput label",
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "PasswordInput label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "PasswordInput label",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    labelProps: {
      label: "PasswordInput label",
    },
  },
};

export const Invalid: Story = {
  args: {
    hasError: true,
    labelProps: {
      label: "PasswordInput label",
    },
    alerts: [
      {
        severity: "error",
        children: "Error description over two lines if required.",
      },
    ],
  },
};

export const WithFocus = withFocusControlStoryArgs(Invalid);
