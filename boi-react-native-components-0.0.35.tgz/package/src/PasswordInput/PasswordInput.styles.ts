import { StyleSheet } from "react-native";
import { CoreTypography } from "@boi/components-core";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { type PasswordInputProps } from "./PasswordInput";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { textInput, typography } = tokens;

  const typographyVariant: CoreTypography.Variant =
    textInput.typography.variant;

  return StyleSheet.create({
    text: {
      flexGrow: 1,
      flexShrink: 1,

      margin: 0,
      padding: 0,
      height: textInput.height,
      borderColor: "transparent",
      backgroundColor: "transparent",
      color: textInput.color.base,
      fontFamily: typography.fontFamily[typographyVariant],
      fontSize: parseSizeToken(
        typography.fontSize[typographyVariant],
        fontScale
      ),
    },
    textDisabled: {
      color: textInput.color.disabled,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  disabled,
}: Pick<PasswordInputProps, "disabled">) {
  const styles = useStyles();

  return {
    text: [styles.text, disabled && styles.textDisabled],
  };
}

export default useStyles;
