import { renderHook } from "@testing-library/react-native";
import { Platform } from "react-native";
import { SharedValue } from "react-native-reanimated";

import { useContainerAnimatedStyle } from "./useModalContainerAnimation";

jest.mock("react-native", () => ({
  Platform: { OS: "ios" },
  useWindowDimensions: jest.fn(),
}));

jest.mock("react-native-reanimated", () => ({
  useAnimatedStyle: jest.fn(),
  useSharedValue: jest.fn(),
}));

import { useWindowDimensions } from "react-native";
import { useAnimatedStyle, useSharedValue } from "react-native-reanimated";

describe("useContainerAnimatedStyle", () => {
  const mockUseWindowDimensions = jest.mocked(useWindowDimensions);
  const mockUseAnimatedStyle = jest.mocked(useAnimatedStyle);
  const mockUseSharedValue = jest.mocked(useSharedValue);

  const mockProgress: SharedValue<number> = {
    value: 0.5,
  } as SharedValue<number>;

  beforeEach(() => {
    jest.clearAllMocks();
    mockUseWindowDimensions.mockReturnValue({
      width: 400,
      height: 800,
      scale: 1,
      fontScale: 1,
    });
    mockUseSharedValue.mockReturnValue({ value: 800 } as any);
    mockUseAnimatedStyle.mockImplementation((fn: Function) => fn());
  });

  it("should call required hooks", () => {
    const { result } = renderHook(() =>
      useContainerAnimatedStyle(mockProgress)
    );

    expect(mockUseWindowDimensions).toHaveBeenCalled();
    expect(mockUseSharedValue).toHaveBeenCalledWith(800);
    expect(mockUseAnimatedStyle).toHaveBeenCalled();
    expect(result.current?.transform?.[0]?.translateY).toBe(800);
  });

  it("should work with different platforms", () => {
    (Platform as any).OS = "android";

    const { result } = renderHook(() =>
      useContainerAnimatedStyle(mockProgress)
    );

    expect(mockUseAnimatedStyle).toHaveBeenCalled();
    expect(result.current?.top).toBe(800);
  });
});
