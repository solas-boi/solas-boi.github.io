import { ThemeTokens } from "@boi/react-native-design-tokens";
import { createThemedStyleSheet } from "../../themedStylesheet";
import { StyleSheet } from "react-native";

function styleSheetFactory(tokens: ThemeTokens) {
  const { modal } = tokens;

  const styles = StyleSheet.create({
    container: {
      height: "100%",
      alignItems: "center",
    },
    containerMobile: {
      justifyContent: "flex-end",
    },
    containerTablet: {
      justifyContent: "center",
    },
    sheet: {
      overflow: "hidden",
      borderTopEndRadius: modal.radius,
      borderTopStartRadius: modal.radius,
      backgroundColor: modal.backgroundColor,
      height: "auto",
      width: "100%",
    },
    sheetMobile: {
      maxWidth: modal.maxWidth.mobile,
      minHeight: modal.minHeight.mobile,
      maxHeight: "90%",
    },
    sheetTablet: {
      borderBottomEndRadius: modal.radius,
      borderBottomStartRadius: modal.radius,
      minWidth: modal.minWidth.tablet,
      maxWidth: modal.maxWidth.tablet,
      minHeight: modal.minHeight.tablet,
      maxHeight: modal.maxHeight.tablet,
    },
    backdrop: {
      position: "absolute",
      top: 0,
      left: 0,
      height: "100%",
      width: "100%",
      backgroundColor: modal.backdrop.backgroundColor,
    },
    hiddenContainer: { width: "100%", height: 1 },
    avoidingViewContainer: {
      flex: 1,
    },
  });

  return styles;
}

export const useModalStyles = createThemedStyleSheet(styleSheetFactory);
