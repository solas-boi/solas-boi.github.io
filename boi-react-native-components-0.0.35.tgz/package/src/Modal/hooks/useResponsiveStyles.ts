import { useWindowDimensions } from "react-native";
import { ModalStyleProps } from "../Modal.types";
import { useModalStyles } from "./useModalStyles";
import { useDesignTokens } from "@boi/react-native-design-tokens";

export const useResponsiveStyles = (
  isTablet: boolean,
  { tabletWidth }: Pick<ModalStyleProps, "tabletWidth">
) => {
  const styles = useModalStyles();
  const { tokens } = useDesignTokens();
  const { modal } = tokens;

  const windowDimensions = useWindowDimensions();

  const maxTabletScreenWidth =
    windowDimensions.width - parseInt(modal.padding.tablet, 10) * 2;

  const sheetDeviceStyle = isTablet
    ? [
        styles.sheet,
        styles.sheetTablet,
        tabletWidth && tabletWidth < maxTabletScreenWidth
          ? {
              width: tabletWidth,
            }
          : undefined,
      ]
    : [styles.sheet, styles.sheetMobile];

  return {
    sheetDeviceStyle,
    container: [
      styles.container,
      isTablet ? styles.containerTablet : styles.containerMobile,
    ],
  };
};
