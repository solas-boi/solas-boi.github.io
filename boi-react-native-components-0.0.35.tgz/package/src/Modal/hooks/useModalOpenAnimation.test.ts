import { renderHook } from "@testing-library/react-native";

import { useModalOpenAnimation } from "./useModalOpenAnimation";

jest.mock("react-native-reanimated", () => ({
  useSharedValue: jest.fn(),
  useAnimatedStyle: jest.fn(),
  withTiming: jest.fn(),
  runOnJS: jest.fn(),
}));

jest.mock("./useModalContainerAnimation", () => ({
  useContainerAnimatedStyle: jest.fn(),
}));

import {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  runOnJS,
} from "react-native-reanimated";
import { useContainerAnimatedStyle } from "./useModalContainerAnimation";

const mockUseSharedValue = jest.mocked(useSharedValue);
const mockUseAnimatedStyle = jest.mocked(useAnimatedStyle);
const mockWithTiming = jest.mocked(withTiming);
const mockRunOnJS = jest.mocked(runOnJS);
const mockUseContainerAnimatedStyle = jest.mocked(useContainerAnimatedStyle);

describe("useModalOpenAnimation", () => {
  const mockSetVisible = jest.fn();
  const mockOnCloseAnimationComplete = jest.fn();
  const mockOnOpenAnimationComplete = jest.fn();

  const mockSharedValue = {
    value: 1,
  };

  const mockContainerStyle = { transform: [{ translateY: 0 }] };
  const mockBackdropStyle = { opacity: 0 };

  beforeEach(() => {
    jest.clearAllMocks();

    mockUseSharedValue.mockReturnValue(mockSharedValue as any);
    mockUseContainerAnimatedStyle.mockReturnValue(mockContainerStyle as any);
    mockUseAnimatedStyle.mockReturnValue(mockBackdropStyle as any);
    mockWithTiming.mockReturnValue("mocked-animation" as any);
    mockRunOnJS.mockImplementation((fn) => fn as any);
  });

  it("should return container and backdrop styles", () => {
    const { result } = renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
        onCloseAnimationComplete: mockOnCloseAnimationComplete,
        onOpenAnimationComplete: mockOnOpenAnimationComplete,
      })
    );

    expect(result.current).toEqual({
      container: mockContainerStyle,
      backdrop: mockBackdropStyle,
    });
  });

  it("should call setVisible(true) when modal is opening", () => {
    renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
      })
    );

    expect(mockSetVisible).toHaveBeenCalledWith(true);
  });

  it("should not call setVisible when modal is closing", () => {
    renderHook(() =>
      useModalOpenAnimation({
        isOpen: false,
        setVisible: mockSetVisible,
      })
    );

    expect(mockSetVisible).not.toHaveBeenCalled();
  });

  it("should initialize shared value and create animations", () => {
    renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
      })
    );

    expect(mockUseSharedValue).toHaveBeenCalledWith(1);
    expect(mockUseContainerAnimatedStyle).toHaveBeenCalledWith(mockSharedValue);
    expect(mockUseAnimatedStyle).toHaveBeenCalled();
  });

  it("should trigger animation when isOpen changes from false to true", () => {
    mockSharedValue.value = 1;

    const { rerender } = renderHook(
      ({ isOpen }) =>
        useModalOpenAnimation({
          isOpen,
          setVisible: mockSetVisible,
        }),
      { initialProps: { isOpen: false } }
    );
    rerender({ isOpen: true });

    expect(mockWithTiming).toHaveBeenCalledWith(
      0,
      { duration: 500 },
      expect.any(Function)
    );
  });

  it("should trigger animation when isOpen changes from true to false", () => {
    mockSharedValue.value = 0;

    const { rerender } = renderHook(
      ({ isOpen }) =>
        useModalOpenAnimation({
          isOpen,
          setVisible: mockSetVisible,
        }),
      { initialProps: { isOpen: true } }
    );

    rerender({ isOpen: false });

    expect(mockWithTiming).toHaveBeenCalledWith(
      1,
      { duration: 500 },
      expect.any(Function)
    );
  });

  it("should call onOpenAnimationComplete when opening animation finishes", () => {
    let animationCallback: ((finished: boolean) => void) | undefined;

    mockWithTiming.mockImplementation((value, config, callback) => {
      animationCallback = callback;
      return "mocked-animation" as any;
    });

    renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
        onOpenAnimationComplete: mockOnOpenAnimationComplete,
      })
    );

    if (animationCallback) {
      animationCallback(true);
    }

    expect(mockOnOpenAnimationComplete).toHaveBeenCalled();
  });

  it("should call setVisible(false) and onCloseAnimationComplete when closing animation finishes", () => {
    let animationCallback: ((finished: boolean) => void) | undefined;

    mockWithTiming.mockImplementation((value, config, callback) => {
      animationCallback = callback;
      return "mocked-animation" as any;
    });

    renderHook(() =>
      useModalOpenAnimation({
        isOpen: false,
        setVisible: mockSetVisible,
        onCloseAnimationComplete: mockOnCloseAnimationComplete,
      })
    );

    if (animationCallback) {
      animationCallback(true);
    }

    expect(mockSetVisible).toHaveBeenCalledWith(false);
    expect(mockOnCloseAnimationComplete).toHaveBeenCalled();
  });

  it("should handle missing optional callbacks", () => {
    let animationCallback: ((finished: boolean) => void) | undefined;

    mockWithTiming.mockImplementation((value, config, callback) => {
      animationCallback = callback;
      return "mocked-animation" as any;
    });

    renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
      })
    );

    expect(() => {
      if (animationCallback) {
        animationCallback(true);
      }
    }).not.toThrow();
  });

  it("should not trigger animation when shared value is already at target value", () => {
    mockSharedValue.value = 0;

    renderHook(() =>
      useModalOpenAnimation({
        isOpen: true,
        setVisible: mockSetVisible,
      })
    );

    expect(mockWithTiming).not.toHaveBeenCalled();
  });
});
