import { Platform, useWindowDimensions } from "react-native";
import {
  SharedValue,
  useAnimatedStyle,
  useSharedValue,
} from "react-native-reanimated";

export const useContainerAnimatedStyle = (progress: SharedValue<number>) => {
  const windowDimensions = useWindowDimensions();
  const height = useSharedValue(windowDimensions.height);

  return useAnimatedStyle(() => {
    if (Platform.OS === "android") {
      /* TODO: Check once in a while if this condition still necessary as currently there is a bug on React Native New Arch
               which only happens on android, the bug is that you have to press twice on a Pressable
               to interact with it due to animating the tranform.translate style.
               As a quick fix, when it's Android, instead of animating `transform.translateY`, we use the `top` style
               which might be less performant, but at least doesn't trigger the bug.
               https://github.com/facebook/react-native/issues/36504
               https://github.com/facebook/react-native/issues/44768
               https://github.com/software-mansion/react-native-reanimated/issues/6676
      */
      return {
        top: progress.value * 2 * height.value,
      };
    } else {
      return {
        transform: [{ translateY: progress.value * 2 * height.value }],
      };
    }
  });
};
