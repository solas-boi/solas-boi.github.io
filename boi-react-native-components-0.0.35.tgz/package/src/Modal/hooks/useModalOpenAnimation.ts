import {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";
import { ModalLayoutAnimationProps } from "../Modal.types";
import { useLayoutEffect } from "react";
import { useContainerAnimatedStyle } from "./useModalContainerAnimation";

const ANIMATION_DURATION = 500;

export const useModalOpenAnimation = ({
  isOpen,
  onCloseAnimationComplete,
  onOpenAnimationComplete,
  setVisible,
}: ModalLayoutAnimationProps) => {
  const progress = useSharedValue(1);

  // if modal is opening, we set the visibility to true straight away.
  useLayoutEffect(() => {
    if (isOpen) {
      setVisible(true);
    }
  }, [isOpen, setVisible]);

  useLayoutEffect(() => {
    const newValue = isOpen ? 0 : 1;
    if (progress.value !== newValue) {
      const mainAnimation = withTiming(
        newValue,
        { duration: ANIMATION_DURATION },
        (finished) => {
          if (finished) {
            // If modal is closing, we wait for the animation to be finish to set visibility to false.
            if (isOpen) {
              if (onOpenAnimationComplete) {
                runOnJS(onOpenAnimationComplete)();
              }
            } else {
              runOnJS(setVisible)(false);
              if (onCloseAnimationComplete) {
                runOnJS(onCloseAnimationComplete)();
              }
            }
          }
        }
      );
      progress.value = mainAnimation;
    }
  }, [
    isOpen,
    onCloseAnimationComplete,
    onOpenAnimationComplete,
    setVisible,
    progress,
  ]);

  const containerStyle = useContainerAnimatedStyle(progress);

  const backdropStyle = useAnimatedStyle(() => ({
    opacity: 1 - progress.value,
  }));

  return {
    container: containerStyle,
    backdrop: backdropStyle,
  };
};
