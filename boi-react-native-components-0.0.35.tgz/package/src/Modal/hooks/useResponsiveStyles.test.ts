import { renderHook } from "@testing-library/react-native";

import { useResponsiveStyles } from "./useResponsiveStyles";

jest.mock("react-native", () => ({
  useWindowDimensions: jest.fn(),
}));

jest.mock("@boi/react-native-design-tokens", () => ({
  useDesignTokens: jest.fn(),
}));

jest.mock("./useModalStyles", () => ({
  useModalStyles: jest.fn(),
}));

import { useWindowDimensions } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { useModalStyles } from "./useModalStyles";

const mockUseWindowDimensions =
  jest.mocked<() => { width: number; height: number }>(useWindowDimensions);
const mockUseDesignTokens = jest.mocked(useDesignTokens);
const mockUseModalStyles = jest.mocked(useModalStyles);

describe("useResponsiveStyles", () => {
  const mockStyles = {
    container: { height: "100%", alignItems: "center" },
    containerMobile: { justifyContent: "flex-end" },
    containerTablet: { justifyContent: "center" },
    sheet: { backgroundColor: "white", width: "100%" },
    sheetMobile: { maxWidth: 400 },
    sheetTablet: { minWidth: 300, maxWidth: 600 },
  };

  const mockTokens = {
    modal: {
      padding: {
        tablet: "20",
      },
    },
  };

  const mockWindowDimensions = {
    width: 800,
    height: 600,
    scale: 1,
    fontScale: 1,
  };

  beforeEach(() => {
    jest.clearAllMocks();

    mockUseModalStyles.mockReturnValue(mockStyles as any);
    mockUseDesignTokens.mockReturnValue({
      tokens: mockTokens,
    } as any);
    mockUseWindowDimensions.mockReturnValue(mockWindowDimensions);
  });

  it("should return tablet styles when isTablet is true", () => {
    const { result } = renderHook(() =>
      useResponsiveStyles(true, { tabletWidth: 500 })
    );

    expect(result.current.sheetDeviceStyle).toEqual([
      mockStyles.sheet,
      mockStyles.sheetTablet,
      { width: 500 },
      undefined,
    ]);

    expect(result.current.container).toEqual([
      mockStyles.container,
      mockStyles.containerTablet,
    ]);
  });

  it("should return mobile styles when isTablet is false", () => {
    const { result } = renderHook(() =>
      useResponsiveStyles(false, { tabletWidth: 500 })
    );

    expect(result.current.sheetDeviceStyle).toEqual([
      mockStyles.sheet,
      mockStyles.sheetMobile,
    ]);

    expect(result.current.container).toEqual([
      mockStyles.container,
      mockStyles.containerMobile,
      undefined,
    ]);
  });

  it("should not apply custom tablet width when it exceeds max screen width", () => {
    mockUseWindowDimensions.mockReturnValue({
      width: 400,
      height: 600,
    });

    const { result } = renderHook(() =>
      useResponsiveStyles(true, { tabletWidth: 500 })
    );

    expect(result.current.sheetDeviceStyle).toEqual([
      mockStyles.sheet,
      mockStyles.sheetTablet,
      undefined,
      undefined,
    ]);
  });

  it("should handle undefined tabletWidth", () => {
    const { result } = renderHook(() =>
      useResponsiveStyles(true, { tabletWidth: undefined })
    );

    expect(result.current.sheetDeviceStyle).toEqual([
      mockStyles.sheet,
      mockStyles.sheetTablet,
      undefined,
      undefined,
    ]);
  });
});
