import {
  RefObject,
  useCallback,
  useEffect,
  useRef,
  useState,
  type PropsWithChildren,
} from "react";
import {
  AccessibilityInfo,
  KeyboardAvoidingView,
  Modal as NativeModal,
  ModalProps as NativeModalProps,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  type AccessibilityProps,
} from "react-native";
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import Animated from "react-native-reanimated";
import { isTablet } from "react-native-device-info";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { useAccessibilityInfo } from "@react-native-community/hooks";
import { type PropsWithOptionalTestID } from "@boi/components-core";
import { useStateStyles } from "./Modal.styles";
import { FocusableComponent } from "../types";
import { setAccessibilityFocus } from "../utils/setAccessibilityFocus";

const KEYBOARD_BEHAVIOR = Platform.select({ ios: "padding" as const });

export type ModalProps = PropsWithOptionalTestID &
  Omit<
    NativeModalProps,
    "visible" | "animationType" | "style" | "onRequestClose"
  > &
  Pick<AccessibilityProps, "accessibilityLabel" | "accessibilityHint"> &
  PropsWithChildren<{
    isOpen: boolean;
    onCloseAnimationComplete?: () => void;
    onOpenAnimationComplete?: () => void;
    onRequestClose?: (() => void) | undefined;
    __useTalkBackWorkaround?: boolean;
    tabletWidth?: number;
    focusReturnRef?: RefObject<FocusableComponent>;
  }>;

const __REQUIRES_ANDROID_35_FIX =
  Platform.OS === "android" && Platform.Version >= 35;

const __REQUIRES_ANDROID_RN_77_FIX =
  Platform.OS === "android" &&
  Platform.constants.reactNativeVersion.minor >= 77;

function Modal(props: ModalProps) {
  const {
    isOpen,
    onCloseAnimationComplete,
    onOpenAnimationComplete,
    __useTalkBackWorkaround = true,
    accessibilityLabel,
    accessibilityHint,
    children,
    tabletWidth,
    focusReturnRef,
    ...nativeModalProps
  } = props;
  const { onRequestClose } = nativeModalProps;
  const [visible, setVisible] = useState(false);

  const onCloseAnimationCompleteWithFocusReturn = useCallback(() => {
    setAccessibilityFocus(focusReturnRef);
    onCloseAnimationComplete?.();
  }, [focusReturnRef, onCloseAnimationComplete]);

  const styles = useStateStyles(
    isOpen,
    setVisible,
    onCloseAnimationCompleteWithFocusReturn,
    onOpenAnimationComplete,
    tabletWidth
  );

  const a11yLabelForDialog = accessibilityLabel
    ? accessibilityLabel + ", dialog"
    : "dialog";

  const a11yRef = useRef<View>(null);

  useEffect(() => {
    if (isOpen) {
      if (Platform.OS === "android") {
        /** This is a workaround for a bug in React Native where the modal does not
         * get focus when it opens. This is a temporary fix until the bug is fixed
         * in React Native.
         * TODO: Once this issue is resolved, we can remove this workaround and hiddenContainer with Platform.OS === "ios"
         */
        AccessibilityInfo.announceForAccessibility(a11yLabelForDialog);
      }

      if (Platform.OS === "ios") {
        requestAnimationFrame(() => {
          setAccessibilityFocus(a11yRef);
        });
      }
    }
  }, [isOpen, a11yLabelForDialog]);

  const modalJSX = (
    <NativeModal
      {...nativeModalProps}
      visible={visible}
      animationType="none"
      transparent={true}
      statusBarTranslucent={__REQUIRES_ANDROID_35_FIX}
    >
      <KeyboardAvoidingView
        behavior={KEYBOARD_BEHAVIOR}
        style={styles.avoidingViewContainer}
      >
        <GestureHandlerRootView>
          <SafeAreaProvider>
            <Animated.View style={styles.backdrop}>
              {__useTalkBackWorkaround && Platform.OS === "android" && (
                <TalkBackWorkaround />
              )}
              {onRequestClose && (
                <Pressable
                  accessible={false}
                  importantForAccessibility="no"
                  focusable={false}
                  style={StyleSheet.absoluteFill}
                  onPress={onRequestClose}
                />
              )}
            </Animated.View>
            <Animated.View style={styles.container} pointerEvents="box-none">
              {Platform.OS === "ios" && (
                <View
                  accessible
                  ref={a11yRef}
                  importantForAccessibility="yes"
                  accessibilityLabel={a11yLabelForDialog}
                  accessibilityHint={accessibilityHint}
                  style={styles.hiddenContainer}
                />
              )}
              <View style={styles.sheet}>
                {children}
                <ModalBottomInset />
              </View>
            </Animated.View>
          </SafeAreaProvider>
        </GestureHandlerRootView>
      </KeyboardAvoidingView>
    </NativeModal>
  );

  /** Workaround for bug on Android that was introduced with React Native 0.77
   * The bug caused the modal to sometimes not have the dimensions of the window.
   * Making it look like the modal haven't got rendered.
   * TODO: Verify if the workaround still required after this react-native PR gets merged and we're on the latest RN Version
   * https://github.com/facebook/react-native/issues/50442
   */
  if (__REQUIRES_ANDROID_RN_77_FIX) {
    return (
      <View style={visible ? StyleSheet.absoluteFill : undefined}>
        {modalJSX}
      </View>
    );
  } else {
    return modalJSX;
  }
}

function ModalBottomInset() {
  const { bottom } = useSafeAreaInsets();
  if (isTablet()) {
    return undefined;
  }
  return <View style={{ height: bottom }} />;
}

/** Workaround for this issue related to Modal and Talkback: https://github.com/facebook/react-native/issues/49796
 * If we upgrade to React Native 0.78.0 the issue still persists, but is slightly different.
 * On 0.78.0 we would have to move this workaround to the end of the Modal tree, to ensure it's the last text element
 * TODO: Once this issue is resolved, we can remove this workaround
 */
function TalkBackWorkaround() {
  const { screenReaderEnabled } = useAccessibilityInfo();
  if (!screenReaderEnabled || Platform.OS !== "android") {
    return null;
  }
  return (
    <Text importantForAccessibility="no" accessibilityElementsHidden>
      {" "}
    </Text>
  );
}

export default Modal;
