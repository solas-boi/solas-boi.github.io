export type ModalStyleProps = {
  isOpen: boolean;
  setVisible: (value: boolean) => void;
  onCloseAnimationComplete?: () => void;
  onOpenAnimationComplete?: () => void;
  tabletWidth?: number;
};

export type ModalLayoutAnimationProps = Pick<
  ModalStyleProps,
  | "isOpen"
  | "setVisible"
  | "onCloseAnimationComplete"
  | "onOpenAnimationComplete"
>;
