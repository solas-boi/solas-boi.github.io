import { renderHook } from "@testing-library/react-native";
import DeviceInfo from "react-native-device-info";

import { useStateStyles } from "./Modal.styles";

jest.mock("react-native-device-info", () => ({
  isTablet: jest.fn(),
}));

jest.mock("./hooks", () => ({
  useModalStyles: jest.fn(),
  useModalOpenAnimation: jest.fn(),
  useResponsiveStyles: jest.fn(),
}));

import {
  useModalStyles,
  useModalOpenAnimation,
  useResponsiveStyles,
} from "./hooks";

const mockUseModalStyles = jest.mocked<() => object>(useModalStyles);
const mockUseModalOpenAnimation = jest.mocked(
  useModalOpenAnimation as () => object
);
const mockUseResponsiveStyles = jest.mocked(
  useResponsiveStyles as () => object
);
const mockDeviceInfo = jest.mocked(DeviceInfo);

describe("useStateStyles", () => {
  const mockSetVisible = jest.fn();
  const mockOnCloseAnimationComplete = jest.fn();
  const mockOnOpenAnimationComplete = jest.fn();

  const mockStyles = {
    backdrop: { backgroundColor: "rgba(0,0,0,0.5)" },
    container: { flex: 1 },
    sheet: { backgroundColor: "white" },
  };

  const mockAnimated = {
    container: { opacity: 1 },
    backdrop: { opacity: 0.5 },
  };

  const mockDeviceSpecificStyles = {
    sheetDeviceStyle: { width: "100%" },
    container: [{ maxWidth: 500 }],
  };

  beforeEach(() => {
    jest.clearAllMocks();

    mockUseModalStyles.mockReturnValue(mockStyles);
    mockUseModalOpenAnimation.mockReturnValue(mockAnimated);
    mockUseResponsiveStyles.mockReturnValue(mockDeviceSpecificStyles);
  });

  it("should return combined styles for phone device", () => {
    mockDeviceInfo.isTablet.mockReturnValue(false);

    const { result } = renderHook(() =>
      useStateStyles(
        true,
        mockSetVisible,
        mockOnCloseAnimationComplete,
        mockOnOpenAnimationComplete,
        400
      )
    );

    expect(mockUseModalStyles).toHaveBeenCalledTimes(1);
    expect(mockUseModalOpenAnimation).toHaveBeenCalledWith({
      isOpen: true,
      onCloseAnimationComplete: mockOnCloseAnimationComplete,
      onOpenAnimationComplete: mockOnOpenAnimationComplete,
      setVisible: mockSetVisible,
    });
    expect(mockUseResponsiveStyles).toHaveBeenCalledWith(false, {
      tabletWidth: 400,
    });

    expect(result.current).toEqual({
      ...mockStyles,
      sheet: mockDeviceSpecificStyles.sheetDeviceStyle,
      container: [
        ...mockDeviceSpecificStyles.container,
        mockAnimated.container,
      ],
      backdrop: [mockStyles.backdrop, mockAnimated.backdrop],
    });
  });

  it("should return combined styles for tablet device", () => {
    mockDeviceInfo.isTablet.mockReturnValue(true);

    const { result } = renderHook(() => useStateStyles(false, mockSetVisible));

    expect(mockUseModalStyles).toHaveBeenCalledTimes(1);
    expect(mockUseModalOpenAnimation).toHaveBeenCalledWith({
      isOpen: false,
      onCloseAnimationComplete: undefined,
      onOpenAnimationComplete: undefined,
      setVisible: mockSetVisible,
    });
    expect(mockUseResponsiveStyles).toHaveBeenCalledWith(true, {
      tabletWidth: undefined,
    });

    expect(result.current).toEqual({
      ...mockStyles,
      sheet: mockDeviceSpecificStyles.sheetDeviceStyle,
      container: [
        ...mockDeviceSpecificStyles.container,
        mockAnimated.container,
      ],
      backdrop: [mockStyles.backdrop, mockAnimated.backdrop],
    });
  });

  it("should handle optional parameters correctly", () => {
    mockDeviceInfo.isTablet.mockReturnValue(false);

    const { result } = renderHook(() => useStateStyles(true, mockSetVisible));

    expect(mockUseModalOpenAnimation).toHaveBeenCalledWith({
      isOpen: true,
      onCloseAnimationComplete: undefined,
      onOpenAnimationComplete: undefined,
      setVisible: mockSetVisible,
    });
    expect(mockUseResponsiveStyles).toHaveBeenCalledWith(false, {
      tabletWidth: undefined,
    });

    expect(result.current).toBeDefined();
  });
});
