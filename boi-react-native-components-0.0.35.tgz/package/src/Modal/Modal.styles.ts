import DeviceInfo from "react-native-device-info";
import { ModalStyleProps } from "./Modal.types";
import {
  useModalStyles,
  useModalOpenAnimation,
  useResponsiveStyles,
} from "./hooks";

export function useStateStyles(
  isOpen: ModalStyleProps["isOpen"],
  setVisible: ModalStyleProps["setVisible"],
  onCloseAnimationComplete?: ModalStyleProps["onCloseAnimationComplete"],
  onOpenAnimationComplete?: ModalStyleProps["onOpenAnimationComplete"],
  tabletWidth?: ModalStyleProps["tabletWidth"]
) {
  const styles = useModalStyles();

  const animated = useModalOpenAnimation({
    isOpen,
    onCloseAnimationComplete,
    onOpenAnimationComplete,
    setVisible,
  });

  const isTablet = DeviceInfo.isTablet();
  const deviceSpecificStyles = useResponsiveStyles(isTablet, { tabletWidth });

  return {
    ...styles,
    sheet: deviceSpecificStyles.sheetDeviceStyle,
    container: [...deviceSpecificStyles.container, animated.container],
    backdrop: [styles.backdrop, animated.backdrop],
  };
}

export default useModalStyles;
