import { CoreCurrencyInput } from "@boi/components-core";
import { currencyFormatter } from "./currencyFormatter";

const cases: {
  currencyFormat: string;
  inputValue: string;
  textValue: string;
  currencyValue?: number | null;
  locale?: string;
  minValue?: number;
  maxValue?: number;
}[] = [
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: ".",
    textValue: "0.00",
    currencyValue: 0,
    locale: "en-IE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-.",
    textValue: "-0.00",
    currencyValue: -0,
    locale: "en-IE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-.1",
    textValue: "-0.10",
    currencyValue: -0.1,
    locale: "en-IE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: ".1",
    textValue: "0.10",
    currencyValue: 0.1,
    locale: "en-IE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: ",",
    textValue: "0,00",
    currencyValue: 0,
    locale: "de-DE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-,",
    textValue: "-0,00",
    currencyValue: -0,
    locale: "de-DE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-,1",
    textValue: "-0,10",
    currencyValue: -0.1,
    locale: "de-DE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: ",1",
    textValue: "0,10",
    currencyValue: 0.1,
    locale: "de-DE",
  },

  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "1233.89,89.90,2",
    textValue: "12,338,989.90",
    currencyValue: 12338989.9,
    locale: "en-IE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-1233.8-9,89.90,2",
    textValue: "-12,338,989.90",
    currencyValue: -12338989.9,
    locale: "en-IE",
  },
  {
    currencyFormat: "ZeroDecimalPlaces",
    inputValue: "1233.89,89.90,2",
    textValue: "12,338,990",
    currencyValue: 12338990,
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "1233.89,89.90,2",
    textValue: "1.233.898.990,20",
    currencyValue: 1233898990.2,
    locale: "de-DE",
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "-1233.8-9,89.90,2",
    textValue: "-12,000.00",
    currencyValue: -12000,
    locale: "en-IE",
    minValue: -12000,
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "1233.8-9,89.90,2",
    textValue: "11,000,000.00",
    currencyValue: 11000000,
    locale: "en-IE",
    maxValue: 11000000,
  },
  {
    currencyFormat: "TwoDecimalPlaces",
    inputValue: "",
    textValue: "",
    currencyValue: null,
    locale: "en-IE",
  },
];

describe("currencyFormatter", () => {
  test.each(cases)(
    "should evaluate to textValue and currencyValue for the input: %p)",
    (
      {
        currencyFormat,
        inputValue,
        textValue,
        currencyValue,
        locale,
        minValue,
        maxValue,
      },
      done
    ) => {
      const res = currencyFormatter(
        currencyFormat as CoreCurrencyInput.CurrencyFormat,
        inputValue as string,
        locale as string,
        minValue as number,
        maxValue as number
      );

      expect(res).toEqual({
        textValue,
        currencyValue,
      });
      done();
    }
  );
});
