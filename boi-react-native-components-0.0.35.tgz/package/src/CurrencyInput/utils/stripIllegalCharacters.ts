import { getNumberSeparators } from "@boi/js-utils";

const stripIllegalTextCharacters = (
  value: string,
  maximumFractionDigits: number,
  locale?: string,
  allowMinusSign?: boolean
) => {
  const { fraction: fractionSeparator, thousand: thousandSeparator } =
    getNumberSeparators(locale);
  const separators = `${thousandSeparator}${
    maximumFractionDigits > 0 ? fractionSeparator : ""
  }`;

  const regExpPattern = `[^0-9${allowMinusSign ? "-" : ""}${separators}]`;
  const regExp = new RegExp(regExpPattern, "g");

  return value.replace(regExp, "");
};

const stripIllegalFractionalCharacters = (
  value: string,
  maximumFractionDigits: number,
  locale?: string
): string => {
  const { fraction: fractionSeparator } = getNumberSeparators(locale);
  const fractionSeparatorPos = value.indexOf(fractionSeparator);
  const wholeNumberSubString = value.substring(0, fractionSeparatorPos);
  const fractionSubString = value.substring(fractionSeparatorPos + 1);

  if (fractionSeparatorPos < 0) {
    return value;
  }

  if (fractionSubString.length > maximumFractionDigits) {
    return `${wholeNumberSubString}${fractionSeparator}${fractionSubString.substring(
      0,
      maximumFractionDigits
    )}`;
  }

  return value;
};

export const stripIllegalCharacters = (
  value: string,
  maximumFractionDigits: number,
  locale?: string,
  minValue?: number
) => {
  // by illegal here, we mean too many
  // so for 2 decimal places, every character
  // after the 2nd decimal place is illegal
  const fractionalSafeValue = stripIllegalFractionalCharacters(
    value,
    maximumFractionDigits,
    locale
  );

  const allowMinusSign = minValue === undefined || minValue < 0;
  return stripIllegalTextCharacters(
    fractionalSafeValue,
    maximumFractionDigits,
    locale,
    allowMinusSign
  );
};
