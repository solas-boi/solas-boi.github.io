import { forwardRef, useCallback, useEffect, useState } from "react";
import {
  NativeSyntheticEvent,
  TextInput as RNTextInput,
  TextInputFocusEventData,
} from "react-native";
import {
  CoreCurrencyInput,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useCalculateSafeValue } from "./hooks";
import { currencyFormatter, stripIllegalCharacters } from "./utils";
import { InputLabelTopProps } from "../InputLabelTop";
import { type InputAlertsProps } from "../InputAlerts";
import { TextInput, type TextInputProps } from "../TextInput";

export type CurrencyInputProps = PropsWithOptionalTestID &
  Omit<
    TextInputProps,
    "defaultValue" | "value" | "style" | "editable" | "selectionColor"
  > & {
    defaultValue?: number;
    value?: number | null;
    minValue?: number;
    maxValue?: number;
    currencySymbol?: string;
    locale?: string;
    hasError?: boolean;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    labelProps: Omit<
      InputLabelTopProps,
      "htmlFor" | "labelHintID" | "children"
    >;
    currencyFormat?: CoreCurrencyInput.CurrencyFormat;
    onChangeCurrency?: (value: number | null | undefined) => void;
  };

const CurrencyInput = forwardRef<RNTextInput, CurrencyInputProps>(
  (props, ref) => {
    const {
      defaultValue,
      value,
      minValue,
      maxValue,
      testID = "currency-input",
      currencySymbol = CoreCurrencyInput.DEFAULT_SYMBOL,
      currencyFormat = CoreCurrencyInput.DEFAULT_DECIMAL_PLACES,
      locale,
      onBlur,
      onChangeCurrency,
      onChangeText,
      labelProps,
      accessibilityLabel,
      accessibilityHint,
    } = props;

    const safeValue = useCalculateSafeValue(
      value,
      defaultValue,
      minValue,
      maxValue
    );

    const { textValue: initialInternalValue } = currencyFormatter(
      currencyFormat,
      (safeValue || "").toString(),
      locale,
      minValue,
      maxValue
    );

    const [internalValue, setInternalValue] = useState<string>();
    const [internalCurrencyValue, setInternalCurrencyValue] =
      useState(safeValue);

    useEffect(() => {
      setInternalValue(initialInternalValue);
    }, [initialInternalValue]);

    const shouldFireOnChangeCurrency =
      (value && value !== safeValue) ||
      (defaultValue && defaultValue !== safeValue);

    if (shouldFireOnChangeCurrency && onChangeCurrency) {
      onChangeCurrency(safeValue);
    }

    const handleBlur = useCallback<NonNullable<typeof onBlur>>(
      (evt: NativeSyntheticEvent<TextInputFocusEventData>) => {
        const { textValue, currencyValue } = currencyFormatter(
          currencyFormat,
          internalValue,
          locale,
          minValue,
          maxValue
        );

        setInternalValue(textValue);
        if (internalCurrencyValue !== currencyValue) {
          setInternalCurrencyValue(currencyValue);
          onChangeCurrency && onChangeCurrency(currencyValue);
        }
        onBlur?.(evt);
      },
      [
        onBlur,
        onChangeCurrency,
        internalValue,
        internalCurrencyValue,
        currencyFormat,
        locale,
        minValue,
        maxValue,
      ]
    );

    const { maximumFractionDigits } =
      currencyFormat === CoreCurrencyInput.TWO_DECIMAL_PLACES
        ? CoreCurrencyInput.TWO_DP_FORMAT_OPTIONS
        : CoreCurrencyInput.ZERO_DP_FORMAT_OPTIONS;

    const handleChangeText = useCallback(
      (text: string) => {
        const characterSafeValue = stripIllegalCharacters(
          text,
          maximumFractionDigits,
          locale
        );

        setInternalValue(characterSafeValue);
        onChangeText?.(characterSafeValue);
      },
      [onChangeText, locale, maximumFractionDigits]
    );

    const a11yLabel =
      accessibilityLabel ??
      props["aria-label"] ??
      labelProps.accessibilityLabel ??
      labelProps["aria-label"] ??
      labelProps.label;

    const accessibilityLabelWithFractionPlaceWarning = `${
      a11yLabel ? `${a11yLabel} . ` : ""
    }you can only enter ${maximumFractionDigits} decimal places`;

    return (
      <TextInput
        {...props}
        ref={ref}
        defaultValue={`${defaultValue ?? ""}`}
        inputMode="decimal"
        value={internalValue}
        testID={testID}
        prefix={currencySymbol}
        onBlur={handleBlur}
        onChangeText={handleChangeText}
        accessibilityLabel={accessibilityLabelWithFractionPlaceWarning}
        accessibilityHint={accessibilityHint}
      />
    );
  }
);

CurrencyInput.displayName = "CurrencyInput";

export default CurrencyInput;
