import { useCalculateSafeValue } from "./useCalculateSafeValue";

const cases: {
  value?: number;
  defaultValue?: number;
  minValue?: number;
  maxValue?: number;
  result: number | undefined;
}[] = [
  {
    result: undefined,
  },
  {
    value: 12,
    result: 12,
  },
  {
    defaultValue: 12,
    result: 12,
  },
  {
    value: -10,
    minValue: 0,
    result: 0,
  },
  {
    value: 1,
    minValue: 5,
    result: 5,
  },
  {
    value: 10,
    maxValue: 0,
    result: 0,
  },
  {
    value: 10,
    maxValue: 1,
    result: 1,
  },
];

describe("useCalculateSafeValue", () => {
  test.each(cases)(
    "should evaluate to textValue and currencyValue for the input: %p)",
    ({ value, defaultValue, minValue, maxValue, result }, done) => {
      const res = useCalculateSafeValue(
        value as number | undefined,
        defaultValue as number | undefined,
        minValue as number | undefined,
        maxValue as number | undefined
      );

      expect(res).toEqual(result as number);
      done();
    }
  );
});
