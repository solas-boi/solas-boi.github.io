export {
  default as ResponsiveTable,
  type ResponsiveTableProps,
} from "./ResponsiveTable";
