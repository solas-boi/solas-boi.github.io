import { View } from "react-native";
import {
  CoreResponsiveTable,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useWidth } from "./ResponsiveTable.hooks";
import { StandardTable } from "./StandardTable";
import { CompactTable } from "./CompactTable";

type Header = CoreResponsiveTable.Header;
type Row = CoreResponsiveTable.Row;

export type ResponsiveTableProps = PropsWithOptionalTestID & {
  minWidth: number;
  headers: [Header, Header, ...Header[]];
  rows: [Row, ...Row[]];
};

function ResponsiveTable(props: ResponsiveTableProps) {
  const { minWidth, testID = "responsive-table", ...otherProps } = props;
  const { headers, rows } = otherProps;

  const { ref, width, handleLayout } = useWidth();

  if (!CoreResponsiveTable.isDataValid(headers, rows)) {
    console.warn("Invalid responsive table data");
    return null;
  }

  return (
    <View ref={ref} onLayout={handleLayout} testID={testID}>
      {width < minWidth ? (
        <CompactTable {...otherProps} testID={testID} />
      ) : (
        <StandardTable {...otherProps} testID={testID} />
      )}
    </View>
  );
}

export default ResponsiveTable;
