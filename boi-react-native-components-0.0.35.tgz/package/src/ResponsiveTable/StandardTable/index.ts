export {
  default as StandardTable,
  type StandardTableProps,
} from "./StandardTable";
