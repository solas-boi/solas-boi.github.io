import { useState } from "react";
import { View } from "react-native";

import { Tooltip, TooltipIconButton } from "../../Tooltip";

type StandardTableTooltipProps = {
  heading: string;
  text: string;
  label: string;
};

export function StandardTableTooltip(props: StandardTableTooltipProps) {
  const { heading, text, label } = props;

  const [isOpen, setIsOpen] = useState(false);

  function handlePress() {
    setIsOpen(true);
  }

  return (
    <Tooltip
      text={text}
      isOpen={isOpen}
      onOpenChange={setIsOpen}
      heading={heading}
      reference={
        <View style={{ margin: -8 }}>
          <TooltipIconButton
            isOpen={isOpen}
            onPress={handlePress}
            aria-label={label}
          />
        </View>
      }
    />
  );
}
