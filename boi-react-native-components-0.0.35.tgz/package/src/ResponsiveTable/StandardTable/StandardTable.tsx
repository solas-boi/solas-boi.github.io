import { type PropsWithTestID } from "@boi/components-core";

import { StandardTableTooltip } from "./StandardTableTooltip";
import { type ResponsiveTableProps } from "../ResponsiveTable";
import {
  Table,
  TableHead,
  TableHeadRow,
  TableHeadCell,
  TableHeadTypography,
  TableBody,
  TableBodyRow,
  TableBodyCell,
  TableBodyTypography,
} from "../../Table";

export type StandardTableProps = PropsWithTestID &
  Pick<ResponsiveTableProps, "headers" | "rows">;

function StandardTable(props: StandardTableProps) {
  const { headers, rows, testID } = props;

  return (
    <Table testID={`${testID}-standard`}>
      <TableHead>
        <TableHeadRow testID={`${testID}-standard-row`}>
          {headers.map((header, headerIndex) => (
            <TableHeadCell
              key={headerIndex}
              align={header.align}
              testID={`${testID}-standard-header`}
            >
              {header.tooltip && (
                <StandardTableTooltip
                  heading={header.text}
                  text={header.tooltip}
                  label={`${header.text} tooltip`}
                />
              )}

              <TableHeadTypography>{header.text}</TableHeadTypography>
            </TableHeadCell>
          ))}
        </TableHeadRow>
      </TableHead>

      <TableBody>
        {rows.map((row, rowIndex) => {
          const isEven = (rowIndex + 1) % 2 === 0;

          return (
            <TableBodyRow
              key={rowIndex}
              isEven={isEven}
              testID={`${testID}-standard-row`}
            >
              {row.map((data, dataIndex) => (
                <TableBodyCell
                  key={dataIndex}
                  align={headers[dataIndex]?.align}
                  testID={`${testID}-standard-data`}
                >
                  <TableBodyTypography>{data.text}</TableBodyTypography>
                </TableBodyCell>
              ))}
            </TableBodyRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

export default StandardTable;
