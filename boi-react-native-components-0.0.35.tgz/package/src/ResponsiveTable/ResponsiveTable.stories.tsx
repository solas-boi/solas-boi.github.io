import type { Meta, StoryObj } from "@storybook/react";

import ResponsiveTable from "./ResponsiveTable";
import { mockResponsiveTableProps } from "./ResponsiveTable.mocks";

const meta = {
  title: "Data Display/ResponsiveTable",
  component: ResponsiveTable,
  argTypes: {
    minWidth: {
      control: "number",
      description:
        "The minimum width of the container, in pixels, needed to display the table in full.",
    },
  },
} satisfies Meta<typeof ResponsiveTable>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: { ...mockResponsiveTableProps },
};
