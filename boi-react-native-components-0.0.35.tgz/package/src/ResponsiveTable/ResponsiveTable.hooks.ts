import { useRef, useState, useLayoutEffect } from "react";
import { View, type LayoutChangeEvent } from "react-native";

export function useWidth() {
  const ref = useRef<View>(null);

  const [width, setWidth] = useState(0);

  useLayoutEffect(() => {
    ref.current?.measure((_x, _y, refWidth) => {
      setWidth(refWidth);
    });
  }, []);

  function handleLayout(event: LayoutChangeEvent) {
    setWidth(event.nativeEvent.layout.width);
  }

  return { ref, width, handleLayout };
}
