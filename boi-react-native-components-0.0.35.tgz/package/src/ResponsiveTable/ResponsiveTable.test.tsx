import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import ResponsiveTable, { type ResponsiveTableProps } from "./ResponsiveTable";
import { mockResponsiveTableProps } from "./ResponsiveTable.mocks";

jest.useFakeTimers();

function WrappedResponsiveTable(props: ResponsiveTableProps) {
  return (
    <DesignTokensProvider>
      <ResponsiveTable {...props} />
    </DesignTokensProvider>
  );
}

describe("ResponsiveTable", () => {
  let baseProps: ResponsiveTableProps;

  beforeEach(() => {
    baseProps = { ...mockResponsiveTableProps };
  });

  it("should render with a default testID", () => {
    render(<WrappedResponsiveTable {...baseProps} />);

    expect(screen.getByTestId("responsive-table")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-responsive-table";

    render(<WrappedResponsiveTable {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
