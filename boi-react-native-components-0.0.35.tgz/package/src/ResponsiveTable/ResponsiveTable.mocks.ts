import { type ResponsiveTableProps } from "./ResponsiveTable";

export const mockResponsiveTableProps: ResponsiveTableProps = {
  minWidth: 650,
  headers: [
    {
      text: "Loan amount",
      align: "left",
    },
    {
      text: "Interest rate",
      tooltip: "Additional information",
    },
    {
      text: "APR variable",
      tooltip: "Additional information",
    },
    { text: "Repayment term" },
    { text: "Monthly repayment" },
    { text: "Cost of credit" },
  ],
  rows: [
    [
      { text: "€8,000" },
      { text: "8.25%" },
      { text: "8.5%" },
      { text: "60 months" },
      { text: "€162.95" },
      { text: "€1,777.00" },
    ],
    [
      { text: "€15,000" },
      { text: "7.3%" },
      { text: "7.5%" },
      { text: "60 months" },
      { text: "€298.83" },
      { text: "€2,929.80" },
    ],
    [
      { text: "€20,000" },
      { text: "6.6%" },
      { text: "6.8%" },
      { text: "60 months" },
      { text: "€391.92" },
      { text: "€3,515.20" },
    ],
    [
      { text: "€40,000" },
      { text: "6.6%" },
      { text: "6.8%" },
      { text: "60 months" },
      { text: "€783.85" },
      { text: "€7,031.00" },
    ],
  ],
};
