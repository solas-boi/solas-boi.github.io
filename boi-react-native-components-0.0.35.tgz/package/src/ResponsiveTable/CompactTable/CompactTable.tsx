import { useState, useMemo } from "react";
import {
  CoreResponsiveTable,
  type PropsWithTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { type ResponsiveTableProps } from "../ResponsiveTable";
import { Select, type SelectItem } from "../../Select";
import {
  Table,
  TableHead,
  TableHeadRow,
  TableHeadCell,
  TableBody,
  TableBodyRow,
  TableBodyCell,
  TableBodyTypography,
} from "../../Table";
import { TypographyTooltip } from "../../TypographyTooltip";

export type CompactTableProps = PropsWithTestID &
  Pick<ResponsiveTableProps, "headers" | "rows">;

function CompactTable(props: CompactTableProps) {
  const { headers, rows, testID } = props;

  const [visibleRowIndex, setVisibleRowIndex] = useState(0);

  const { tokens } = useDesignTokens();
  const { table } = tokens;

  const selectItems = useMemo(() => {
    return CoreResponsiveTable.getSelectItems(rows);
  }, [rows]);

  const primaryHeader = headers[0];
  const visibleRow = rows[visibleRowIndex] || rows[0];

  function handleChange(selectedItem: SelectItem | null | undefined) {
    setVisibleRowIndex(selectedItem ? parseInt(selectedItem.id, 10) || 0 : 0);
  }

  return (
    <Table testID={`${testID}-compact`}>
      <TableHead>
        <TableHeadRow>
          <TableHeadCell align="stretch">
            <Select
              labelProps={{
                label: primaryHeader.text,
              }}
              items={selectItems}
              selectedItem={selectItems[visibleRowIndex]}
              onChange={handleChange}
            />
          </TableHeadCell>
        </TableHeadRow>
      </TableHead>

      <TableBody>
        {headers.map((header, headerIndex) => {
          const isEven = headerIndex % 2 === 0;

          if (headerIndex === 0) {
            return null;
          }

          return (
            <TableBodyRow
              key={headerIndex}
              isEven={isEven}
              testID={`${testID}-compact-row`}
            >
              <TableBodyCell align="left" testID={`${testID}-compact-header`}>
                {header.tooltip ? (
                  <TypographyTooltip
                    typographyVariant={table.head.typography.variant}
                    iconButtonProps={{
                      "aria-label": `${header.text} tooltip`,
                    }}
                    otherIconButtonProps={{ variant: "default" }}
                    tooltipProps={{
                      heading: header.text,
                      text: header.tooltip,
                    }}
                  >
                    <TableBodyTypography style={{ textAlign: "left" }}>
                      {header.text}
                    </TableBodyTypography>
                  </TypographyTooltip>
                ) : (
                  <TableBodyTypography style={{ textAlign: "left" }}>
                    {header.text}
                  </TableBodyTypography>
                )}
              </TableBodyCell>

              {visibleRow[headerIndex] && (
                <TableBodyCell testID={`${testID}-compact-data`}>
                  <TableBodyTypography style={{ textAlign: "right" }}>
                    {visibleRow[headerIndex].text}
                  </TableBodyTypography>
                </TableBodyCell>
              )}
            </TableBodyRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

export default CompactTable;
