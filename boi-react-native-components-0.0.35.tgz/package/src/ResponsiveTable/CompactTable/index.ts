export {
  default as CompactTable,
  type CompactTableProps,
} from "./CompactTable";
