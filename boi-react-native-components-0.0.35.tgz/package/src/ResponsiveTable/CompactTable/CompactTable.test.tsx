import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import CompactTable, { type CompactTableProps } from "./CompactTable";
import { mockResponsiveTableProps } from "../ResponsiveTable.mocks";

jest.useFakeTimers();

function WrappedCompactTable(props: CompactTableProps) {
  return (
    <DesignTokensProvider>
      <CompactTable {...props} />
    </DesignTokensProvider>
  );
}

describe("ResponsiveTable: CompactTable", () => {
  let baseProps: CompactTableProps;

  beforeEach(() => {
    baseProps = {
      ...mockResponsiveTableProps,
      testID: "table",
    };
  });

  it("should render the correct label", async () => {
    render(<WrappedCompactTable {...baseProps} />);

    const primaryHeader = screen.getByText("Loan amount");

    expect(primaryHeader).toBeDefined();
  });

  it("should render the correct number of dropdown items", async () => {
    const user = userEvent.setup();

    render(<WrappedCompactTable {...baseProps} />);

    const combobox = await screen.findByTestId("select");

    await act(async () => {
      await user.press(combobox);
    });

    const options = screen.getAllByRole("radio");
    expect(options).toHaveLength(baseProps.rows.length);
  });

  it("should render the correct number of rows", async () => {
    render(<WrappedCompactTable {...baseProps} />);

    const rows = screen.getAllByTestId("table-compact-row");

    expect(rows).toHaveLength(baseProps.rows[0].length - 1);
  });

  it("should render the first row by default", async () => {
    render(<WrappedCompactTable {...baseProps} />);

    const headerCells = screen.getAllByTestId("table-compact-header");
    const dataCells = screen.getAllByTestId("table-compact-data");

    expect(headerCells[0]).toHaveTextContent("Interest rate");
    expect(dataCells[0]).toHaveTextContent("8.25%");

    expect(headerCells[1]).toHaveTextContent("APR variable");
    expect(dataCells[1]).toHaveTextContent("8.5%");

    expect(headerCells[2]).toHaveTextContent("Repayment term");
    expect(dataCells[2]).toHaveTextContent("60 months");

    expect(headerCells[3]).toHaveTextContent("Monthly repayment");
    expect(dataCells[3]).toHaveTextContent("€162.95");

    expect(headerCells[4]).toHaveTextContent("Cost of credit");
    expect(dataCells[4]).toHaveTextContent("€1,777.00");
  });

  it("should render the correct row when dropdown is updated", async () => {
    const user = userEvent.setup();

    render(<WrappedCompactTable {...baseProps} />);

    const combobox = await screen.findByTestId("select");

    await act(async () => {
      await user.press(combobox);
    });

    const options = screen.getAllByRole("radio");
    await act(async () => {
      await user.press(options[1]!);
    });

    const headerCells = await screen.findAllByTestId("table-compact-header");
    const dataCells = await screen.findAllByTestId("table-compact-data");

    expect(headerCells[0]).toHaveTextContent("Interest rate");
    expect(dataCells[0]).toHaveTextContent("7.3%");

    expect(headerCells[1]).toHaveTextContent("APR variable");
    expect(dataCells[1]).toHaveTextContent("7.5%");

    expect(headerCells[2]).toHaveTextContent("Repayment term");
    expect(dataCells[2]).toHaveTextContent("60 months");

    expect(headerCells[3]).toHaveTextContent("Monthly repayment");
    expect(dataCells[3]).toHaveTextContent("€298.83");

    expect(headerCells[4]).toHaveTextContent("Cost of credit");
    expect(dataCells[4]).toHaveTextContent("€2,929.80");
  });
});
