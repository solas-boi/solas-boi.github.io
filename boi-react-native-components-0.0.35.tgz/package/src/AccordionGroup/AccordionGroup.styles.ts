import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { accordionGroup } = tokens;

  return StyleSheet.create({
    container: {
      gap: accordionGroup.gap.default,
    },
    nestedContainer: {
      gap: accordionGroup.gap.nested,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
