import type { Meta, StoryObj } from "@storybook/react";

import AccordionGroup from "./AccordionGroup";
import { Typography } from "../Typography";

const meta = {
  title: "Surfaces/AccordionGroup",
  component: AccordionGroup,
  argTypes: {
    items: { control: { disable: true } },
  },
  args: {
    items: [
      {
        title: "What is a loan?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
      {
        title: "How do I apply for a loan?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
      {
        title: "What types of loan do Bank of Ireland offer?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
    ],
  },
} satisfies Meta<typeof AccordionGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Nested: Story = {
  args: {
    items: [
      {
        title: "What is the Bank of Ireland UK ISA?",
        content: [
          {
            title: "How does it work?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
          {
            title: "What does my holding account do?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
          {
            title: "Do I pay tax on my savings in an ISA?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
        ],
      },
    ],
  },
};
