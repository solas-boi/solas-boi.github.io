export {
  default as AccordionGroup,
  type AccordionGroupProps,
} from "./AccordionGroup";
