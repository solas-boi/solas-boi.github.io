import { View } from "react-native";
import { type PropsWithOptionalTestID } from "@boi/components-core";

import useStyles from "./AccordionGroup.styles";
import { Accordion, type AccordionProps } from "../Accordion";

type NestedAccordionItem = Omit<AccordionProps, "variant">;

type AccordionItem = Omit<NestedAccordionItem, "content"> & {
  content: NestedAccordionItem["content"] | NestedAccordionItem[];
};

export type AccordionGroupProps = PropsWithOptionalTestID & {
  items: AccordionItem[];
};

function AccordionGroup(props: AccordionGroupProps) {
  const { items, testID = "accordion-group" } = props;

  const styles = useStyles();

  return (
    <View style={styles.container} testID={testID}>
      {items.map((item) => {
        if (Array.isArray(item.content)) {
          return (
            <Accordion
              key={item.title}
              title={item.title}
              content={<NestedAccordionGroup items={item.content} />}
            />
          );
        }

        return <Accordion key={item.title} {...item} content={item.content} />;
      })}
    </View>
  );
}

type NestedAccordionGroupProps = {
  items: NestedAccordionItem[];
};

function NestedAccordionGroup(props: NestedAccordionGroupProps) {
  const { items } = props;

  const styles = useStyles();

  return (
    <View style={styles.nestedContainer}>
      {items.map((item) => (
        <Accordion key={item.title} {...item} variant="nested" />
      ))}
    </View>
  );
}

export default AccordionGroup;
