import { type GestureResponderEvent } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";

import Radio from "./Radio";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta = {
  title: "Inputs/Radio",
  component: Radio,
  render: function Render(args: any) {
    const [, updateArgs] = useArgs();

    function handlePress(event: GestureResponderEvent) {
      updateArgs({ isChecked: true });
      action("onPress")(event);
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => <Radio {...args} ref={ref} onPress={handlePress} />}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    disabled: { control: "boolean" },
    isChecked: { control: "boolean" },
    hasError: { control: "boolean" },
  },
  args: {
    disabled: false,
    isChecked: false,
    hasError: false,
  },
} satisfies Meta<typeof Radio>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "Try Me!",
    },
  },
};

export const Disabled: Story = {
  ...Basic,
  args: {
    disabled: true,
    labelProps: {
      label: "Try Me!",
    },
  },
};

export const WithLabel: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "Try Me!",
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    labelProps: {
      label: "Try Me!",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);
