import { forwardRef, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelRight, type InputLabelRightProps } from "../InputLabelRight";
import { RadioBase, type RadioBaseProps } from "../RadioBase";
import { KeyboardPressableProps } from "../types";
import useStyles from "./Radio.styles";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type RadioProps = Omit<
  KeyboardPressableProps,
  | "role"
  | "accessibilityRole"
  | "accessibilityValue"
  | "accessibilityState"
  | "children"
  | "style"
  | "ref"
> &
  Omit<RadioBaseProps, "children" | "hasFocus"> & {
    value?: string;
    labelProps: Omit<InputLabelRightProps, "children" | "isDisabled">;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
  };

const Radio = forwardRef<View, RadioProps>((props, ref) => {
  const {
    labelProps,
    alertProps,
    disabled,
    isChecked,
    hasError,
    value,
    testID = "radio",
    ...inputProps
  } = props;

  const styles = useStyles();

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <ScreenReaderAlertNotifier alert={alertProps}>
        <KeyboardPressable
          {...inputProps}
          ref={ref}
          onFocusChange={handleKeyboardFocusChange}
          haloEffect={false}
          tintType="none"
          enableA11yFocus
          role="radio"
          accessibilityRole="radio"
          accessibilityValue={{ text: value }}
          accessibilityState={{
            checked: Boolean(isChecked),
            disabled: Boolean(disabled),
          }}
          disabled={disabled}
          containerStyle={styles.container}
          testID={testID}
        >
          <RadioBase
            isChecked={isChecked}
            hasError={hasError}
            disabled={false}
            testID={`${testID}-base`}
          >
            {(radioComponent) => (
              <InputLabelRight
                isDisabled={Boolean(disabled)}
                hasFocus={hasKeyboardFocus}
                {...labelProps}
              >
                {radioComponent}
              </InputLabelRight>
            )}
          </RadioBase>
        </KeyboardPressable>
      </ScreenReaderAlertNotifier>
    </InputWrapper>
  );
});

export default Radio;
