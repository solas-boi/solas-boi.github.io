import {
  render,
  screen,
  within,
  userEvent,
  act,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Radio, { type RadioProps } from "./Radio";

jest.useFakeTimers();

function WrappedRadio(props: RadioProps) {
  return (
    <DesignTokensProvider>
      <Radio {...props} />
    </DesignTokensProvider>
  );
}

describe("Radio", () => {
  let baseProps: RadioProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "Radio Label",
      },
    };
  });

  it("should render an enabled radio input by default", () => {
    render(<WrappedRadio {...baseProps} />);

    const radio = screen.getByRole("radio");

    expect(radio).toBeEnabled();
  });

  it("should render an unchecked radio input by default", () => {
    render(<WrappedRadio {...baseProps} />);

    const radio = screen.getByRole("radio");

    expect(radio).not.toBeChecked();
  });

  it("should render a disabled radio input", () => {
    render(<WrappedRadio {...baseProps} disabled />);

    const radio = screen.getByRole("radio");

    expect(radio).not.toBeEnabled();
  });

  it("should render a checked radio input", () => {
    const mockOnPress = jest.fn();

    render(<WrappedRadio {...baseProps} isChecked onPress={mockOnPress} />);

    const radio = screen.getByRole("radio");

    expect(radio).toBeChecked();
  });

  it("should trigger the onPress event when clicked", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(<WrappedRadio {...baseProps} onPress={mockOnPress} />);

    const radio = screen.getByRole("radio");

    await act(async () => {
      await user.press(radio);
    });

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it("should render a label with the correct aria-label", () => {
    render(<WrappedRadio {...baseProps} />);

    const radio = screen.getByRole("radio");
    const label = within(radio).getByLabelText("Radio Label");

    expect(radio).toBeDefined();
    expect(label).toBeDefined();
  });

  it("should render an alert when alertProps are provided", () => {
    render(
      <WrappedRadio
        {...baseProps}
        testID="radio"
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("radio-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render with a default testID", () => {
    render(<WrappedRadio {...baseProps} />);

    expect(screen.getByTestId("radio")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-radio";

    render(<WrappedRadio {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
