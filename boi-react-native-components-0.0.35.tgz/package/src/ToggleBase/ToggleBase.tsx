import { useEffect } from "react";
import { View, ViewProps, useWindowDimensions } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from "react-native-reanimated";

import ToggleText from "./ToggleText/index";

import { useStateStyles } from "./ToggleBase.styles";
import {
  parseSizeToken,
  useDesignTokens,
} from "@boi/react-native-design-tokens";
import { CoreToggle } from "@boi/components-core";

export type ToggleBaseProps = Omit<ViewProps, "style"> & {
  checked: boolean;
  toggleSize?: CoreToggle.Size;
  disabled?: boolean;
  hasFocus?: boolean;
};

const getTranslateX = (checked: boolean, swipeRange: number) =>
  checked ? swipeRange : 0;

function ToggleBase(props: ToggleBaseProps) {
  const {
    checked,
    toggleSize = "default",
    disabled = false,
    hasFocus,
    testID = "toggle",
    ...viewProps
  } = props;

  const {
    tokens: { toggle },
  } = useDesignTokens();
  const { fontScale } = useWindowDimensions();

  const stateStyles = useStateStyles(checked, disabled, toggleSize);

  const toggleWidth = parseSizeToken(toggle.size[toggleSize].width, fontScale);
  const toggleHeight = parseSizeToken(
    toggle.size[toggleSize].height,
    fontScale
  );
  const togglePadding = toggle.thumb.padding;
  const toggleableDimensions = toggleHeight - 2 * togglePadding;

  const swipeRange = toggleWidth - 2 * togglePadding - toggleableDimensions;

  const translateX = useSharedValue(getTranslateX(checked, swipeRange));

  useEffect(() => {
    translateX.value = getTranslateX(checked, swipeRange);
  }, [checked, toggleWidth, swipeRange, translateX]);

  const animatedStyles = {
    checkedText: useAnimatedStyle(() => {
      return {
        opacity: withSpring(checked ? 1 : 0, { duration: 1000 }),
      };
    }),
    uncheckedText: useAnimatedStyle(() => {
      return {
        opacity: withSpring(checked ? 0 : 1, { duration: 1000 }),
      };
    }),
    thumb: useAnimatedStyle(() => {
      return {
        transform: [
          { translateX: withSpring(translateX.value, { damping: 50 }) },
        ],
      };
    }),
  };

  return (
    <View testID={testID} {...viewProps}>
      {hasFocus && <View pointerEvents="none" style={stateStyles.focusRing} />}
      <View style={stateStyles.customContainer}>
        <Animated.View style={stateStyles.customBackground} />

        <ToggleText
          disabled={disabled}
          toggleSize={toggleSize}
          checked={true}
          text="On"
          swipeRange={swipeRange}
          animatedStyle={animatedStyles.checkedText}
          testID={`${testID}-checked-text`}
        />
        <ToggleText
          disabled={disabled}
          toggleSize={toggleSize}
          checked={false}
          text="Off"
          swipeRange={swipeRange}
          animatedStyle={animatedStyles.uncheckedText}
          testID={`${testID}-unchecked-text`}
        />
        <Animated.View
          style={[
            stateStyles.customThumb,
            animatedStyles.thumb,
            {
              height: toggle.thumb.size[toggleSize],
              width: toggle.thumb.size[toggleSize],
              borderRadius: toggleHeight,
            },
          ]}
        />
      </View>
    </View>
  );
}

export default ToggleBase;
