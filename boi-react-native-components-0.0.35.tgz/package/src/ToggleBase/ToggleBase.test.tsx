import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import ToggleBase, { type ToggleBaseProps } from "./ToggleBase";

jest.useFakeTimers();

function WrappedToggleBase(props: ToggleBaseProps) {
  return (
    <DesignTokensProvider>
      <ToggleBase {...props} />
    </DesignTokensProvider>
  );
}

describe("ToggleBase", () => {
  it("should render focus ring if hasFocus prop is true", () => {
    render(<WrappedToggleBase hasFocus checked={false} />);

    const checkbox = screen.getByTestId("toggle");

    expect(checkbox).toBeDefined();
  });
});
