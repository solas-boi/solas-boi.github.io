import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet/index";
import { type CoreToggle } from "@boi/components-core";

function styleSheetFactory({ toggle }: ThemeTokens, fontScale: number) {
  const thumbSizeSmall = toggle.thumb.size.small - 2 * toggle.thumb.padding;
  const thumbSizeDefault = toggle.thumb.size.default - 2 * toggle.thumb.padding;

  return StyleSheet.create({
    customContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
    },
    customContainerChecked: {
      backgroundColor: toggle.backgroundColor.checked.base,
    },
    customContainerCheckedDisabled: {
      backgroundColor: toggle.backgroundColor.checked.disabled,
    },
    customContainerUnchecked: {
      backgroundColor: toggle.backgroundColor.unchecked.base,
    },
    customContainerUncheckedDisabled: {
      backgroundColor: toggle.backgroundColor.unchecked.disabled,
    },
    customContainerDefault: {
      width: parseSizeToken(toggle.size.default.width, fontScale),
      height: toggle.size.default.height,
      justifyContent: "center",
      borderRadius: toggle.size.default.height,
    },
    customContainerSmall: {
      width: parseSizeToken(toggle.size.small.width, fontScale),
      height: toggle.size.small.height,
      justifyContent: "center",
      borderRadius: toggle.size.small.height,
    },
    customBackground: {
      position: "absolute",
      top: 0,
      left: 0,
      backgroundColor: toggle.thumb.backgroundColor.base,
    },
    customBackgroundDefault: {
      height: toggle.size.default.height,
    },
    customBackgroundSmall: {
      height: toggle.size.small.height,
    },
    customThumb: {
      position: "absolute",
      backgroundColor: toggle.thumb.backgroundColor.base,
      shadowColor: toggle.thumb.shadowColor,
      shadowOffset: { width: 3, height: 3 },
      shadowOpacity: 0.2,
      shadowRadius: 3,
      elevation: 3,
    },
    customThumDefault: {
      left: toggle.thumb.padding,
      width: thumbSizeDefault,
      height: thumbSizeDefault,
      borderRadius: thumbSizeDefault,
    },
    customThumbSmall: {
      left: toggle.thumb.padding,
      width: thumbSizeSmall,
      height: thumbSizeSmall,
      borderRadius: thumbSizeSmall,
    },
    customText: {
      color: toggle.text.color.base,
    },
    customTextDisabled: {
      color: toggle.text.color.disabled,
    },
    focusRing: {
      position: "absolute",
      borderWidth: toggle.focusRing.width,
      borderColor: toggle.focusRing.color,
      left: -1 * (toggle.focusRing.offset + toggle.focusRing.width),
      top: -1 * (toggle.focusRing.offset + toggle.focusRing.width),
      right: -1 * (toggle.focusRing.offset + toggle.focusRing.width),
      bottom: -1 * (toggle.focusRing.offset + toggle.focusRing.width),
    },
    focusRingDefault: {
      borderRadius: toggle.size.default.height,
    },
    focusRingSmall: {
      borderRadius: toggle.size.small.height,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  checked: boolean,
  disabled: boolean,
  toggleSize: CoreToggle.Size
) {
  const styles = useStyles();

  const containerSizedStyles =
    toggleSize === "default"
      ? styles.customContainerDefault
      : styles.customContainerSmall;

  const backgroundSizedStyles =
    toggleSize === "default"
      ? styles.customBackgroundDefault
      : styles.customBackgroundSmall;

  const buildBackgroundStyles = () => {
    if (disabled) {
      return checked
        ? styles.customContainerCheckedDisabled
        : styles.customContainerUncheckedDisabled;
    }

    return checked
      ? styles.customContainerChecked
      : styles.customContainerUnchecked;
  };

  const backgroundStyles = buildBackgroundStyles();

  const thumbSizedStyles =
    toggleSize === "default"
      ? styles.customThumDefault
      : styles.customThumbSmall;

  const focusRingSizedStyles =
    toggleSize === "default" ? styles.focusRingDefault : styles.focusRingSmall;

  return {
    customContainer: [
      styles.customContainer,
      containerSizedStyles,
      backgroundStyles,
    ],
    customBackground: [
      styles.customBackground,
      backgroundStyles,
      backgroundSizedStyles,
    ],
    customThumb: [styles.customThumb, thumbSizedStyles],
    focusRing: [styles.focusRing, focusRingSizedStyles],
  };
}

export default useStyles;
