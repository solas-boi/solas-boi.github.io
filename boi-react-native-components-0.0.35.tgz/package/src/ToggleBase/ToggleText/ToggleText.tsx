import Animated from "react-native-reanimated";

import { useStateStyles } from "./ToggleText.styles";
import { Typography } from "../../Typography";
import { ToggleBaseProps } from "../index";
import { useDesignTokens } from "@boi/react-native-design-tokens";

type ToggleTextProps = Pick<
  ToggleBaseProps,
  "checked" | "testID" | "toggleSize" | "disabled"
> & {
  text: string;
  swipeRange: number;
  animatedStyle: { [key: string]: any };
};

export default function ToggleText(props: ToggleTextProps) {
  const {
    toggleSize = "default",
    checked,
    text,
    swipeRange,
    animatedStyle,
    testID,
    disabled = false,
  }: ToggleTextProps = props;

  const stateStyles = useStateStyles(checked, disabled, toggleSize, swipeRange);
  const {
    tokens: { toggle },
  } = useDesignTokens();

  const style = [stateStyles.customText, { width: swipeRange }, animatedStyle];

  return (
    <Animated.Text
      allowFontScaling={false}
      numberOfLines={1}
      style={style}
      testID={testID}
    >
      <Typography
        variant={toggle.text.size[toggleSize].typography.variant}
        fontFamily={toggle.text.size[toggleSize].typography.fontFamily}
        color={disabled ? toggle.text.color.disabled : toggle.text.color.base}
      >
        {text}
      </Typography>
    </Animated.Text>
  );
}
