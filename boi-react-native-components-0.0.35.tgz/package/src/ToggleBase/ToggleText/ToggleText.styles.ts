import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet/index";
import { type CoreToggle } from "@boi/components-core";

function styleSheetFactory({ toggle }: ThemeTokens) {
  const defaultTextPadding =
    toggle.thumb.size.default + toggle.thumb.padding * 3;
  const smallTextPadding = toggle.thumb.size.small + toggle.thumb.padding * 3;

  return StyleSheet.create({
    customText: {
      position: "absolute",
      userSelect: "none",
    },
    customTextUncheckedDefault: {
      textAlign: "left",
      left: defaultTextPadding,
      color: toggle.text.color.base,
    },
    customTextCheckedDefault: {
      textAlign: "right",
      right: defaultTextPadding,
      color: toggle.text.color.base,
    },
    customTextUncheckedDisabledDefault: {
      textAlign: "left",
      left: defaultTextPadding,
      color: toggle.text.color.disabled,
    },
    customTextCheckedDisabledDefault: {
      textAlign: "right",
      right: defaultTextPadding,
      color: toggle.text.color.disabled,
    },
    customTextUncheckedSmall: {
      textAlign: "left",
      left: smallTextPadding,
      color: toggle.text.color.base,
    },
    customTextCheckedSmall: {
      textAlign: "right",
      right: smallTextPadding,
      color: toggle.text.color.base,
    },
    customTextUncheckedDisabledSmall: {
      textAlign: "left",
      left: smallTextPadding,
      color: toggle.text.color.disabled,
    },
    customTextCheckedDisabledSmall: {
      textAlign: "right",
      right: smallTextPadding,
      color: toggle.text.color.disabled,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  checked: boolean,
  disabled: boolean,
  toggleSize: CoreToggle.Size,
  swipeRange: number
) {
  const styles = useStyles();

  const buildTextStyles = () => {
    if (toggleSize === "default") {
      if (disabled) {
        return checked
          ? styles.customTextCheckedDisabledDefault
          : styles.customTextUncheckedDisabledDefault;
      }

      return checked
        ? styles.customTextCheckedDefault
        : styles.customTextUncheckedDefault;
    }
    if (disabled) {
      return checked
        ? styles.customTextCheckedDisabledSmall
        : styles.customTextUncheckedDisabledSmall;
    }

    return checked
      ? styles.customTextCheckedSmall
      : styles.customTextUncheckedSmall;
  };

  const textStyles = buildTextStyles();

  return {
    customText: [styles.customText, { width: swipeRange }, textStyles],
  };
}

export default useStyles;
