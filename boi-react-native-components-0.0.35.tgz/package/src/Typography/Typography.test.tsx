import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Typography, { type TypographyProps } from "./Typography";

function WrappedTypography(props: TypographyProps) {
  return (
    <DesignTokensProvider>
      <Typography {...props} />
    </DesignTokensProvider>
  );
}

describe("Typography", () => {
  let baseProps: TypographyProps;

  beforeEach(() => {
    baseProps = {
      children: "Some text",
    };
  });

  it("should render the correct text", () => {
    const text = baseProps.children as string;

    render(<WrappedTypography {...baseProps} />);

    expect(screen.getByText(text)).toBeDefined();
  });

  it("should render with an optional testID", () => {
    const testID = "test-typography";

    render(<WrappedTypography {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  it("should render with the correct a11y props for displayXL variant", () => {
    render(<WrappedTypography {...baseProps} variant="displayXL" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(1);
  });

  it("should render with the correct a11y props for displayL variant", () => {
    render(<WrappedTypography {...baseProps} variant="displayL" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(1);
  });

  it("should render with the correct a11y props for displayM variant", () => {
    render(<WrappedTypography {...baseProps} variant="displayM" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(1);
  });

  it("should render with the correct a11y props for displayS variant", () => {
    render(<WrappedTypography {...baseProps} variant="displayS" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(1);
  });

  it("should render with the correct a11y props for headlineL variant", () => {
    render(<WrappedTypography {...baseProps} variant="headlineL" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(1);
  });

  it("should render with the correct a11y props for headlineM variant", () => {
    render(<WrappedTypography {...baseProps} variant="headlineM" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(2);
  });

  it("should render with the correct a11y props for headlineS variant", () => {
    render(<WrappedTypography {...baseProps} variant="headlineS" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(3);
  });

  it("should render with the correct a11y props for headlineXS variant", () => {
    render(<WrappedTypography {...baseProps} variant="headlineXS" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(4);
  });

  it("should render with the correct a11y props for titleL variant", () => {
    render(<WrappedTypography {...baseProps} variant="titleL" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(2);
  });

  it("should render with the correct a11y props for titleM variant", () => {
    render(<WrappedTypography {...baseProps} variant="titleM" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(3);
  });

  it("should render with the correct a11y props for titleS variant", () => {
    render(<WrappedTypography {...baseProps} variant="titleS" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(4);
  });

  it("should render with the correct a11y props for titleXS variant", () => {
    render(<WrappedTypography {...baseProps} variant="titleXS" />);

    expect(screen.getByRole("heading").props["aria-level"]).toBe(5);
  });

  it("should render with the correct a11y props for bodyL variant", () => {
    render(<WrappedTypography {...baseProps} variant="bodyL" />);

    expect(screen.getByRole("text").props.role).toBeUndefined();
    expect(screen.getByRole("text").props["aria-level"]).toBeUndefined();
  });

  it("should render with the correct a11y props for bodyM variant", () => {
    render(<WrappedTypography {...baseProps} variant="bodyM" />);

    expect(screen.getByRole("text").props.role).toBeUndefined();
    expect(screen.getByRole("text").props["aria-level"]).toBeUndefined();
  });

  it("should render with the correct a11y props for bodyS variant", () => {
    render(<WrappedTypography {...baseProps} variant="bodyS" />);

    expect(screen.getByRole("text").props.role).toBeUndefined();
    expect(screen.getByRole("text").props["aria-level"]).toBeUndefined();
  });

  it("should render with the correct a11y props for labelM variant", () => {
    render(<WrappedTypography {...baseProps} variant="labelM" />);

    expect(screen.getByRole("text").props.role).toBeUndefined();
    expect(screen.getByRole("text").props["aria-level"]).toBeUndefined();
  });

  it("should render with the correct a11y props for labelS variant", () => {
    render(<WrappedTypography {...baseProps} variant="labelS" />);

    expect(screen.getByRole("text").props.role).toBeUndefined();
    expect(screen.getByRole("text").props["aria-level"]).toBeUndefined();
  });

  it("should render with the component a11y props when provided", () => {
    const text = baseProps.children as string;

    render(
      <WrappedTypography {...baseProps} variant="displayXL" component="div" />
    );

    expect(screen.getByText(text).props.role).toBeUndefined();
    expect(screen.getByText(text).props["aria-level"]).toBeUndefined();
  });
});
