import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";
import { CoreTypography } from "@boi/components-core";

import { type TypographyProps } from "./Typography";
import type { TypographyStyles } from "./Typography.types";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { typography, fontFamily } = tokens;

  const styles = {} as TypographyStyles;

  CoreTypography.VARIANTS.forEach((key) => {
    styles[key] = {
      fontSize: parseSizeToken(typography.fontSize[key], fontScale),
      lineHeight: parseSizeToken(typography.lineHeight[key], fontScale),
      color: typography.color[key],
      fontFamily: typography.fontFamily[key],
    };
  });

  CoreTypography.FONT_FAMILIES.forEach((key) => {
    styles[key] = {
      fontFamily: fontFamily[key],
    };
  });

  return StyleSheet.create(styles);
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant = CoreTypography.DEFAULT_VARIANT,
  fontFamily,
  style,
  color,
}: Pick<TypographyProps, "variant" | "style" | "color"> & {
  fontFamily?: CoreTypography.FontFamily;
}) {
  const styles = useStyles();

  return {
    text: [
      styles[variant],
      fontFamily ? styles[fontFamily] : undefined,
      style,
      color ? { color } : undefined,
    ],
  };
}

export default useStyles;
