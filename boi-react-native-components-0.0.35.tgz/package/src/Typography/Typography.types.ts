import { type CoreTypography } from "@boi/components-core";

import { TYPOGRAPHY_COMPONENTS } from "./Typography.constants";

export type TypographyComponent = (typeof TYPOGRAPHY_COMPONENTS)[number];

export type TypographyStyles = {
  [key in CoreTypography.Variant]: {
    color: string;
    fontSize: number;
    lineHeight: number;
    fontFamily: string;
  };
} & {
  [key in CoreTypography.FontFamily]: {
    fontFamily: string;
  };
};
