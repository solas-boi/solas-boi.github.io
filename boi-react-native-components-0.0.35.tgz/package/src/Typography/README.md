# Typography component

## Changing the entire string's font weight or style

If you want to change the default `font-weight` or `font-style`, it's important that you use the `fontFamily` prop. e.g.

```jsx
<Typography>This is normal</Typography>
```

```jsx
<Typography fontFamily="OpenSansBold">This is bold</Typography>
```

```jsx
<Typography fontFamily="OpenSansItalic">This is italic</Typography>
```

```jsx
<Typography fontFamily="OpenSansSemiBoldItalic">
  This is bold and italic
</Typography>
```

> NB: You can't change all Typography variants' styles. Design rules state the Display and Headline variants should not change. You will encounter Typescript errors if you try to change the `fontFamily` of these variants.

## Changing part of the string's font weight or style

If you want to change part of your sentence's `font-weight` or `font-style` you can do the following and the correct `font-family` will be assigned:

```jsx
<Typography>
  Only
  <Typography fontFamily="OpenSansBold">this text</Typography>
  is bold
</Typography>
```

```jsx
<Typography>
  Only
  <Typography fontFamily="OpenSansItalic">this text</Typography>
  is italic
</Typography>
```

```jsx
<Typography>
  Only
  <Typography fontFamily="OpenSansSemiBoldItalic">this text</Typography>
  is bold and italic
</Typography>
```
