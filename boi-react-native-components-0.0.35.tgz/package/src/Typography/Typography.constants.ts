import { type HeadingLevel } from "@boi/components-core";

export const TYPOGRAPHY_COMPONENTS = [
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "div",
] as const;

export const TYPOGRAPHY_HEADING_LEVEL_MAP: {
  [key: string]: HeadingLevel;
} = {
  displayXL: 1,
  displayL: 1,
  displayM: 1,
  displayS: 1,
  headlineL: 1,
  headlineM: 2,
  headlineS: 3,
  headlineXS: 4,
  titleL: 2,
  titleM: 3,
  titleS: 4,
  titleXS: 5,
  h1: 1,
  h2: 2,
  h3: 3,
  h4: 4,
  h5: 5,
} as const;
