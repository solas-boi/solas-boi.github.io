export {
  default as StandardModalBase,
  type StandardModalBaseProps,
} from "./StandardModalBase";
