import { Ref, useMemo } from "react";
import {
  FlatList,
  type LayoutChangeEvent,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
  type FlatListProps,
} from "react-native";
import { CoreStandardModal } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./StandardModalBaseFlatList.styles";
import { Typography } from "../../Typography";
import { useStandardModalContext } from "../StandardModalBase.hooks";

function StandardModalBaseFlatList<T>(
  props: FlatListProps<T> & { flatlistRef?: Ref<FlatList<T>> }
) {
  const { snapToOffsets, ListHeaderComponent, flatlistRef, ...rest } = props;
  const {
    tokens: { standardModal },
  } = useDesignTokens();
  const styles = useStyles();
  const {
    testID,
    title,
    headingLevel = CoreStandardModal.DEFAULT_HEADING_LEVEL,
    headingHeight,
    setHeadingHeight,
    onScroll,
    onLayout,
    onContentChange,
  } = useStandardModalContext();
  const scrollSnapOffsets = useMemo(
    () =>
      !rest.snapToInterval
        ? [headingHeight, ...(snapToOffsets || [])]
        : undefined,
    [headingHeight, snapToOffsets, rest.snapToInterval]
  );

  function handleScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
    onScroll(event);
    props.onScroll?.(event);
  }

  function handleLayout(event: LayoutChangeEvent) {
    onLayout(event);
    props.onLayout?.(event);
  }
  function handleContentChange(width: number, height: number) {
    onContentChange(width, height);
    props.onContentSizeChange?.(width, height);
  }

  return (
    <FlatList
      ref={flatlistRef}
      testID={`${testID}-flatlist`}
      contentContainerStyle={styles.contentContainer}
      snapToOffsets={scrollSnapOffsets}
      alwaysBounceVertical={false}
      snapToEnd={false}
      ListHeaderComponent={
        <>
          <Typography
            style={styles.title}
            component={`h${headingLevel}`}
            onLayout={({ nativeEvent }) => {
              setHeadingHeight(nativeEvent.layout.height);
            }}
            variant={standardModal.content.heading.typography.variant}
            fontFamily={standardModal.content.heading.typography.fontFamily}
            testID={`${testID}-heading`}
          >
            {title}
          </Typography>
          {ListHeaderComponent}
        </>
      }
      {...rest}
      onLayout={handleLayout}
      onScroll={handleScroll}
      onContentSizeChange={handleContentChange}
    />
  );
}

export default StandardModalBaseFlatList;
