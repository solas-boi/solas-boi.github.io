import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";
import { isTablet } from "react-native-device-info";

function styleSheetFactory(tokens: ThemeTokens) {
  const { standardModal } = tokens;
  const screenType = isTablet() ? "tablet" : "mobile";
  const styles = StyleSheet.create({
    contentContainer: {
      paddingTop: standardModal.content.padding[screenType].top,
      paddingLeft: standardModal.content.padding[screenType].left,
      paddingRight: standardModal.content.padding[screenType].right,
      paddingBottom: standardModal.content.padding[screenType].bottom,
    },
    title: {
      paddingBottom: standardModal.content.gap,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
