import { type PropsWithChildren } from "react";
import { View } from "react-native";
import { A11y } from "react-native-a11y-order";
import {
  type HeadingLevel,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CloseIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./StandardModalBase.styles";
import { IconButton } from "../IconButton";
import { Typography } from "../Typography";
import { type ModalProps } from "../Modal";
import {
  StandardModalContext,
  useStandardModal,
} from "./StandardModalBase.hooks";
import { ScrollShadowContainer } from "../ScrollShadowContainer";

export type StandardModalBaseProps = PropsWithOptionalTestID &
  PropsWithChildren<{
    title: string;
    onRequestClose: Exclude<ModalProps["onRequestClose"], undefined>;
    headingLevel?: HeadingLevel;
  }>;

function StandardModalBase(props: StandardModalBaseProps) {
  const { title, onRequestClose, testID = "standard-modal", children } = props;

  const { tokens } = useDesignTokens();
  const { standardModal } = tokens;

  const state = useStandardModal(props);
  const {
    borderVisible,
    topShadowVisible,
    bottomShadowVisible,
    contentWidth,
    headingVisible,
    setContentWidth,
  } = state;

  const styles = useStyles();
  const stateStyles = useStateStyles(borderVisible, headingVisible);

  return (
    <StandardModalContext.Provider value={state}>
      <A11y.Order
        style={stateStyles.header}
        onLayout={(evt) => setContentWidth(evt.nativeEvent.layout.width)}
      >
        <A11y.Index index={1} style={styles.miniHeadingWrapper}>
          <Typography
            noWrap
            style={stateStyles.miniHeading}
            variant={standardModal.header.heading.typography.variant}
            fontFamily={standardModal.header.heading.typography.fontFamily}
          >
            {title}
          </Typography>
        </A11y.Index>

        <A11y.Index index={0} style={styles.closeButtonWrapper}>
          <IconButton
            aria-label="Close modal"
            onPress={onRequestClose}
            testID={`${testID}-close-button`}
            variant={standardModal.header.closeButton.variant}
          >
            <CloseIcon />
          </IconButton>
        </A11y.Index>
      </A11y.Order>

      <ScrollShadowContainer
        bottomShadowVisible={bottomShadowVisible}
        topShadowVisible={topShadowVisible}
        contentWidth={contentWidth}
      >
        {children}
      </ScrollShadowContainer>

      <View style={styles.footer} />
    </StandardModalContext.Provider>
  );
}

export default StandardModalBase;
