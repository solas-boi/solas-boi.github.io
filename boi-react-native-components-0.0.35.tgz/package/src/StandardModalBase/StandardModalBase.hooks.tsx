import { createContext, useContext, useState } from "react";
import { type StandardModalBaseProps } from "./StandardModalBase";
import {
  type LayoutChangeEvent,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from "react-native";
import { useScrollShadowContainer } from "../ScrollShadowContainer";

const fn = () => {};

type StandardModalState = ReturnType<typeof useStandardModal>;
export const StandardModalContext = createContext<StandardModalState>({
  title: "",
  testID: "",
  topShadowVisible: false,
  borderVisible: false,
  bottomShadowVisible: false,
  contentWidth: 1,
  headingHeight: 1,
  headingLevel: undefined,
  headingVisible: false,
  setBorderVisible: fn,
  setContentWidth: fn,
  setHeadingHeight: fn,
  setHeadingVisible: fn,
  onScroll: fn,
  onLayout: fn,
  onContentChange: fn,
});

export function useStandardModalContext() {
  return useContext(StandardModalContext);
}

type UseStandardModalProps = Pick<
  StandardModalBaseProps,
  "title" | "headingLevel" | "testID"
>;

export function useStandardModal(props: UseStandardModalProps) {
  const { title, headingLevel, testID } = props;
  const [borderVisible, setBorderVisible] = useState(false);
  const [headingHeight, setHeadingHeight] = useState(1);
  const [headingVisible, setHeadingVisible] = useState(true);

  const scrollContainerState = useScrollShadowContainer();

  function determineHeadingState() {
    setBorderVisible(scrollContainerState.contentOffsetY.current > 0);
    setHeadingVisible(
      scrollContainerState.contentOffsetY.current < headingHeight
    );
  }
  function onScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
    scrollContainerState.onScroll(event);
    determineHeadingState();
  }

  function onLayout(event: LayoutChangeEvent) {
    scrollContainerState.onLayout(event);
    determineHeadingState();
  }
  function onContentChange(width: number, height: number) {
    scrollContainerState.onContentChange(width, height);
    determineHeadingState();
  }

  const {
    topShadowVisible,
    bottomShadowVisible,
    setContentWidth,
    contentWidth,
  } = scrollContainerState;

  return {
    title,
    headingLevel,
    testID,
    borderVisible,
    topShadowVisible,
    bottomShadowVisible,
    headingHeight,
    headingVisible,
    contentWidth,
    setBorderVisible,
    setContentWidth,
    setHeadingHeight,
    setHeadingVisible,
    onScroll,
    onLayout,
    onContentChange,
  };
}
