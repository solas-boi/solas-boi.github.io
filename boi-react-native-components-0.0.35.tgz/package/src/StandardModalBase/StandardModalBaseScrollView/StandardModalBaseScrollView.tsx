import { forwardRef, useMemo } from "react";
import {
  View,
  ScrollView,
  type ScrollViewProps,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
  type LayoutChangeEvent,
} from "react-native";

import { CoreStandardModal } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./StandardModalBaseScrollView.styles";
import { Typography } from "../../Typography";
import { useStandardModalContext } from "../StandardModalBase.hooks";

const StandardModalBaseScrollView = forwardRef<ScrollView, ScrollViewProps>(
  (props, ref) => {
    const {
      children,
      snapToOffsets,

      ...rest
    } = props;
    const {
      tokens: { standardModal },
    } = useDesignTokens();
    const styles = useStyles();
    const {
      testID,
      title,
      headingLevel = CoreStandardModal.DEFAULT_HEADING_LEVEL,
      headingHeight,
      setHeadingHeight,
      onScroll,
      onLayout,
      onContentChange,
    } = useStandardModalContext();
    const scrollSnapOffsets = useMemo(
      () => [headingHeight, ...(snapToOffsets || [])],
      [headingHeight, snapToOffsets]
    );

    function handleScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
      onScroll(event);
      props.onScroll?.(event);
    }

    function handleLayout(event: LayoutChangeEvent) {
      onLayout(event);
      props.onLayout?.(event);
    }
    function handleContentChange(width: number, height: number) {
      onContentChange(width, height);
      props.onContentSizeChange?.(width, height);
    }

    return (
      <ScrollView
        ref={ref}
        testID={`${testID}-scrollview`}
        contentContainerStyle={styles.contentContainer}
        snapToOffsets={scrollSnapOffsets}
        alwaysBounceVertical={false}
        snapToEnd={false}
        {...rest}
        onLayout={handleLayout}
        onScroll={handleScroll}
        onContentSizeChange={handleContentChange}
      >
        <Typography
          component={`h${headingLevel}`}
          onLayout={({ nativeEvent }) => {
            setHeadingHeight(nativeEvent.layout.height);
          }}
          variant={standardModal.content.heading.typography.variant}
          fontFamily={standardModal.content.heading.typography.fontFamily}
          testID={`${testID}-heading`}
        >
          {title}
        </Typography>

        <View>{children}</View>
      </ScrollView>
    );
  }
);

StandardModalBaseScrollView.displayName = "StandardModalBaseScrollView";

export default StandardModalBaseScrollView;
