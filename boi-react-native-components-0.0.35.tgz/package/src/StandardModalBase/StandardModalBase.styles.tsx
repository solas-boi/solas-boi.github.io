import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";
import { isTablet } from "react-native-device-info";

function styleSheetFactory(tokens: ThemeTokens) {
  const { modal, standardModal } = tokens;
  const screenType = isTablet() ? "tablet" : "mobile";
  const styles = StyleSheet.create({
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: standardModal.header.gap,
      backgroundColor: modal.backgroundColor,
      borderBottomWidth: standardModal.header.stroke.bottom.width,
      borderStyle: standardModal.header.stroke.bottom.style,
      borderBottomColor: "transparent",
      paddingTop: standardModal.header.padding[screenType].top,
      paddingLeft: standardModal.header.padding[screenType].left,
      paddingRight: standardModal.header.padding[screenType].right,
      paddingBottom: standardModal.header.padding[screenType].bottom,
    },
    headerBorderVisible: {
      borderBottomColor: standardModal.header.stroke.bottom.color,
      borderBottomWidth: 1,
    },
    miniHeadingWrapper: {
      flex: 1,
    },
    miniHeading: {
      opacity: 0,
    },
    miniHeadingVisible: {
      opacity: 1,
    },
    closeButtonWrapper: {
      flexShrink: 0,
      margin: -6,
      marginTop: -10,
      marginBottom: -11,
    },
    footer: {
      height: standardModal.footer.height[screenType],
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  borderVisible: boolean,
  headingVisible: boolean
) {
  const styles = useStyles();

  return {
    header: [styles.header, borderVisible && styles.headerBorderVisible],
    miniHeading: [
      styles.miniHeading,
      !headingVisible && styles.miniHeadingVisible,
    ],
  };
}

export default useStyles;
