import {
  render,
  screen,
  within,
  userEvent,
  act,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Checkbox, { type CheckboxProps } from "./Checkbox";

jest.useFakeTimers();

function WrappedCheckbox(props: CheckboxProps) {
  return (
    <DesignTokensProvider>
      <Checkbox {...props} />
    </DesignTokensProvider>
  );
}

describe("Checkbox", () => {
  let baseProps: CheckboxProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "Checkbox Label",
      },
    };
  });

  it("should render an enabled checkbox input by default", () => {
    render(<WrappedCheckbox {...baseProps} />);

    const checkbox = screen.getByRole("checkbox");

    expect(checkbox).toBeEnabled();
  });

  it("should render an unchecked checkbox input by default", () => {
    render(<WrappedCheckbox {...baseProps} />);

    const checkbox = screen.getByRole("checkbox");

    expect(checkbox).not.toBeChecked();
  });

  it("should render a disabled checkbox input", () => {
    render(<WrappedCheckbox {...baseProps} disabled />);

    const checkbox = screen.getByRole("checkbox");

    expect(checkbox).not.toBeEnabled();
  });

  it("should render a checked checkbox input", () => {
    const mockOnPress = jest.fn();

    render(<WrappedCheckbox {...baseProps} isChecked onPress={mockOnPress} />);

    const checkbox = screen.getByRole("checkbox");

    expect(checkbox).toBeChecked();
  });

  it("should trigger the onPress event when clicked", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(<WrappedCheckbox {...baseProps} onPress={mockOnPress} />);

    const checkbox = screen.getByRole("checkbox");

    await act(async () => {
      await user.press(checkbox);
    });

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it("should render a label with the correct aria-label", () => {
    render(<WrappedCheckbox {...baseProps} />);

    const checkbox = screen.getByRole("checkbox");
    const label = within(checkbox).getByLabelText("Checkbox Label");

    expect(checkbox).toBeDefined();
    expect(label).toBeDefined();
  });

  it("should render an alert when alertProps are provided", () => {
    render(
      <WrappedCheckbox
        {...baseProps}
        testID="checkbox"
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("checkbox-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render an indeterminate checkbox when isIndeterminate is set", () => {
    render(<WrappedCheckbox {...baseProps} isIndeterminate />);

    const checkbox = screen.getByRole("checkbox");

    expect(checkbox).toBePartiallyChecked();
  });

  it("should render with a default testID", () => {
    render(<WrappedCheckbox {...baseProps} />);

    expect(screen.getByTestId("checkbox")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-checkbox";

    render(<WrappedCheckbox {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
