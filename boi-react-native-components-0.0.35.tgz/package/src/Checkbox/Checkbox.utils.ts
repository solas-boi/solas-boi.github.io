export function getCheckedAccessibilityState(
  isChecked: boolean | undefined,
  isIndeterminate: boolean | undefined
) {
  if (isIndeterminate) {
    return "mixed";
  }

  if (isChecked === undefined) {
    return undefined;
  }

  return isChecked;
}
