import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory() {
  return StyleSheet.create({
    container: {
      display: "flex",
      alignSelf: "flex-start",
      width: "100%",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
