import { forwardRef } from "react";
import { TextInput as RNTextInput } from "react-native";
import {
  render,
  screen,
  userEvent,
  waitFor,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { TextInput, type TextInputProps } from "../TextInput";
import { CalculatorIcon } from "@boi/react-native-icons";

jest.useFakeTimers();

const WrappedTextInput = forwardRef<RNTextInput, TextInputProps>(
  (props, ref) => {
    return (
      <DesignTokensProvider>
        <TextInput {...props} ref={ref} />
      </DesignTokensProvider>
    );
  }
);

describe("TextInput", () => {
  let baseProps: TextInputProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "TextInput Label",
      },
    };
  });

  it("should render an enabled input by default", async () => {
    render(<WrappedTextInput {...baseProps} />);

    const input = screen.getByTestId("input");

    expect(input).toBeEnabled();
  });

  it("should render a disabled input", async () => {
    render(<WrappedTextInput {...baseProps} disabled />);

    const input = screen.getByTestId("input");

    expect(input).toBeDisabled();
  });

  it("should render a readonly input", async () => {
    render(<WrappedTextInput {...baseProps} readonly />);

    const input = screen.getByTestId("input");

    expect(input).toBeDisabled();
  });

  it("should call custom onChangeText handler", async () => {
    const value = "Test";
    const mockOnChangeText = jest.fn();
    render(<WrappedTextInput {...baseProps} onChangeText={mockOnChangeText} />);

    const input = screen.getByTestId("input");
    const user = userEvent.setup();
    await user.type(input, value);

    expect(mockOnChangeText).toHaveBeenCalledWith(value);
  });

  it("should call custom onFocus handler", async () => {
    const mockOnFocus = jest.fn();
    render(<WrappedTextInput {...baseProps} onFocus={mockOnFocus} />);

    const input = screen.getByTestId("input");
    const user = userEvent.setup();
    await user.type(input, "Something");

    expect(mockOnFocus).toHaveBeenCalledTimes(1);
  });

  it("should call custom onBlur handler", async () => {
    const mockOnBlur = jest.fn();
    render(<WrappedTextInput {...baseProps} onBlur={mockOnBlur} />);

    const input = screen.getByTestId("input");
    const user = userEvent.setup();
    await user.type(input, "Something");

    expect(mockOnBlur).toHaveBeenCalledTimes(1);
  });

  it("should render a prefix", async () => {
    const prefixValue = "EUR";
    render(<WrappedTextInput {...baseProps} prefix={prefixValue} />);
    const prefix = screen.getByTestId("input-prefix");
    expect(prefix).toHaveTextContent(prefixValue);
  });

  it("should render an icon", async () => {
    render(<WrappedTextInput {...baseProps} icon={<CalculatorIcon />} />);
    const iconwrapper = screen.getByTestId("input-icon-wrapper");
    expect(iconwrapper.children.length).toBe(1);
  });

  it("should render a length counter if maxLength prop is provided", async () => {
    const maxLength = 30;
    render(<WrappedTextInput {...baseProps} maxLength={maxLength} />);
    const counter = screen.getByTestId("input-characters-counter");
    expect(counter).toHaveTextContent(`${maxLength} characters remaining`);
  });

  it("should not render a length counter if noCounter prop is provided", async () => {
    const maxLength = 30;
    render(<WrappedTextInput {...baseProps} maxLength={maxLength} noCounter />);
    const counter = screen.queryByTestId("input-characters-counter");
    expect(counter).toBeNull();
  });

  it("should render a length counter with length of value prop", async () => {
    const maxLength = 30;
    const value = "SomeValue";
    render(
      <WrappedTextInput {...baseProps} value={value} maxLength={maxLength} />
    );
    const counter = screen.getByTestId("input-characters-counter");
    expect(counter).toHaveTextContent(
      `${maxLength - value.length} characters remaining`
    );
  });

  it("should render a length counter with length of defaultValue prop", async () => {
    const maxLength = 30;
    const value = "SomeValue";
    render(
      <WrappedTextInput
        {...baseProps}
        defaultValue={value}
        maxLength={maxLength}
      />
    );
    const counter = screen.getByTestId("input-characters-counter");
    expect(counter).toHaveTextContent(
      `${maxLength - value.length} characters remaining`
    );
  });

  it("should render an alert when alertProps are provided", async () => {
    render(
      <WrappedTextInput
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("input-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should not display clear text button when 'withClearTextburtton' is not provided ", async () => {
    render(
      <WrappedTextInput
        {...baseProps}
        defaultValue="foo"
      />
    );

    const textboxClearButtonCandidate =
      screen.queryByTestId("input-clear-button");
    expect(textboxClearButtonCandidate).toBeNull();
  });

  it("should call onChange with an empty string and clear the text box when the clear button is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChangeText = jest.fn();

    render(
      <WrappedTextInput
        {...baseProps}
        withClearButton={true}
        defaultValue="foo"
        onChangeText={mockOnChangeText}
      />
    );

    const textbox = screen.getByTestId("input");
    const textboxClearButton = screen.getByTestId("input-clear-button");

    await waitFor(async () => {
      await user.press(textboxClearButton);
    });

    expect(mockOnChangeText).toHaveBeenCalled();
    expect(textbox).toHaveTextContent("");
  });
});
