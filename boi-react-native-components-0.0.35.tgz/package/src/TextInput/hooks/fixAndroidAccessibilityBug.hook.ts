import { useEffect } from "react";
import { Platform, type TextInputProps } from "react-native";

type NewPropsFragment = Pick<
  TextInputProps,
  | "placeholder"
  | "accessibilityLabel"
  | "accessibilityHint"
  | "value"
  | "defaultValue"
>;

/*
This is a workaround for the React Native TextInput not annoucing the accessibilityLabel if the input has any value or a placeholder. Happens only on Android
*/
export const useFixAndroidAccessibilityProps = (
  props: TextInputProps,
  valueLength: number,
  setLength: (value: number) => void
): NewPropsFragment => {
  const {
    placeholder,
    accessibilityLabel,
    accessibilityHint,
    value,
    defaultValue,
  } = props;

  if (Platform.OS !== "android") {
    return {
      placeholder,
      accessibilityHint,
      accessibilityLabel,
    };
  }

  // eslint-disable-next-line react-hooks/rules-of-hooks
  useEffect(() => {
    if (typeof value === "string") {
      setLength(value.length);
    } else if (typeof defaultValue === "string") {
      setLength(defaultValue.length);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, defaultValue]);

  const hackedPlaceholder = valueLength > 0 ? undefined : placeholder;

  const combinedHint =
    [accessibilityLabel, accessibilityHint].filter(Boolean).join(". ") ||
    undefined;

  const isWorksProperlyEdgeCase = !(valueLength > 0 || placeholder);

  return {
    placeholder: hackedPlaceholder,
    accessibilityHint:
      (isWorksProperlyEdgeCase ? accessibilityHint : combinedHint) || " . ",
    accessibilityLabel:
      (isWorksProperlyEdgeCase ? accessibilityLabel : undefined) || " . ",
  };
};
