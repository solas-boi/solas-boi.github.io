import { renderHook } from "@testing-library/react-native";
import { Platform } from "react-native";
import { useFixAndroidAccessibilityProps } from "./fixAndroidAccessibilityBug.hook";

const setPlatform = (os: "android" | "ios") => {
  jest.replaceProperty(Platform, "OS", os);
};

const THE_LABEL = "the label";
const THE_HINT = "the hint";
const LABEL_HINT_COMBINED = `${THE_LABEL}. ${THE_HINT}`;
const THE_PLACEHOLDER = "the placeholder";

type TestCase = {
  presentedPropsDescription: string;
  platform: "ios" | "android";
  valueLength: number;
  props: {
    accessibilityLabel?: string;
    accessibilityHint?: string;
    placeholder?: string;
    value?: string;
    defaultValue?: string;
  };
  expectedResult: {
    accessibilityLabel?: string;
    accessibilityHint?: string;
    placeholder?: string;
  };
};

const testCases: TestCase[] = [
  // Android
  {
    presentedPropsDescription: "only placeholder",
    platform: "android",
    valueLength: 0,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: " . ",
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "label and placeholder",
    platform: "android",
    valueLength: 0,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_LABEL,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "hint and placeholder",
    platform: "android",
    valueLength: 0,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "label, hint and placeholder",
    platform: "android",
    valueLength: 0,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: LABEL_HINT_COMBINED,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "value, label and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_LABEL,
      placeholder: undefined,
    },
  },
  {
    presentedPropsDescription: "value, hint and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_HINT,
      placeholder: undefined,
    },
  },
  {
    presentedPropsDescription: "value, label, hint and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: LABEL_HINT_COMBINED,
      placeholder: undefined,
    },
  },
  {
    presentedPropsDescription: "defaultValue, label and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_LABEL,
      placeholder: undefined,
    },
  },
  {
    presentedPropsDescription: "defaultValue, hint and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      value: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: THE_HINT,
      placeholder: undefined,
    },
  },
  {
    presentedPropsDescription: "defaultValue, label, hint and placeholder",
    platform: "android",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: " . ",
      accessibilityHint: LABEL_HINT_COMBINED,
      placeholder: undefined,
    },
  },

  // Non-android (iOS)
  {
    presentedPropsDescription: "label and placeholder",
    platform: "ios",
    valueLength: 0,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "hint and placeholder",
    platform: "ios",
    valueLength: 0,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "label, hint and placeholder",
    platform: "ios",
    valueLength: 0,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "value, label and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "value, hint and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "value, label, hint and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "defaultValue, label and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: undefined,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "defaultValue, hint and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: undefined,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
  {
    presentedPropsDescription: "defaultValue, label, hint and placeholder",
    platform: "ios",
    valueLength: 1,
    props: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
    expectedResult: {
      accessibilityLabel: THE_LABEL,
      accessibilityHint: THE_HINT,
      placeholder: THE_PLACEHOLDER,
    },
  },
];

const useExecuteTest = ({
  platform,
  valueLength,
  props,
  expectedResult,
}: TestCase) => {
  setPlatform(platform);

  const { result } = renderHook(() =>
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useFixAndroidAccessibilityProps(props, valueLength, () => {})
  );

  expect(result.current.accessibilityLabel).toBe(
    expectedResult.accessibilityLabel
  );
  expect(result.current.accessibilityHint).toBe(
    expectedResult.accessibilityHint
  );
  expect(result.current.placeholder).toBe(expectedResult.placeholder);
};

describe("useFixAndroidAccessibilityProps for", () => {
  beforeEach(jest.clearAllMocks);

  describe("Android should return the expected result when supplied with ", () =>
    test.each(testCases.filter((testCase) => testCase.platform === "android"))(
      "$presentedPropsDescription",
      useExecuteTest
    ));

  describe("Non-android should return the expected result when supplied with ", () =>
    test.each(testCases.filter((testCase) => testCase.platform !== "android"))(
      "$presentedPropsDescription",
      useExecuteTest
    ));

  describe("Call setLength when values changes ", () => {
    it("should call setLength when value prop changes", () => {
      setPlatform("android");
      const mockSetLength = jest.fn();
      renderHook(() =>
        useFixAndroidAccessibilityProps({ value: "text" }, 0, mockSetLength)
      );
      // rerender({ value: "" });

      expect(mockSetLength).toHaveBeenCalledWith(4);
    });

    it("should call setLength when defaultValue prop changes", () => {
      setPlatform("android");
      const mockSetLength = jest.fn();
      renderHook(() =>
        useFixAndroidAccessibilityProps(
          { defaultValue: "text" },
          0,
          mockSetLength
        )
      );
      // rerender({ value: "" });

      expect(mockSetLength).toHaveBeenCalledWith(4);
    });
  });
});
