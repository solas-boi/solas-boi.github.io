import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";

import TextInput, { type TextInputProps } from "./TextInput";
import { TickIcon, UsedCarIcon } from "@boi/react-native-icons";
import { getIconSelectArgType } from "@boi/react-utils";
import * as Icons from "@boi/react-native-icons";
import { IconButton } from "../IconButton";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta = {
  title: "Inputs/TextInput",
  component: TextInput,
  render: function Render(args: any) {
    function handleTextChange(newValue: string) {
      action("onTextChange")(newValue);
    }

    function handleFocus() {
      action("onFocus")();
    }

    function handleBlur() {
      action("onFocus")();
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => (
          <TextInput
            {...args}
            ref={ref}
            onChangeText={handleTextChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
          />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    disabled: { control: "boolean" },
    readonly: { control: "boolean" },
    hasError: { control: "boolean" },
    maxLength: { control: "number" },
    prefix: { control: "text" },
    icon: getIconSelectArgType(Icons as {}, 24) as {},
    placeholder: { control: "text" },
    defaultValue: { control: "text" },
    accessibilityLabel: { control: "text" },
    accessibilityHint: { control: "text" },
  },
  args: {
    disabled: false,
    readonly: false,
    hasError: false,
  },
} satisfies Meta<TextInputProps>;

export default meta;
type Story = StoryObj<TextInputProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "TextInput",
    },
  },
};

export const WithLabel: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "TextInput with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithClearButton: Story = {
  ...Basic,
  args: {
    withClearButton: true,
    labelProps: {
      label: "TextInput with clear button",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "TextInput with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithPrefix: Story = {
  args: {
    prefix: "€",
    labelProps: {
      label: "TextInput with Prefix",
    },
  },
};

export const WithIcon: Story = {
  args: {
    icon: <TickIcon height={24} width={24} color="blue" />,
    labelProps: {
      label: "TextInput with Icon",
    },
  },
};

export const WithAllSlotsFilled: Story = {
  args: {
    placeholder: "Fill me",
    withClearButton: true,
    prefix: "$",
    icon: <TickIcon height={24} width={24} />,
    labelProps: {
      label: "TextInput with all slots filled",
    },
    buttonSlot: (
      <View style={{ marginRight: -8 }}>
        <IconButton aria-label="moose">
          <UsedCarIcon style={{ padding: 0 }} height={24} width={24} />
        </IconButton>
      </View>
    ),
  },
};

export const WithLimit: Story = {
  args: {
    maxLength: 15,
    labelProps: {
      label: "TextInput with Limit",
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    labelProps: {
      label: "TextInput with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithAlley: Story = {
  ...Basic,
  args: {
    placeholder: "placeholder",
    labelProps: {
      label: "TextInput with a11y props",
    },
    accessibilityLabel: "alley label",
    accessibilityHint: "alley hint",
  },
};

export const Disabled: Story = {
  ...Basic,
  args: {
    disabled: true,
    value: "Some text",
    labelProps: {
      label: "Disabled TextInput",
    },
  },
};

export const ReadOnly: Story = {
  ...Basic,
  args: {
    readonly: true,
    value: "Some text",
    labelProps: {
      label: "ReadOnly TextInput",
    },
  },
};

export const WithFocus: Story = withFocusControlStoryArgs(WithError);
