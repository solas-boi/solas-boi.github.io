import { StyleSheet } from "react-native";
import { CoreTypography } from "@boi/components-core";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";
import { type OuterFieldProps } from "../OuterField/OuterField";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { textInput, typography } = tokens;

  const typographyVariant: CoreTypography.Variant =
    textInput.typography.variant;

  const inputContainer = StyleSheet.create({
    base: {
      flexGrow: 1,
      flexShrink: 1,

      height: textInput.height,
    },
  });

  const input = StyleSheet.create({
    base: {
      flexGrow: 1,
      flexShrink: 1,
      backgroundColor: "transparent",
      borderColor: "transparent",

      paddingHorizontal: 0,
      paddingVertical: 0,

      color: textInput.color.base,
      fontFamily: typography.fontFamily[typographyVariant],
      fontSize: parseSizeToken(
        typography.fontSize[typographyVariant],
        fontScale
      ),
      height: textInput.height,
    },
    isReadOnly: {
      color: textInput.color.readOnly,
    },
    isDisabled: {
      color: textInput.color.disabled,
    },
  });

  const prefix = StyleSheet.create({
    base: {
      color: textInput.prefix.color,
    },
  });

  return {
    input,
    inputContainer,
    prefix,
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({ isDisabled, isReadOnly }: OuterFieldProps) {
  const { input, prefix, inputContainer } = useStyles();

  return {
    inputContainer: inputContainer.base,
    input: [
      input.base,
      isReadOnly && input.isReadOnly,
      isDisabled && input.isDisabled,
    ],
    prefix: prefix.base,
  };
}

export default useStyles;
