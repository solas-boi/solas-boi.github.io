import { forwardRef, useEffect, useState } from "react";
import { View, type PressableStateCallbackType } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from "react-native-reanimated";
import { type CoreButton } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles, { useStateStyles } from "./ButtonBase.styles";
import { KeyboardPressableProps } from "../../types";

export type ButtonBaseProps = Omit<
  KeyboardPressableProps,
  "role" | "accessibilityRole" | "style" | "ref" | "children"
> & {
  variant: CoreButton.Variant;
  children: (state: PressableStateCallbackType) => JSX.Element;
  isLoading?: boolean;
  fullWidth?: boolean;
};

const ButtonBase = forwardRef<View, ButtonBaseProps>((props, ref) => {
  const { variant, children, isLoading, fullWidth, ...pressableProps } = props;
  const { disabled } = pressableProps;

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
    props.onFocusChange?.(isFocused);
  };

  const stateStyles = useStateStyles({
    variant,
    isLoading,
    fullWidth,
    disabled,
  });

  return (
    <View style={stateStyles.wrapper} needsOffscreenAlphaCompositing>
      <KeyboardPressable
        ref={ref}
        {...pressableProps}
        disabled={pressableProps.disabled || !!isLoading}
        enableA11yFocus
        onFocusChange={handleKeyboardFocusChange}
        tintType="none"
        role="button"
        accessibilityRole="button"
      >
        {(pressableState) => (
          <>
            {hasKeyboardFocus && (
              <View pointerEvents="none" style={stateStyles.focusRing} />
            )}
            <PressableChildren
              {...props}
              children={children}
              stateStyles={stateStyles}
              pressableState={pressableState}
            />
          </>
        )}
      </KeyboardPressable>
    </View>
  );
});
ButtonBase.displayName = "ButtonBase";

type PressableChildrenProps = ButtonBaseProps & {
  stateStyles: ReturnType<typeof useStateStyles>;
  pressableState: PressableStateCallbackType;
};

function PressableChildren(props: PressableChildrenProps) {
  const { variant, children, isLoading, stateStyles, pressableState } = props;
  const { pressed } = pressableState;

  const { tokens } = useDesignTokens();
  const { button } = tokens;

  const styles = useStyles();
  const translateY = useSharedValue(0);

  const animatedStyles = {
    topLayer: useAnimatedStyle(() => {
      return {
        transform: [
          {
            translateY: withSpring(translateY.value, {
              duration: button.topLayer.animationDuration,
            }),
          },
        ],
      };
    }),
  };

  useEffect(() => {
    translateY.value =
      pressed || isLoading ? button.topLayer.translateY[variant].active : 0;
  }, [translateY, pressed, isLoading, button, variant]);

  return (
    <View style={styles.container}>
      <View style={stateStyles.bottomLayer} />
      <Animated.View
        style={[stateStyles.topLayer(pressableState), animatedStyles.topLayer]}
        pointerEvents="none"
      >
        {children(pressableState)}
      </Animated.View>
    </View>
  );
}

export default ButtonBase;
