import { StyleSheet, type PressableStateCallbackType } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { type ButtonBaseProps } from "./ButtonBase";
import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { button } = tokens;

  const styles = StyleSheet.create({
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
    wrapperFullWidth: {
      width: "100%",
    },
    wrapperDisabled: {
      opacity: button.opacity.disabled,
    },
    container: {
      position: "relative",
      height: button.height,
      minWidth: button.minWidth,
    },
    topLayer: {
      maxWidth: "100%",
      paddingLeft: button.topLayer.padding.primary.left,
      paddingRight: button.topLayer.padding.primary.right,
      borderWidth: button.topLayer.stroke.width,
      borderStyle: button.topLayer.stroke.style,
      borderRadius: button.topLayer.stroke.radius,
      userSelect: "none",
    },
    topLayerVariantPrimary: {
      height: button.topLayer.height.primary,
      borderColor: button.topLayer.stroke.color.primary.base,
      backgroundColor: button.topLayer.backgroundColor.primary.base,
    },
    topLayerVariantSecondary: {
      height: button.topLayer.height.secondary,
      borderColor: button.topLayer.stroke.color.secondary.base,
      backgroundColor: button.topLayer.backgroundColor.secondary.base,
    },
    topLayerVariantPrimaryPressed: {
      borderColor: button.topLayer.stroke.color.primary.active,
      backgroundColor: button.topLayer.backgroundColor.primary.active,
    },
    topLayerVariantSecondaryPressed: {
      borderColor: button.topLayer.stroke.color.secondary.active,
      backgroundColor: button.topLayer.backgroundColor.secondary.active,
    },
    bottomLayer: {
      position: "absolute",
      bottom: 0,
      left: 0,
      width: "100%",
      height: button.bottomLayer.height,
      borderRadius: button.bottomLayer.radius,
    },
    bottomLayerVariantPrimary: {
      backgroundColor: button.bottomLayer.backgroundColor.primary.base,
    },
    bottomLayerVariantSecondary: {
      backgroundColor: button.bottomLayer.backgroundColor.secondary.base,
    },
    focusRing: {
      position: "absolute",
      borderRadius:
        button.topLayer.stroke.radius +
        button.focusRing.offset +
        button.topLayer.stroke.width,
      borderWidth: button.focusRing.width,
      borderStyle: button.focusRing.style,
      borderColor: button.focusRing.color.primary,
      left: -1 * (button.focusRing.offset + button.focusRing.width),
      top: -1 * (button.focusRing.offset + button.focusRing.width),
      right: -1 * (button.focusRing.offset + button.focusRing.width),
      bottom: -1 * (button.focusRing.offset + button.focusRing.width),
    },
    focusRingVariantPrimary: {
      borderColor: button.focusRing.color.primary,
    },
    focusRingVariantSecondary: {
      borderColor: button.focusRing.color.secondary,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant,
  isLoading,
  fullWidth,
  disabled,
}: Pick<ButtonBaseProps, "variant" | "isLoading" | "fullWidth" | "disabled">) {
  const styles = useStyles();

  const topLayerVariantStyles = {
    primary: styles.topLayerVariantPrimary,
    secondary: styles.topLayerVariantSecondary,
  };

  const topLayerVariantPressedStyles = {
    primary: styles.topLayerVariantPrimaryPressed,
    secondary: styles.topLayerVariantSecondaryPressed,
  };

  const bottomLayerVariantStyles = {
    primary: styles.bottomLayerVariantPrimary,
    secondary: styles.bottomLayerVariantSecondary,
  };

  const focusRingVariantStyles = {
    primary: styles.focusRingVariantPrimary,
    secondary: styles.focusRingVariantSecondary,
  };

  return {
    wrapper: [
      styles.wrapper,
      fullWidth && styles.wrapperFullWidth,
      disabled && styles.wrapperDisabled,
    ],
    topLayer: ({ pressed }: PressableStateCallbackType) => [
      styles.topLayer,
      topLayerVariantStyles[variant],
      (pressed || isLoading) && topLayerVariantPressedStyles[variant],
    ],
    bottomLayer: [styles.bottomLayer, bottomLayerVariantStyles[variant]],
    focusRing: [styles.focusRing, focusRingVariantStyles[variant]],
  };
}

export default useStyles;
