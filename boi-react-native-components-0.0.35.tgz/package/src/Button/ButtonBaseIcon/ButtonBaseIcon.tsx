import { cloneElement } from "react";
import {
  useWindowDimensions,
  type PressableStateCallbackType,
} from "react-native";
import {
  parseSizeToken,
  useDesignTokens,
} from "@boi/react-native-design-tokens";
import { type CoreButton } from "@boi/components-core";

export type ButtonBaseIconProps = {
  variant: CoreButton.Variant;
  icon: JSX.Element;
  pressableState: PressableStateCallbackType;
};

function ButtonBaseIcon(props: ButtonBaseIconProps) {
  const {
    variant,
    icon,
    pressableState: { pressed },
  }: ButtonBaseIconProps = props;

  const { tokens } = useDesignTokens();
  const { fontScale } = useWindowDimensions();

  const { button } = tokens;

  const state = pressed ? "active" : "base";

  return cloneElement(icon, {
    ...icon.props,
    width: parseSizeToken(button.topLayer.icon.width, fontScale),
    height: parseSizeToken(button.topLayer.icon.height, fontScale),
    color: button.topLayer.color[variant][state],
  });
}

export default ButtonBaseIcon;
