export { default, type ButtonBaseIconProps } from "./ButtonBaseIcon";
