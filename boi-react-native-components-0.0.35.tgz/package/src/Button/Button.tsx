import { forwardRef } from "react";
import { View } from "react-native";
import { CoreButton } from "@boi/components-core";

import useStyles, { useStateStyles } from "./Button.styles";
import ButtonBase, { type ButtonBaseProps } from "./ButtonBase";
import ButtonBaseText from "./ButtonBaseText";
import ButtonBaseIcon from "./ButtonBaseIcon";
import { Spinner } from "../Spinner";

export type ButtonProps = Omit<ButtonBaseProps, "variant" | "children"> & {
  text: string;
  variant?: CoreButton.Variant;
  startIcon?: JSX.Element;
};

const Button = forwardRef<View, ButtonProps>((props, ref) => {
  const {
    text,
    variant = CoreButton.DEFAULT_VARIANT,
    startIcon,
    isLoading,
    testID = "button",
    ...pressableProps
  }: ButtonProps = props;

  const styles = useStyles();
  const stateStyles = useStateStyles({ isLoading });

  return (
    <ButtonBase
      ref={ref}
      {...pressableProps}
      variant={variant}
      isLoading={isLoading}
      testID={testID}
    >
      {(pressableState) => (
        <>
          <View style={styles.container}>
            {startIcon && (
              <View style={stateStyles.iconWrapper}>
                <ButtonBaseIcon
                  icon={startIcon}
                  variant={variant}
                  pressableState={pressableState}
                />
              </View>
            )}

            <View style={stateStyles.textWrapper}>
              <ButtonBaseText
                text={text}
                variant={variant}
                pressableState={pressableState}
                testID={`${testID}-text`}
              />
            </View>
          </View>

          {isLoading && (
            <View style={styles.spinnerWrapper}>
              <Spinner
                variant={CoreButton.SPINNER_VARIANTS[variant]}
                testID={`${testID}-spinner`}
              />
            </View>
          )}
        </>
      )}
    </ButtonBase>
  );
});
Button.displayName = "Button";

export default Button;
