import { type PressableStateCallbackType } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { type CoreButton, type PropsWithTestID } from "@boi/components-core";

import { Typography } from "../../Typography";

export type ButtonBaseTextProps = PropsWithTestID & {
  variant: CoreButton.Variant;
  text: string;
  pressableState: PressableStateCallbackType;
};

function ButtonBaseText(props: ButtonBaseTextProps) {
  const {
    variant,
    text,
    pressableState: { pressed },
    testID,
  }: ButtonBaseTextProps = props;

  const { tokens } = useDesignTokens();
  const { button } = tokens;

  const state = pressed ? "active" : "base";

  return (
    <Typography
      variant={button.topLayer.text.typography.variant}
      fontFamily={button.topLayer.text.typography.fontFamily}
      color={button.topLayer.color[variant][state]}
      noWrap
      style={{ flexShrink: 1 }}
      testID={testID}
    >
      {text}
    </Typography>
  );
}

export default ButtonBaseText;
