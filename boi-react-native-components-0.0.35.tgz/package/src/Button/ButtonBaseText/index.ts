export { default, type ButtonBaseTextProps } from "./ButtonBaseText";
