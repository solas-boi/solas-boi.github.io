import { StyleSheet } from "react-native";

import { type ButtonProps } from "./Button";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory() {
  return StyleSheet.create({
    container: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
      height: "100%",
      overflow: "hidden",
    },
    iconWrapper: {
      flexShrink: 0,
    },
    iconWrapperLoading: {
      opacity: 0,
    },
    textWrapperLoading: {
      opacity: 0,
    },
    spinnerWrapper: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({ isLoading }: Pick<ButtonProps, "isLoading">) {
  const styles = useStyles();

  return {
    iconWrapper: [styles.iconWrapper, isLoading && styles.iconWrapperLoading],
    textWrapper: [isLoading && styles.textWrapperLoading],
  };
}

export default useStyles;
