import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { ArrowLeftIcon } from "@boi/react-native-icons";

import Button, { ButtonProps } from "./Button";

function WrappedButton(props: ButtonProps) {
  return (
    <DesignTokensProvider>
      <Button {...props} />
    </DesignTokensProvider>
  );
}

describe("Button", () => {
  let baseProps: ButtonProps;

  beforeEach(() => {
    baseProps = {
      text: "Button Text",
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedButton {...baseProps} />);

    expect(screen.getByRole("button")).toBeDefined();
  });

  it("should render the correct text", () => {
    const { text } = baseProps;

    render(<WrappedButton {...baseProps} />);

    expect(screen.getByRole("button")).toHaveTextContent(text);
  });

  it("should render the startIcon component when provided", () => {
    const iconTestID = "start-icon";

    render(
      <WrappedButton
        {...baseProps}
        startIcon={<ArrowLeftIcon testID={iconTestID} />}
      />
    );

    expect(screen.getByTestId(iconTestID)).toBeDefined();
  });

  it("should render a spinner component when isLoading is true", () => {
    render(<WrappedButton {...baseProps} isLoading />);

    expect(screen.getByTestId("button-spinner")).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedButton {...baseProps} />);

    expect(screen.getByTestId("button")).toBeDefined();
    expect(screen.getByTestId("button-text")).toBeDefined();
  });

  it("should render with an optional testID", () => {
    const testID = "custom-button";

    render(<WrappedButton {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
    expect(screen.getByTestId(`${testID}-text`)).toBeDefined();
  });

  it("should call onPress event handler when pressed", async () => {
    const testID = "custom-button";
    const mockFn = jest.fn();
    render(<WrappedButton {...baseProps} onPress={mockFn} testID={testID} />);

    const button = screen.getByRole("button");
    const user = userEvent.setup();
    await act(async () => {
      await user.press(button);
    });

    expect(mockFn).toHaveBeenCalled();
  });

  it("should NOT call onPress event handler when pressed if `isLoading` prop is true", async () => {
    const testID = "custom-button";
    const mockFn = jest.fn();
    render(
      <WrappedButton
        {...baseProps}
        onPress={mockFn}
        isLoading
        testID={testID}
      />
    );

    const button = screen.getByRole("button");
    const user = userEvent.setup();
    await act(async () => {
      await user.press(button);
    });

    expect(mockFn).not.toHaveBeenCalled();
  });

  it("should NOT call onPress event handler when pressed if `disabled` prop is true", async () => {
    const testID = "custom-button";
    const mockFn = jest.fn();
    render(
      <WrappedButton {...baseProps} onPress={mockFn} disabled testID={testID} />
    );

    const button = screen.getByRole("button");
    const user = userEvent.setup();
    await act(async () => {
      await user.press(button);
    });

    expect(mockFn).not.toHaveBeenCalled();
  });
});
