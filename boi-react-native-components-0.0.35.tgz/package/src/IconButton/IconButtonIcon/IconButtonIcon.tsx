import { cloneElement } from "react";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIconButton } from "@boi/components-core";

export type IconButtonIconProps = {
  variant: CoreIconButton.Variant;
  icon: JSX.Element;
  isPressed: boolean;
};

function IconButtonIcon(props: IconButtonIconProps) {
  const { variant, icon, isPressed }: IconButtonIconProps = props;

  const { tokens } = useDesignTokens();
  const { iconButton } = tokens;

  const state = isPressed ? "active" : "base";

  return cloneElement(icon, {
    ...icon.props,
    width: iconButton.inner.icon.height[variant],
    height: iconButton.inner.icon.height[variant],
    color: iconButton.inner.icon.color[state],
  });
}

export default IconButtonIcon;
