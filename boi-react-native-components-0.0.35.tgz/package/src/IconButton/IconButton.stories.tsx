import type { Meta, StoryObj } from "@storybook/react";
import { CoreIconButton } from "@boi/components-core";
import * as Icons from "@boi/react-native-icons";
import { getIconSelectArgType } from "@boi/react-utils";

import IconButton from "./IconButton";

type IconsType = {
  [key: string | number]: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
};

const meta = {
  title: "Inputs/IconButton",
  component: IconButton,
  argTypes: {
    variant: {
      control: { type: "select" },
      options: CoreIconButton.VARIANTS,
    },
    disabled: { control: { type: "boolean" } },
    children: getIconSelectArgType(Icons as IconsType) as {},
  },
  args: {
    children: <Icons.PlusIcon />,
    "aria-label": "Add button",
  },
} satisfies Meta<typeof IconButton>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Default: Story = {
  argTypes: {
    variant: { control: { disable: true } },
  },
};

export const Contained: Story = {
  argTypes: {
    variant: { control: { disable: true } },
  },
  args: {
    variant: "contained",
  },
};
