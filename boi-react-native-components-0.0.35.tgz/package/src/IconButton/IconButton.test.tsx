import { View } from "react-native";
import { render, screen, within } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import IconButton, { type IconButtonProps } from "./IconButton";

function WrappedIconButton(props: IconButtonProps) {
  return (
    <DesignTokensProvider>
      <IconButton {...props} />
    </DesignTokensProvider>
  );
}

describe("IconButton", () => {
  let baseProps: IconButtonProps;

  beforeEach(() => {
    baseProps = {
      children: <View testID="mock-icon" />,
      "aria-label": "Calendar button",
    };
  });

  it("should render with the correct role by default", () => {
    render(<WrappedIconButton {...baseProps} />);

    const button = screen.getByRole("button");

    expect(button).toBeDefined();
  });

  it.each(["button", "switch"] as const)(
    "should render with the %s role",
    (role) => {
      render(
        <WrappedIconButton
          {...baseProps}
          role={role}
          accessibilityRole={role}
        />
      );

      const button = screen.getByRole(role);

      expect(button).toBeDefined();
    }
  );

  it("should render with the correct icon", () => {
    render(<WrappedIconButton {...baseProps} />);

    const button = screen.getByRole("button");
    const icon = within(button).getByTestId("mock-icon");

    expect(icon).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedIconButton {...baseProps} />);

    expect(screen.getByTestId("icon-button")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-icon-button";

    render(<WrappedIconButton {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
