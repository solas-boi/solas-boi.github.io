import { render } from "@testing-library/react-native";
import { CoreCombobox } from "@boi/components-core";

import ComboboxModal from "./ComboboxModal";

const mockFocus = jest.fn();

jest.mock("../Modal", () => {
  const { useEffect } = require("react");
  const { View } = require("react-native");

  return {
    Modal: ({
      children,
      isOpen,
      onOpenAnimationComplete,
      testID,
    }: {
      children: React.ReactNode;
      isOpen: boolean;
      onOpenAnimationComplete?: () => void;
      testID?: string;
    }) => {
      useEffect(() => {
        if (isOpen) {
          onOpenAnimationComplete?.();
        }
      }, [isOpen, onOpenAnimationComplete]);

      return <View testID={testID}>{children}</View>;
    },
  };
});

jest.mock("../ComboboxModalBase", () => {
  const { useEffect } = require("react");
  const { View } = require("react-native");

  return {
    ComboboxModalBase: ({ inputRef }: { inputRef?: { current: unknown } }) => {
      useEffect(() => {
        if (inputRef) {
          inputRef.current = { focus: mockFocus };
        }
      }, [inputRef]);

      return <View testID="combobox-modal-base" />;
    },
  };
});

describe("ComboboxModal", () => {
  it("should focus the input when open animation completes", () => {
    const onOpenAnimationComplete = jest.fn();

    const items: CoreCombobox.ComboboxItem[] = [
      {
        id: "1",
        title: "Option 1",
        value: "option-1",
      },
    ];

    render(
      <ComboboxModal
        testID="combobox-modal"
        isOpen
        title="Choose an option"
        items={items}
        onChange={jest.fn()}
        onRequestClose={jest.fn()}
        onOpenAnimationComplete={onOpenAnimationComplete}
      />
    );

    expect(mockFocus).toHaveBeenCalledTimes(1);
    expect(onOpenAnimationComplete).toHaveBeenCalledTimes(1);
  });
});
