import { useRef } from "react";
import { TextInput as RNTextInput } from "react-native";
import { CoreCombobox } from "@boi/components-core";
import { Modal, type ModalProps } from "../Modal";
import {
  ComboboxModalBase,
  type ComboboxModalBaseProps,
} from "../ComboboxModalBase";

export type ComboboxModalProps<T extends CoreCombobox.ComboboxItem> = Omit<
  ModalProps,
  "children"
> &
  ComboboxModalBaseProps<T>;

function ComboboxModal<T extends CoreCombobox.ComboboxItem>(
  props: ComboboxModalProps<T>
) {
  const {
    title,
    selectedItem,
    items,
    disabledKeys,
    defaultInputValue,
    onInputChange,
    onChange,
    testID = "combobox-modal",
    ...modalProps
  } = props;
  const inputRef = useRef<RNTextInput>(null);

  const handleOpenAnimationComplete = () => {
    inputRef.current?.focus();
    modalProps.onOpenAnimationComplete?.();
  };

  return (
    <Modal
      {...modalProps}
      testID={testID}
      onOpenAnimationComplete={handleOpenAnimationComplete}
    >
      <ComboboxModalBase
        testID={testID}
        title={title}
        onRequestClose={modalProps.onRequestClose}
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        defaultInputValue={defaultInputValue}
        onInputChange={onInputChange}
        onChange={onChange}
        inputRef={inputRef}
      />
    </Modal>
  );
}

export default ComboboxModal;
