import { AccessibilityRole, Role } from "react-native";

/**
 * Some values for the `accessibilityRole` and `role` props don't have any
 * effect on React Native. For this purpose we created this hook to work around this
 * limitation.
 * TODO: Once the ticket below is resolved on RN repository, we can remove this hook
 * @see https://github.com/facebook/react-native/issues/50123
 */
export default function useA11yRoleWorkaround(
  role: AccessibilityRole | Role,
  accessibilityLabel?: string
) {
  if (accessibilityLabel) {
    return `${accessibilityLabel}, ${role}`;
  } else {
    return role;
  }
}
