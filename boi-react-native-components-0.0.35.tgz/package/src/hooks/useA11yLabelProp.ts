import { type TextInputProps } from "react-native";

import { type LabelProps } from "./useA11yHintPropWithAlerts";

export type A11yLabelProp = Pick<
  TextInputProps,
  "accessibilityLabel" | "aria-label"
>;

type HookParams = A11yLabelProp & {
  labelProps?: LabelProps;
};

export const useA11yLabelProp = (props: HookParams): A11yLabelProp => {
  const { accessibilityLabel, labelProps } = props;
  return {
    accessibilityLabel: (
      accessibilityLabel ??
      props["aria-label"] ??
      labelProps?.accessibilityLabel ??
      labelProps?.["aria-label"] ??
      labelProps?.label ??
      ""
    ).trim(),
  };
};

export default useA11yLabelProp;
