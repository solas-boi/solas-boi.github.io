import { type TextInputProps } from "react-native";

import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";

export type AlertProps =
  | InputAlertsProps["alerts"][number]
  | InputAlertsProps["alerts"]
  | undefined;

export type LabelProps = Omit<InputLabelTopProps, "children">;

export type A11yHintProp = Pick<TextInputProps, "accessibilityHint">;

type HookParams = A11yHintProp & {
  labelProps?: LabelProps;
};

export const useA11yHintPropWithAlerts = ({
  accessibilityHint,
  labelProps,
}: HookParams): A11yHintProp => {
  const hints = [accessibilityHint, labelProps?.labelHint]
    .filter(Boolean)
    .map((hint) => `${hint}`?.trim());

  const resultHing = hints.length > 0 ? hints.join(" ") : undefined;

  return {
    accessibilityHint: resultHing,
  };
};

export default useA11yHintPropWithAlerts;
