import { renderHook } from "@testing-library/react-native";
import useA11yRoleWorkaround from "./useA11yRoleWorkaround";
describe("useA11yRoleWorkaround", () => {
  it("return a string with the label followed by the role separated by a comma if label is provided", async () => {
    const role = "combobox";
    const label = "some label";
    const { result } = renderHook(() => useA11yRoleWorkaround(role, label));
    expect(result.current).toBe(`${label}, ${role}`);
  });

  it("return a string containing only the role if only the role is provided", async () => {
    const role = "combobox";
    const { result } = renderHook(() => useA11yRoleWorkaround(role));
    expect(result.current).toBe(role);
  });
});
