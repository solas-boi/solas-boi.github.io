import { renderHook } from "@testing-library/react-native";
import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";
import { useA11yHintPropWithAlerts } from "./useA11yHintPropWithAlerts";

type AlertProps =
  | InputAlertsProps["alerts"][number]
  | InputAlertsProps["alerts"]
  | undefined;

type LabelProps = Omit<InputLabelTopProps, "children">;

const testCase = (
  name: string,
  accessibilityHint: string | undefined,
  alertProps: AlertProps | undefined,
  labelPropHint: string | undefined,
  expectedAccessibilityHint: { expected: string | undefined } | undefined
): (
  | string
  | undefined
  | AlertProps
  | LabelProps
  | { expected: string | undefined }
)[] => [
  name,
  accessibilityHint,
  alertProps,
  labelPropHint,
  expectedAccessibilityHint,
];

const testCases = [
  testCase(
    "the supplied accessibility hint when an accessibility hint and no alert or label props are supplied",
    "accessibility hint",
    undefined,
    undefined,
    { expected: "accessibility hint" }
  ),

  testCase(
    "the accessibility hint concatenated with the label hint when an accessibility hint and a label hint and no alert are supplied with leading and trailing spaces",
    " accessibility hint ",
    undefined,
    " label prop hint ",
    { expected: "accessibility hint label prop hint" }
  ),
];

const processTestCases = (
  _: any,
  accessibilityHint: any,
  _alertProps: any,
  labelPropHint: any,
  expectedAccessibilityHint: any
) => {
  const { result } = renderHook(() =>
    useA11yHintPropWithAlerts({
      accessibilityHint: accessibilityHint as string | undefined,
      labelProps: { labelHint: labelPropHint } as LabelProps,
    })
  );

  expect(result.current).toEqual(
    expect.objectContaining({
      accessibilityHint: expectedAccessibilityHint.expected as string,
    })
  );
};

describe("useAccessibilityHintPropWithAlerts", () => {
  describe("returns object with property 'accessibilityHint' that is ", () => {
    test.each(testCases)("%p", processTestCases);
  });
});
