import { renderHook } from "@testing-library/react-native";
import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";
import { useA11yLabelProp } from "./useA11yLabelProp";

type AlertProps =
  | InputAlertsProps["alerts"][number]
  | InputAlertsProps["alerts"]
  | undefined;

type LabelProps = Omit<InputLabelTopProps, "children">;

const testCase = (
  name: string,
  accessibilityLabel: string | undefined,
  labelPropLabel: string | undefined,
  expectedAccessibilityLabel: { expected: string } | undefined
): (string | undefined | AlertProps | LabelProps | { expected: string })[] => [
  name,
  accessibilityLabel,
  labelPropLabel,
  expectedAccessibilityLabel,
];

const testCases = [
  testCase(
    "the empty string when no accessibility label or label are supplied",
    undefined,
    undefined,
    { expected: "" }
  ),
  testCase(
    "the supplied accessibility label when only the accessibility label is supplied",
    "accessibility label",
    undefined,
    { expected: "accessibility label" }
  ),
  testCase(
    "the supplied label when only the label is supplied",
    undefined,
    "label prop label",
    { expected: "label prop label" }
  ),
  testCase(
    "the supplied accessibility label, with leading and trainling white space removed",
    "  accessibility label  ",
    "  label prop label  ",
    { expected: "accessibility label" }
  ),
];

const processTestCases = (
  _: any,
  accessibilityLabel: any,
  labelPropLabel: any,
  expectedAccessibilityLabel: any
) => {
  const { result } = renderHook(() =>
    useA11yLabelProp({
      accessibilityLabel: accessibilityLabel as string | undefined,
      labelProps: { label: labelPropLabel } as LabelProps,
    })
  );

  expect(result.current).toEqual(
    expect.objectContaining({
      accessibilityLabel: expectedAccessibilityLabel.expected as string,
    })
  );
};

describe("useAccessibilityLabelProp", () => {
  describe("returns object with property 'accessibilityLabel' that is ", () => {
    test.each(testCases)("%p", processTestCases);
  });
});
