import {
  type A11yHintProp,
  type AlertProps,
  type LabelProps,
  useA11yHintPropWithAlerts,
} from "./useA11yHintPropWithAlerts";
import { type A11yLabelProp, useA11yLabelProp } from "./useA11yLabelProp";

type HookParams = A11yHintProp &
  A11yLabelProp & {
    alertProps?: AlertProps;
    labelProps?: LabelProps;
  };

type Result = A11yLabelProp & A11yHintProp;

export const useSimpleA11yProps = (props: HookParams): Result => {
  const accessibilityLabelProps = useA11yLabelProp(props);
  const accessibilityHintProps = useA11yHintPropWithAlerts(props);

  return { ...accessibilityHintProps, ...accessibilityLabelProps };
};

export default useSimpleA11yProps;
