import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

export const COMBOBOX_ITEM_HEIGHT = 48;

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { select } = tokens;

  return StyleSheet.create({
    container: {
      minHeight: select.menu.option.minHeight,
      padding: select.menu.option.padding,
      backgroundColor: select.menu.option.backgroundColor.base,
      borderWidth: select.menu.stroke.width,
      borderColor: select.menu.stroke.color,
      borderRadius: select.menu.radius,
    },
    containerNotFirst: {
      borderTopWidth: 0,
      borderTopLeftRadius: 0,
      borderTopRightRadius: 0,
    },
    containerNotLast: {
      borderBottomLeftRadius: 0,
      borderBottomRightRadius: 0,
    },
    containerLastPromoted: {
      borderBottomWidth: 3,
    },
    contentWrapper: {
      display: "flex",
      justifyContent: "center",
      flex: 1,
      paddingTop: select.menu.option.inner.padding.top,
      paddingLeft: select.menu.option.inner.padding.left,
      paddingRight: select.menu.option.inner.padding.right,
      paddingBottom: select.menu.option.inner.padding.bottom,
      borderRadius: select.menu.option.inner.radius,
      borderWidth: select.menu.option.inner.stroke.width,
      borderColor: select.menu.option.inner.stroke.color.base,
    },
    contentWrapperPressed: {
      backgroundColor: select.menu.option.inner.backgroundColor.active,
      borderColor: select.menu.option.inner.stroke.color.active,
    },
    content: {
      display: "flex",
      flexDirection: "row",
      gap: select.menu.option.inner.gap,
    },
    text: {
      color: select.menu.option.inner.color.base,
    },
    textDisabled: {
      color: select.menu.option.inner.color.disabled,
    },
    tickIconWrapper: {
      display: "flex",
      justifyContent: "center",
      width: select.menu.option.inner.tickIconWrapper.width,
      height: parseSizeToken(
        select.menu.option.inner.tickIconWrapper.height,
        fontScale
      ),
    },
    iconWrapper: {
      display: "flex",
      justifyContent: "center",
      marginRight: 4,
      height: parseSizeToken(
        select.menu.option.inner.iconWrapper.height,
        fontScale
      ),
    },
    icon: {
      width: select.menu.option.inner.icon.width,
      maxHeight: select.menu.option.inner.icon.maxHeight,
      color: select.menu.option.inner.icon.color,
      opacity: select.menu.option.inner.icon.opacity.base,
    },
    iconDisabled: {
      opacity: select.menu.option.inner.icon.opacity.disabled,
    },
    typographyWrapper: {
      flexShrink: 1,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  isFirst: boolean,
  isLast: boolean,
  isLastPromoted: boolean,
  isDisabled: boolean
) {
  const styles = useStyles();

  return {
    container: [
      styles.container,
      !isFirst ? styles.containerNotFirst : undefined,
      !isLast ? styles.containerNotLast : undefined,
      isLastPromoted ? styles.containerLastPromoted : undefined,
    ],
    contentWrapper: (isPressed: boolean) => [
      styles.contentWrapper,
      isPressed ? styles.contentWrapperPressed : undefined,
    ],
    text: [styles.text, isDisabled && styles.textDisabled],
    icon: [styles.icon, isDisabled && styles.iconDisabled],
  };
}

export default useStyles;
