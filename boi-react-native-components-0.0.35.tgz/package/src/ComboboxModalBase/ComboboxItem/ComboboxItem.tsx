import { memo, cloneElement, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { CoreCombobox } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { TickIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./ComboboxItem.styles";
import { Typography } from "../../Typography";

export type ComboboxItemProps = {
  item: CoreCombobox.ComboboxItem;
  isFirst: boolean;
  isLast: boolean;
  isLastPromoted: boolean;
  isSelected: boolean;
  isDisabled: boolean;
  onPress: () => void;
};

const ComboboxItem = memo((props: ComboboxItemProps) => {
  const {
    item,
    onPress,
    isSelected,
    isDisabled,
    isFirst,
    isLast,
    isLastPromoted,
  } = props;

  const { tokens } = useDesignTokens();
  const { select } = tokens;

  const styles = useStyles();
  const stateStyles = useStateStyles(
    isFirst,
    isLast,
    isLastPromoted,
    isDisabled
  );

  const [pressed, setPressed] = useState(false);
  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <KeyboardPressable
      style={stateStyles.container}
      enableA11yFocus
      accessibilityRole="radio"
      role="radio"
      accessibilityLabel={item.title}
      accessibilityHint={!isSelected ? "Selects the item" : undefined}
      accessibilityState={{ selected: isSelected }}
      disabled={isDisabled}
      onFocusChange={handleKeyboardFocusChange}
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      <View style={stateStyles.contentWrapper(pressed || hasKeyboardFocus)}>
        <View style={styles.content}>
          <View style={styles.tickIconWrapper}>
            {isSelected && (
              <TickIcon
                color={select.menu.option.inner.tickIcon.color}
                width={select.menu.option.inner.tickIcon.width}
                height={select.menu.option.inner.tickIcon.height}
              />
            )}
          </View>

          {item.icon && (
            <View style={styles.iconWrapper}>
              {cloneElement(item.icon, {
                ...item.icon.props,
                style: stateStyles.icon,
              })}
            </View>
          )}

          <View style={styles.typographyWrapper}>
            <Typography style={stateStyles.text}>{item.title}</Typography>
          </View>
        </View>
      </View>
    </KeyboardPressable>
  );
});

export default ComboboxItem;
