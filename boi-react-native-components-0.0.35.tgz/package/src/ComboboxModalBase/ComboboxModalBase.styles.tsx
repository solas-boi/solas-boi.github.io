import { StyleSheet } from "react-native";
import { isTablet } from "react-native-device-info";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { modal, standardModal } = tokens;

  const screenType = isTablet() ? "tablet" : "mobile";

  const styles = StyleSheet.create({
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: standardModal.header.gap,
      backgroundColor: modal.backgroundColor,
      paddingTop: standardModal.header.padding[screenType].top,
      paddingLeft: standardModal.header.padding[screenType].left,
      paddingRight: standardModal.header.padding[screenType].right,
      paddingBottom: standardModal.header.padding[screenType].bottom,
      borderBottomWidth: standardModal.header.stroke.bottom.width,
      borderStyle: standardModal.header.stroke.bottom.style,
      borderBottomColor: "transparent",
    },
    headerBorderVisible: {
      borderBottomColor: standardModal.header.stroke.bottom.color,
      borderBottomWidth: 1,
    },
    miniHeadingWrapper: {
      flex: 1,
    },
    labelWrapper: {
      flexShrink: 1,
    },
    miniHeadingLabelWrapper: {
      flexDirection: "row",
      justifyContent: "space-between",
    },
    miniHeadingInputWrapper: {
      paddingRight:
        standardModal.content.padding[screenType].right -
        standardModal.header.padding[screenType].right,
    },
    closeButtonWrapper: {
      flexShrink: 0,
      margin: -6,
      marginTop: -10,
      marginBottom: -11,
    },
    clearFilterButton: {
      marginRight: -8,
    },
    contentContainer: {
      paddingTop: standardModal.content.padding[screenType].top,
      paddingLeft: standardModal.content.padding[screenType].left,
      paddingRight: standardModal.content.padding[screenType].right,
      paddingBottom: standardModal.content.padding[screenType].bottom,
    },
    title: {
      paddingBottom: standardModal.content.gap,
    },
    scrollShadowContainer: {
      height: "100%",
    },
    footer: {
      height: standardModal.footer.height[screenType],
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(topShadowVisible: boolean) {
  const styles = useStyles();

  return {
    header: [styles.header, topShadowVisible && styles.headerBorderVisible],
  };
}

export default useStyles;
