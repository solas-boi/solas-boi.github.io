import { memo } from "react";
import { View } from "react-native";
import { SearchingDocIllustration } from "@boi/react-native-illustrations";

import { Typography } from "../../Typography";

import useStyles from "./ComboboxEmpty.styles";
import { PropsWithOptionalTestID } from "@boi/components-core";

const ComboboxEmpty = memo(({ testID }: PropsWithOptionalTestID) => {
  const styles = useStyles();

  return (
    <View testID={testID} style={styles.container}>
      <SearchingDocIllustration colorPalette="hueA" />
      <Typography variant="bodyL" fontFamily="OpenSansSemiBold">
        No results found
      </Typography>
    </View>
  );
});

export default ComboboxEmpty;
