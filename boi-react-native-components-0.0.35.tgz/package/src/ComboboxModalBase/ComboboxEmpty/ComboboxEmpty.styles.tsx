import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const {
    spacing: { s64, s16 },
  } = tokens;

  return StyleSheet.create({
    container: {
      alignItems: "center",
      marginTop: s64,
      gap: s16,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
