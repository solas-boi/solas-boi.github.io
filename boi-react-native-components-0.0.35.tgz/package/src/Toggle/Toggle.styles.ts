import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../themedStylesheet/index";

function styleSheetFactory() {
  return StyleSheet.create({
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
