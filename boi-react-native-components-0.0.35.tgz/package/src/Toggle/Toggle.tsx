import { forwardRef, useState } from "react";
import { View, ViewProps } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

import { PropsWithOptionalTestID } from "@boi/components-core";

import useStyles from "./Toggle.styles";
import { KeyboardPressableProps } from "../types";
import ToggleBase, { ToggleBaseProps } from "../ToggleBase/ToggleBase";

export type ToggleProps = Omit<ToggleBaseProps, keyof ViewProps> &
  PropsWithOptionalTestID &
  Pick<KeyboardPressableProps, "accessibilityLabel" | "accessibilityHint"> & {
    onChange: (checked: boolean) => void;
  };

const Toggle = forwardRef<View, ToggleProps>((props, ref) => {
  const {
    toggleSize = "default",
    onChange,
    disabled = false,
    accessibilityLabel,
    accessibilityHint,
    testID = "toggle",
    checked,
  } = props;

  const stateStyles = useStyles();

  const handlePress = () => onChange(!checked);

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  return (
    <KeyboardPressable
      ref={ref}
      onFocusChange={handleKeyboardFocusChange}
      haloEffect={false}
      onPress={handlePress}
      tintType="none"
      testID={`${testID}-button`}
      enableA11yFocus
      accessibilityRole="switch"
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
      accessibilityState={{
        checked: Boolean(checked),
        disabled: Boolean(disabled),
      }}
      containerStyle={stateStyles.wrapper}
      disabled={disabled}
    >
      <ToggleBase
        testID={testID}
        disabled={disabled}
        toggleSize={toggleSize}
        checked={checked}
        hasFocus={hasKeyboardFocus}
      />
    </KeyboardPressable>
  );
});

Toggle.displayName = "Toggle";

export default Toggle;
