# Toggle component

The `Toggle` component uses the [React Native Gesture Handler](https://docs.swmansion.com/react-native-gesture-handler) library.

This requires an [extended installation](https://docs.swmansion.com/react-native-gesture-handler/docs/fundamentals/installation) at the application level.
