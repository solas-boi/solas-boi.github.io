import {
  render,
  screen,
  userEvent,
  act,
  waitFor,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Toggle, { type ToggleProps } from "./Toggle";

jest.useFakeTimers();

function WrappedToggle(props: ToggleProps) {
  return (
    <DesignTokensProvider>
      <Toggle {...props} />
    </DesignTokensProvider>
  );
}

describe("Toggle", () => {
  let baseProps: ToggleProps;

  beforeEach(() => {
    baseProps = {
      checked: false,
      onChange: jest.fn(),
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedToggle {...baseProps} />);

    expect(screen.getByRole("switch")).toBeDefined();
  });

  it("should render with an optional accessibility label and accessibility hint", () => {
    const accessibilityLabel = "Toggle Label";
    const accessibilityHint = "Toggle Hint";

    render(
      <WrappedToggle
        {...baseProps}
        accessibilityLabel={accessibilityLabel}
        accessibilityHint={accessibilityHint}
      />
    );

    expect(screen.getByLabelText(accessibilityLabel)).toBeDefined();
    expect(screen.getByA11yHint(accessibilityHint)).toBeDefined();
  });

  it("should render in the unchecked state by default", () => {
    render(<WrappedToggle {...baseProps} />);

    expect(
      screen.getByTestId("toggle-button").props.accessibilityState.checked
    ).toBeFalsy();
  });

  it("should render in the checked state when checked is true", () => {
    render(<WrappedToggle {...baseProps} checked />);

    expect(
      screen.getByTestId("toggle-button").props.accessibilityState.checked
    ).toBeTruthy();
  });

  it("should render in the enabled state by default", () => {
    render(<WrappedToggle {...baseProps} />);

    expect(screen.getByRole("switch")).not.toBeDisabled();
  });

  it("should render with small toggleSize", () => {
    render(<WrappedToggle {...baseProps} toggleSize="small" />);

    expect(screen.getByRole("switch")).toBeDefined();
  });

  it("should render with small toggleSize and disabled state", () => {
    render(<WrappedToggle {...baseProps} toggleSize="small" disabled />);

    expect(screen.getByRole("switch")).toBeDisabled();
  });

  it("should render with small toggleSize and checked state", () => {
    render(<WrappedToggle {...baseProps} toggleSize="small" checked />);

    expect(screen.getByTestId("toggle-button")).toBeDefined();
  });

  it("should have accessibility state disabled and not fire on change event when disabled and then pressed", async () => {
    const user = userEvent.setup();

    render(<WrappedToggle {...baseProps} disabled />);

    const toggleButton = screen.getByRole("switch");

    await act(async () => {
      await user.press(toggleButton);
    });

    expect(toggleButton).toBeDisabled();

    await waitFor(() => expect(baseProps.onChange).not.toHaveBeenCalled());
  });

  it("should fire a change event with a false parameter when pressed when not disabled and checked", async () => {
    const user = userEvent.setup();

    render(<WrappedToggle {...baseProps} disabled={false} checked={true} />);

    const toggleButton = screen.getByRole("switch");

    await act(async () => {
      await user.press(toggleButton);
    });

    await waitFor(() => expect(baseProps.onChange).toHaveBeenCalledWith(false));
  });

  it("should fire a change event with a true parameter when pressed when not disabled and unchecked", async () => {
    const user = userEvent.setup();

    render(<WrappedToggle {...baseProps} disabled={false} checked={false} />);

    const toggleButton = screen.getByRole("switch");

    await act(async () => {
      await user.press(toggleButton);
    });

    await waitFor(() => expect(baseProps.onChange).toHaveBeenCalledWith(true));
  });

  it("should render with a default testID", () => {
    render(<WrappedToggle {...baseProps} />);

    expect(screen.getByTestId("toggle")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-toggle";

    render(<WrappedToggle {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
