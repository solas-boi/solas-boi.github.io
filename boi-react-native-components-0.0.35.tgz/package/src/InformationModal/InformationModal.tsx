import { AlertModal, type AlertModalProps } from "../AlertModal";
import { type ModalProps } from "../Modal";

export type InformationModalProps = Omit<AlertModalProps, "severity"> & {
  onRequestClose: Exclude<ModalProps["onRequestClose"], undefined>;
};

function InformationModal(props: InformationModalProps) {
  const { testID = "information-modal", ...rest } = props;
  return <AlertModal testID={testID} {...rest} severity="info" />;
}
InformationModal.Typography = AlertModal.Typography;

export default InformationModal;
