export {
  default as InformationModal,
  type InformationModalProps,
} from "./InformationModal";
