import { View } from "react-native";
import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import InformationModal, {
  type InformationModalProps,
} from "./InformationModal";

function WrappedInformationModal(props: InformationModalProps) {
  return (
    <DesignTokensProvider>
      <InformationModal {...props} />
    </DesignTokensProvider>
  );
}

describe("InformationModal", () => {
  let baseProps: InformationModalProps;

  beforeEach(() => {
    baseProps = {
      heading: "Modal haeading",
      children: <View testID="mock-children" />,
      onRequestClose: () => {},
      isOpen: true,
    };
  });

  it("should render with a default testID", () => {
    render(<WrappedInformationModal {...baseProps} />);
    const modal = screen.getByTestId("information-modal");
    expect(modal).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-information-modal";

    render(<WrappedInformationModal {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
