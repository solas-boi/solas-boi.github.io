import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { checkboxGroup } = tokens;

  return StyleSheet.create({
    container: {
      display: "flex",
      gap: checkboxGroup.gap,
    },
    list: {
      display: "flex",
      gap: checkboxGroup.list.gap,
    },
    listItem: {
      display: "flex",
      gap: checkboxGroup.list.gap,
    },
    nestedList: {
      display: "flex",
      gap: checkboxGroup.list.gap,
      paddingLeft: checkboxGroup.nestedList.paddingLeft,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
