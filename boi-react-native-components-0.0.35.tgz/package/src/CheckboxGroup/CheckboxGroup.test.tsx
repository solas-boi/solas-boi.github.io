import { produce } from "immer";
import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import CheckboxGroup, { type CheckboxGroupProps } from "./CheckboxGroup";

jest.useFakeTimers();

function WrappedCheckboxGroup(props: CheckboxGroupProps) {
  return (
    <DesignTokensProvider>
      <CheckboxGroup {...props} />
    </DesignTokensProvider>
  );
}

describe("CheckboxGroup", () => {
  let baseProps: CheckboxGroupProps;

  beforeEach(() => {
    baseProps = {
      legend: "Group legend",
      inputs: [
        {
          id: "1",
          testID: "1",
          isChecked: false,
          labelProps: { label: "Burger" },
          children: [
            {
              id: "1-1",
              testID: "1-1",
              isChecked: false,
              labelProps: { label: "Bacon" },
            },
            {
              id: "1-2",
              testID: "1-2",
              isChecked: false,
              labelProps: { label: "Cheese" },
            },
            {
              id: "1-3",
              testID: "1-3",
              isChecked: false,
              labelProps: { label: "Onions" },
            },
            {
              id: "1-4",
              testID: "1-4",
              isChecked: false,
              labelProps: { label: "Lettuce" },
            },
            {
              id: "1-5",
              testID: "1-5",
              isChecked: false,
              labelProps: { label: "Tomato" },
            },
          ],
        },
      ],
      onChange: jest.fn(),
    };
  });

  it("should render with a legend element", () => {
    render(<WrappedCheckboxGroup {...baseProps} />);

    const legend = screen.getByText("Group legend");

    expect(legend).toBeDefined();
  });

  it("should render the correct number of inputs", () => {
    render(<WrappedCheckboxGroup {...baseProps} />);

    const checkboxes = screen.getAllByRole("checkbox");

    expect(checkboxes).toHaveLength(6);
  });

  it("should trigger the onChange event when a parent checkbox is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedCheckboxGroup {...baseProps} onChange={mockOnChange} />);

    const parentCheckbox = screen.getByTestId("1");

    await act(async () => {
      await user.press(parentCheckbox);
    });

    const updatedInputs = produce(baseProps.inputs, (draft) => {
      draft[0]!.isChecked = true;
      draft[0]!.isIndeterminate = false;
      draft[0]!.children!.forEach((input) => {
        input.isChecked = true;
        input.isIndeterminate = false;
      });
    });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith(updatedInputs);
  });

  it("should trigger the onChange event when a child checkbox is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedCheckboxGroup {...baseProps} onChange={mockOnChange} />);

    const childCheckbox = screen.getByTestId("1-1");

    expect(childCheckbox).not.toBeChecked();

    await act(async () => {
      await user.press(childCheckbox);
    });

    const updatedInputs = produce(baseProps.inputs, (draft) => {
      draft[0]!.isIndeterminate = true;
      draft[0]!.children![0]!.isChecked = true;
      draft[0]!.children![0]!.isIndeterminate = false;
    });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith(updatedInputs);
  });

  it("should render an alert when alertProps are provided", async () => {
    render(
      <WrappedCheckboxGroup
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("checkbox-group-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render with a default testID", () => {
    render(<WrappedCheckboxGroup {...baseProps} />);

    expect(screen.getByTestId("checkbox-group")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-checkbox-group";

    render(<WrappedCheckboxGroup {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
