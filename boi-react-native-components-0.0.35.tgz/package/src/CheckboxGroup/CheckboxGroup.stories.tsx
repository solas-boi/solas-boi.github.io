import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";

import CheckboxGroup, { type CheckboxGroupProps } from "./CheckboxGroup";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta = {
  title: "Inputs/CheckboxGroup",
  component: CheckboxGroup,
  render: function Render(args: any) {
    const [, updateArgs] = useArgs();

    function handlePress(inputs: CheckboxGroupProps["inputs"]) {
      updateArgs({ inputs });
      action("onChange")(inputs);
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => <CheckboxGroup {...args} ref={ref} onChange={handlePress} />}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    legend: { control: "text" },
    legendHint: { control: "text" },
    accessibilityLabel: { control: "text" },
    accessibilityHint: { control: "text" },
  },
  args: {
    legend: "Group legend",
    inputs: [
      {
        id: "1",
        isChecked: false,
        labelProps: { label: "Bacon" },
      },
      {
        id: "2",
        isChecked: false,
        labelProps: { label: "Cheese" },
      },
      {
        id: "3",
        isChecked: false,
        labelProps: { label: "Onions" },
      },
      {
        id: "4",
        isChecked: false,
        labelProps: { label: "Lettuce" },
      },
      {
        id: "5",
        isChecked: false,
        labelProps: { label: "Tomato" },
      },
      {
        id: "6",
        isChecked: false,
        labelProps: {
          label:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        },
      },
    ],
  },
} satisfies Meta<typeof CheckboxGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const WithLegend: Story = {
  ...Basic,
  args: {
    legend: "CheckboxGroup legend",
    legendTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithoutLegend: Story = {
  ...Basic,
  args: {
    legend: undefined,
    legendTooltipProps: undefined,
    accessibilityLabel: "CheckboxGroup without legend",
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    legend: "CheckboxGroup legend",
    legendHint: "Additional information",
    legendHintTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    inputs: [
      {
        id: "1",
        isChecked: false,
        labelProps: { label: "Bacon" },
        hasError: true,
      },
      {
        id: "2",
        isChecked: false,
        labelProps: { label: "Cheese" },
        hasError: true,
      },
      {
        id: "3",
        isChecked: false,
        labelProps: { label: "Onions" },
        hasError: true,
      },
      {
        id: "4",
        isChecked: false,
        labelProps: { label: "Lettuce" },
        hasError: true,
      },
      {
        id: "5",
        isChecked: false,
        labelProps: { label: "Tomato" },
        hasError: true,
      },
    ],
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const Nested: Story = {
  args: {
    inputs: [
      {
        id: "1",
        isChecked: false,
        labelProps: { label: "Burger" },
        children: [
          {
            id: "1-1",
            isChecked: false,
            labelProps: { label: "Bacon" },
          },
          {
            id: "1-2",
            isChecked: false,
            labelProps: { label: "Cheese" },
          },
          {
            id: "1-3",
            isChecked: false,
            labelProps: { label: "Onions" },
          },
          {
            id: "1-4",
            isChecked: false,
            labelProps: { label: "Lettuce" },
          },
          {
            id: "1-5",
            isChecked: false,
            labelProps: { label: "Tomato" },
          },
        ],
      },
    ],
  },
};
