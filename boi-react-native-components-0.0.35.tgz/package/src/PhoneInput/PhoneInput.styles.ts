import { StyleSheet } from "react-native";

import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { spacing } = tokens;

  return StyleSheet.create({
    group: {
      display: "flex",
      flexDirection: "row",
      gap: spacing.s8,
    },
    inputAlertsContainer: {
      display: "flex",
      gap: spacing.s4,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
