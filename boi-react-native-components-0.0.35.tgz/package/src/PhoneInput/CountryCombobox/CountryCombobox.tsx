import { useState } from "react";
import { CoreCombobox } from "@boi/components-core";

import CountryComboboxBase, {
  type CountryComboboxBaseProps,
} from "./CountryComboboxBase";

export type CountryComboboxProps<
  T extends CoreCombobox.ComboboxItem = CoreCombobox.ComboboxItem
> = Omit<CountryComboboxBaseProps<T>, "isOpen" | "onFocus" | "onBlur">;

function CountryCombobox<
  T extends CoreCombobox.ComboboxItem = CoreCombobox.ComboboxItem
>(props: CountryComboboxProps<T>) {
  const { testID = "country-combobox", ...comboboxBaseProps } = props;

  const [isOpen, setOpen] = useState(false);

  return (
    <CountryComboboxBase
      {...comboboxBaseProps}
      isOpen={isOpen}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      testID={testID}
    />
  );
}

export default CountryCombobox;
