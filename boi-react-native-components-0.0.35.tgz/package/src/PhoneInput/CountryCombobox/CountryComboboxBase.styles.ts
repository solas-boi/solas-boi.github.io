import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { select } = tokens;

  return StyleSheet.create({
    button: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      minHeight: select.button.minHeight,
      paddingTop: select.button.padding.top,
      paddingLeft: select.button.padding.left,
      paddingRight: select.button.padding.right,
      paddingBottom: select.button.padding.bottom,
    },
    buttonIcon: {
      width: 32,
      height: 22,
    },
    buttonIconDisabled: {
      opacity: select.menu.option.inner.icon.opacity.disabled,
    },
    listContainer: {
      flex: 1,
    },
    list: {
      borderTopWidth: select.menu.stroke.width,
      borderTopColor: select.menu.stroke.color,
      height: "100%",
    },
    dialogTitle: {
      paddingLeft: 32,
      paddingRight: 32 + 8,
      paddingVertical: 8,
      textAlign: "center",
    },
    closeDialogButton: {
      position: "absolute",
      right: 8,
      top: 8,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  isDisabled,
}: {
  isDisabled: boolean | undefined;
}) {
  const styles = useStyles();

  return {
    buttonIcon: [styles.buttonIcon, isDisabled && styles.buttonIconDisabled],
  };
}

export default useStyles;
