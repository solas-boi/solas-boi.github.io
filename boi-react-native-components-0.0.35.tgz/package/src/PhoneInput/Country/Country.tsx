import { useContext, useEffect } from "react";
import { View, type ViewProps } from "react-native";

import PhoneInputContext from "../PhoneInputContext";
import { CountryCombobox, type CountryComboboxProps } from "../CountryCombobox";
import { useSimpleA11yProps } from "../../hooks";

export type CountryProps = Omit<CountryComboboxProps, "labelProps"> &
  Pick<ViewProps, "aria-label">;

function Country(props: CountryProps) {
  const { selectedItem } = props;

  const { labelProps, alertProps, setPrefix } = useContext(PhoneInputContext);

  const a11yProps = useSimpleA11yProps({
    labelProps,
    alertProps: alertProps?.country,
  });

  useEffect(() => {
    if (selectedItem) {
      setPrefix(selectedItem.value);
    }
  }, [selectedItem, setPrefix]);

  return (
    <View style={{ width: 98 }}>
      <CountryCombobox
        {...props}
        {...a11yProps}
        labelProps={{
          "aria-label": props["aria-label"] || "Country code",
        }}
      />
    </View>
  );
}

export default Country;
