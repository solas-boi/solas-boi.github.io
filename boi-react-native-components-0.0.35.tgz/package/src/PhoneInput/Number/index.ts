export { default as Number, type NumberProps } from "./Number";
