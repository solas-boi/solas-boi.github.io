import { forwardRef, useContext } from "react";
import { View, TextInput as RNTextInput } from "react-native";
import { useControlledState } from "@react-stately/utils";

import PhoneInputContext from "../PhoneInputContext";
import { useSimpleA11yProps } from "../../hooks";
import { TextInput, type TextInputProps } from "../../TextInput";

export type NumberProps = Omit<
  TextInputProps,
  "labelProps" | "alertProps" | "prefix" | "inputMode"
>;

const Number = forwardRef<RNTextInput, NumberProps>((props, ref) => {
  const { labelProps, alertProps, prefix } = useContext(PhoneInputContext);

  const a11yProps = useSimpleA11yProps({
    labelProps,
    alertProps: alertProps?.number,
  });

  const [value, setValue] = useControlledState(
    props.value,
    props.defaultValue || ""
  );

  function handleChangeText(text: string) {
    const modifiedText = text.replace(/[^\d\s]/g, "");

    props.onChangeText?.(modifiedText);
    setValue(modifiedText);
  }

  return (
    <View style={{ flex: 1 }}>
      <TextInput
        {...props}
        {...a11yProps}
        ref={ref}
        labelProps={{
          "aria-label": props["aria-label"] || "Phone number",
        }}
        inputMode="numeric"
        prefix={prefix}
        value={value}
        onChangeText={handleChangeText}
      />
    </View>
  );
});

Number.displayName = "Number";

export default Number;
