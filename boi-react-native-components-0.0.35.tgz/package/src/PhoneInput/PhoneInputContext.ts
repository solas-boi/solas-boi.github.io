import { createContext } from "react";

import { type PhoneInputProps } from "./PhoneInput";

type PhoneInputContextValue = Pick<
  PhoneInputProps,
  "labelProps" | "alertProps"
> & {
  prefix: string | undefined;
  setPrefix: (prefix: string) => void;
};

const PhoneInputContext = createContext<PhoneInputContextValue>(
  {} as PhoneInputContextValue
);

export default PhoneInputContext;
