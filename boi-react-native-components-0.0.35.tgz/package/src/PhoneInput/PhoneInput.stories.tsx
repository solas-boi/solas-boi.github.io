import { useState, type ComponentPropsWithRef } from "react";
import type { Meta, StoryObj } from "@storybook/react";

import PhoneInput from "./PhoneInput";
import { MOCK_COUNTRY_ITEMS } from "./PhoneInput.mocks";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";
import { TextInput } from "react-native";

type CountryProps = ComponentPropsWithRef<typeof PhoneInput.Country>;
type CountryItem = CountryProps["items"][number] | null | undefined;

const INITIAL_SELECTED_ITEM = MOCK_COUNTRY_ITEMS.find((item) => {
  return item.id === "IE";
});

const meta = {
  title: "Inputs/PhoneInput",
  component: PhoneInput,
  render: function Render(args) {
    const [selectedItem, setSelectedItem] = useState<CountryItem>(
      INITIAL_SELECTED_ITEM
    );

    return (
      <PhoneInput {...args}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={selectedItem}
          onChange={setSelectedItem}
        />
        <PhoneInput.Number />
      </PhoneInput>
    );
  },
  argTypes: {
    alertProps: { control: { disable: true } },
  },
} satisfies Meta<typeof PhoneInput>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    "aria-label": "PhoneInput label",
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "PhoneInput label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "PhoneInput label",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const Disabled: Story = {
  render: function Render(args) {
    const [selectedItem, setSelectedItem] = useState<CountryItem>(
      INITIAL_SELECTED_ITEM
    );

    return (
      <PhoneInput {...args}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={selectedItem}
          onChange={setSelectedItem}
          isDisabled
        />
        <PhoneInput.Number disabled />
      </PhoneInput>
    );
  },
  args: {
    labelProps: {
      label: "PhoneInput label",
    },
  },
};

export const Invalid: Story = {
  render: function Render(args) {
    const [selectedItem, setSelectedItem] = useState<CountryItem>(
      INITIAL_SELECTED_ITEM
    );

    return (
      <FocusControlWrapper<TextInput> {...args}>
        {(ref) => (
          <PhoneInput {...args}>
            <PhoneInput.Country
              items={MOCK_COUNTRY_ITEMS}
              selectedItem={selectedItem}
              onChange={setSelectedItem}
            />
            <PhoneInput.Number ref={ref} hasError />
          </PhoneInput>
        )}
      </FocusControlWrapper>
    );
  },
  args: {
    labelProps: {
      label: "PhoneInput label",
    },
    alertProps: {
      number: [
        {
          severity: "error",
          children: "Error description over two lines if required.",
        },
      ],
    },
  },
};

export const DisabledItems: Story = {
  render: function Render(args) {
    const [selectedItem, setSelectedItem] = useState<CountryItem>(
      INITIAL_SELECTED_ITEM
    );

    return (
      <PhoneInput {...args}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={selectedItem}
          onChange={setSelectedItem}
          disabledKeys={MOCK_COUNTRY_ITEMS.slice(1, 3).map(({ id }) => id)}
        />
        <PhoneInput.Number />
      </PhoneInput>
    );
  },
  args: {
    labelProps: {
      label: "PhoneInput label",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(Invalid);
