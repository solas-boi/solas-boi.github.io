import { useState, useMemo } from "react";
import { View, ViewProps } from "react-native";
import { type PropsWithOptionalTestID } from "@boi/components-core";

import useStyles from "./PhoneInput.styles";
import PhoneInputContext from "./PhoneInputContext";
import { Country } from "./Country";
import { Number } from "./Number";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type PhoneInputProps = PropsWithOptionalTestID &
  Pick<ViewProps, "aria-label" | "children"> & {
    labelProps?: Omit<InputLabelTopProps, "children">;
    alertProps?: {
      country?: InputAlertsProps["alerts"];
      number?: InputAlertsProps["alerts"];
    };
  };

function PhoneInput(props: PhoneInputProps) {
  const {
    labelProps,
    alertProps,
    testID = "phone-input",
    ...otherProps
  } = props;

  const styles = useStyles();

  const inputWrapperAlerts = useMemo(
    () => (
      <View style={styles.inputAlertsContainer}>
        {alertProps?.country && <InputAlerts alerts={alertProps.country} />}
        {alertProps?.number && <InputAlerts alerts={alertProps.number} />}
      </View>
    ),
    [styles, alertProps]
  );

  const [prefix, setPrefix] = useState<string | undefined>();

  const phoneInputContextValue = useMemo(() => {
    return { labelProps, alertProps, prefix, setPrefix };
  }, [labelProps, alertProps, prefix, setPrefix]);

  return (
    <PhoneInputContext.Provider value={phoneInputContextValue}>
      <InputWrapper alert={alertProps && inputWrapperAlerts}>
        <InputLabelTop {...labelProps}>
          <ScreenReaderAlertNotifier
            alert={alertProps?.country ?? alertProps?.number}
          >
            <View {...otherProps} style={styles.group} testID={testID} />
          </ScreenReaderAlertNotifier>
        </InputLabelTop>
      </InputWrapper>
    </PhoneInputContext.Provider>
  );
}

PhoneInput.Country = Country;
PhoneInput.Number = Number;

export default PhoneInput;
