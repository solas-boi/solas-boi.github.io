import { countriesData } from "@boi/react-native-country-assets";

export const MOCK_COUNTRY_ITEMS = countriesData.map((item) => {
  const { component: FlagComponent } = item;

  const PROMOTED_ITEMS = ["IE", "GB", "US"];

  return {
    id: item.code,
    title: `${item.label} ${item.callingCode}`,
    value: item.callingCode,
    icon: FlagComponent && <FlagComponent />,
    isPromoted: PROMOTED_ITEMS.includes(item.code),
  };
});
