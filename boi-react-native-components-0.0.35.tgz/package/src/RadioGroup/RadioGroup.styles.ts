import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { radioGroup } = tokens;

  return StyleSheet.create({
    container: {
      display: "flex",
      gap: radioGroup.gap,
    },
    list: {
      display: "flex",
      gap: radioGroup.list.gap,
    },
    listItem: {
      display: "flex",
      gap: radioGroup.list.gap,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
