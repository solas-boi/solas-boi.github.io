import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import RadioGroup, { type RadioGroupProps } from "./RadioGroup";

jest.useFakeTimers();

function WrappedRadioGroup(props: RadioGroupProps) {
  return (
    <DesignTokensProvider>
      <RadioGroup {...props} />
    </DesignTokensProvider>
  );
}

describe("RadioGroup", () => {
  let baseProps: RadioGroupProps;

  beforeEach(() => {
    baseProps = {
      legend: "Group legend",
      inputs: [
        { value: "bacon", labelProps: { label: "Bacon" } },
        { value: "cheese", labelProps: { label: "Cheese" } },
        { value: "onions", labelProps: { label: "Onions" } },
        { value: "lettuce", labelProps: { label: "Lettuce" } },
        { value: "tomato", labelProps: { label: "Tomato" } },
      ],
      onChange: jest.fn(),
    };
  });

  it("should render with a legend element", () => {
    render(<WrappedRadioGroup {...baseProps} />);

    const legend = screen.getByText("Group legend");

    expect(legend).toBeDefined();
  });

  it("should render the correct number of inputs", () => {
    render(<WrappedRadioGroup {...baseProps} />);

    const radios = screen.getAllByRole("radio");

    expect(radios).toHaveLength(baseProps.inputs.length);
  });

  it("should trigger the onChange event when a radio is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(
      <WrappedRadioGroup
        {...baseProps}
        inputs={[baseProps.inputs[0]!]}
        onChange={mockOnChange}
      />
    );

    const radio = screen.getByRole("radio");

    await act(async () => {
      await user.press(radio);
    });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith([
      expect.objectContaining({
        value: "bacon",
        isChecked: true,
      }),
    ]);
  });

  it("should render an alert when alertProps are provided", async () => {
    render(
      <WrappedRadioGroup
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("radio-group-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render with a default testID", () => {
    render(<WrappedRadioGroup {...baseProps} />);

    expect(screen.getByTestId("radio-group")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-radio-group";

    render(<WrappedRadioGroup {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
