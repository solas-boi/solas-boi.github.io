import { forwardRef } from "react";
import { View } from "react-native";
import { type PropsWithOptionalTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { Fieldset, type FieldsetProps } from "../Fieldset";
import { Radio, type RadioProps } from "../Radio";

import useStyles from "./RadioGroup.styles";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

type RadioGroupInput = Omit<RadioProps, "alertProps">;

export type RadioGroupProps = PropsWithOptionalTestID &
  Omit<FieldsetProps, "children" | "role"> & {
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    inputs: RadioGroupInput[];
    onChange: (inputs: RadioGroupInput[]) => void;
  };

const RadioGroup = forwardRef<View, RadioGroupProps>((props, ref) => {
  const {
    alertProps,
    legend,
    legendHint,
    legendTooltipProps,
    legendHintTooltipProps,
    accessibilityLabel,
    accessibilityHint,
    inputs,
    onChange,
    testID = "radio-group",
  } = props;

  const { tokens } = useDesignTokens();
  const { radioGroup } = tokens;

  const styles = useStyles();

  function handlePress(pressedInput: RadioGroupInput) {
    const updatedInputs = inputs.map((input) => {
      if (input === pressedInput) {
        return { ...input, isChecked: true };
      }

      return { ...input, isChecked: false };
    });

    onChange(updatedInputs);
  }

  return (
    <InputWrapper
      gap={radioGroup.gap}
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <Fieldset
        legend={legend}
        legendHint={legendHint}
        legendTooltipProps={legendTooltipProps}
        legendHintTooltipProps={legendHintTooltipProps}
        accessibilityLabel={accessibilityLabel}
        accessibilityHint={accessibilityHint}
        role="radiogroup"
        testID={testID}
      >
        <ScreenReaderAlertNotifier
          alert={alertProps}
          role="list"
          style={styles.list}
        >
          {inputs.map((input, index) => (
            <View key={index} role="listitem" style={styles.listItem}>
              {/* eslint-disable-next-line react-native-a11y/has-accessibility-hint*/}
              <Radio
                {...input}
                ref={index === 0 ? ref : null}
                accessibilityLabel={`${input.labelProps.label}, ${
                  index + 1
                } of ${inputs.length}`}
                onPress={() => handlePress(input)}
              />
            </View>
          ))}
        </ScreenReaderAlertNotifier>
      </Fieldset>
    </InputWrapper>
  );
});

RadioGroup.displayName = "RadioGroup";

export default RadioGroup;
