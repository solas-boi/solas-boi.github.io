import { Ref, useEffect, useRef, useState } from "react";
import {
  FlatList,
  Platform,
  View,
  type AccessibilityProps,
} from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

import { CoreSelect, type PropsWithOptionalTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { ChevronDownIcon } from "@boi/react-native-icons";

import { OuterField } from "../OuterField";
import { Typography } from "../Typography";
import { ModalProps } from "../Modal";
import { SelectModal } from "../SelectModal";
import { InputLabelTopProps } from "../InputLabelTop";
import { type InputAlertsProps } from "../InputAlerts";

import useStyles from "./SelectBase.styles";
import { useA11yRoleWorkaround, useMergeRefs } from "../hooks";

const isAndroid = Platform.OS === "android";
const isOlderThanAndroid16 = isAndroid && Number(Platform.Version) < 36;

export type SelectBaseProps<T extends CoreSelect.SelectItem> =
  PropsWithOptionalTestID &
    Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
    AccessibilityProps & {
      labelProps: InputLabelTopProps;
      isOpen: boolean;
      selectedItem?: T | null | undefined;
      items: T[];
      disabledKeys?: string[];
      placeholder?: string;
      hasError?: boolean;
      isDisabled?: boolean;
      onChange: (selectedItem: T | null | undefined) => void;
      onFocus: () => void;
      onBlur: () => void;
      pressableRef?: Ref<View>;
      alertProps?:
        | InputAlertsProps["alerts"][number]
        | InputAlertsProps["alerts"];
    };

function SelectBase<T extends CoreSelect.SelectItem>(
  props: SelectBaseProps<T>
) {
  const {
    items,
    disabledKeys,
    placeholder,
    isDisabled,
    hasError,
    isOpen,
    selectedItem,
    labelProps,
    onChange,
    onFocus,
    onBlur,
    supportedOrientations,
    onCloseAnimationComplete,
    testID = "select",
    pressableRef,
    role,
    accessibilityRole,
    alertProps,
    ...accessibilityProps
  } = props;

  const localPressableRef = useRef<View>(null);
  const mergedRefs = useMergeRefs([localPressableRef, pressableRef]);
  const flatlistRef = useRef<FlatList>(null);
  const styles = useStyles();

  useEffect(() => {
    if (isOpen && selectedItem) {
      flatlistRef.current?.scrollToItem({
        item: selectedItem,
        animated: true,
      });
    }
  }, [isOpen, selectedItem]);

  const selectedItemA11y =
    selectedItem?.ariaLabel || selectedItem?.title || placeholder || "";

  const a11yLabelWithAlerts =
    useA11yRoleWorkaround(
      role || accessibilityRole || "combobox",
      accessibilityProps.accessibilityLabel || labelProps.label || ""
    ) + ".";

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <>
      <OuterField
        isDisabled={isDisabled}
        hasFocus={hasKeyboardFocus}
        isActive={isOpen}
        hasError={hasError}
      >
        <KeyboardPressable
          ref={mergedRefs}
          onPress={onFocus}
          onFocusChange={handleKeyboardFocusChange}
          enableA11yFocus
          tintType="none"
          pointerEvents={isDisabled ? "none" : "auto"}
          style={styles.button}
          testID={testID}
          accessibilityValue={{
            text: `${
              (!isAndroid || isOlderThanAndroid16) && !isOpen
                ? "collapsed, "
                : ""
            }${selectedItemA11y}`,
          }}
          accessibilityState={{
            expanded: isAndroid && !isOlderThanAndroid16 ? isOpen : undefined,
            disabled: Boolean(isDisabled),
          }}
          accessibilityHint={labelProps.labelHint}
          {...accessibilityProps}
          accessibilityLabel={a11yLabelWithAlerts}
        >
          {selectedItem ? (
            <Typography
              fontFamily={styles.buttonText.fontFamily}
              variant={styles.buttonText.fontVariant}
              style={[
                styles.buttonText,
                isDisabled && styles.buttonTextDisabled,
              ]}
              noWrap
            >
              {selectedItem.title}
            </Typography>
          ) : (
            <Typography
              fontFamily={styles.buttonText.fontFamily}
              variant={styles.buttonText.fontVariant}
              style={[
                styles.buttonPlaceholder,
                isDisabled && styles.buttonPlaceholderDisabled,
              ]}
              noWrap
            >
              {placeholder}
            </Typography>
          )}

          <SelectChevron isOpen={isOpen} isDisabled={isDisabled} />
        </KeyboardPressable>
      </OuterField>
      <SelectModal
        testID={`${testID}-modal`}
        isOpen={isOpen}
        title={labelProps.label || placeholder || ""}
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        onChange={onChange}
        onRequestClose={onBlur}
        supportedOrientations={supportedOrientations}
        onCloseAnimationComplete={() => {
          localPressableRef.current?.focus();
          onCloseAnimationComplete?.();
        }}
      />
    </>
  );
}

function SelectChevron(props: { isOpen: boolean; isDisabled?: boolean }) {
  const { tokens } = useDesignTokens();
  const { width, height, color } = tokens.select.button.icon;

  return (
    <ChevronDownIcon
      width={width}
      height={height}
      color={props.isDisabled ? color.disabled : color.base}
      style={props.isOpen && { transform: [{ rotate: "180deg" }] }}
    />
  );
}

export default SelectBase;
