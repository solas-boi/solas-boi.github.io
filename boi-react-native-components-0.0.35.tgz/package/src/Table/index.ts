export {
  Table,
  TableHead,
  TableHeadRow,
  TableHeadCell,
  TableHeadTypography,
  TableBody,
  TableBodyRow,
  TableBodyCell,
  TableBodyTypography,
} from "./Table";
