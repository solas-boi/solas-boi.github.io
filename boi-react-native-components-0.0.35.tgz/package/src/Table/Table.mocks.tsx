import {
  Table,
  TableHead,
  TableHeadRow,
  TableHeadCell,
  TableHeadTypography,
  TableBody,
  TableBodyRow,
  TableBodyCell,
  TableBodyTypography,
  type TableProps,
} from "./Table";

export function MockTable(props: TableProps) {
  return (
    <Table {...props}>
      <TableHead>
        <TableHeadRow>
          <TableHeadCell>
            <TableHeadTypography>Loan amount</TableHeadTypography>
          </TableHeadCell>
          <TableHeadCell>
            <TableHeadTypography>Interest rate</TableHeadTypography>
          </TableHeadCell>
          <TableHeadCell>
            <TableHeadTypography>APR variable</TableHeadTypography>
          </TableHeadCell>
          <TableHeadCell>
            <TableHeadTypography>Repayment term</TableHeadTypography>
          </TableHeadCell>
          <TableHeadCell>
            <TableHeadTypography>Monthly repayment</TableHeadTypography>
          </TableHeadCell>
          <TableHeadCell>
            <TableHeadTypography>Cost of credit</TableHeadTypography>
          </TableHeadCell>
        </TableHeadRow>
      </TableHead>
      <TableBody>
        <TableBodyRow isEven={false}>
          <TableBodyCell>
            <TableBodyTypography>€8,000</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>8.25%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>8.5%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>60 months</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€162.95</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€1,777.00</TableBodyTypography>
          </TableBodyCell>
        </TableBodyRow>
        <TableBodyRow isEven={true}>
          <TableBodyCell>
            <TableBodyTypography>€15,000</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>7.3%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>7.5%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>60 months</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€298.83</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€2,929.80</TableBodyTypography>
          </TableBodyCell>
        </TableBodyRow>
        <TableBodyRow isEven={false}>
          <TableBodyCell>
            <TableBodyTypography>€20,000</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>6.6%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>6.8%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>60 months</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€391.92</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€3,515.20</TableBodyTypography>
          </TableBodyCell>
        </TableBodyRow>
        <TableBodyRow isEven={true}>
          <TableBodyCell>
            <TableBodyTypography>€40,000</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>6.6%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>6.8%</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>60 months</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€783.85</TableBodyTypography>
          </TableBodyCell>
          <TableBodyCell>
            <TableBodyTypography>€7,031.00</TableBodyTypography>
          </TableBodyCell>
        </TableBodyRow>
      </TableBody>
    </Table>
  );
}
