import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import type { Align } from "./Table.types";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { table } = tokens;

  return StyleSheet.create({
    table: {
      borderBottomWidth: table.stroke.bottom.width,
      borderStyle: table.stroke.bottom.style,
      borderBottomColor: table.stroke.bottom.color,
    },
    head: {
      backgroundColor: table.head.backgroundColor,
      borderBottomWidth: table.head.stroke.bottom.width,
      borderStyle: table.head.stroke.bottom.style,
      borderBottomColor: table.head.stroke.bottom.color,
    },
    headRow: {
      display: "flex",
      flexDirection: "row",
      paddingLeft: table.head.cell.padding.left.base,
      paddingRight: table.head.cell.padding.right.base,
    },
    headCell: {
      flex: 1,
      justifyContent: "flex-end",
      paddingTop: table.head.cell.padding.top,
      paddingLeft: table.head.cell.padding.left.base,
      paddingRight: table.head.cell.padding.right.base,
      paddingBottom: table.head.cell.padding.bottom,
    },
    headCellAlignLeft: {
      alignItems: "flex-start",
    },
    headCellAlignCenter: {
      alignItems: "center",
    },
    headCellAlignRight: {
      alignItems: "flex-end",
    },
    headCellAlignStretch: {
      alignItems: "stretch",
    },
    bodyRow: {
      display: "flex",
      flexDirection: "row",
      paddingLeft: table.body.cell.padding.left.base,
      paddingRight: table.body.cell.padding.right.base,
    },
    bodyRowOdd: {
      backgroundColor: table.body.row.backgroundColor.odd,
    },
    bodyRowEven: {
      backgroundColor: table.body.row.backgroundColor.even,
    },
    bodyCell: {
      flex: 1,
      paddingTop: table.body.cell.padding.top,
      paddingLeft: table.body.cell.padding.left.base,
      paddingRight: table.body.cell.padding.right.base,
      paddingBottom: table.body.cell.padding.bottom,
    },
    bodyCellAlignLeft: {
      alignItems: "flex-start",
    },
    bodyCellAlignCenter: {
      alignItems: "center",
    },
    bodyCellAlignRight: {
      alignItems: "flex-end",
    },
    bodyCellAlignStretch: {
      alignItems: "stretch",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles() {
  const styles = useStyles();

  const headCellAlignStyles = {
    left: styles.headCellAlignLeft,
    center: styles.headCellAlignCenter,
    right: styles.headCellAlignRight,
    stretch: styles.headCellAlignStretch,
  };

  const bodyCellAlignStyles = {
    left: styles.bodyCellAlignLeft,
    center: styles.bodyCellAlignCenter,
    right: styles.bodyCellAlignRight,
    stretch: styles.bodyCellAlignStretch,
  };

  return {
    headCell: (align: Align) => [styles.headCell, headCellAlignStyles[align]],
    bodyRow: (isEven: boolean) => [
      styles.bodyRow,
      isEven ? styles.bodyRowEven : styles.bodyRowOdd,
    ],
    bodyCell: (align: Align) => [styles.bodyCell, bodyCellAlignStyles[align]],
  };
}

export default useStyles;
