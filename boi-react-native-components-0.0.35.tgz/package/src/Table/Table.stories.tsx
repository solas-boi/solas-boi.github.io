import type { Meta, StoryObj } from "@storybook/react";

import { Table } from "./Table";
import { MockTable } from "./Table.mocks";

const meta = {
  title: "Data Display/Table",
  component: Table,
} satisfies Meta<typeof Table>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  render: function Render(args) {
    return <MockTable {...args} />;
  },
};
