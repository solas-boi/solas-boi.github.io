import { View, type ViewProps } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles, { useStateStyles } from "./Table.styles";
import type { Align } from "./Table.types";
import { Typography, type TypographyProps } from "../Typography";

export type TableProps = Omit<ViewProps, "role" | "style">;

export function Table(props: TableProps) {
  const { testID = "table", ...otherProps } = props;

  const styles = useStyles();

  return (
    <View {...otherProps} role="table" style={styles.table} testID={testID} />
  );
}

type TableHeadProps = Omit<ViewProps, "style">;

export function TableHead(props: TableHeadProps) {
  const styles = useStyles();

  return <View {...props} style={styles.head} />;
}

type TableHeadRowProps = Omit<ViewProps, "style">;

export function TableHeadRow(props: TableHeadRowProps) {
  const styles = useStyles();

  return <View {...props} style={styles.headRow} />;
}

type TableHeadCellProps = Omit<ViewProps, "styles"> & {
  align?: Align;
};

export function TableHeadCell(props: TableHeadCellProps) {
  const { align = "right", ...otherProps } = props;

  const stateStyles = useStateStyles();

  return <View {...otherProps} style={stateStyles.headCell(align)} />;
}

type TableHeadTypographyProps = Omit<TypographyProps, "variant" | "fontFamily">;

export function TableHeadTypography(props: TableHeadTypographyProps) {
  const { style, ...otherProps } = props;

  const { tokens } = useDesignTokens();
  const { table } = tokens;

  return (
    <Typography
      variant={table.head.typography.variant}
      fontFamily={table.head.typography.fontFamily}
      style={[{ textAlign: "right" }, style]}
      {...otherProps}
    />
  );
}

type TableBodyProps = Omit<ViewProps, "styles">;

export function TableBody(props: TableBodyProps) {
  return <View {...props} />;
}

type TableBodyRowProps = Omit<ViewProps, "styles"> & {
  isEven: boolean;
};

export function TableBodyRow(props: TableBodyRowProps) {
  const { isEven, ...otherProps } = props;

  const stateStyles = useStateStyles();

  return <View {...otherProps} style={stateStyles.bodyRow(isEven)} />;
}

type TableBodyCellProps = Omit<ViewProps, "styles"> & {
  align?: Align;
};

export function TableBodyCell(props: TableBodyCellProps) {
  const { align = "right", ...otherProps } = props;

  const stateStyles = useStateStyles();

  return <View {...otherProps} style={stateStyles.bodyCell(align)} />;
}

type TableBodyTypographyProps = Omit<TypographyProps, "variant" | "fontFamily">;

export function TableBodyTypography(props: TableBodyTypographyProps) {
  const { style, ...otherProps } = props;

  const { tokens } = useDesignTokens();
  const { table } = tokens;

  return (
    <Typography
      variant={table.body.typography.variant}
      fontFamily={table.body.typography.fontFamily}
      style={[{ textAlign: "right" }, style]}
      {...otherProps}
    />
  );
}
