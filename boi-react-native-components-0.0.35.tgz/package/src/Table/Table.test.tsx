import { render, screen, within } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { type TableProps } from "./Table";
import { MockTable } from "./Table.mocks";

function WrappedTable(props: TableProps) {
  return (
    <DesignTokensProvider>
      <MockTable {...props} />
    </DesignTokensProvider>
  );
}

describe("Table", () => {
  let baseProps: TableProps;

  beforeEach(() => {
    baseProps = {};
  });

  it("should render with the correct data", async () => {
    render(<WrappedTable {...baseProps} />);

    const table = screen.getByTestId("table");

    const header = within(table).getByText("Loan amount");
    const data = within(table).getByText("€8,000");

    expect(header).toBeDefined();
    expect(data).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedTable {...baseProps} />);

    expect(screen.getByTestId("table")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-table";

    render(<WrappedTable {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
