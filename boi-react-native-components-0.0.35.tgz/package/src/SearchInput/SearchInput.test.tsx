import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import SearchInput, { type SearchInputProps } from "./SearchInput";

jest.useFakeTimers();

function WrappedSearchInput(props: SearchInputProps) {
  return (
    <DesignTokensProvider>
      <SearchInput {...props} />
    </DesignTokensProvider>
  );
}

describe("SearchInput", () => {
  let baseProps: SearchInputProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        label: "SearchInput label",
      },
    };
  });

  it("should render with a default testID", () => {
    render(<WrappedSearchInput {...baseProps} />);

    expect(screen.getByTestId("search-input")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-search-input";

    render(<WrappedSearchInput {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
