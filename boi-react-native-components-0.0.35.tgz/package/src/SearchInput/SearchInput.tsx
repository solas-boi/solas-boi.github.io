import { useDesignTokens } from "@boi/react-native-design-tokens";
import { SearchIcon } from "@boi/react-native-icons";
import { forwardRef } from "react";
import { TextInput as RNTextInput } from "react-native";

import { InputLabelTopProps } from "../InputLabelTop";
import { TextInput, type TextInputProps } from "../TextInput";

export type SearchInputProps = Omit<
  TextInputProps,
  "icon" | "prefix" | "withClearButton" | "labelProps"
> & {
  labelProps?: Omit<InputLabelTopProps, "children">;
};

const SearchInput = forwardRef<RNTextInput, SearchInputProps>((props, ref) => {
  const { testID = "search-input", labelProps } = props;
  const { tokens } = useDesignTokens();

  return (
    <TextInput
      {...props}
      testID={testID}
      labelProps={labelProps || {}}
      prefix={
        <SearchIcon
          width={tokens.searchInput.icon.width}
          height={tokens.searchInput.icon.height}
          color={
            props.disabled
              ? tokens.textInput.color.disabled
              : tokens.outerField.column01.startSlot.color
          }
        />
      }
      withClearButton={true}
      ref={ref}
    />
  );
});

SearchInput.displayName = "SearchInput";

export default SearchInput;
