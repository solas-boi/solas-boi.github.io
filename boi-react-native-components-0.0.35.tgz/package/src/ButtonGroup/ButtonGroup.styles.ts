import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { CoreButtonGroup } from "@boi/components-core";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { buttonGroup } = tokens;

  const styles = StyleSheet.create({
    container: {
      flexDirection: "row",
      gap: buttonGroup.items.gap,
    },
    containerVariantStretch: {
      maxWidth: buttonGroup.maxWidth.stretch,
    },
    containerVariantLeft: {
      maxWidth: buttonGroup.maxWidth.left,
    },
    containerVariantCenter: {
      justifyContent: "center",
      maxWidth: buttonGroup.maxWidth.center,
    },
    containerVariantStacked: {
      flexDirection: "column",
      maxWidth: buttonGroup.maxWidth.stacked,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant,
}: {
  variant: CoreButtonGroup.Variant;
}) {
  const styles = useStyles();

  const containerVariantStyles = {
    stretch: styles.containerVariantStretch,
    left: styles.containerVariantLeft,
    center: styles.containerVariantCenter,
    stacked: styles.containerVariantStacked,
  };

  return {
    container: [styles.container, containerVariantStyles[variant]],
  };
}

export default useStyles;
