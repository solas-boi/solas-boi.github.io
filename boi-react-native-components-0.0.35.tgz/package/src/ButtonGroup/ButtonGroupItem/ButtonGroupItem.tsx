import { forwardRef, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import {
  CoreButtonAlt,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { useStateStyles } from "./ButtonGroupItem.styles";
import { Typography } from "../../Typography";
import { KeyboardPressableProps } from "../../types";

export type ButtonGroupItemProps = PropsWithOptionalTestID & {
  label: string;
  value: string;
  accessibilityLabel: string;
  onPress: KeyboardPressableProps["onPress"];
  isChecked?: boolean;
  hasError?: boolean;
  isDisabled?: boolean;
  fullWidth?: boolean;
  textAlign?: CoreButtonAlt.TextAlign;
  typographyVariant?: CoreButtonAlt.TypographyVariant;
};

const ButtonGroupItem = forwardRef<View, ButtonGroupItemProps>((props, ref) => {
  const {
    label,
    accessibilityLabel,
    onPress,
    isChecked = false,
    hasError = false,
    isDisabled = false,
    fullWidth = false,
    textAlign = CoreButtonAlt.DEFAULT_TEXT_ALIGN,
    typographyVariant = CoreButtonAlt.DEFAULT_TYPOGRAPHY_VARIANT,
    testID = "button-group-item",
  } = props;

  const { tokens } = useDesignTokens();
  const { buttonAlt } = tokens;

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  const stateStyles = useStateStyles({
    isChecked,
    isDisabled,
    hasError,
    fullWidth,
    textAlign,
  });

  return (
    <KeyboardPressable
      ref={ref}
      tintType="none"
      role="radio"
      disabled={isDisabled}
      enableA11yFocus
      accessibilityRole="radio"
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={undefined}
      accessibilityState={{
        checked: Boolean(isChecked),
        disabled: Boolean(isDisabled),
      }}
      containerStyle={stateStyles.container}
      style={stateStyles.button}
      onPress={onPress}
      onFocusChange={handleKeyboardFocusChange}
      testID={`${testID}-item`}
    >
      {hasKeyboardFocus && (
        <View pointerEvents="none" style={stateStyles.focusRing} />
      )}
      <Typography
        color={
          buttonAlt.color[
            isChecked ? "active" : isDisabled ? "disabled" : "base"
          ]
        }
        variant={typographyVariant}
        fontFamily={buttonAlt.typography.fontFamily}
        style={{ textAlign }}
      >
        {label}
      </Typography>
    </KeyboardPressable>
  );
});

ButtonGroupItem.displayName = "ButtonGroupItem";

export default ButtonGroupItem;
