export type Item = {
  id: string;
  label: string;
  value: string;
  isChecked?: boolean;
  hasError?: boolean;
  isDisabled?: boolean;
};
