export const mockButtonGroup = {
  items: [
    {
      id: "button-group-item-01",
      label: "Button label 01",
      value: "button-group-item-01",
    },
    {
      id: "button-group-item-02",
      label: "Button label 02",
      value: "button-group-item-02",
    },
  ],
};

export const mockErrorButtonGroup = {
  items: [
    {
      id: "error-button-group-item-01",
      label: "Button label 01",
      value: "error-button-group-item-01",
      hasError: true,
    },
    {
      id: "error-button-group-item-02",
      label: "Button label 02",
      value: "error-button-group-item-02",
      hasError: true,
    },
  ],
};
