import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import ButtonGroup, { type ButtonGroupProps } from "./ButtonGroup";
import { mockButtonGroup } from "./ButtonGroup.mocks";

jest.useFakeTimers();

function WrappedButtonGroup(props: ButtonGroupProps) {
  return (
    <DesignTokensProvider>
      <ButtonGroup {...props} />
    </DesignTokensProvider>
  );
}

describe("ButtonGroup", () => {
  let baseProps: ButtonGroupProps;

  beforeEach(() => {
    baseProps = {
      ...mockButtonGroup,
      onChange: jest.fn(),
    };
  });

  it("should render the correct number of items", () => {
    render(<WrappedButtonGroup {...baseProps} />);

    const radios = screen.getAllByRole("radio");

    expect(radios).toHaveLength(baseProps.items.length);
  });

  it("should trigger the onChange event when an item is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedButtonGroup {...baseProps} onChange={mockOnChange} />);

    const nextItemProps = baseProps.items[1]!;

    const nextItem = screen.getByRole("radio", {
      name: nextItemProps.label,
      checked: false,
    });

    await act(async () => {
      await user.press(nextItem);
    });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith([
      {
        ...baseProps.items[0],
        isChecked: false,
      },
      {
        ...baseProps.items[1],
        isChecked: true,
      },
    ]);
  });

  it("should render all items as disabled if prop isDisabled is set to true", async () => {
    render(<WrappedButtonGroup {...baseProps} isDisabled />);

    baseProps.items.forEach((item) => {
      const itemElement = screen.getByRole("radio", {
        name: item.label,
        disabled: true,
      });

      expect(itemElement).not.toBeUndefined();
    });
  });

  it("should render a item as disabled if its prop isDisabled is set to true", async () => {
    const itemsWithOneDisabled = [
      {
        id: "button-group-item-01",
        label: "Button label 01",
        value: "button-group-item-01",
      },
      {
        id: "button-group-item-02",
        label: "Button label 02",
        value: "button-group-item-02",
        isDisabled: true,
      },
    ];

    render(<WrappedButtonGroup {...baseProps} items={itemsWithOneDisabled} />);

    itemsWithOneDisabled.forEach((item) => {
      const itemElement = screen.getByRole("radio", {
        name: item.label,
        disabled: Boolean(item.isDisabled),
      });

      expect(itemElement).not.toBeUndefined();
    });
  });

  it("should render a item as checked if its prop isChecked is set to true", async () => {
    const itemsWithOneChecked = [
      {
        id: "button-group-item-01",
        label: "Button label 01",
        value: "button-group-item-01",
      },
      {
        id: "button-group-item-02",
        label: "Button label 02",
        value: "button-group-item-02",
        isChecked: true,
      },
    ];

    render(<WrappedButtonGroup {...baseProps} items={itemsWithOneChecked} />);

    itemsWithOneChecked.forEach((item) => {
      const itemElement = screen.getByRole("radio", {
        name: item.label,
        checked: Boolean(item.isChecked),
      });

      expect(itemElement).not.toBeUndefined();
    });
  });

  it("should render an alert when alertProps are provided", () => {
    render(
      <WrappedButtonGroup
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("button-group-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render with a default testID", () => {
    render(<WrappedButtonGroup {...baseProps} />);

    expect(screen.getByTestId("button-group")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-button-group";

    render(<WrappedButtonGroup {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
