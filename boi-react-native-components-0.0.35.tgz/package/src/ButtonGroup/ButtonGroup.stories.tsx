import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import { CoreButtonAlt, CoreButtonGroup } from "@boi/components-core";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import ButtonGroup from "./ButtonGroup";
import { mockButtonGroup, mockErrorButtonGroup } from "./ButtonGroup.mocks";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta = {
  title: "Inputs/ButtonGroup",
  component: ButtonGroup,
  decorators: [
    (Story) => (
      <DesignTokensDecorator brandTheme="light">
        <Story />
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    function handleChange(items: any) {
      updateArgs({ items });
      action("onChange")();
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => <ButtonGroup {...args} ref={ref} onChange={handleChange} />}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    alertProps: { control: { disable: true } },
    variant: {
      control: { type: "select" },
      options: CoreButtonGroup.VARIANTS,
    },
    items: { control: { disable: true } },
    typographyVariant: {
      control: { type: "select" },
      options: CoreButtonAlt.TYPOGRAPHY_VARIANTS,
    },
    accessibilityLabel: { control: "text" },
    accessibilityHint: { control: "text" },
  },
  args: {
    variant: CoreButtonGroup.DEFAULT_VARIANT,
    items: mockButtonGroup.items,
    typographyVariant: CoreButtonAlt.DEFAULT_TYPOGRAPHY_VARIANT,
    accessibilityLabel: "ButtonGroup label",
  },
} satisfies Meta<typeof ButtonGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const WithLegend: Story = {
  ...Basic,
  args: {
    legend: "ButtonGroup legend",
    legendTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    legend: "ButtonGroup legend",
    legendHint: "Additional information",
    legendHintTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithError: Story = {
  args: {
    items: mockErrorButtonGroup.items,
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const Disabled: Story = {
  args: {
    isDisabled: true,
    items: mockButtonGroup.items,
  },
};

export const WithDisabledItem: Story = {
  args: {
    items: [
      ...mockButtonGroup.items.slice(0, 1),
      {
        id: "disabled-item",
        label: "Disabled Button",
        value: "disabled value",
        isDisabled: true,
      },
    ],
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);
