import type { Meta, StoryObj } from "@storybook/react";
import { getThemeTokens } from "@boi/react-native-design-tokens";
import { getColorSelectArgType } from "@boi/react-utils";

import Spinner from "./Spinner";

const {
  light: { color, spinner },
} = getThemeTokens("boi");

const meta = {
  title: "Data Display/Spinner",
  component: Spinner,
  render: function Render(args: any) {
    return <Spinner {...args} />;
  },
  argTypes: {
    color: getColorSelectArgType(color) as {},
    size: { control: { type: "number" } },
    variant: {
      control: { type: "select" },
      options: Object.keys(spinner.variants),
    },
  },
  args: {
    size: 108,
    variant: "default",
    "aria-label": "Loading...",
  },
} satisfies Meta<typeof Spinner>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
