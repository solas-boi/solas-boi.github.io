import { memo } from "react";
import { View, type ViewProps } from "react-native";
import Animated from "react-native-reanimated";
import {
  CoreSpinner,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useStateStyles } from "./Spinner.styles";

export type SpinnerProps = PropsWithOptionalTestID &
  Pick<ViewProps, "aria-label" | "aria-labelledby"> &
  (
    | {
        color: string;
        size: number;
      }
    | {
        variant: CoreSpinner.Variant;
        color?: string;
        size?: number;
      }
  ) & {
    isAnimated?: boolean;
  };

const Spinner = memo<SpinnerProps>((props) => {
  const { testID = "spinner", isAnimated = true, ...otherProps } = props;
  const styles = useStateStyles({ ...props, isAnimated });

  return (
    // eslint-disable-next-line react-native-a11y/has-accessibility-hint
    <View
      accessible
      accessibilityLabel="Loading"
      {...otherProps}
      role="progressbar"
      accessibilityRole="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      style={styles.container}
      testID={testID}
    >
      <View style={styles.circle} />
      {isAnimated && (
        <>
          <Animated.View style={styles.shard[0]} />
          <Animated.View style={styles.shard[1]} />
          <Animated.View style={styles.shard[2]} />
        </>
      )}
    </View>
  );
});
Spinner.displayName = "Spinner";

export default Spinner;
