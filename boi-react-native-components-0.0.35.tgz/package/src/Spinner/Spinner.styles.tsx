import {
  type ThemeTokens,
  useDesignTokens,
} from "@boi/react-native-design-tokens";
import { useEffect } from "react";
import { StyleSheet } from "react-native";
import {
  Easing,
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { createThemedStyleSheet } from "../themedStylesheet";
import { SpinnerProps } from "./Spinner";

function styleSheetFactory(tokens: ThemeTokens) {
  const { spinner } = tokens;
  const styles = StyleSheet.create({
    container: {
      position: "relative",
    },
    circle: {
      position: "absolute",
      height: "100%",
      width: "100%",
      opacity: spinner.backgroundOpacity,
    },
    shard: {
      position: "absolute",
      height: "100%",
      width: "100%",
      // TODO: Check if the issue https://github.com/facebook/react-native/issues/34722
      //       is fixed so we can use a real transparent value here
      borderTopColor: "rgba(0,0,0,0.01)",
      borderRightColor: "rgba(0,0,0,0.01)",
      borderBottomColor: "rgba(0,0,0,0.01)",
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(props: SpinnerProps) {
  const { container, shard, circle } = useStyles();
  const {
    tokens: { spinner },
  } = useDesignTokens();
  let color: string | undefined;
  let size: number | undefined;
  if ("variant" in props) {
    const variantObj = spinner.variants[props.variant];
    if (variantObj) {
      [color, size] = [variantObj.color, variantObj.size];
    }
  }
  if ("size" in props && props.size) {
    size = props.size;
  } else if (!size) {
    size = spinner.variants.default.size as number;
  }
  if ("color" in props) {
    color = props.color;
  } else if (!color) {
    color = spinner.variants.default.color as string;
  }
  const borderWidth = Math.ceil(size / 12);
  const rotation1 = useSharedValue(0);
  const rotation2 = useSharedValue(0);
  const rotation3 = useSharedValue(0);
  const animatedStyles1 = useAnimatedStyle(() => {
    return {
      transform: [
        {
          rotateZ: `${rotation1.value}deg`,
        },
      ],
    };
  });
  const animatedStyles2 = useAnimatedStyle(() => {
    return {
      transform: [
        {
          rotateZ: `${rotation2.value}deg`,
        },
      ],
    };
  });
  const animatedStyles3 = useAnimatedStyle(() => {
    return {
      transform: [
        {
          rotateZ: `${rotation3.value}deg`,
        },
      ],
    };
  });

  useEffect(() => {
    if (!props.isAnimated) {
      return;
    }

    const mainAnimation = withRepeat(
      withTiming(360, {
        duration: 1200,
        easing: Easing.bezier(0.5, 0, 0.5, 1),
      }),
      0
    );
    rotation1.value = mainAnimation;
    rotation2.value = withDelay(125, mainAnimation);
    rotation3.value = withDelay(125 * 2, mainAnimation);
    return () => {
      cancelAnimation(rotation1);
      cancelAnimation(rotation2);
      cancelAnimation(rotation3);
    };
  }, [props.isAnimated, rotation1, rotation2, rotation3]);

  return {
    container: [container, { width: size, height: size }],
    circle: [
      circle,
      {
        borderWidth,
        borderRadius: size,
        borderColor: color,
      },
    ],
    shard: [
      [
        shard,
        {
          borderWidth,
          borderRadius: size,
          borderLeftColor: color,
        },
        animatedStyles1,
      ],
      [
        shard,
        {
          borderWidth,
          borderRadius: size,
          borderLeftColor: color,
        },
        animatedStyles2,
      ],
      [
        shard,
        {
          borderWidth,
          borderRadius: size,
          borderLeftColor: color,
        },
        animatedStyles3,
      ],
    ],
  };
}

export default useStyles;
