import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Spinner, { type SpinnerProps } from "./Spinner";

function WrappedSpinner(props: SpinnerProps) {
  return (
    <DesignTokensProvider>
      <Spinner {...props} />
    </DesignTokensProvider>
  );
}

describe("Spinner", () => {
  let baseProps: SpinnerProps;

  beforeEach(() => {
    baseProps = {
      "aria-label": "Loading...",
      color: "#0000FF",
      size: 96,
    };
  });

  it("should render with the correct role", async () => {
    render(<WrappedSpinner {...baseProps} />);

    const spinner = screen.getByLabelText("Loading...");

    expect(spinner.props.role).toEqual("progressbar");
    expect(spinner.props.accessibilityRole).toEqual("progressbar");
  });

  it("should render with a default testID", async () => {
    render(<WrappedSpinner {...baseProps} />);

    expect(screen.getByTestId("spinner")).not.toBeDisabled();
  });

  it("should render with custom testID", async () => {
    const testID = "custom-spinner";

    render(<WrappedSpinner {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).not.toBeDisabled();
  });
});
