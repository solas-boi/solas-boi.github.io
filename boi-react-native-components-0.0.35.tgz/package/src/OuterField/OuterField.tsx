import { useState, memo, type PropsWithChildren } from "react";
import { View, type LayoutRectangle } from "react-native";
import { type PropsWithOptionalTestID } from "@boi/components-core";

import { useStateStyles } from "./OuterField.styles";

export type OuterFieldProps = PropsWithOptionalTestID & {
  hasFocus?: boolean;
  hasError?: boolean;
  isActive?: boolean;
  isReadOnly?: boolean;
  isDisabled?: boolean;
};

const OuterField = memo(
  (props: PropsWithOptionalTestID & PropsWithChildren<OuterFieldProps>) => {
    const { testID, children, ...outerFieldProps } = props;

    const [containerLayout, setContainerLayout] = useState<LayoutRectangle>();
    const stateStyles = useStateStyles(outerFieldProps, containerLayout);

    return (
      <View
        testID={testID}
        onLayout={(event) => setContainerLayout(event.nativeEvent.layout)}
        style={stateStyles.container}
      >
        <View
          testID={testID ? `${testID}-focus-ring` : undefined}
          style={stateStyles.focusRing}
        />
        <View style={stateStyles.stroke} />
        {children}
      </View>
    );
  }
);

export default OuterField;
