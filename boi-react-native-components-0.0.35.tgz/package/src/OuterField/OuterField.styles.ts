import { type LayoutRectangle, type ViewStyle, StyleSheet } from "react-native";
import {
  useDesignTokens,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";
import { type OuterFieldProps } from "./OuterField";

function styleSheetFactory(tokens: ThemeTokens) {
  const { outerField } = tokens;

  const container = StyleSheet.create({
    base: {
      width: "100%",
      position: "relative",
    },
  });

  const stroke = StyleSheet.create({
    base: {
      position: "absolute",
      width: "100%",
      height: "100%",
      backgroundColor: outerField.backgroundColor,

      borderRadius: outerField.radius,
      borderColor: outerField.stroke.color.base,
      borderWidth: outerField.stroke.width.base,
      borderStyle: "solid",
    },
    isReadOnly: {
      borderColor: outerField.stroke.color.readOnly,
    },
    isDisabled: {
      borderColor: outerField.stroke.color.disabled,
    },
    isActive: {
      borderColor: outerField.stroke.color.active,
      borderWidth: outerField.stroke.width.active,
    },
    hasError: {
      borderColor: outerField.stroke.color.error,
      borderWidth: outerField.stroke.width.error,
    },
  });

  const focusRing = StyleSheet.create({
    base: {
      position: "absolute",
      width: "100%",
      height: "100%",
      padding: 4,
      borderColor: outerField.focusRing.color,
      borderWidth: outerField.focusRing.width.base,
      borderStyle: "solid",
      borderRadius: outerField.radius,
    },
    hasFocus: {
      borderWidth: outerField.focusRing.width.focus,
    },
  });

  return {
    container,
    stroke,
    focusRing,
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(
  { hasError, hasFocus, isActive, isDisabled, isReadOnly }: OuterFieldProps,
  containerLayout: LayoutRectangle | undefined
) {
  const { container, focusRing, stroke } = useStyles();
  const focusRingFocusedStyles = useFocusRingStyles(containerLayout);

  return {
    container: [container.base],
    stroke: [
      stroke.base,
      isDisabled && stroke.isDisabled,
      isReadOnly && stroke.isReadOnly,
      hasError && stroke.hasError,
      isActive && stroke.isActive,
    ],
    focusRing: [
      focusRing.base,
      hasFocus && focusRing.hasFocus,
      hasFocus && containerLayout && focusRingFocusedStyles,
    ],
  };
}

function useFocusRingStyles(
  containerLayout: LayoutRectangle | undefined
): ViewStyle {
  const {
    tokens: { outerField },
  } = useDesignTokens();

  if (!containerLayout) {
    return {};
  }

  const offset: number = outerField.focusRing.offset.focus;
  const borderWidth = outerField.focusRing.width.focus;

  return {
    width: containerLayout.width + (offset + borderWidth) * 2,
    height: containerLayout.height + (offset + borderWidth) * 2,
    top: -borderWidth - offset,
    left: -borderWidth - offset,
    borderRadius: outerField.radius + borderWidth + offset,
  };
}

export default useStyles;
