import { render, screen, fireEvent } from "@testing-library/react-native";
import { StyleSheet } from "react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import OuterField, { type OuterFieldProps } from "./OuterField";

function WrappedOuterField(props: OuterFieldProps) {
  return (
    <DesignTokensProvider>
      <OuterField {...props} />
    </DesignTokensProvider>
  );
}

describe("OuterField", () => {
  let baseProps: OuterFieldProps;

  beforeEach(() => {
    baseProps = {
      testID: "field",
    };
  });

  it("should render", async () => {
    render(<WrappedOuterField {...baseProps} />);

    const field = screen.getByTestId("field");

    expect(field).toBeVisible();
  });

  it("should listen to onLayout events and calculate the focusRing accordingly", async () => {
    render(<WrappedOuterField {...baseProps} hasFocus hasError />);

    const field = screen.getByTestId("field");
    fireEvent(field, "layout", {
      nativeEvent: { layout: { height: 100, width: 100 } },
    });

    const focusRing = screen.getByTestId("field-focus-ring");
    expect(StyleSheet.flatten(focusRing.props.style)).toMatchObject({
      width: 108,
      height: 108,
    });
  });
});
