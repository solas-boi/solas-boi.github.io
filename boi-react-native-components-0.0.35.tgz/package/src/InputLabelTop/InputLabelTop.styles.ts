import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { inputLabelTop } = tokens;

  const styles = StyleSheet.create({
    container: {
      display: "flex",
      gap: inputLabelTop.gap,
    },
    inputWrapper: {
      flexShrink: 0,
    },
    label: {
      color: inputLabelTop.label.color,
    },
    labelHint: {
      color: inputLabelTop.labelHint.color,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
