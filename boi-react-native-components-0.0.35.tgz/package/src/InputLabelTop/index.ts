export {
  default as InputLabelTop,
  type InputLabelTopProps,
} from "./InputLabelTop";
