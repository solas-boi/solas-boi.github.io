import { View, type ViewProps } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./InputLabelTop.styles";
import { Typography } from "../Typography";
import {
  TypographyTooltip,
  type TypographyTooltipProps,
} from "../TypographyTooltip";

export type InputLabelTopProps = Omit<ViewProps, "style"> & {
  label?: string;
  labelTooltipProps?: Omit<
    TypographyTooltipProps,
    "typographyVariant" | "otherIconButtonProps"
  >;
  labelHint?: string;
  labelHintTooltipProps?: Omit<
    TypographyTooltipProps,
    "typographyVariant" | "otherIconButtonProps"
  >;
};

function InputLabelTop(props: InputLabelTopProps) {
  const {
    label,
    labelTooltipProps,
    labelHint,
    labelHintTooltipProps,
    children,
    ...labelProps
  } = props;

  const { tokens } = useDesignTokens();
  const { inputLabelTop } = tokens;

  const styles = useStyles();

  return (
    <View {...labelProps} style={styles.container}>
      {(label || labelHint) && (
        <View>
          {label && (
            <LabelWrapper labelTooltipProps={labelTooltipProps}>
              <Typography
                component="div"
                style={styles.label}
                variant={inputLabelTop.label.typography.variant}
                fontFamily={inputLabelTop.label.typography.fontFamily}
              >
                {label}
              </Typography>
            </LabelWrapper>
          )}

          {labelHint && (
            <LabelHintWrapper labelHintTooltipProps={labelHintTooltipProps}>
              <Typography
                component="div"
                style={styles.labelHint}
                variant={inputLabelTop.labelHint.typography.variant}
                fontFamily={inputLabelTop.labelHint.typography.fontFamily}
              >
                {labelHint}
              </Typography>
            </LabelHintWrapper>
          )}
        </View>
      )}

      <View style={styles.inputWrapper}>{children}</View>
    </View>
  );
}

type LabelWrapperProps = Pick<
  InputLabelTopProps,
  "labelTooltipProps" | "children"
>;

function LabelWrapper(props: LabelWrapperProps) {
  const { labelTooltipProps, children } = props;

  const { tokens } = useDesignTokens();
  const { inputLabelTop } = tokens;

  if (labelTooltipProps) {
    return (
      <TypographyTooltip
        {...labelTooltipProps}
        otherIconButtonProps={{
          variant: "default",
        }}
        typographyVariant={inputLabelTop.label.typography.variant}
      >
        {children}
      </TypographyTooltip>
    );
  }

  return children;
}

type LabelHintWrapperProps = Pick<
  InputLabelTopProps,
  "labelHintTooltipProps" | "children"
>;

function LabelHintWrapper(props: LabelHintWrapperProps) {
  const { labelHintTooltipProps, children } = props;

  const { tokens } = useDesignTokens();
  const { inputLabelTop } = tokens;

  if (labelHintTooltipProps) {
    return (
      <TypographyTooltip
        {...labelHintTooltipProps}
        otherIconButtonProps={{
          variant: "default20",
        }}
        typographyVariant={inputLabelTop.labelHint.typography.variant}
      >
        {children}
      </TypographyTooltip>
    );
  }

  return children;
}

export default InputLabelTop;
