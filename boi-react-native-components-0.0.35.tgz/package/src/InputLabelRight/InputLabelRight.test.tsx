import { render } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import InputLabelRight, { type InputLabelRightProps } from "./InputLabelRight";

jest.useFakeTimers();

function WrappedInputLabelRight(props: InputLabelRightProps) {
  return (
    <DesignTokensProvider>
      <InputLabelRight {...props} />
    </DesignTokensProvider>
  );
}

describe("InputLabelRight", () => {
  it("should render focus ring if hasFocus prop is true", () => {
    const renderComponent = () => render(<WrappedInputLabelRight hasFocus />);

    expect(renderComponent).not.toThrow();
  });
});
