import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { type InputLabelRightProps } from "./InputLabelRight";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { inputLabelRight } = tokens;

  const styles = StyleSheet.create({
    container: {
      display: "flex",
      flexDirection: "row",
      gap: inputLabelRight.gap,
      width: "100%",
    },
    inputWrapper: {
      display: "flex",
      justifyContent: "center",
      height: parseSizeToken(inputLabelRight.inputWrapper.height, fontScale),
      flexShrink: 0,
    },
    labelWrapper: {
      flexShrink: 1,
    },
    label: {
      color: inputLabelRight.label.color.base,
    },
    labelDisabled: {
      color: inputLabelRight.label.color.disabled,
    },
    focusRing: {
      position: "absolute",
      borderRadius:
        inputLabelRight.focusRing.radius +
        inputLabelRight.focusRing.offset +
        inputLabelRight.focusRing.width,
      borderWidth: inputLabelRight.focusRing.width,
      borderColor: inputLabelRight.focusRing.color,
      left:
        -1 *
        (inputLabelRight.focusRing.offset + inputLabelRight.focusRing.width),
      top:
        -1 *
        (inputLabelRight.focusRing.offset + inputLabelRight.focusRing.width),
      right:
        -1 *
        (inputLabelRight.focusRing.offset + inputLabelRight.focusRing.width),
      bottom:
        -1 *
        (inputLabelRight.focusRing.offset + inputLabelRight.focusRing.width),
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  isDisabled,
}: Pick<InputLabelRightProps, "isDisabled">) {
  const styles = useStyles();

  return {
    label: [styles.label, isDisabled && styles.labelDisabled],
  };
}

export default useStyles;
