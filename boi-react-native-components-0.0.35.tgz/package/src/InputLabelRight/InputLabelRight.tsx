import { View, type ViewProps } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles, { useStateStyles } from "./InputLabelRight.styles";
import { Typography } from "../Typography";

export type InputLabelRightProps = Omit<ViewProps, "style"> & {
  label?: string;
  isDisabled?: boolean;
  hasFocus?: boolean;
};

function InputLabelRight(props: InputLabelRightProps) {
  const { label, isDisabled, hasFocus, children, ...labelProps } = props;

  const { tokens } = useDesignTokens();
  const { inputLabelRight } = tokens;

  const styles = useStyles();
  const stateStyles = useStateStyles({ isDisabled });

  return (
    <View {...labelProps} style={styles.container}>
      {hasFocus && <View pointerEvents="none" style={styles.focusRing} />}
      <View style={styles.inputWrapper}>{children}</View>

      <View style={styles.labelWrapper}>
        {label && (
          <Typography
            component="div"
            style={stateStyles.label}
            variant={inputLabelRight.label.typography.variant}
            fontFamily={inputLabelRight.label.typography.fontFamily}
          >
            {label}
          </Typography>
        )}
      </View>
    </View>
  );
}

export default InputLabelRight;
