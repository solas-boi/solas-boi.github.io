export {
  default as InputLabelRight,
  type InputLabelRightProps,
} from "./InputLabelRight";
