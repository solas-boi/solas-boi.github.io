import { enIE, enGB } from "date-fns/locale";

export const MINIMUM_INPUT_LENGTH = 14;

export const DATE_FNS_LOCALES = {
  "en-IE": enIE,
  "en-GB": enGB,
} as const;

export const DATE_FORMATS = {
  "en-IE": "dd / MM / yyyy",
  "en-GB": "dd / MM / yyyy",
} as const;

export const DATE_MASKS = {
  "en-IE": "DD / MM / YYYY",
  "en-GB": "DD / MM / YYYY",
} as const;
