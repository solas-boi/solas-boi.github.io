import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { datePicker, typography } = tokens;

  return StyleSheet.create({
    container: {
      flexDirection: "row",
      alignItems: "center",
      minHeight: datePicker.input.minHeight,
      paddingLeft: datePicker.input.padding.left,
      paddingRight: datePicker.input.padding.right,
    },
    dateInput: {
      flex: 1,
    },
    maskedInput: {
      flex: 1,
      fontFamily: typography.fontFamily.bodyM,
      fontSize: parseSizeToken(typography.fontSize.bodyM, fontScale),
      // TODO: Find out why we need a -2 here for it to look right and why lineHeight is not taken into account on Android
      lineHeight: parseSizeToken(typography.lineHeight.bodyM, fontScale) - 2,
      color: datePicker.input.segment.color.base,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
