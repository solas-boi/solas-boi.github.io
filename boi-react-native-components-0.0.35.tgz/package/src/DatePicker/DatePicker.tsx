import { useState, useEffect, useCallback, forwardRef } from "react";
import { TextInput, TextInputProps, View } from "react-native";
import { KeyboardExtendedInput } from "react-native-external-keyboard";
import { parse, format, isValid } from "date-fns";
import { mask, unMask } from "react-native-mask-text";
import {
  CoreDatePicker,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./DatePicker.styles";
import {
  MINIMUM_INPUT_LENGTH,
  DATE_FNS_LOCALES,
  DATE_FORMATS,
  DATE_MASKS,
} from "./DatePicker.constants";
import { DatePickerCalendar } from "./DatePickerCalendar";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { OuterField } from "../OuterField";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type CommonProps = {
  locale?: CoreDatePicker.Locale;
  date?: Date | undefined | null;
  onChange: (date: Date | undefined | null) => void;
};

/**
 * @deprecated - use DatePickerV2Props instead
 */
export type DatePickerProps = PropsWithOptionalTestID &
  CommonProps & {
    labelProps: Omit<InputLabelTopProps, "children">;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    hasError?: boolean;
    withCalendar?: boolean;
    inputAccessoryViewID?: string;
    maximumDate?: Date;
    minimumDate?: Date;
  } & Omit<
    TextInputProps,
    | "value"
    | "defaultValue"
    | "onChange"
    | "allowFontScaling"
    | "maxLength"
    | "placeholder"
    | "placeholderTextColor"
    | "style"
  >;

export const DEFAULT_INPUT_ACCESSORY_VIEW_ID =
  "DEFAULT_INPUT_ACCESSORY_VIEW_ID";

const getMaskedValue = (value: string, locale: CoreDatePicker.Locale) =>
  mask(
    value,
    DATE_MASKS[locale],
    "date",
    {
      dateFormat: DATE_FORMATS[locale],
    },
    false
  );
const getUnMaskedValue = (value: string) => unMask(value, "custom");

/**
 * @deprecated - use DatePickerV2 instead
 */
const DatePicker = forwardRef<TextInput, DatePickerProps>((props, ref) => {
  const {
    labelProps,
    alertProps,
    hasError,
    withCalendar,
    locale = CoreDatePicker.DEFAULT_LOCALE,
    date,
    onChange,
    onChangeText,
    inputAccessoryViewID,
    testID = "date-picker",
    onBlur,
    onFocus,
    maximumDate,
    minimumDate,
    ...textInputProps
  } = props;

  const { tokens } = useDesignTokens();
  const { datePicker } = tokens;

  const [hasFocus, setHasFocus] = useState(false);
  const [maskedValue, setMaskedValue] = useState("");

  useEffect(() => {
    if (date && isValid(date)) {
      setMaskedValue(
        format(date, DATE_FORMATS[locale], {
          locale: DATE_FNS_LOCALES[locale],
        })
      );
    }

    if (date === null) {
      setMaskedValue("");
    }
  }, [date, locale]);

  const handleFocus = useCallback<NonNullable<typeof onFocus>>(
    (evt) => {
      setHasFocus(true);
      onFocus?.(evt);
    },
    [onFocus]
  );
  const handleBlur = useCallback<NonNullable<typeof onBlur>>(
    (evt) => {
      setHasFocus(false);

      const masked = getMaskedValue(maskedValue, locale);
      setMaskedValue(masked);
      onChangeText?.(masked);

      onBlur?.(evt);
    },
    [onBlur, onChangeText, maskedValue, locale]
  );

  function handleOnChangeText(text: string) {
    if (maskedValue.length > text.length) {
      /*
      If new value length is less than previous value
      Then it means it's deleting characters
      So we don't try to mask the value as to prevent the bug where
      you can't delete a mask character
      */
      setMaskedValue(text);
      onChangeText?.(text);
      return;
    }
    const unmasked = getUnMaskedValue(text);
    const masked = getMaskedValue(unmasked, locale);

    if (masked === maskedValue) {
      return;
    }

    setMaskedValue(masked);
    onChangeText?.(masked);

    if (masked.length === MINIMUM_INPUT_LENGTH) {
      const parsedDate = parse(masked, DATE_FORMATS[locale], new Date(), {
        locale: DATE_FNS_LOCALES[locale],
      });

      if (isValid(parsedDate)) {
        return onChange(parsedDate);
      }
    }

    if (date !== undefined) {
      return onChange(undefined);
    }
  }

  const styles = useStyles();

  const a11yLabelWithAlerts = labelProps.label + ".";

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <View testID={testID}>
          <OuterField
            hasFocus={hasFocus}
            isActive={hasFocus}
            hasError={hasError}
          >
            <ScreenReaderAlertNotifier
              alert={alertProps}
              style={styles.container}
            >
              <KeyboardExtendedInput
                {...textInputProps}
                tintType="none"
                onFocusChange={(isFocused) => {
                  setHasFocus(isFocused);
                }}
                ref={ref}
                inputAccessoryViewID={
                  inputAccessoryViewID || DEFAULT_INPUT_ACCESSORY_VIEW_ID
                }
                allowFontScaling={false}
                maxLength={DATE_MASKS[locale].length}
                placeholder={DATE_MASKS[locale]}
                value={maskedValue}
                onChangeText={handleOnChangeText}
                placeholderTextColor={datePicker.input.segment.placeholderColor}
                onFocus={handleFocus}
                onBlur={handleBlur}
                containerStyle={styles.dateInput}
                style={styles.maskedInput}
                accessibilityLabel={a11yLabelWithAlerts}
                accessibilityHint={labelProps.labelHint}
                testID={`${testID}-masked-input`}
              />

              {withCalendar && (
                <DatePickerCalendar
                  locale={locale}
                  date={date}
                  onChange={onChange}
                  setHasFocus={setHasFocus}
                  testID={testID}
                  maximumDate={maximumDate}
                  minimumDate={minimumDate}
                />
              )}
            </ScreenReaderAlertNotifier>
          </OuterField>
        </View>
      </InputLabelTop>
    </InputWrapper>
  );
});

DatePicker.displayName = "DatePicker";

export default DatePicker;
