import { useState } from "react";
import { View } from "react-native";
import { isValid } from "date-fns";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { type PropsWithTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CalendarIcon } from "@boi/react-native-icons";

import { type CommonProps } from "../DatePicker";

export type DatePickerCalendarProps = PropsWithTestID &
  CommonProps & {
    setHasFocus: (value: boolean) => void;
    maximumDate?: Date;
    minimumDate?: Date;
  };

function DatePickerCalendar(props: DatePickerCalendarProps) {
  const { onChange, setHasFocus, testID, date, ...otherProps } = props;

  const [isVisible, setIsVisible] = useState(false);

  const { tokens } = useDesignTokens();
  const { datePicker } = tokens;

  function handlePress() {
    setIsVisible(true);
    setHasFocus(true);
  }

  function handleConfirm(newDate: Date) {
    setIsVisible(false);
    setHasFocus(false);
    onChange(newDate);
  }

  function handleCancel() {
    setIsVisible(false);
    setHasFocus(false);
  }

  return (
    <>
      <KeyboardPressable
        enableA11yFocus
        role="button"
        accessibilityRole="button"
        onPress={handlePress}
        aria-label="Calendar"
        testID={`${testID}-calendar-button`}
      >
        <View
          style={{
            padding: datePicker.input.button.padding,
            borderRadius: datePicker.input.button.radius,
            backgroundColor:
              datePicker.input.button.backgroundColor[
                isVisible ? "focus" : "base"
              ],
          }}
        >
          <CalendarIcon
            width={datePicker.input.button.icon.width}
            height={datePicker.input.button.icon.height}
            color={
              datePicker.input.button.icon.color[isVisible ? "focus" : "base"]
            }
          />
        </View>
      </KeyboardPressable>

      <DateTimePickerModal
        {...otherProps}
        date={date instanceof Date && isValid(date) ? date : undefined}
        mode="date"
        display="inline"
        isVisible={isVisible}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
        testID={`${testID}-modal`}
      />
    </>
  );
}

export default DatePickerCalendar;
