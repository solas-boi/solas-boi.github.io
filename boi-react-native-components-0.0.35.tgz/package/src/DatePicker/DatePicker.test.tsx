import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreDatePicker } from "@boi/components-core";

import DatePicker, { type DatePickerProps } from "./DatePicker";
import { DATE_MASKS } from "./DatePicker.constants";

jest.useFakeTimers();

function WrappedDatePicker(props: DatePickerProps) {
  return (
    <DesignTokensProvider>
      <DatePicker {...props} />
    </DesignTokensProvider>
  );
}

describe("DatePicker", () => {
  let baseProps: DatePickerProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "DatePicker Label",
      },
      onChange: jest.fn(),
    };
  });

  it("should render with the correct placeholder text", () => {
    render(<WrappedDatePicker {...baseProps} />);

    const placeholder = DATE_MASKS[CoreDatePicker.DEFAULT_LOCALE];
    const input = screen.getByPlaceholderText(placeholder);

    expect(input).toBeDefined();
  });

  it("should render with the correct formatted date when provided", () => {
    render(<WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />);

    const input = screen.getByTestId("date-picker-masked-input");

    expect(input).toHaveDisplayValue("31 / 01 / 2020");
  });

  it("should trigger the onChange event when a valid date is entered", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedDatePicker {...baseProps} onChange={mockOnChange} />);

    const input = screen.getByTestId("date-picker-masked-input");

    await act(async () => {
      await user.type(input, "31012020");
    });

    expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 0, 31));
  }, 15000);

  it("should not trigger the onChange event when an invalid date is entered", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedDatePicker {...baseProps} onChange={mockOnChange} />);

    const input = screen.getByTestId("date-picker-masked-input");

    await act(async () => {
      await user.type(input, "99999999");
    });

    expect(mockOnChange).not.toHaveBeenCalled();
  });

  it("should trigger the onChangeText event when the input is modified", async () => {
    const user = userEvent.setup();

    const mockOnChangeText = jest.fn();

    render(
      <WrappedDatePicker {...baseProps} onChangeText={mockOnChangeText} />
    );

    const input = screen.getByTestId("date-picker-masked-input");

    await act(async () => {
      await user.type(input, "31");
    });

    expect(mockOnChangeText).toHaveBeenLastCalledWith("31");

    await act(async () => {
      await user.type(input, "01");
    });

    expect(mockOnChangeText).toHaveBeenLastCalledWith("31 / 01");

    await act(async () => {
      await user.type(input, "2020");
    });

    expect(mockOnChangeText).toHaveBeenLastCalledWith("31 / 01 / 2020");
  });

  it("should not mask the value if the user deletes some of the value", async () => {
    const user = userEvent.setup();
    const mockOnChangeText = jest.fn();

    render(
      <WrappedDatePicker {...baseProps} onChangeText={mockOnChangeText} />
    );

    const input = screen.getByTestId("date-picker-masked-input");

    await act(async () => {
      await user.type(input, "31012000");
    });

    expect(mockOnChangeText).toHaveBeenLastCalledWith("31 / 01 / 2000");

    await act(async () => {
      await user.clear(input);
    });

    await act(async () => {
      await user.type(input, "31 / 01/");
    });

    expect(mockOnChangeText).toHaveBeenLastCalledWith("31 / 01");
  });

  it("should call custom onFocus handler", async () => {
    const user = userEvent.setup();
    const mockOnFocus = jest.fn();

    render(<WrappedDatePicker {...baseProps} onFocus={mockOnFocus} />);

    const input = screen.getByTestId("date-picker-masked-input");

    await user.type(input, "Something");

    expect(mockOnFocus).toHaveBeenCalledTimes(1);
  });

  it("should call custom onBlur handler", async () => {
    const user = userEvent.setup();
    const mockOnBlur = jest.fn();

    render(<WrappedDatePicker {...baseProps} onBlur={mockOnBlur} />);

    const input = screen.getByTestId("date-picker-masked-input");

    await user.type(input, "Something");

    expect(mockOnBlur).toHaveBeenCalledTimes(1);
  });

  it("should render an alert when alertProps are provided", () => {
    render(
      <WrappedDatePicker
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("date-picker-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });

  it("should render with a default testID", () => {
    render(<WrappedDatePicker {...baseProps} />);

    expect(screen.getByTestId("date-picker")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-date-picker";

    render(<WrappedDatePicker {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  describe("with calendar", () => {
    it("should render with the correct role", () => {
      render(<WrappedDatePicker {...baseProps} withCalendar />);

      const button = screen.getByRole("button", {
        name: "Calendar",
      });

      expect(button).toBeDefined();
    });

    it("should render without a modal by default", () => {
      render(<WrappedDatePicker {...baseProps} withCalendar />);

      const modal = screen.queryByTestId("date-picker-modal");

      expect(modal).toBeNull();
    });

    it("should render with a modal when the calendar button is clicked", async () => {
      const user = userEvent.setup();

      render(<WrappedDatePicker {...baseProps} withCalendar />);

      const button = screen.getByRole("button", {
        name: "Calendar",
      });

      await act(async () => {
        await user.press(button);
      });

      const modal = screen.findByTestId("date-picker-modal");

      expect(modal).toBeDefined();
    });
  });

  it("should reset maskedValue if date is null", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    const { rerender } = render(
      <WrappedDatePicker {...baseProps} onChange={mockOnChange} />
    );

    const input = screen.getByTestId("date-picker-masked-input");

    await act(async () => {
      await user.type(input, "31012020");
    });

    expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 0, 31));

    rerender(<WrappedDatePicker {...baseProps} date={null} />);

    const placeholder = DATE_MASKS[CoreDatePicker.DEFAULT_LOCALE];
    const placeholderInput = screen.getByPlaceholderText(placeholder);

    expect(placeholderInput).toBeDefined();
    expect(placeholderInput).toHaveDisplayValue("");
  });
});
