import { StyleSheet } from "react-native";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory() {
  return StyleSheet.create({
    container: {
      display: "flex",
      gap: 8,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles(gap: number = 8) {
  const styles = useStyles();
  return {
    container: [styles.container, { gap }],
  };
}

export default useStyles;
