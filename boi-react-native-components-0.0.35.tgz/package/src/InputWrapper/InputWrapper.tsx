import { type PropsWithChildren, type ReactNode } from "react";
import { View } from "react-native";

import { useStateStyles } from "./InputWrapper.styles";

export type InputWrapperProps = PropsWithChildren & {
  alert?: ReactNode;
  gap?: number;
};

function InputWrapper(props: InputWrapperProps) {
  const { alert, gap, children } = props;

  const styles = useStateStyles(gap);

  return (
    <View style={styles.container}>
      {children}
      {alert && alert}
    </View>
  );
}

export default InputWrapper;
