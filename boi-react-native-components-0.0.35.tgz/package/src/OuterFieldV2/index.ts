export {
  default as OuterFieldV2,
  type OuterFieldV2Props,
} from "./OuterFieldV2";
