import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { type OuterFieldV2Props } from "./OuterFieldV2";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { outerField } = tokens;
  const { stroke, focusRing } = outerField;

  return StyleSheet.create({
    innerContainer: {
      display: "flex",
      flexDirection: "row",
      minHeight: outerField.minHeight,
      borderRadius: outerField.radius,
      backgroundColor: outerField.backgroundColor,
    },
    innerContainerWithGap: {
      gap: outerField.gap,
    },
    column01: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      gap: outerField.column01.gap,
      paddingLeft: outerField.column01.padding.left,
      paddingRight: outerField.column01.padding.right.base,
    },
    column01WithButton: {
      paddingRight: outerField.column01.padding.right.withButton,
    },
    startSlotWrapper: {
      display: "flex",
      alignItems: "center",
      flexShrink: 0,
      width: outerField.column01.startSlot.width,
      height: outerField.column01.startSlot.height,
      overflow: "hidden",
    },
    endSlotWrapper: {
      display: "flex",
      alignItems: "center",
      flexShrink: 0,
      width: outerField.column01.endSlot.width,
      height: outerField.column01.endSlot.height,
      overflow: "hidden",
    },
    innerButtonSlotWrapper: {
      margin: outerField.column01.innerButtonSlot.margin,
      display: "flex",
      justifyContent: "center",
    },
    column02: {
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      flexShrink: 0,
      paddingRight: outerField.column02.padding.right,
    },
    stroke: {
      position: "absolute",
      top: stroke.offset.base + stroke.width.base,
      left: stroke.offset.base + stroke.width.base,
      right: stroke.offset.base + stroke.width.base,
      bottom: stroke.offset.base + stroke.width.base,
      borderWidth: stroke.width.base,
      borderStyle: stroke.style,
      borderColor: stroke.color.base,
      borderRadius: outerField.radius + stroke.offset.base,
    },
    strokeError: {
      top: stroke.offset.error + stroke.width.error,
      left: stroke.offset.error + stroke.width.error,
      right: stroke.offset.error + stroke.width.error,
      bottom: stroke.offset.error + stroke.width.error,
      borderWidth: stroke.width.error,
      borderStyle: stroke.style,
      borderColor: stroke.color.error,
      borderRadius: outerField.radius + stroke.offset.error,
    },
    strokeActive: {
      top: stroke.offset.active + stroke.width.active,
      left: stroke.offset.active + stroke.width.active,
      right: stroke.offset.active + stroke.width.active,
      bottom: stroke.offset.active + stroke.width.active,
      borderWidth: stroke.width.active,
      borderStyle: stroke.style,
      borderColor: stroke.color.active,
      borderRadius: outerField.radius + stroke.offset.active,
    },
    strokeDisabled: {
      top: stroke.offset.base + stroke.width.base,
      left: stroke.offset.base + stroke.width.base,
      right: stroke.offset.base + stroke.width.base,
      bottom: stroke.offset.base + stroke.width.base,
      borderWidth: stroke.width.base,
      borderStyle: stroke.style,
      borderColor: stroke.color.disabled,
      borderRadius: outerField.radius + stroke.offset.base,
    },
    focusRing: {
      position: "absolute",
      top: -1 * (focusRing.offset.focus + focusRing.width.focus),
      left: -1 * (focusRing.offset.focus + focusRing.width.focus),
      right: -1 * (focusRing.offset.focus + focusRing.width.focus),
      bottom: -1 * (focusRing.offset.focus + focusRing.width.focus),
      borderWidth: focusRing.width.focus,
      borderStyle: focusRing.style,
      borderColor: focusRing.color,
      borderRadius: outerField.radius + focusRing.offset.focus,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  hasError,
  hasFocus,
  isActive,
  isDisabled,
  innerButtonSlot,
  endSlot,
  buttonSlot,
}: Pick<
  OuterFieldV2Props,
  | "hasError"
  | "hasFocus"
  | "isDisabled"
  | "isActive"
  | "innerButtonSlot"
  | "endSlot"
  | "buttonSlot"
>) {
  const styles = useStyles();

  return {
    innerContainer: [
      styles.innerContainer,
      innerButtonSlot || endSlot
        ? undefined
        : styles.innerContainerWithGap,
    ],
    column01: [
      styles.column01,
      buttonSlot ? styles.column01WithButton : undefined,
    ],
    stroke: [
      styles.stroke,
      hasError ? styles.strokeError : undefined,
      isActive ? styles.strokeActive : undefined,
      isDisabled ? styles.strokeDisabled : undefined,
    ],
    focusRing: [!isDisabled && hasFocus ? styles.focusRing : undefined],
  };
}

export default useStyles;
