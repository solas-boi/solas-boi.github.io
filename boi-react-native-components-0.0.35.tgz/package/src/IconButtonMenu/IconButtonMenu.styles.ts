import { StyleSheet } from "react-native";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { iconButtonMenu } = tokens;

  return StyleSheet.create({
    listItemContent: {
      display: "flex",
      flexDirection: "row",
      gap: iconButtonMenu.menu.item.content.gap,
      paddingTop: iconButtonMenu.menu.item.content.padding.top,
      paddingLeft: iconButtonMenu.menu.item.content.padding.left,
      paddingRight: iconButtonMenu.menu.item.content.padding.right,
      paddingBottom: iconButtonMenu.menu.item.content.padding.bottom,
    },
    listItemIconWrapper: {
      display: "flex",
      justifyContent: "center",
      height: parseSizeToken(
        iconButtonMenu.menu.item.content.iconWrapper.height,
        fontScale
      ),
    },
    listItemTypographyWrapper: {
      flexShrink: 1,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
