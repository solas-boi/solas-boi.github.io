import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { CoreMenu, CoreIconButton } from "@boi/components-core";
import { MoreVerticalIcon, AddCardIcon } from "@boi/react-native-icons";

import IconButtonMenu from "./IconButtonMenu";
import { IconButton } from "../IconButton";

const meta = {
  title: "Navigation/IconButtonMenu",
  component: IconButtonMenu,
  render: function Render(args) {
    return (
      <View>
        <IconButtonMenu
          {...args}
          supportedOrientations={["landscape", "portrait"]}
        >
          {(referenceProps) => (
            <IconButton
              variant={args.variant}
              aria-label="Burger menu"
              {...referenceProps}
            >
              <MoreVerticalIcon />
            </IconButton>
          )}
        </IconButtonMenu>
      </View>
    );
  },
  argTypes: {
    variant: {
      control: { type: "select" },
      options: CoreIconButton.VARIANTS,
    },
    placement: { control: { disable: true } },
  },
  args: {
    variant: CoreIconButton.DEFAULT_VARIANT,
    placement: CoreMenu.DEFAULT_PLACEMENT,
    items: [
      {
        id: "item-01",
        text: "Item 01",
        onPress: () => {},
      },
      {
        id: "item-02",
        text: "Item 02",
        onPress: () => {},
      },
      {
        id: "item-03",
        text: "Item 03",
        onPress: () => {},
      },
      {
        id: "item-04",
        text: "Item 04",
        onPress: () => {},
      },
      {
        id: "item-05",
        text: "Item 05",
        onPress: () => {},
      },
      {
        id: "item-06",
        text: "Item 06",
        onPress: () => {},
      },
      {
        id: "item-07",
        text: "Item 07",
        onPress: () => {},
      },
      {
        id: "item-08",
        text: "Item 08",
        onPress: () => {},
      },
      {
        id: "item-09",
        text: "Item 09",
        onPress: () => {},
      },
    ],
  },
} satisfies Meta<typeof IconButtonMenu>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  decorators: [
    (Story) => (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "flex-end",
        }}
      >
        <Story />
      </View>
    ),
  ],
};

export const WithIcons: Story = {
  decorators: [
    (Story) => (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "flex-end",
        }}
      >
        <Story />
      </View>
    ),
  ],
  args: {
    items: [
      {
        id: "item-01",
        icon: <AddCardIcon />,
        text: "Item 01",
        onPress: () => {},
      },
      {
        id: "item-02",
        icon: <AddCardIcon />,
        text: "Item 02",
        onPress: () => {},
      },
      {
        id: "item-03",
        icon: <AddCardIcon />,
        text: "Item 03",
        onPress: () => {},
      },
    ],
  },
};

export const PlacementLeft: Story = {
  args: {
    placement: "bottom-start",
  },
};

export const DisabledItemsWithIcons: Story = {
  args: {
    placement: "bottom-start",
    items: [
      {
        id: "item-01",
        icon: <AddCardIcon />,
        text: "Item 01",
        onPress: () => {},
      },
      {
        id: "item-02",
        icon: <AddCardIcon />,
        text: "Item 02",
        onPress: () => {},
      },
      {
        id: "item-03",
        icon: <AddCardIcon />,
        text: "Item 03",
        onPress: () => {},
      },
    ],
    disabledKeys: ["item-02", "item-03"],
  },
};
