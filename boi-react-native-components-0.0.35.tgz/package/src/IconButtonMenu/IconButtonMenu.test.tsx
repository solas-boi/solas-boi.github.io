import {
  render,
  screen,
  userEvent,
  act,
  waitFor,
} from "@testing-library/react-native";
import { View } from "react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { MoreVerticalIcon } from "@boi/react-native-icons";

import IconButtonMenu, { type IconButtonMenuProps } from "./IconButtonMenu";
import { IconButton } from "../IconButton";

jest.useFakeTimers();

function WrappedIconButtonMenu(props: IconButtonMenuProps) {
  return (
    <DesignTokensProvider>
      <IconButtonMenu {...props} />
    </DesignTokensProvider>
  );
}

const MockIcon = (props: any) => {
  return <View testID={props.testID ?? "mock-icon"} />;
};

describe("IconButtonMenu", () => {
  let baseProps: IconButtonMenuProps;

  beforeEach(() => {
    baseProps = {
      items: [
        {
          id: "item-01",
          text: "Item 01",
          onPress: jest.fn(),
        },
        {
          id: "item-02",
          text: "Item 02",
          onPress: jest.fn(),
        },
        {
          id: "item-03",
          text: "Item 03",
          onPress: jest.fn(),
        },
      ],
      children: (referenceProps) => (
        <IconButton
          {...referenceProps}
          aria-label="Burger menu"
          testID="burger-menu-button"
        >
          <MoreVerticalIcon />
        </IconButton>
      ),
    };
  });

  it("should render a trigger button", async () => {
    render(<WrappedIconButtonMenu {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    expect(button).toBeDefined();
  });

  it("should not render the menu on mount", async () => {
    render(<WrappedIconButtonMenu {...baseProps} />);

    const menu = screen.queryByTestId("icon-button-menu");

    expect(menu).toBeNull();
  });

  it("should render the menu once the IconButton is clicked", async () => {
    const user = userEvent.setup();

    render(<WrappedIconButtonMenu {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const menu = await screen.findByTestId("icon-button-menu");

    expect(menu).toBeDefined();
  });

  it("should render the correct number of menu items", async () => {
    const user = userEvent.setup();

    render(<WrappedIconButtonMenu {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const menuItems = await screen.findAllByTestId(
      /icon-button-menu-item-item-\d+/
    );

    expect(menuItems).toHaveLength(baseProps.items.length);
  });

  it("should trigger the onPress event when the menu item is clicked", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(
      <WrappedIconButtonMenu
        {...baseProps}
        items={[
          {
            id: "item-01",
            text: "Item 01",
            onPress: mockOnPress,
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const menuItem = await screen.findByTestId("icon-button-menu-item-item-01");

    await act(async () => {
      await user.press(menuItem);
    });

    expect(mockOnPress).toHaveBeenCalled();
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it("should render with a default testID", async () => {
    const user = userEvent.setup();

    render(<WrappedIconButtonMenu {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    expect(screen.findByTestId("icon-button-menu")).toBeDefined();
  });

  it("should render with a custom testID", async () => {
    const user = userEvent.setup();
    const testID = "custom-icon-button-menu";

    render(<WrappedIconButtonMenu {...baseProps} testID={testID} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    expect(screen.findByTestId(testID)).toBeDefined();
  });

  it("should render item icon when an icon is provided for a menu item", async () => {
    const user = userEvent.setup();

    render(
      <WrappedIconButtonMenu
        {...baseProps}
        items={[
          {
            id: "item-01",
            text: "Item 01",
            onPress: jest.fn(),
            icon: <MockIcon testID="item-01-icon" />,
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const icon = await screen.findByTestId("item-01-icon");

    expect(icon).toBeDefined();
  });

  it("should mark menu item as disabled when disabledKey is provided and prevent press", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(
      <WrappedIconButtonMenu
        {...baseProps}
        disabledKeys={["item-disabled"]}
        items={[
          {
            id: "item-disabled",
            text: "Disabled Item",
            onPress: mockOnPress,
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const menuItem = await screen.findByTestId(
      "icon-button-menu-item-item-disabled"
    );

    expect(menuItem.props?.accessibilityState?.disabled).toBeTruthy();

    await act(async () => {
      await user.press(menuItem);
    });

    expect(mockOnPress).not.toHaveBeenCalled();
  });

  it("should close the menu when trigger is pressed again", async () => {
    const user = userEvent.setup();

    render(<WrappedIconButtonMenu {...baseProps} />);

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    await screen.findByTestId("icon-button-menu");

    await act(async () => {
      await user.press(button);
    });

    await waitFor(() => {
      expect(screen.queryByTestId("icon-button-menu")).toBeNull();
    });
  });

  it("should render menu item text content", async () => {
    const user = userEvent.setup();

    render(
      <WrappedIconButtonMenu
        {...baseProps}
        items={[
          {
            id: "item-01",
            text: "Unique Item Text",
            onPress: jest.fn(),
          },
        ]}
      />
    );

    const button = screen.getByRole("button", {
      name: "Burger menu",
    });

    await act(async () => {
      await user.press(button);
    });

    const text = await screen.findByText("Unique Item Text");

    expect(text).toBeDefined();
  });
});
