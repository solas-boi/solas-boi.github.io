import { cloneElement } from "react";
import { View } from "react-native";
import { CoreIconButton, CoreIconButtonMenu } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles from "./IconButtonMenu.styles";
import type { IconButtonMenuItem } from "./IconButtonMenu.types";
import { Menu, type MenuProps } from "../Menu";
import { Typography } from "../Typography";

export type IconButtonMenuProps = Omit<
  MenuProps<IconButtonMenuItem>,
  "offset" | "padding" | "renderListItemContent"
> & {
  variant?: CoreIconButton.Variant;
};

function IconButtonMenu(props: IconButtonMenuProps) {
  const {
    variant = CoreIconButton.DEFAULT_VARIANT,
    testID = "icon-button-menu",
    ...menuProps
  } = props;

  const styles = useStyles();

  const { tokens } = useDesignTokens();
  const { menu, iconButtonMenu, select } = tokens;

  return (
    <Menu
      {...menuProps}
      offset={CoreIconButtonMenu.VARIANT_OFFSET[variant]}
      padding={CoreIconButtonMenu.VARIANT_PADDING[variant]}
      renderListItemContent={(
        item: IconButtonMenuItem,
        isDisabled: boolean
      ) => {
        return (
          <View style={styles.listItemContent}>
            {item.icon && (
              <View style={styles.listItemIconWrapper}>
                {cloneElement(item.icon, {
                  ...item.icon.props,
                  width: iconButtonMenu.menu.item.content.icon.width,
                  height: iconButtonMenu.menu.item.content.icon.height,
                  color: isDisabled
                    ? select.menu.option.inner.color.disabled
                    : menu.option.inner.color.base,
                })}
              </View>
            )}

            <View style={styles.listItemTypographyWrapper}>
              <Typography
                color={
                  isDisabled
                    ? select.menu.option.inner.color.disabled
                    : menu.option.inner.color.base
                }
                variant={
                  iconButtonMenu.menu.item.content.text.typography.variant
                }
                fontFamily={
                  iconButtonMenu.menu.item.content.text.typography.fontFamily
                }
              >
                {item.text}
              </Typography>
            </View>
          </View>
        );
      }}
      testID={testID}
    />
  );
}

export default IconButtonMenu;
