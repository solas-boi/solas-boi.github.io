import type { MenuItem } from "../Menu";

export type IconButtonMenuItem = MenuItem & {
  text: string;
  icon?: JSX.Element;
};
