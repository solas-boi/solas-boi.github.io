import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { select } = tokens;

  return StyleSheet.create({
    button: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      minHeight: select.button.minHeight,
      paddingTop: select.button.padding.top,
      paddingLeft: select.button.padding.left,
      paddingRight: select.button.padding.right,
      paddingBottom: select.button.padding.bottom,
    },
    buttonText: {
      fontFamily: select.button.text.typography.fontFamily,
      fontVariant: select.button.text.typography.variant,
      color: select.button.text.color.base,
      flexShrink: 1,
    },
    buttonTextDisabled: {
      color: select.button.text.color.disabled,
    },
    buttonPlaceholder: {
      color: select.button.placeholder.color.base,
      flexShrink: 1,
    },
    buttonPlaceholderDisabled: {
      color: select.button.placeholder.color.disabled,
    },
    listContainer: {
      flex: 1,
    },
    list: {
      borderTopWidth: select.menu.stroke.width,
      borderTopColor: select.menu.stroke.color,
      height: "100%",
    },
    dialogTitle: {
      paddingLeft: 32,
      paddingRight: 32 + 8,
      paddingVertical: 8,
      textAlign: "center",
    },
    closeDialogButton: {
      position: "absolute",
      right: 8,
      top: 8,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
