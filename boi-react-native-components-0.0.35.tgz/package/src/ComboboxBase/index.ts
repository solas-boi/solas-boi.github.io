export {
  default as ComboboxBase,
  type ComboboxBaseProps,
} from "./ComboboxBase";
