import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import CharactersCounter, { CharactersCounterProps } from "./CharactersCounter";
import { render, screen } from "@testing-library/react-native";

function WrappedCharactersCounter(props: CharactersCounterProps) {
  return (
    <DesignTokensProvider>
      <CharactersCounter {...props} />
    </DesignTokensProvider>
  );
}

describe("CharactersCounter", () => {
  it("should render correct text", async () => {
    render(
      <WrappedCharactersCounter
        testID="my-characters-counter"
        maxLength={5}
        length={1}
      />
    );

    const counter = screen.getByTestId("my-characters-counter");

    expect(counter).toHaveTextContent("4 characters remaining");
  });

  it("should not render counter with a negative value", async () => {
    render(
      <WrappedCharactersCounter
        testID="my-characters-counter"
        maxLength={5}
        length={10}
      />
    );

    const counter = screen.getByTestId("my-characters-counter");

    expect(counter).toHaveTextContent("0 characters remaining");
  });

  it("should render text in singular if remaining characters is 1", async () => {
    render(
      <WrappedCharactersCounter
        testID="my-characters-counter"
        maxLength={5}
        length={4}
      />
    );

    const counter = screen.getByTestId("my-characters-counter");

    expect(counter).toHaveTextContent("1 character remaining");
  });
});
