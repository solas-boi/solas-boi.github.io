export {
  default as CharactersCounter,
  type CharactersCounterProps,
} from "./CharactersCounter";
