import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { charactersCounter } = tokens;

  return StyleSheet.create({
    base: {
      width: "100%",
      color: charactersCounter.color,
      textAlign: charactersCounter.textAlign,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
