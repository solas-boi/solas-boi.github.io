import { type PropsWithOptionalTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { Typography } from "../Typography";
import useStyles from "./CharactersCounter.styles";

export type CharactersCounterProps = PropsWithOptionalTestID & {
  length: number;
  maxLength: number;
};

function CharactersCounter(props: CharactersCounterProps) {
  const { length, maxLength, testID } = props;
  const { tokens } = useDesignTokens();
  const { charactersCounter } = tokens;
  const styles = useStyles();
  const remaining = Math.max(0, maxLength - length);
  return (
    <Typography
      style={styles.base}
      variant={charactersCounter.typography.variant}
      fontFamily={charactersCounter.typography.fontFamily}
      testID={testID}
    >
      {`${remaining} character${remaining !== 1 ? "s" : ""} remaining`}
    </Typography>
  );
}

export default CharactersCounter;
