export { default as ButtonTabs, type ButtonTabsProps } from "./ButtonTabs";
