import { View } from "react-native";
import {
  render,
  screen,
  within,
  userEvent,
  act,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import ButtonTabs, { type ButtonTabsProps } from "./ButtonTabs";
import { mockButtonTabs } from "./ButtonTabs.mocks";

jest.useFakeTimers();

function WrappedButtonTabs(props: ButtonTabsProps) {
  return (
    <DesignTokensProvider>
      <View testID="button-tabs-container">
        <ButtonTabs {...props}>
          <ButtonTabs.Items />
          <ButtonTabs.Panels />
        </ButtonTabs>
      </View>
    </DesignTokensProvider>
  );
}

describe("ButtonTabs", () => {
  let baseProps: ButtonTabsProps;

  beforeEach(() => {
    baseProps = {
      ...mockButtonTabs,
      onChange: jest.fn(),
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedButtonTabs {...baseProps} />);

    const container = screen.getByTestId("button-tabs-container");

    const tabPanel01 = within(container).getByTestId(
      "button-tabs-panel-button-tab-01",
      { hidden: false }
    );
    const tabPanel02 = within(container).getByTestId(
      "button-tabs-panel-button-tab-02",
      { hidden: true }
    );

    expect(tabPanel01.props.role).toBe("tabpanel");
    expect(tabPanel02.props.role).toBe("tabpanel");
  });

  it("should only render one visible tab panel", () => {
    render(<WrappedButtonTabs {...baseProps} />);

    const container = screen.getByTestId("button-tabs-container");

    const tabPanel01 = within(container).getByTestId(
      "button-tabs-panel-button-tab-01",
      { hidden: false }
    );
    const tabPanel02 = within(container).getByTestId(
      "button-tabs-panel-button-tab-02",
      { hidden: true }
    );

    expect(tabPanel01.props.style.display).toBe("flex");
    expect(tabPanel02.props.style.display).toBe("none");
  });

  it("should trigger the onChange event when a tab is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedButtonTabs {...baseProps} onChange={mockOnChange} />);

    const nextTabProps = baseProps.items[1]!;

    const nextTab = screen.getByTestId(`button-tabs-item-${nextTabProps.id}`);
    expect(nextTab.props.accessibilityState.selected).toBe(false);

    await act(async () => {
      await user.press(nextTab);
    });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith(nextTabProps.id);
  });

  it("should render the correct tab panel", async () => {
    const activeItemId = "button-tab-02";

    render(<WrappedButtonTabs {...baseProps} activeItemId={activeItemId} />);

    const container = screen.getByTestId("button-tabs-container");
    const tabPanel = within(container).getByTestId(
      "button-tabs-panel-button-tab-02",
      { hidden: false }
    );

    expect(tabPanel).toHaveTextContent("Tab panel 02");
  });

  it("should render with a default testID", () => {
    render(<WrappedButtonTabs {...baseProps} />);

    expect(screen.getByTestId("button-tabs-items")).toBeDefined();
    expect(screen.getByTestId("button-tabs-panels")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-button-tabs";

    render(<WrappedButtonTabs {...baseProps} testID={testID} />);

    expect(screen.getByTestId(`${testID}-items`)).toBeDefined();
    expect(screen.getByTestId(`${testID}-panels`)).toBeDefined();
  });
});
