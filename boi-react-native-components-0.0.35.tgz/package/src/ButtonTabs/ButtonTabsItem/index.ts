export {
  default as ButtonTabsItem,
  type ButtonTabsItemProps,
} from "./ButtonTabsItem";
