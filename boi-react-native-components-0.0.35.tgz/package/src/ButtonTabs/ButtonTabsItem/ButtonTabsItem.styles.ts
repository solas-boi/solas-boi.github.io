import { StyleSheet } from "react-native";
import { CoreButtonAlt } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { buttonAlt } = tokens;

  const focusRingOffset =
    -1 *
    (buttonAlt.focusRing.offset +
      buttonAlt.focusRing.width +
      buttonAlt.stroke.width.base);

  const styles = StyleSheet.create({
    container: {
      flexShrink: 1,
    },
    containerFullWidth: {
      width: "100%",
    },
    button: {
      alignItems: "center",
      borderWidth: buttonAlt.stroke.width.base,
      borderStyle: buttonAlt.stroke.style,
      borderColor: buttonAlt.stroke.color.base,
      borderRadius: buttonAlt.radius,
      minWidth: buttonAlt.minWidth,
      minHeight: buttonAlt.minHeight.md,
      paddingTop: buttonAlt.padding.top,
      paddingLeft: buttonAlt.padding.left,
      paddingRight: buttonAlt.padding.right,
      paddingBottom: buttonAlt.padding.bottom,
      backgroundColor: buttonAlt.backgroundColor.base,
      flexShrink: 1,
    },
    buttonTextAlignLeft: {
      justifyContent: "flex-start",
    },
    buttonTextAlignCenter: {
      justifyContent: "center",
    },
    buttonActive: {
      borderColor: buttonAlt.stroke.color.active,
      backgroundColor: buttonAlt.backgroundColor.active,
    },
    buttonDisabled: {
      borderColor: buttonAlt.stroke.color.disabled,
      backgroundColor: buttonAlt.backgroundColor.disabled,
    },
    focusRing: {
      position: "absolute",
      borderRadius:
        buttonAlt.focusRing.radius +
        buttonAlt.focusRing.offset +
        buttonAlt.stroke.width.base,
      borderWidth: buttonAlt.focusRing.width,
      borderStyle: buttonAlt.focusRing.style,
      borderColor: buttonAlt.focusRing.color,
      left: focusRingOffset,
      top: focusRingOffset,
      right: focusRingOffset,
      bottom: focusRingOffset,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  isActive,
  fullWidth,
  textAlign,
  isDisabled,
}: {
  isActive: boolean;
  fullWidth: boolean;
  textAlign: CoreButtonAlt.TextAlign;
  isDisabled: boolean;
}) {
  const styles = useStyles();

  const buttonTextAlignStyles = {
    left: styles.buttonTextAlignLeft,
    center: styles.buttonTextAlignCenter,
  };

  return {
    container: [styles.container, fullWidth && styles.containerFullWidth],
    button: [
      styles.button,
      isActive && styles.buttonActive,
      buttonTextAlignStyles[textAlign],
      isDisabled && styles.buttonDisabled,
    ],
    focusRing: styles.focusRing,
  };
}

export default useStyles;
