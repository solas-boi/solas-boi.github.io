import { useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import {
  CoreButtonAlt,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { useStateStyles } from "./ButtonTabsItem.styles";
import { Typography } from "../../Typography";
import { KeyboardPressableProps } from "../../types";

export type ButtonTabsItemProps = PropsWithOptionalTestID &
  Pick<KeyboardPressableProps, "onPress"> & {
    id: string;
    label: string;
    isActive: boolean;
    index: number;
    listLength: number;
    fullWidth?: boolean;
    textAlign?: CoreButtonAlt.TextAlign;
    typographyVariant?: CoreButtonAlt.TypographyVariant;
    isDisabled?: boolean;
  };

function ButtonTabsItem(props: ButtonTabsItemProps) {
  const {
    id,
    label,
    isActive,
    index,
    listLength,
    fullWidth = false,
    textAlign = CoreButtonAlt.DEFAULT_TEXT_ALIGN,
    typographyVariant = CoreButtonAlt.DEFAULT_TYPOGRAPHY_VARIANT,
    isDisabled = false,
    testID = "button-tabs-item",
    ...pressableProps
  } = props;

  const stateStyles = useStateStyles({
    isActive,
    fullWidth,
    textAlign,
    isDisabled,
  });

  const { tokens } = useDesignTokens();
  const { buttonAlt } = tokens;

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  function getButtonColor() {
    if (isDisabled) {
      return buttonAlt.color.disabled;
    }

    if (isActive) {
      return buttonAlt.color.active;
    }

    return buttonAlt.color.base;
  }

  return (
    <KeyboardPressable
      {...pressableProps}
      onFocusChange={handleKeyboardFocusChange}
      tintType="none"
      containerStyle={stateStyles.container}
      style={stateStyles.button}
      enableA11yFocus
      accessibilityState={{ selected: isActive }}
      aria-label={`${label}. Tab. ${index + 1} of ${listLength}`}
      aria-controls={`${id}-panel`}
      id={id}
      nativeID={id}
      tabIndex={isActive ? -1 : undefined}
      disabled={isDisabled}
      testID={testID}
    >
      {hasKeyboardFocus && (
        <View pointerEvents="none" style={stateStyles.focusRing} />
      )}
      <Typography
        color={getButtonColor()}
        variant={typographyVariant}
        fontFamily={buttonAlt.typography.fontFamily}
        style={{ textAlign }}
      >
        {label}
      </Typography>
    </KeyboardPressable>
  );
}

export default ButtonTabsItem;
