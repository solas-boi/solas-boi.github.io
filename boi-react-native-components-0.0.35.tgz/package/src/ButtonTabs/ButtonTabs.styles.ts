import { StyleSheet } from "react-native";
import { CoreButtonTabs } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { buttonTabs } = tokens;

  const styles = StyleSheet.create({
    itemsContainer: {
      flexDirection: "row",
      gap: buttonTabs.items.gap,
    },
    itemsContainerVariantLeft: {
      justifyContent: "flex-start",
    },
    itemsContainerVariantCenter: {
      justifyContent: "center",
    },
    itemsContainerVariantStretch: {
      justifyContent: "flex-start",
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant,
}: {
  variant: CoreButtonTabs.Variant;
}) {
  const styles = useStyles();

  const itemsContainerVariantStyles = {
    left: styles.itemsContainerVariantLeft,
    center: styles.itemsContainerVariantCenter,
    stretch: styles.itemsContainerVariantStretch,
  };

  return {
    itemsContainer: [
      styles.itemsContainer,
      itemsContainerVariantStyles[variant],
    ],
  };
}

export default useStyles;
