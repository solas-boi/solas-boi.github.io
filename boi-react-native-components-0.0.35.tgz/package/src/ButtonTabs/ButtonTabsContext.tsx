import { createContext, useContext, type PropsWithChildren } from "react";
import { type PropsWithTestID } from "@boi/components-core";

import { type ButtonTabsProps } from "./ButtonTabs";

type ButtonTabsContextValue = PropsWithTestID &
  Pick<
    ButtonTabsProps,
    "variant" | "items" | "activeItemId" | "onChange" | "typographyVariant"
  >;

const ButtonTabsContext = createContext<ButtonTabsContextValue>(
  {} as ButtonTabsContextValue
);

export type ButtonTabsProviderProps = ButtonTabsContextValue &
  PropsWithChildren;

export const ButtonTabsProvider = (props: ButtonTabsProviderProps) => {
  const { children, ...providerValue } = props;

  return (
    <ButtonTabsContext.Provider value={providerValue}>
      {children}
    </ButtonTabsContext.Provider>
  );
};

export function useButtonTabs() {
  return useContext(ButtonTabsContext);
}

export default ButtonTabsProvider;
