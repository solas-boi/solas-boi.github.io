import { type PropsWithChildren } from "react";
import { View } from "react-native";
import {
  CoreButtonTabs,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useStateStyles } from "./ButtonTabs.styles";
import ButtonTabsProvider, { useButtonTabs } from "./ButtonTabsContext";
import { ButtonTabsItem, type ButtonTabsItemProps } from "./ButtonTabsItem";

export type ButtonTabsProps = PropsWithOptionalTestID &
  Pick<ButtonTabsItemProps, "typographyVariant"> &
  PropsWithChildren<{
    variant?: CoreButtonTabs.Variant;
    items: CoreButtonTabs.Items;
    activeItemId: CoreButtonTabs.Item["id"];
    onChange: (activeItemId: CoreButtonTabs.Item["id"]) => void;
  }>;

function ButtonTabs(props: ButtonTabsProps) {
  const { testID = "button-tabs", ...otherProps } = props;

  return <ButtonTabsProvider {...otherProps} testID={testID} />;
}

ButtonTabs.Items = function ButtonTabsItems() {
  const {
    variant = CoreButtonTabs.DEFAULT_VARIANT,
    items,
    activeItemId,
    onChange,
    typographyVariant,
    testID,
  } = useButtonTabs();

  const stateStyles = useStateStyles({ variant });

  function handlePress(id: CoreButtonTabs.Item["id"]) {
    if (id !== activeItemId) {
      onChange(id);
    }
  }

  return (
    <View style={stateStyles.itemsContainer} testID={`${testID}-items`}>
      {items.map((item, index) => (
        <ButtonTabsItem
          key={item.id}
          id={item.id}
          label={item.label}
          index={index}
          listLength={items.length}
          isActive={item.id === activeItemId}
          fullWidth={variant === "stretch"}
          textAlign="center"
          typographyVariant={typographyVariant}
          isDisabled={item.isDisabled}
          onPress={() => handlePress(item.id)}
          testID={`${testID}-item-${item.id}`}
        />
      ))}
    </View>
  );
};

ButtonTabs.Panels = function ButtonTabsPanels() {
  const { items, activeItemId, testID } = useButtonTabs();

  return (
    <View testID={`${testID}-panels`}>
      {items.map((item) => {
        const isActive = item.id === activeItemId;

        return (
          <View
            key={item.id}
            role="tabpanel"
            id={`${item.id}-panel`}
            tabIndex={isActive ? 0 : -1}
            style={{ display: isActive ? "flex" : "none" }}
            aria-labelledby={item.id}
            testID={`${testID}-panel-${item.id}`}
          >
            {item.panel}
          </View>
        );
      })}
    </View>
  );
};

export default ButtonTabs;
