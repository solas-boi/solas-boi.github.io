import { Typography } from "../Typography";

export const mockButtonTabs = {
  activeItemId: "button-tab-01",
  items: [
    {
      id: "button-tab-01",
      label: "Tab label 01",
      panel: <Typography>Tab panel 01</Typography>,
    },
    {
      id: "button-tab-02",
      label: "Tab label 02",
      panel: <Typography>Tab panel 02</Typography>,
    },
  ],
};

export const mockButtonTabsDisabled = {
  activeItemId: "button-tab-disabled-01",
  items: [
    {
      id: "button-tab-disabled-01",
      label: "Tab label 01",
      panel: <Typography>Tab panel 01</Typography>,
    },
    {
      id: "button-tab-disabled-02",
      label: "Tab label 02",
      panel: <Typography>Tab panel 02</Typography>,
      isDisabled: true,
    },
  ],
};
