import { TextInput } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";

import { DatePickerV2, type DatePickerV2Props } from ".";
import { DateType } from "react-native-ui-datepicker";
import { isWeekend, parseISO, isSameDay } from "date-fns";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const bankHolidays = [
  "2025-01-01",
  "2025-02-03",
  "2025-03-17",
  "2025-04-18",
  "2025-04-21",
  "2025-05-05",
  "2025-06-02",
  "2025-08-04",
  "2025-10-27",
  "2025-12-25",
  "2025-12-26",
  "2025-12-29",
]; // Ireland bank holidays in 2025

// Dates to disable
const disabledWeekends = (date: DateType) =>
  date ? isWeekend(new Date(date as Date)) : false; // Disable weekends

const disableBankHolidays = (date: DateType) =>
  date
    ? bankHolidays.some((holiday) =>
        isSameDay(new Date(date as Date), parseISO(holiday))
      )
    : false; // Disable bank holidays

const disabledDates = (date: DateType) => {
  return disabledWeekends(date) || disableBankHolidays(date);
};

const meta = {
  title: "Inputs/DatePickerV2",
  component: DatePickerV2,
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    function handleChange(newDate: DateType) {
      updateArgs({ date: newDate });
      action("onChange")(newDate?.toString());
    }

    function handleChangeText(text: string) {
      action("onChangeText")(text);
    }

    return (
      <FocusControlWrapper<TextInput> {...args}>
        {(ref) => (
          <DatePickerV2
            {...args}
            ref={ref}
            onChange={handleChange}
            onChangeText={handleChangeText}
            disabledDates={(days) => disabledDates(days)}
            minimumDate={new Date()}
          />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    date: { control: { disable: true } },
    startMonth: {
      control: { type: "number" },
      description: "The month from which the calendar starts to appear.",
    },
    startYear: {
      control: { type: "number" },
      description: "The year from which the calendar starts to appear.",
    },
  },
  args: {
    date: undefined,
  },
} satisfies Meta<typeof DatePickerV2>;

export default meta;
type Story = StoryObj<DatePickerV2Props>;

export const Basic: Story = {
  args: {
    labelProps: {
      label: "DatePickerV2 with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const Disabled: Story = {
  args: {
    withCalendar: true,
    isDisabled: true,
    labelProps: {
      label: "Disabled DatePickerV2 ",
    },
  },
};

export const WithCalendar: Story = {
  args: {
    withCalendar: true,
    labelProps: {
      label: "DatePickerV2 with Label",
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    withCalendar: true,
    labelProps: {
      label: "DatePickerV2 with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    withCalendar: true,
    labelProps: {
      label: "DatePickerV2 with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);
