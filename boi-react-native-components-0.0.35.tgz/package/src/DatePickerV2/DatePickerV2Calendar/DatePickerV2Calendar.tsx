import { useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { isValid } from "date-fns";

import DatePickerV2, {
  DateType,
  useDefaultStyles,
  CalendarComponents,
  CalendarWeek,
  CalendarDay,
  CalendarMonth,
  CalendarYear,
} from "react-native-ui-datepicker";
import { type PropsWithTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import useStyles, { useStateStyles } from "./DatePickerV2Calendar.styles";

import {
  CalendarIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
} from "@boi/react-native-icons";

import { type CommonProps } from "../DatePickerV2";
import { StandardModal } from "../../StandardModal";
import { Typography } from "../../Typography";
import { type ModalProps } from "../../Modal";

const initialDayValue = {
  number: 1,
  text: "1",
  date: new Date().toString(),
  isCurrentMonth: true,
  isDisabled: false,
  isSelected: false,
  isToday: false,
  inRange: false,
  leftCrop: false,
  rightCrop: false,
  isStartOfWeek: false,
  isEndOfWeek: false,
  isCrop: false,
  inMiddle: false,
  rangeStart: false,
  rangeEnd: false,
};

export type BaseProps = {
  day: CalendarDay;
  isVisible: boolean;
  isDisabled?: boolean;
};

export type DatePickerV2CalendarProps = PropsWithTestID &
  Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
  CommonProps & {
    maximumDate?: DateType;
    minimumDate?: DateType;
    disabledDates?: DateType[] | ((date: DateType) => boolean);
    title?: string;
    startMonth?: number;
    startYear?: number;
    isDisabled?: boolean;
  };

function DatePickerV2Calendar(props: DatePickerV2CalendarProps) {
  const {
    onChange,
    testID,
    maximumDate,
    minimumDate,
    disabledDates = [],
    title = "",
    date: selectedDate,
    supportedOrientations,
    startMonth,
    startYear,
    onCloseAnimationComplete,
    isDisabled,
    ...otherProps
  } = props;

  const { tokens } = useDesignTokens();
  const { datePicker } = tokens;

  const [isVisible, setIsVisible] = useState(false);

  function handlePress() {
    setIsVisible(true);
  }

  function handleChange(newDate: DateType) {
    if (newDate instanceof Date) {
      onChange(newDate);
      handleClose();
    } else {
      console.warn("Invalid date selected");
    }
  }

  function handleClose() {
    setIsVisible(false);
  }

  const defaultStyles = useDefaultStyles();
  const styles = useStyles();
  const stateStyles = useStateStyles({
    isVisible,
    isDisabled,
    day: { ...initialDayValue },
  });

  const renderArrowLeft = () => (
    <ArrowLeftIcon style={styles.calendarNavButton} />
  );
  const renderArrowRight = () => (
    <ArrowRightIcon style={styles.calendarNavButton} />
  );
  const renderWeekday = (weekday: CalendarWeek) => (
    <Typography
      variant={datePicker.calendar.headerCell.typography.variant}
      fontFamily={datePicker.calendar.headerCell.typography.fontFamily}
      color={datePicker.calendar.headerCell.color.base}
      style={styles.calendarHeaderCell}
    >
      {weekday.name.min[0]}
    </Typography>
  );

  const renderDay = (day: CalendarDay) => (
    <DayComponent day={day} isVisible={isVisible} />
  );

  const renderMonth = (month: CalendarMonth) => (
    <Typography
      variant={datePicker.calendar.cell.typography.variant}
      fontFamily={datePicker.calendar.cell.typography.fontFamily}
      color={datePicker.calendar.cell.color.base}
    >
      {month.name.short}
    </Typography>
  );
  const renderYear = (year: CalendarYear) => (
    <Typography
      variant={datePicker.calendar.cell.typography.variant}
      fontFamily={datePicker.calendar.cell.typography.fontFamily}
      color={datePicker.calendar.cell.color.base}
    >
      {year.text}
    </Typography>
  );

  const components: CalendarComponents = {
    IconPrev: renderArrowLeft(),
    IconNext: renderArrowRight(),
    Weekday: (weekday) => renderWeekday(weekday),
    Day: (day) => renderDay(day),
    Month: (month) => renderMonth(month),
    Year: (year) => renderYear(year),
  };

  const a11yLabel =
    title +
    (selectedDate instanceof Date && isValid(selectedDate)
      ? `, selected date: ${selectedDate.toLocaleDateString()}`
      : ", no date selected");

  return (
    <>
      <KeyboardPressable
        enableA11yFocus
        role="button"
        accessibilityRole="button"
        onPress={handlePress}
        aria-label="Calendar"
        testID={`${testID}-calendar-button`}
        disabled={isDisabled}
        aria-disabled={isDisabled}
        style={stateStyles.calendarIconWrapper}
        hitSlop={8}
      >
        <View style={stateStyles.calendarIconContainer}>
          <CalendarIcon
            style={styles.calendarIcon}
            color={stateStyles.calendarIconColor}
          />
        </View>
      </KeyboardPressable>
      <StandardModal
        title={title}
        isOpen={isVisible}
        onRequestClose={handleClose}
        testID={`${testID}-modal`}
        supportedOrientations={supportedOrientations}
        accessibilityLabel={a11yLabel}
        accessibilityHint="Select a date from the calendar"
        onCloseAnimationComplete={onCloseAnimationComplete}
      >
        <StandardModal.ScrollView>
          <DatePickerV2
            {...otherProps}
            date={
              selectedDate instanceof Date && isValid(selectedDate)
                ? selectedDate
                : undefined
            }
            mode="single"
            minDate={minimumDate}
            maxDate={maximumDate}
            disabledDates={disabledDates}
            onChange={({ date }: { date: DateType }) => handleChange(date)}
            firstDayOfWeek={1}
            disableMonthPicker
            disableYearPicker
            weekdaysFormat="min"
            styles={{
              ...defaultStyles,
              day_label: styles.calendarLabel,
              month_label: styles.calendarLabel,
              year_label: styles.calendarLabel,
              today: styles.calendarToday,
              disabled_label: styles.calendarDisabledLabel,
              selected: styles.calendarSelected,
              selected_month: styles.calendarSelected,
              selected_year: styles.calendarSelected,
              day: styles.calendarDay,
              month_selector_label: styles.calendarHeading,
              year_selector_label: styles.calendarHeading,
            }}
            components={components}
            month={startMonth}
            year={startYear}
          />
        </StandardModal.ScrollView>
      </StandardModal>
    </>
  );
}

const DayComponent = ({ day, isVisible }: BaseProps) => {
  const stateStyles = useStateStyles({ day, isVisible });
  const { tokens } = useDesignTokens();
  const { datePicker } = tokens;

  return (
    <Typography
      variant={datePicker.calendar.cell.typography.variant}
      fontFamily={datePicker.calendar.cell.typography.fontFamily}
      style={stateStyles.calendarDayContainer}
    >
      {day.number}
    </Typography>
  );
};

export default DatePickerV2Calendar;
