import { StyleSheet } from "react-native";
import {
  type ThemeTokens,
  parseSizeToken,
} from "@boi/react-native-design-tokens";
import { CoreTypography } from "@boi/components-core";
import { createThemedStyleSheet } from "../../themedStylesheet";
import { BaseProps } from "./DatePickerV2Calendar";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { datePicker, typography } = tokens;

  const typographyHeaderCellVariant: CoreTypography.Variant =
    datePicker.calendar.headerCell.typography.variant;

  const typographyHeadingVariant: CoreTypography.Variant =
    datePicker.calendar.heading.typography.variant;

  return StyleSheet.create({
    calendarIconWrapper: {
      padding: datePicker.input.button.padding,
      borderRadius: datePicker.input.button.radius,
    },
    calendarIconWrapperDisabled: {
      opacity: datePicker.input.button.icon.opacity.disabled,
    },
    calendarIcon: {
      width: datePicker.input.button.icon.width,
      height: datePicker.input.button.icon.height,
    },
    calendarIconBase: {
      color: datePicker.input.button.icon.color.base,
      backgroundColor: datePicker.input.button.backgroundColor.base,
      opacity: datePicker.input.button.icon.opacity.base,
    },
    calendarIconFocus: {
      color: datePicker.input.button.icon.color.focus,
      backgroundColor: datePicker.input.button.backgroundColor.focus,
    },
    calendarToday: {
      borderColor: datePicker.calendar.cell.color.base,
      borderWidth: datePicker.calendar.stroke.width,
      borderRadius: datePicker.calendar.cell.radius,
    },
    calendarSelected: {
      color: datePicker.calendar.cell.color.active,
      backgroundColor: datePicker.calendar.cell.backgroundColor.active,
      borderRadius: datePicker.calendar.cell.radius,
      width: 44, // mobile native specific style;
      height: 44, // mobile native specific style;
      textAlign: "center",
      lineHeight: 44,
    },
    calendarDisabledLabel: {
      color: datePicker.calendar.cell.color.disabled,
    },
    calendarLabel: {
      height: 44, // mobile native specific style; add generic token to datePicker.ts if we'll have the same height for web calendar version
      width: 44, // mobile native specific style; add generic token to datePicker.ts if we'll have the same width for web calendar version
      color: datePicker.calendar.cell.color.base,
      textAlign: "center",
      lineHeight: 44, // mobile native specific style; add generic token to datePicker.ts if we'll have the same lineHeight for web calendar version
    },
    calendarDay: {
      width: 44, // mobile native specific style; add generic token to datePicker.ts if we'll have the same width for web calendar version
      height: 44, // mobile native specific style; add generic token to datePicker.ts if we'll have the same height for web calendar version
      backgroundColor: datePicker.calendar.cell.backgroundColor.base,
      alignSelf: "center",
    },
    calendarNavButton: {
      width: datePicker.calendar.button.icon.width,
      height: datePicker.calendar.button.icon.height,
      color: datePicker.calendar.button.icon.color.base,
    },
    calendarHeaderCell: {
      lineHeight:
        parseSizeToken(
          typography.lineHeight[typographyHeaderCellVariant],
          fontScale
        ) - 6, // -6 fix alignment issue for header cell when scaled
    },
    calendarHeading: {
      fontFamily: datePicker.calendar.heading.typography.fontFamily,
      fontSize: parseSizeToken(
        typography.fontSize[typographyHeadingVariant],
        fontScale
      ),
      fontWeight: "600", // fontFamily OpenSansSemiBold doesn't work properly with Calendar heading, use instead with fontWeight 600
      color: datePicker.calendar.heading.color.base,
    },
  });
}

export function useStateStyles({ isVisible, isDisabled, day }: BaseProps) {
  const styles = useStyles();
  const backgroundColor = isVisible
    ? styles.calendarIconFocus.backgroundColor
    : styles.calendarIconBase.backgroundColor;

  let color = isVisible
    ? styles.calendarIconFocus.color
    : styles.calendarIconBase.color;

  return {
    calendarIconContainer: [
      styles.calendarIconWrapper,
      {
        backgroundColor,
      },
    ],
    calendarIconWrapper: [
      styles.calendarIconWrapper,
      isDisabled ? styles.calendarIconWrapperDisabled : undefined,
    ],
    calendarIconColor: color,
    calendarDayContainer: [
      styles.calendarLabel,
      day.isDisabled && styles.calendarDisabledLabel,
      day.isSelected && styles.calendarSelected,
    ],
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export default useStyles;
