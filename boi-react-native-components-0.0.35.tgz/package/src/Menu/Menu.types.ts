export type MenuItem = {
  id: string;
  text?: string;
  onPress: () => void;
};
