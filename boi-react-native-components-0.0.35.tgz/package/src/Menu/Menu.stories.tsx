import { View, Text, Pressable } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { CoreMenu } from "@boi/components-core";

import Menu from "./Menu";

const meta = {
  title: "Navigation/Menu",
  component: Menu,
  render: function Render(args) {
    return (
      <View>
        <Menu {...args} supportedOrientations={["landscape", "portrait"]}>
          {(referenceProps) => (
            <Pressable
              style={{
                width: 48,
                height: 48,
                justifyContent: "center",
                backgroundColor: "lightgray",
              }}
              {...referenceProps}
            >
              <Text style={{ textAlign: "center" }}>Menu</Text>
            </Pressable>
          )}
        </Menu>
      </View>
    );
  },
  argTypes: {
    placement: { control: { disable: true } },
    renderListItemContent: { control: { disable: true } },
  },
  args: {
    placement: CoreMenu.DEFAULT_PLACEMENT,
    items: [
      {
        id: "item-01",
        onPress: () => {},
      },
      {
        id: "item-02",
        onPress: () => {},
      },
      {
        id: "item-03",
        onPress: () => {},
      },
      {
        id: "item-04",
        onPress: () => {},
      },
      {
        id: "item-05",
        onPress: () => {},
      },
      {
        id: "item-06",
        onPress: () => {},
      },
      {
        id: "item-07",
        onPress: () => {},
      },
      {
        id: "item-08",
        onPress: () => {},
      },
      {
        id: "item-09",
        onPress: () => {},
      },
    ],
    renderListItemContent: () => (
      <View
        style={{
          width: 200,
          height: 40,
          backgroundColor: "lime",
        }}
      />
    ),
  },
} satisfies Meta<typeof Menu>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  decorators: [
    (Story) => (
      <View
        style={{
          flexDirection: "row",
          justifyContent: "flex-end",
        }}
      >
        <Story />
      </View>
    ),
  ],
};

export const PlacementLeft: Story = {
  args: {
    placement: "bottom-start",
  },
};

export const DisabledItems: Story = {
  args: {
    placement: "bottom-start",
    items: [
      {
        id: "item-01",
        text: "Item 01",
        onPress: () => {},
      },
      {
        id: "item-02",
        text: "Item 02",
        onPress: () => {},
      },
      {
        id: "item-03",
        text: "Item 03",
        onPress: () => {},
      },
      {
        id: "item-04",
        text: "Item 04",
        onPress: () => {},
      },
      {
        id: "item-05",
        text: "Item 05",
        onPress: () => {},
      },
      {
        id: "item-06",
        text: "Item 06",
        onPress: () => {},
      },
      {
        id: "item-07",
        text: "Item 07",
        onPress: () => {},
      },
      {
        id: "item-08",
        text: "Item 08",
        onPress: () => {},
      },
      {
        id: "item-09",
        text: "Item 09",
        onPress: () => {},
      },
    ],
    disabledKeys: ["item-02", "item-03"],
  },
};
