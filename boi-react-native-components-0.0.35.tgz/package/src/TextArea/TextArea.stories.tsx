import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";

import TextArea, { type TextAreaProps } from "./TextArea";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta = {
  title: "Inputs/TextArea",
  component: TextArea,
  render: function Render(args: any) {
    function handleTextChange(newValue: string) {
      action("onTextChange")(newValue);
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => (
          <TextArea {...args} ref={ref} onChangeText={handleTextChange} />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    disabled: { control: "boolean" },
    readonly: { control: "boolean" },
    hasError: { control: "boolean" },
    maxLength: { control: "number" },
    autoGrow: { control: "boolean" },
    autoGrowMaxLines: {
      control: "number",
    },
  },
  args: {
    disabled: false,
    readonly: false,
    hasError: false,
    autoGrow: false,
  },
} satisfies Meta<TextAreaProps>;

export default meta;
type Story = StoryObj<TextAreaProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "TextArea",
    },
  },
};

export const AutoGrow: Story = {
  args: {
    labelProps: {
      "aria-label": "TextArea with AutoGrow",
    },
    autoGrow: true,
    autoGrowMaxLines: 10,
  },
};

export const WithLabel: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "TextArea with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "TextArea with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithLimit: Story = {
  args: {
    maxLength: 15,
    labelProps: {
      label: "TextArea with Limit",
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    labelProps: {
      label: "TextArea with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const Disabled: Story = {
  ...Basic,
  args: {
    disabled: true,
    value: "Some text",
    labelProps: {
      label: "Disabled TextArea",
    },
  },
};

export const ReadOnly: Story = {
  ...Basic,
  args: {
    readonly: true,
    value: "Some text",
    labelProps: {
      label: "ReadOnly TextArea",
    },
  },
};
