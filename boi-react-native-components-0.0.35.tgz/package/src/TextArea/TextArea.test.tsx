import {
  render,
  screen,
  fireEvent,
  userEvent,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import TextArea, { type TextAreaProps } from "./TextArea";

jest.useFakeTimers();

function WrappedTextArea(props: TextAreaProps) {
  return (
    <DesignTokensProvider>
      <TextArea {...props} />
    </DesignTokensProvider>
  );
}

describe("TextArea", () => {
  let baseProps: TextAreaProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "TextArea Label",
      },
    };
  });

  it("should render an enabled TextArea by default", async () => {
    render(<WrappedTextArea {...baseProps} />);

    const textarea = screen.getByTestId("textarea");

    expect(textarea).toBeEnabled();
  });

  it("should render disabled state", async () => {
    render(<WrappedTextArea {...baseProps} disabled />);

    const textarea = screen.getByTestId("textarea");

    expect(textarea).toBeDisabled();
  });

  it("should render readonly state", async () => {
    render(<WrappedTextArea {...baseProps} readonly />);

    const textarea = screen.getByTestId("textarea");

    expect(textarea).toBeDisabled();
  });

  it("should call custom onChangeText handler", async () => {
    const value = "Test";
    const mockOnChangeText = jest.fn();
    render(<WrappedTextArea {...baseProps} onChangeText={mockOnChangeText} />);

    const textarea = screen.getByTestId("textarea");
    const user = userEvent.setup();
    await user.type(textarea, value);

    expect(mockOnChangeText).toBeCalledWith(value);
  });

  it("should call custom onFocus handler", async () => {
    const mockOnFocus = jest.fn();
    render(<WrappedTextArea {...baseProps} onFocus={mockOnFocus} />);

    const textarea = screen.getByTestId("textarea");
    const user = userEvent.setup();
    await user.type(textarea, "Something");

    expect(mockOnFocus).toBeCalledTimes(1);
  });

  it("should call custom onBlur handler", async () => {
    const mockOnBlur = jest.fn();
    render(<WrappedTextArea {...baseProps} onBlur={mockOnBlur} />);

    const textarea = screen.getByTestId("textarea");
    const user = userEvent.setup();
    await user.type(textarea, "Something");

    expect(mockOnBlur).toBeCalledTimes(1);
  });

  it("should call custom onScroll handler", async () => {
    const mockOnScroll = jest.fn();
    render(<WrappedTextArea {...baseProps} onScroll={mockOnScroll} />);

    const scrollView = screen.getByTestId("textarea-scrollview");
    await fireEvent.scroll(scrollView, {
      nativeEvent: {
        contentSize: { height: 100 },
        contentOffset: { y: 50 },
        layoutMeasurement: { height: 50 },
      },
    });

    expect(mockOnScroll).toBeCalledTimes(1);
  });

  it("should display only the bottom innerShadow if scroll is at the start", async () => {
    render(<WrappedTextArea {...baseProps} />);

    const scrollView = screen.getByTestId("textarea-scrollview");
    await fireEvent.scroll(scrollView, {
      nativeEvent: {
        contentSize: { height: 100, width: 100 },
        contentOffset: { y: 0 },
        layoutMeasurement: { height: 50 },
      },
    });
    const topInnerShadow = screen.queryByTestId("textarea-top-innershadow");
    const bottomInnerShadow = screen.queryByTestId(
      "textarea-bottom-innershadow"
    );

    expect(topInnerShadow).not.toBeOnTheScreen();
    expect(bottomInnerShadow).toBeOnTheScreen();
  });

  it("should display only the top innerShadow if scroll is at the end", async () => {
    render(<WrappedTextArea {...baseProps} />);

    const scrollView = screen.getByTestId("textarea-scrollview");
    await fireEvent.scroll(scrollView, {
      nativeEvent: {
        contentSize: { height: 100, width: 100 },
        contentOffset: { y: 50 },
        layoutMeasurement: { height: 50 },
      },
    });
    const topInnerShadow = screen.queryByTestId("textarea-top-innershadow");
    const bottomInnerShadow = screen.queryByTestId(
      "textarea-bottom-innershadow"
    );

    expect(topInnerShadow).toBeOnTheScreen();
    expect(bottomInnerShadow).not.toBeOnTheScreen();
  });

  it("should display both innerShadows if scroll is at the middle", async () => {
    render(<WrappedTextArea {...baseProps} />);

    const scrollView = screen.getByTestId("textarea-scrollview");
    await fireEvent.scroll(scrollView, {
      nativeEvent: {
        contentSize: { height: 100, width: 100 },
        contentOffset: { y: 25 },
        layoutMeasurement: { height: 50 },
      },
    });

    const topInnerShadow = screen.queryByTestId("textarea-top-innershadow");
    const bottomInnerShadow = screen.queryByTestId(
      "textarea-bottom-innershadow"
    );

    expect(topInnerShadow).toBeOnTheScreen();
    expect(bottomInnerShadow).toBeOnTheScreen();
  });

  it("should render a length counter if maxLength prop is provided", async () => {
    const maxLength = 30;
    render(<WrappedTextArea {...baseProps} maxLength={maxLength} />);
    const counter = screen.getByTestId("textarea-characters-counter");
    expect(counter).toHaveTextContent(`${maxLength} characters remaining`);
  });

  it("should not render a length counter if noCounter prop is provided", async () => {
    const maxLength = 30;
    render(<WrappedTextArea {...baseProps} maxLength={maxLength} noCounter />);
    const counter = screen.queryByTestId("input-characters-counter");
    expect(counter).toBeNull();
  });

  it("should render a length counter with length of value prop", async () => {
    const maxLength = 30;
    const value = "SomeValue";
    render(
      <WrappedTextArea {...baseProps} value={value} maxLength={maxLength} />
    );
    const counter = screen.getByTestId("textarea-characters-counter");
    expect(counter).toHaveTextContent(
      `${maxLength - value.length} characters remaining`
    );
  });

  it("should render a length counter with length of defaultValue prop", async () => {
    const maxLength = 30;
    const value = "SomeValue";
    render(
      <WrappedTextArea
        {...baseProps}
        defaultValue={value}
        maxLength={maxLength}
      />
    );
    const counter = screen.getByTestId("textarea-characters-counter");
    expect(counter).toHaveTextContent(
      `${maxLength - value.length} characters remaining`
    );
  });

  it("should render an alert when alertProps are provided", async () => {
    render(
      <WrappedTextArea
        {...baseProps}
        alertProps={{
          severity: "error",
          children: "Something went wrong",
        }}
      />
    );

    const alerts = screen.getByTestId("textarea-alerts");

    expect(alerts).toHaveTextContent("Something went wrong");
  });
});
