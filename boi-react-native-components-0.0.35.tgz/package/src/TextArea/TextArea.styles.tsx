import { StyleSheet, useWindowDimensions } from "react-native";
import { CoreTypography } from "@boi/components-core";
import {
  parseSizeToken,
  useDesignTokens,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";
import { OuterFieldProps } from "../OuterField/OuterField";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { textArea, typography } = tokens;

  const typographyVariant: CoreTypography.Variant = textArea.typography.variant;

  const scrollViewMargin = {
    horizontal: 8,
    vertical: 2,
  };

  const scrollView = StyleSheet.create({
    base: {
      height: textArea.minHeight,
      marginHorizontal: scrollViewMargin.horizontal,
      marginVertical: scrollViewMargin.vertical,
    },
  });

  const scrollViewContent = StyleSheet.create({
    base: {
      width: "100%",
    },
  });

  const input = StyleSheet.create({
    base: {
      minHeight: textArea.minHeight,
      width: "100%",
      height: "100%",
      backgroundColor: "transparent",
      borderColor: "transparent",

      paddingVertical: 12 - scrollViewMargin.horizontal,
      paddingHorizontal:
        textArea.paddingHorizontal - scrollViewMargin.horizontal,

      textAlignVertical: "top",
      color: textArea.color.base,
      fontFamily: typography.fontFamily[typographyVariant],
      fontSize: parseSizeToken(
        typography.fontSize[typographyVariant],
        fontScale
      ),
      lineHeight:
        parseSizeToken(typography.lineHeight[typographyVariant], fontScale) - 2, // TODO: Find out why we need a -2 here for it to look right
    },
    isReadOnly: {
      color: textArea.color.readOnly,
    },
    isDisabled: {
      color: textArea.color.disabled,
    },
  });

  return {
    input,
    scrollView,
    scrollViewContent,
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

type StylesProps = OuterFieldProps & {
  autoGrow?: boolean;
  autoGrowMaxLines?: number;
};

export function useStateStyles({
  isDisabled,
  isReadOnly,
  autoGrow,
  autoGrowMaxLines,
}: StylesProps) {
  const { input, scrollView, scrollViewContent } = useStyles();
  const { fontScale } = useWindowDimensions();
  const { tokens } = useDesignTokens();

  const typographyVariant: CoreTypography.Variant =
    tokens.textArea.typography.variant;

  return {
    input: [
      input.base,
      isReadOnly && input.isReadOnly,
      isDisabled && input.isDisabled,
    ],
    scrollView: [
      scrollView.base,
      autoGrow
        ? {
            height: undefined,
          }
        : undefined,
      autoGrowMaxLines
        ? {
            maxHeight:
              autoGrowMaxLines *
              parseSizeToken(
                tokens.typography.lineHeight[typographyVariant],
                fontScale
              ),
          }
        : undefined,
    ],
    scrollViewContent: scrollViewContent.base,
  };
}

export default useStyles;
