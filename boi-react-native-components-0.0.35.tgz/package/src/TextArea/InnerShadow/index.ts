export { default as InnerShadow, type InnerShadowProps } from "./InnerShadow";
