import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";
import { useSharedValue, withSpring } from "react-native-reanimated";
import { useEffect } from "react";
import { InnerShadowProps } from ".";

function styleSheetFactory(tokens: ThemeTokens) {
  const { textArea, radius } = tokens;

  const innerShadow = StyleSheet.create({
    base: {
      position: "absolute",
      left: 0,
      width: "100%",
      height: textArea.innerShadow.height - 5,
      borderRadius: radius.r8,
    },
    top: {
      top: 0,
    },
    bottom: {
      bottom: 0,
    },
  });

  return innerShadow;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({ type, show }: InnerShadowProps) {
  const { base, bottom, top } = useStyles();

  const opacity = useSharedValue(0);
  useEffect(() => {
    opacity.value = withSpring(show ? 1 : 0);
  }, [show, opacity]);

  return [
    base,
    type === "TOP" ? top : undefined,
    type === "BOTTOM" ? bottom : undefined,
    { opacity },
  ];
}

export default useStyles;
