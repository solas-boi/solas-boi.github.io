import { memo, useId } from "react";
import { View } from "react-native";
import { Defs, LinearGradient, Rect, Stop, Svg } from "react-native-svg";
import Animated from "react-native-reanimated";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import type {
  PropsWithOptionalTestID,
  CoreTextArea,
} from "@boi/components-core";

import { useStateStyles } from "./InnerShadow.styles";

export type InnerShadowProps = PropsWithOptionalTestID & {
  type: CoreTextArea.InnerShadowPosition;
  show: boolean;
};

const InnerShadow = memo(({ type, show, testID }: InnerShadowProps) => {
  const {
    tokens: {
      textArea: { innerShadow },
    },
  } = useDesignTokens();

  const gradId = useId();
  const styles = useStateStyles({ type, show });

  return (
    <Animated.View style={styles} pointerEvents="none">
      {testID && show && <View testID={testID} />}
      <Svg height="100%" width="100%">
        <Defs>
          <LinearGradient id={gradId} x1="0%" y1="0%" x2="0%" y2="100%">
            <Stop
              offset="0"
              stopColor={innerShadow.color}
              stopOpacity={
                type === "TOP"
                  ? innerShadow.opacity.active
                  : innerShadow.opacity.inactive
              }
            />
            <Stop
              offset="1"
              stopColor={innerShadow.color}
              stopOpacity={
                type === "BOTTOM"
                  ? innerShadow.opacity.active
                  : innerShadow.opacity.inactive
              }
            />
          </LinearGradient>
        </Defs>
        <Rect rx={10} width="100%" height="100%" fill={`url(#${gradId})`} />
      </Svg>
    </Animated.View>
  );
});
export default InnerShadow;
