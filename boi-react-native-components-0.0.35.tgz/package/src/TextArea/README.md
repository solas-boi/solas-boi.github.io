# TextArea component

## Known Bugs

- There is a known bug on the React Native TextInput component on Android when you have multiline={true} and custom fonts. https://github.com/facebook/react-native/issues/18132

- When increasing the fontScale, the lineHeight wont change, the text will not be aligned correctly if the font is scaled. It's probably caused by the above bug.
