import { View } from "react-native";
import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreAlert, type AlertSeverity } from "@boi/components-core";

import Alert, { type AlertProps } from "./Alert";

jest.useFakeTimers();

function WrappedAlert(props: AlertProps) {
  return (
    <DesignTokensProvider>
      <Alert {...props} />
    </DesignTokensProvider>
  );
}

describe("Alert", () => {
  let baseProps: AlertProps;

  beforeEach(() => {
    baseProps = {
      heading: "Alert heading",
    };
  });

  it.each([
    ["error" as AlertSeverity, "alert"],
    ["warning" as AlertSeverity, "alert"],
    ["success" as AlertSeverity, undefined],
    ["info" as AlertSeverity, undefined],
  ])("should render with the correct role", (severity, role) => {
    render(<WrappedAlert {...baseProps} severity={severity} />);

    const alert = screen.getByTestId("alert");

    expect(alert.props.role).toEqual(role);
    expect(alert.props.accessibilityRole).toEqual(role);
  });

  it("should render with the correct heading", () => {
    render(<WrappedAlert {...baseProps} />);

    const heading = screen.getByRole("heading");

    expect(heading.props["aria-level"]).toBe(CoreAlert.DEFAULT_HEADING_LEVEL);
    expect(heading).toHaveTextContent(baseProps.heading);
  });

  it("should render with a custom heading level", () => {
    render(<WrappedAlert {...baseProps} headingLevel={5} />);

    const heading = screen.getByRole("heading");

    expect(heading.props["aria-level"]).toBe(5);
    expect(heading).toHaveTextContent(baseProps.heading);
  });

  it("should render with the correct children", () => {
    render(
      <WrappedAlert {...baseProps} children={<View testID="mock-children" />} />
    );

    const children = screen.getByTestId("mock-children");

    expect(children).toBeDefined();
  });

  it("should render with a close button when the onRequestClose prop is provided", () => {
    const mockOnRequestClose = jest.fn();

    render(<WrappedAlert {...baseProps} onRequestClose={mockOnRequestClose} />);

    const button = screen.getByRole("button", {
      name: "Close",
    });

    expect(button).toBeDefined();
  });

  it("should trigger the onRequestClose event when the close button is pressed", async () => {
    const user = userEvent.setup();
    const mockOnRequestClose = jest.fn();

    render(<WrappedAlert {...baseProps} onRequestClose={mockOnRequestClose} />);

    const button = screen.getByRole("button", {
      name: "Close",
    });

    await act(async () => {
      await user.press(button);
    });

    expect(mockOnRequestClose).toHaveBeenCalledTimes(1);
  });

  it("should render with a default testID", () => {
    render(<WrappedAlert {...baseProps} />);

    expect(screen.getByTestId("alert")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-alert";

    render(<WrappedAlert {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
