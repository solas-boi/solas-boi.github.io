import { StyleSheet } from "react-native";
import { type AlertSeverity } from "@boi/components-core";
import {
  parseSizeToken,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { alert } = tokens;

  const styles = StyleSheet.create({
    container: {
      display: "flex",
      flexDirection: "row",
      gap: alert.gap,
      borderRadius: alert.radius,
      borderTopWidth: alert.stroke.width.top,
      borderLeftWidth: alert.stroke.width.left,
      borderRightWidth: alert.stroke.width.right,
      borderBottomWidth: alert.stroke.width.bottom,
      borderStyle: alert.stroke.style,
      paddingTop: alert.padding.top,
      paddingLeft: alert.padding.left,
      paddingRight: alert.padding.right,
      paddingBottom: alert.padding.bottom,
    },
    containerSeverityError: {
      borderColor: alert.stroke.color.error,
      backgroundColor: alert.background.error,
    },
    containerSeverityWarning: {
      borderColor: alert.stroke.color.warning,
      backgroundColor: alert.background.warning,
    },
    containerSeveritySuccess: {
      borderColor: alert.stroke.color.success,
      backgroundColor: alert.background.success,
    },
    containerSeverityInfo: {
      borderColor: alert.stroke.color.info,
      backgroundColor: alert.background.info,
    },
    contentContainer: {
      display: "flex",
      flexDirection: "row",
      flex: 1,
      gap: alert.contentContainer.gap,
      paddingTop: alert.contentContainer.padding.top,
      paddingLeft: alert.contentContainer.padding.left,
      paddingRight: alert.contentContainer.padding.right.default,
      paddingBottom: alert.contentContainer.padding.bottom,
    },
    contentContainerDismissible: {
      paddingRight: alert.contentContainer.padding.right.dismissible,
    },
    iconWrapper: {
      display: "flex",
      justifyContent: "center",
      height: parseSizeToken(alert.iconWrapper.height, fontScale),
    },
    textContainer: {
      flexShrink: 1,
    },
    closeIconButtonWrapper: {
      alignSelf: "center",
      margin: -8,
    },
    closeIconButtonWrapperBody: {
      alignSelf: "flex-start",
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  severity,
  hasBody,
  isDismissible,
}: {
  severity: AlertSeverity;
  hasBody: boolean;
  isDismissible: boolean;
}) {
  const styles = useStyles();

  const containerSeverityStyles = {
    error: styles.containerSeverityError,
    warning: styles.containerSeverityWarning,
    success: styles.containerSeveritySuccess,
    info: styles.containerSeverityInfo,
  };

  return {
    container: [styles.container, containerSeverityStyles[severity]],
    contentContainer: [
      styles.contentContainer,
      isDismissible && styles.contentContainerDismissible,
    ],
    closeIconButtonWrapper: [
      styles.closeIconButtonWrapper,
      hasBody && styles.closeIconButtonWrapperBody,
    ],
  };
}

export default useStyles;
