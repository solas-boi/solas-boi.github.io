export { default as ModalWrapperDecorator } from "./ModalWrapperDecorator";
