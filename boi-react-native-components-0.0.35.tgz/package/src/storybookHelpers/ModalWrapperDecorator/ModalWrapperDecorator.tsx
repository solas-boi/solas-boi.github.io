import { useState, type PropsWithChildren } from "react";
import { View } from "react-native";
import { StandardModal } from "../../StandardModal";
import { Button } from "../../Button";

function ModalWrapperDecorator(props: PropsWithChildren) {
  const { children } = props;
  const [isOpen, setIsOpen] = useState(false);
  return (
    <View>
      <Button
        text="Open Story wrapped by Modal"
        onPress={() => setIsOpen(true)}
      />
      <StandardModal
        isOpen={isOpen}
        title="Modal Wrapper"
        onRequestClose={() => setIsOpen(false)}
        supportedOrientations={["portrait", "landscape"]}
      >
        <StandardModal.ScrollView focusable={false}>
          {children}
        </StandardModal.ScrollView>
      </StandardModal>
    </View>
  );
}

export default ModalWrapperDecorator;
