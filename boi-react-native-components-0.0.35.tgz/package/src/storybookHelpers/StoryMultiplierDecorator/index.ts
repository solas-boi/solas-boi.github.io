export { default as StoryMultiplierDecorator } from "./StoryMultiplierDecorator";
