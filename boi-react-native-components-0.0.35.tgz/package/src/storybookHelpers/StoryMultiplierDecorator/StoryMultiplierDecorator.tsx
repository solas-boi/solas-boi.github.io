import { cloneElement, useMemo, type PropsWithChildren } from "react";

function StoryMultiplierDecorator(
  props: PropsWithChildren & { count: number }
) {
  const { children, count } = props;
  const multipliedChildren = useMemo(() => {
    return new Array(count).fill("").map((_, index) => {
      return cloneElement(children as any, { key: index });
    });
  }, [count, children]);
  return multipliedChildren;
}

export default StoryMultiplierDecorator;
