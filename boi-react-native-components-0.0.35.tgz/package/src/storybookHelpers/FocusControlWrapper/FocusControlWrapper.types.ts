import type { ReactNode, Ref } from "react";
import { View } from "react-native";

export type FocusableRef = {
  focus?: () => void;
};

export type WithFocusControlStoryArgs<TProps> = TProps & {
  showFocusButton: boolean;
};

export type FocusControlWrapperProps<RefType extends FocusableRef = View> = {
  showFocusButton?: boolean;
  children: (ref: Ref<RefType> | undefined) => ReactNode;
};
