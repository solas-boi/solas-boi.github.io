export const withFocusControlStoryArgs = <StoryType>(
  props: { args?: object } = {}
): StoryType =>
  ({
    ...props,
    args: { ...(props?.args ?? {}), showFocusButton: true },
  } as unknown as StoryType);
