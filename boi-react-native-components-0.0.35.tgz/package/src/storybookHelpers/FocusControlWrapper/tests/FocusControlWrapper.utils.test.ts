import { withFocusControlStoryArgs } from "../FocusControlWrapper.utils";

type MockStory = {
  title?: string;
  parameters?: { layout?: string };
  args?: {
    label?: string;
    showFocusButton?: boolean;
  };
};

describe("FocusControlWrapper.utils", () => {
  it("adds showFocusButton=true when args are missing", () => {
    const story = withFocusControlStoryArgs<MockStory>();

    expect(story).toEqual({
      args: {
        showFocusButton: true,
      },
    });
  });

  it("merges existing args and keeps other story props", () => {
    const input: { args: { label: string }; title: string } = {
      title: "Input story",
      args: { label: "Email" },
    };

    const story = withFocusControlStoryArgs<MockStory>(input);

    expect(story).toEqual({
      title: "Input story",
      args: {
        label: "Email",
        showFocusButton: true,
      },
    });
  });

  it("always forces showFocusButton=true and does not mutate input", () => {
    const input: MockStory = {
      parameters: { layout: "centered" },
      args: {
        label: "Phone",
        showFocusButton: false,
      },
    };

    const story = withFocusControlStoryArgs<MockStory>(input);

    expect(story.args?.showFocusButton).toBe(true);
    expect(input.args?.showFocusButton).toBe(false);
    expect(story.parameters).toEqual({ layout: "centered" });
  });
});
