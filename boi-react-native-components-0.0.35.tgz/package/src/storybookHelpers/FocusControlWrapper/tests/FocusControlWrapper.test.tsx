import { forwardRef, useImperativeHandle } from "react";
import { fireEvent, render, screen } from "@testing-library/react-native";
import { View } from "react-native";
import { FocusControlWrapper } from "../FocusControlWrapper";
import type { FocusableRef } from "../FocusControlWrapper.types";

describe("FocusControlWrapper", () => {
  it("renders children without focus button by default", () => {
    render(
      <FocusControlWrapper>
        {(ref) => {
          expect(ref).toBeUndefined();

          return <View testID="content" />;
        }}
      </FocusControlWrapper>
    );

    expect(screen.getByTestId("content")).toBeTruthy();
    expect(screen.queryByText("Focus Input")).toBeNull();
  });

  it("renders focus button and passes a ref when showFocusButton is true", () => {
    let receivedRef: React.Ref<View> | undefined;

    render(
      <FocusControlWrapper showFocusButton>
        {(ref) => {
          receivedRef = ref;

          return <View testID="content" />;
        }}
      </FocusControlWrapper>
    );

    expect(receivedRef).toBeDefined();
    expect(screen.getByText("Focus Input")).toBeTruthy();
  });

  it("focuses child ref when pressing the focus button", () => {
    const focusMock = jest.fn();

    const FocusableChild = forwardRef<FocusableRef>((_, ref) => {
      useImperativeHandle(ref, () => ({
        focus: focusMock,
      }));

      return <View testID="focusable-child" />;
    });

    render(
      <FocusControlWrapper<FocusableRef> showFocusButton>
        {(ref) => <FocusableChild ref={ref} />}
      </FocusControlWrapper>
    );

    fireEvent.press(screen.getByText("Focus Input"));

    expect(focusMock).toHaveBeenCalledTimes(1);
  });
});
