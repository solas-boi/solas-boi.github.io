import { useRef } from "react";
import { Button, View } from "react-native";
import type {
  FocusableRef,
  FocusControlWrapperProps,
} from "./FocusControlWrapper.types";

export const FocusControlWrapper = <RefType extends FocusableRef = View>({
  showFocusButton = false,
  children,
}: FocusControlWrapperProps<RefType>) => {
  const ref = useRef<RefType | null>(null);

  const handleFocus = () => ref.current?.focus?.();

  if (!showFocusButton) {
    return children(undefined);
  }

  return (
    <View style={{ padding: 10, gap: 10 }}>
      {children(ref)}
      <Button onPress={handleFocus} title="Focus Input" />
    </View>
  );
};
