import { render } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "./themedStyleSheet";

function wrapComponent(Component: React.FunctionComponent) {
  return () => (
    <DesignTokensProvider>
      <Component />
    </DesignTokensProvider>
  );
}

describe("createThemedStyleSheet", () => {
  it("should store stylesheet", () => {
    const styleSheetFactory = () => ({ color: "red" });
    const useStyles = createThemedStyleSheet(styleSheetFactory);
    let styles;
    const WrappedTestComponent = wrapComponent(function TestComponent() {
      styles = useStyles();
      return undefined;
    });
    render(<WrappedTestComponent />);
    expect(styles).toMatchObject({
      color: "red",
    });
  });
});
