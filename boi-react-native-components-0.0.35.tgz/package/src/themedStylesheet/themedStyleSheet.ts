import {
  useDesignTokens,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";
import { useWindowDimensions } from "react-native";

/**
 * Use this method to create a StyleSheet that is cached by theme
 *
 * @param stylesFactory - A function that receives tokens and fontScale as a parameter and returns a StyleSheet
 * @returns a hook that generates a React Native StyleSheet using the factory parameter or gets it from the cache storage
 *
 * @example Creating a themed StyleSheet
 *
 * const useStyles = createThemedStyleSheet((tokens) => {
 *  return StyleSheet.create({
 *      myStyle: {
 *        color: tokens.myComponent.color
 *     }
 *  })
 * })
 *
 * const styles = useStyles();
 */
export function createThemedStyleSheet<T>(
  factory: (tokens: ThemeTokens, fontScale: number) => T
) {
  let cachedTokens: ThemeTokens | undefined;
  let storage: { [theme: string]: T | undefined } = {};
  let previousFontScale: number;
  return function useStyles() {
    const { fontScale } = useWindowDimensions();
    const { theme, tokens } = useDesignTokens();

    if (cachedTokens !== tokens) {
      cachedTokens = tokens;
      storage = {};
    }
    if (previousFontScale !== fontScale) {
      previousFontScale = fontScale;
      storage = {};
    }

    // Look for a StyleSheet using `theme` as an index. If not found, create one
    const styleSheet = (storage[theme] ??= factory(tokens, fontScale));

    return styleSheet;
  };
}
