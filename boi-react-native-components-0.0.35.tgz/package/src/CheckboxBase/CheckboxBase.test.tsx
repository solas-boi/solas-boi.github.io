import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import CheckboxBase, { type CheckboxBaseProps } from "./CheckboxBase";

jest.useFakeTimers();

function WrappedCheckboxBase(props: CheckboxBaseProps) {
  return (
    <DesignTokensProvider>
      <CheckboxBase {...props} />
    </DesignTokensProvider>
  );
}

describe("CheckboxBase", () => {
  it("should render without any children", () => {
    render(<WrappedCheckboxBase />);

    const checkbox = screen.getByTestId("checkbox-base");

    expect(checkbox).toBeDefined();
  });
});
