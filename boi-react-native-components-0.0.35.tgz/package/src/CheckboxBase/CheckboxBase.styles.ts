import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { type CheckboxBaseProps } from "./CheckboxBase";
import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { checkbox } = tokens;

  return StyleSheet.create({
    customCheckbox: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: checkbox.width,
      height: checkbox.height,
      backgroundColor: checkbox.backgroundColor.unchecked.base,
      borderRadius: checkbox.stroke.radius,
      borderWidth: checkbox.stroke.width.unchecked.base,
      borderStyle: "solid",
      borderColor: checkbox.stroke.color.base,
    },
    customCheckboxChecked: {
      backgroundColor: checkbox.backgroundColor.checked.base,
      borderWidth: checkbox.stroke.width.checked.base,
    },
    customCheckboxError: {
      borderWidth: checkbox.stroke.width.unchecked.error,
      borderColor: checkbox.stroke.color.error,
    },
    customCheckboxDisabled: {
      borderWidth: checkbox.stroke.width.unchecked.disabled,
      borderColor: checkbox.stroke.color.disabled,
    },
    customCheckboxCheckedDisabled: {
      backgroundColor: checkbox.backgroundColor.checked.disabled,
      borderWidth: checkbox.stroke.width.checked.disabled,
    },
    icon: {
      width: checkbox.icon.width,
      height: checkbox.icon.height,
      color: checkbox.icon.color.base,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  disabled,
  isChecked,
  isIndeterminate,
  hasError,
}: Pick<
  CheckboxBaseProps,
  "disabled" | "isChecked" | "isIndeterminate" | "hasError"
>) {
  const styles = useStyles();

  return {
    customCheckbox: [
      styles.customCheckbox,
      (isChecked || isIndeterminate) && styles.customCheckboxChecked,
      hasError && styles.customCheckboxError,
      disabled && styles.customCheckboxDisabled,
      (isChecked || isIndeterminate) &&
        disabled &&
        styles.customCheckboxCheckedDisabled,
    ],
  };
}

export default useStyles;
