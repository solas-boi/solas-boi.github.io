import { View, ViewProps } from "react-native";
import { TickIcon, MinusIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./CheckboxBase.styles";

export type CheckboxBaseProps = Omit<ViewProps, "style" | "children"> & {
  disabled?: boolean | null;
  isChecked?: boolean;
  hasError?: boolean;
  isIndeterminate?: boolean;
  children?: (checkboxComponent: JSX.Element) => JSX.Element;
};

function CheckboxBase(props: CheckboxBaseProps) {
  const {
    isChecked,
    hasError,
    isIndeterminate,
    children,
    disabled,
    testID = "checkbox-base",
    ...viewProps
  } = props;

  const styles = useStyles();
  const stateStyles = useStateStyles({
    disabled,
    isChecked,
    isIndeterminate,
    hasError,
  });

  const jsx = (
    <View testID={testID} style={stateStyles.customCheckbox} {...viewProps}>
      {isIndeterminate ? (
        <MinusIcon style={styles.icon} />
      ) : isChecked ? (
        <TickIcon style={styles.icon} />
      ) : undefined}
    </View>
  );

  if (children) {
    return children(jsx);
  } else {
    return jsx;
  }
}

export default CheckboxBase;
