export {
  default as CheckboxBase,
  type CheckboxBaseProps,
} from "./CheckboxBase";
