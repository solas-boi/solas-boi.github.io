import type { Meta, StoryObj } from "@storybook/react";
import { CoreLink } from "@boi/components-core";

import Link from "./Link";

const meta = {
  title: "Inputs/Link",
  component: Link,
  argTypes: {
    variant: {
      control: { type: "select" },
      options: CoreLink.VARIANTS.filter((variant) =>
        ["bodyM", "bodyS"].includes(variant)
      ),
    },
    children: { control: { type: "text" } },
  },
  args: {
    variant: CoreLink.DEFAULT_VARIANT,
    children: "Text link label",
  },
} satisfies Meta<typeof Link>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
