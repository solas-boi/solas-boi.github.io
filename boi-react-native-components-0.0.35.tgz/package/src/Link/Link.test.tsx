import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Link, { type LinkProps } from "./Link";

jest.useFakeTimers();

function WrappedLink(props: LinkProps) {
  return (
    <DesignTokensProvider>
      <Link {...props} />
    </DesignTokensProvider>
  );
}

describe("Link", () => {
  let baseProps: LinkProps;

  beforeEach(() => {
    baseProps = {
      children: "Text link label",
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedLink {...baseProps} />);

    const text = screen.getByRole("text");
    expect(text).toBeDefined();
  });

  it("should render with the correct text", () => {
    render(<WrappedLink {...baseProps} />);

    const text = screen.getByRole("text");
    expect(text).toHaveTextContent(baseProps.children);
  });

  it("should trigger the onPress event when pressed", async () => {
    const user = userEvent.setup();
    const mockOnPress = jest.fn();

    render(<WrappedLink onPress={mockOnPress}>Text link label</WrappedLink>);

    const text = screen.getByRole("text");
    expect(text).toBeDefined();

    await act(async () => {
      await user.press(text);
    });

    expect(mockOnPress).toHaveBeenCalled();
  });

  it("should render with a default testID", () => {
    render(<WrappedLink {...baseProps} />);

    expect(screen.getByTestId("link")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-link";

    render(<WrappedLink {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
