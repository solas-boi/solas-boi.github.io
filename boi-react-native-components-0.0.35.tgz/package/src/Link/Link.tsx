import { forwardRef } from "react";
import { View } from "react-native";
import { KeyboardFocus } from "react-native-external-keyboard";

import { LinkWithIcon, LinkWithIconProps } from "../LinkWithIcon";

export type LinkProps = Omit<LinkWithIconProps, "startIcon" | "endIcon">;

const Link = forwardRef<View | KeyboardFocus, LinkProps>((props, ref) => {
  return <LinkWithIcon {...props} ref={ref} />;
});
Link.displayName = "Link";

export default Link;
