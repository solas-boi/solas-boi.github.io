# React Native components

Shared React Native component library.

## Installation

```console
npm i @react-native-async-storage/async-storage
npm i @react-native-community/datetimepicker
npm i react-native-modal-datetime-picker
npm i @boi/react-native-design-tokens
npm i @boi/react-native-components
```

## Usage

Render the `DesignTokensProvider` at the root of your application:

```jsx
import {
  DesignTokensProvider,
  BOI_THEME_TOKENS,
} from "@boi/react-native-design-tokens";
import { Button } from "@boi/react-native-components";

export default function App() {
  return (
    <DesignTokensProvider themeTokens={BOI_THEME_TOKENS}>
      <Button />
    </DesignTokensProvider>
  );
}
```

## Component Specific Docs

[Toggle component](src/Toggle/README.md)

[Typography component](src/Typography/README.md)

[TextArea component](src/TextArea/README.md)
