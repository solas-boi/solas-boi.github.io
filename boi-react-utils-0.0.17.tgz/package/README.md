# React utils

Set of React utility functions used for Bank of Ireland.

## Installation

```console
npm i @boi/react-utils
```

## Usage

```jsx
import { getIconSelectArgType } from "@boi/react-utils";
```
