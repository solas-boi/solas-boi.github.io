import { render, screen, userEvent } from "@testing-library/react-native";
import { CoreMultiSelect } from "@boi/components-core";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import MultiSelectModal, {
  type MultiSelectModalProps,
} from "./MultiSelectModal";

jest.useFakeTimers();

function WrappedMultiSelectModal(
  props: MultiSelectModalProps<CoreMultiSelect.MultiSelectItem>
) {
  return (
    <DesignTokensProvider>
      <MultiSelectModal {...props} />
    </DesignTokensProvider>
  );
}

describe("MultiSelectModal", () => {
  let baseProps: MultiSelectModalProps<CoreMultiSelect.MultiSelectItem>;

  let mockOnChange = jest.fn();
  let mockOnRequestClose = jest.fn();

  beforeEach(() => {
    baseProps = {
      title: "Modal heading",
      isOpen: false,
      items: CoreMultiSelect.mockItems,
      onChange: mockOnChange,
      onRequestClose: mockOnRequestClose,
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should reset updatedSelectedItems when isOpen changes", async () => {
    const user = userEvent.setup();

    const { rerender } = render(
      <WrappedMultiSelectModal {...baseProps} isOpen />
    );

    const firstOption = screen.getAllByRole("checkbox")[0]!;

    await user.press(firstOption);

    let selectedOptions = screen.queryAllByRole("checkbox", {
      checked: true,
    });

    expect(selectedOptions).toHaveLength(1);

    rerender(<WrappedMultiSelectModal {...baseProps} isOpen={false} />);
    rerender(<WrappedMultiSelectModal {...baseProps} isOpen={true} />);

    selectedOptions = screen.queryAllByRole("checkbox", {
      checked: true,
    });

    expect(selectedOptions).toHaveLength(0);
  });

  it("should call onChange and onRequestClose when the confirm button is pressed", async () => {
    const user = userEvent.setup();

    render(<WrappedMultiSelectModal {...baseProps} isOpen />);

    const confirmButton = screen.getByRole("button", {
      name: "Confirm",
    });

    await user.press(confirmButton);

    expect(mockOnChange).toHaveBeenCalled();
    expect(mockOnRequestClose).toHaveBeenCalled();
  });
});
