import { StyleSheet } from "react-native";
import { CoreMenu } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { menu } = tokens;

  return StyleSheet.create({
    outerListContainer: {
      position: "absolute",
      zIndex: menu.zIndex,
    },
    hidden: {
      opacity: 0,
    },
    listContainer: {
      overflow: "hidden",
      borderRadius: menu.radius,
      borderWidth: menu.stroke.width,
      borderStyle: menu.stroke.style,
      borderColor: menu.stroke.color,
    },
    maxHeightWrapper: {
      width: "100%",
      maxHeight: CoreMenu.MAX_LIST_HEIGHT,
    },
    scrollview: {
      backgroundColor: menu.option.inner.backgroundColor.base,
    },
    list: {
      gap: menu.separator.width,
      backgroundColor: menu.separator.color,
      maxWidth: menu.maxWidth,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

type StateStylesArgs = {
  padding?: number;
  placement: CoreMenu.Placement;
  anchorPosition?: { x: number; y: number };
  floatingStyles: { top: number; left: number };
};

export function useStateStyles({
  padding,
  placement,
  floatingStyles,
  anchorPosition,
}: StateStylesArgs) {
  const styles = useStyles();

  // `padding` inflates the measured floating box, which shifts the
  // alignment edge computed by floating-ui; compensate so the visible
  // menu edge stays flush with the reference edge on the aligned side.
  const paddingCompensation = padding
    ? placement === "bottom-start"
      ? -padding
      : padding
    : 0;

  return {
    outerListContainer: [
      styles.outerListContainer,
      { padding },
      {
        top: floatingStyles.top + (anchorPosition?.y || 0),
        left:
          floatingStyles.left + (anchorPosition?.x || 0) + paddingCompensation,
      },
    ],
  };
}

export default useStyles;
