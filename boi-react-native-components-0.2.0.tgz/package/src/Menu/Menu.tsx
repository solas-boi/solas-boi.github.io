import {
  useState,
  useLayoutEffect,
  useCallback,
  useMemo,
  useRef,
  type JSX,
} from "react";
import {
  View,
  ScrollView,
  StyleSheet,
  Modal,
  ModalProps,
  Platform,
  type ViewInstance,
} from "react-native";
import {
  Pressable as KeyboardPressable,
  type OnKeyPressFn,
  type KeyboardFocus,
} from "react-native-external-keyboard";
import { useFloating, offset } from "@floating-ui/react-native";
import { CoreMenu, type PropsWithOptionalTestID } from "@boi/components-core";

import useStyles, { useStateStyles } from "./Menu.styles";
import type { MenuItem } from "./Menu.types";
import { KeyboardPressableProps } from "../types";
import { MenuListItem } from "../MenuListItem";

type NativeReferenceRef = NonNullable<KeyboardPressableProps["componentRef"]>;

type ReferenceProps = Pick<
  KeyboardPressableProps,
  "onPress" | "aria-expanded"
> & {
  ref: React.Ref<KeyboardFocus>;
  componentRef: NativeReferenceRef;
  isPressed: boolean;
};

export const onKeyUpPressHandlerFactory = (
  platform: typeof Platform.OS,
  onRequestClose: () => void
) => {
  const handler: OnKeyPressFn = (evt) => {
    if (platform === "ios" && evt.nativeEvent.keyCode === 41) {
      onRequestClose();
    }
  };
  return handler;
};

export type MenuProps<T extends MenuItem> = PropsWithOptionalTestID &
  Pick<ModalProps, "supportedOrientations"> & {
    items: T[];
    offset?: number;
    padding?: number;
    placement?: CoreMenu.Placement;
    renderListItemContent: (item: T, isDisabled: boolean) => JSX.Element;
    children: (referenceProps: ReferenceProps) => JSX.Element;
    disabledKeys?: string[];
  };

function isView(reference: any): reference is ViewInstance {
  return !!reference && "measureInWindow" in reference;
}

function Menu<T extends MenuItem>(props: MenuProps<T>) {
  const {
    items,
    offset: offsetValue = CoreMenu.DEFAULT_OFFSET,
    padding,
    placement = CoreMenu.DEFAULT_PLACEMENT,
    renderListItemContent,
    children,
    testID = "menu",
    supportedOrientations,
    disabledKeys,
  } = props;

  const [isOpen, setIsOpen] = useState(false);

  const nativeReferenceRef = useRef<View>(null) as NativeReferenceRef;

  const { refs, floatingStyles, update } = useFloating({
    placement,
    middleware: [offset(offsetValue)],
  });

  const onRequestClose = useCallback(() => {
    setIsOpen(false);

    setTimeout(() => {
      const elementToFocus = refs.reference.current;
      if (elementToFocus) {
        elementToFocus.focus?.();
      }
    }, 500);
  }, [refs.reference]);

  const [anchorPosition, setAnchorPosition] = useState<{
    x: number;
    y: number;
  }>();
  const [isPositioned, setIsPositioned] = useState(false);

  const styles = useStyles();

  const stateStyles = useStateStyles({
    padding,
    placement,
    anchorPosition,
    floatingStyles,
  });

  useLayoutEffect(() => {
    const reference = isView(nativeReferenceRef.current)
      ? nativeReferenceRef.current
      : refs.reference.current;

    if (isView(nativeReferenceRef.current)) {
      refs.setReference(nativeReferenceRef.current);
    }

    if (!isOpen) {
      setIsPositioned(false);
      return;
    }

    if (isView(reference)) {
      // `measure()`'s x is relative to the reference's immediate parent
      // (which floating-ui bakes into its horizontal alignment math), while
      // `measureInWindow` gives the absolute position; subtract the former so
      // it isn't double counted when combined with `floatingStyles.left`.
      reference.measure((relativeX: number) => {
        reference.measureInWindow((x: number, y: number) => {
          setAnchorPosition({ x: x - relativeX, y });
          // Force update the `useFloating` values
          // so to prevent the menu from jumping between renders
          update();
        });
      });
    }
  }, [refs, refs.reference, isOpen, update]);

  const onKeyUpPressHandler = useMemo(() => {
    return onKeyUpPressHandlerFactory(Platform.OS, onRequestClose);
  }, [onRequestClose]);

  function handleClick(item: T) {
    item.onPress();
    setIsOpen(false);
  }

  return (
    <>
      {children({
        ref: refs.setReference,
        componentRef: nativeReferenceRef,
        isPressed: isOpen,
        onPress: () => {
          setIsOpen(!isOpen);
        },
        "aria-expanded": isOpen,
      })}

      <Modal
        visible={isOpen}
        transparent
        onRequestClose={onRequestClose}
        supportedOrientations={supportedOrientations}
      >
        <KeyboardPressable
          containerStyle={StyleSheet.absoluteFill}
          style={StyleSheet.absoluteFill}
          onPress={onRequestClose}
          accessibilityLabel="Close menu"
          accessibilityHint="Close menu"
          onKeyUpPress={onKeyUpPressHandler}
        />
        <View
          ref={refs.setFloating}
          onLayout={() => {
            // Recompute placement now that the anchor position is known
            update();
            requestAnimationFrame(() => setIsPositioned(true));
          }}
          style={[
            stateStyles.outerListContainer,
            !isPositioned && styles.hidden,
          ]}
          testID={testID}
          accessibilityRole="menu"
          accessibilityLabel="Menu"
          accessibilityHint="Menu"
          accessibilityState={{ expanded: isOpen }}
          aria-expanded={isOpen}
          accessibilityLiveRegion="polite"
          importantForAccessibility="yes"
          focusable={true}
        >
          <View style={styles.listContainer}>
            <View style={styles.maxHeightWrapper}>
              <ScrollView style={styles.scrollview}>
                <View style={styles.list}>
                  {items.map((item) => {
                    const isDisabled = disabledKeys
                      ? disabledKeys.includes(item.id)
                      : false;
                    return (
                      <MenuListItem
                        key={item.id}
                        testID={testID}
                        data={item}
                        onPress={() => handleClick(item)}
                        onKeyUpPress={onKeyUpPressHandler}
                        isDisabled={isDisabled}
                      >
                        {renderListItemContent(item, isDisabled)}
                      </MenuListItem>
                    );
                  })}
                </View>
              </ScrollView>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

export default Menu;
