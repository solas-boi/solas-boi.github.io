import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";

import CurrencyInput, { type CurrencyInputProps } from "./CurrencyInput";
import {
  FocusControlWrapper,
  InputAccessoryViewDecorator,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const meta: Meta<CurrencyInputProps> = {
  title: "Inputs/CurrencyInput",
  component: CurrencyInput,
  render: function Render(args: any) {
    function handleTextChange(newValue: string) {
      action("onTextChange")(newValue);
    }

    function handleChangeCurrency(newValue: number) {
      action("onChangeCurrency")(newValue);
    }

    return (
      <FocusControlWrapper {...args}>
        {(ref) => (
          <CurrencyInput
            {...args}
            ref={ref}
            onChangeText={handleTextChange}
            onChangeCurrency={handleChangeCurrency}
          />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    disabled: { control: "boolean" },
    readonly: { control: "boolean" },
    hasError: { control: "boolean" },
    value: { control: "number" },
    minValue: { control: "number" },
    maxValue: { control: "number" },
    maxLength: { control: "number" },
    prefix: { control: "text" },
  },
  args: {
    disabled: false,
    readonly: false,
    hasError: false,
  },
};

export default meta;
type Story = StoryObj<CurrencyInputProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "CurrencyInput",
    },
  },
};

export const WithLabel: Story = {
  ...Basic,
  args: {
    value: 100092.13,
    labelProps: {
      label: "CurrencyInput",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithGermanLocale: Story = {
  ...Basic,
  args: {
    value: 12.54,
    locale: "de-DE",
    labelProps: {
      label: "CurrencyInput (German locale)",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithZeroDecimalPlaces: Story = {
  ...Basic,
  args: {
    currencyFormat: "NoDecimalPlaces",
    value: 12,
    labelProps: {
      label: "CurrencyInput with zero decimal places",
    },
  },
};

export const WithDollarSymbol: Story = {
  ...Basic,
  args: {
    value: 15.24,
    currencySymbol: "$",
    labelProps: {
      label: "CurrencyInput with $",
    },
  },
};

export const WithNegativeValues: Story = {
  ...Basic,
  args: {
    minValue: -90,
    defaultValue: -23.45,
    labelProps: {
      label: "CurrencyInput -",
    },
  },
};

export const WithA11y: Story = {
  ...Basic,
  args: {
    defaultValue: 23.45,
    accessibilityLabel: "a11y label",
    accessibilityHint: "a11y hint",
    labelProps: {
      label: "A11y CurrencyInput",
    },
  },
};

export const Disabled: Story = {
  ...Basic,
  args: {
    disabled: true,
    value: 89.08,
    labelProps: {
      label: "Disabled CurrencyInput",
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    value: 45.89,
    labelProps: {
      label: "CurrencyInput with Error",
    },
    alertProps: {
      severity: "error",
      children: "Amount must be between €1,000 and €2,000.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const ReadOnly: Story = {
  ...Basic,
  args: {
    readonly: true,
    value: 30.67,
    labelProps: {
      label: "ReadOnly CurrencyInput",
    },
  },
};

export const WithKeyboardAccessoryView: Story = {
  ...Basic,
  args: {
    labelProps: {
      label: "CurrencyInput with Keyboard Accessory View",
    },
  },
  decorators: [InputAccessoryViewDecorator],
};
