import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";

import { DatePicker, type DatePickerProps } from ".";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";
import { type TextInputInstance } from "react-native";

const meta: Meta<typeof DatePicker> = {
  title: "Inputs/DatePicker",
  component: DatePicker,
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    function handleChange(newDate: Date | undefined) {
      updateArgs({ date: newDate });
      action("onChange")(newDate?.toString());
    }

    function handleChangeText(text: string) {
      action("onChangeText")(text);
    }

    return (
      <FocusControlWrapper<TextInputInstance> {...args}>
        {(ref) => (
          <DatePicker
            {...args}
            ref={ref}
            onChange={handleChange as () => void}
            onChangeText={handleChangeText}
          />
        )}
      </FocusControlWrapper>
    );
  },
  argTypes: {
    date: { control: { disable: true } },
  },
  args: {
    date: undefined,
  },
};

export default meta;
type Story = StoryObj<DatePickerProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      label: "DatePicker with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithCalendar: Story = {
  args: {
    withCalendar: true,
    labelProps: {
      label: "DatePicker with Label",
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    withCalendar: true,
    labelProps: {
      label: "DatePicker with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    hasError: true,
    withCalendar: true,
    labelProps: {
      label: "DatePicker with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus: Story = withFocusControlStoryArgs(WithError);
