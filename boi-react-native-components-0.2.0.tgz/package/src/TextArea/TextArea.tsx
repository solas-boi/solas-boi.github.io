import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  type ForwardRefExoticComponent,
  type RefAttributes,
} from "react";
import {
  Platform,
  View,
  ScrollView,
  type TextInputProps as RNTextInputProps,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
  type TextInputInstance,
  type ScrollViewInstance,
} from "react-native";
import { KeyboardExtendedInput } from "react-native-external-keyboard";
import {
  CoreTextArea,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { useStateStyles } from "./TextArea.styles";
import { InnerShadow } from "./InnerShadow";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { OuterField } from "../OuterField";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { CharactersCounter } from "../CharactersCounter";
import { useSimpleA11yProps } from "../hooks";
import { ScreenReaderAlertNotifier } from "../ScreenReaderAlertNotifier";

export type TextAreaProps = PropsWithOptionalTestID &
  Omit<
    RNTextInputProps,
    "style" | "editable" | "selectionColor" | "numberOfLines"
  > & {
    noCounter?: boolean;
    hasError?: boolean;
    readonly?: boolean;
    disabled?: boolean;
    autoGrow?: boolean;
    autoGrowMaxLines?: number;
    isCompact?: boolean;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    labelProps: Omit<InputLabelTopProps, "children">;
  };

const TextArea: ForwardRefExoticComponent<
  TextAreaProps & RefAttributes<TextInputInstance>
> = forwardRef<TextInputInstance, TextAreaProps>((props, ref) => {
  const {
    testID = "textarea",
    labelProps,
    alertProps,
    autoGrow,
    autoGrowMaxLines,
    isCompact,
    disabled,
    readonly,
    hasError,
    onChangeText,
    onFocus,
    onBlur,
    onScroll,
    noCounter,
    ...inputProps
  } = props;
  const scrollViewRef = useRef<ScrollViewInstance>(null);
  const inputRef = useRef<TextInputInstance | null>(null);

  const { maxLength } = inputProps;

  const showCounter = !noCounter && maxLength;

  // isCompact always auto-grows, regardless of the autoGrow prop.
  const resolvedAutoGrow = isCompact ? true : autoGrow;

  const { tokens } = useDesignTokens();
  const [displayInnerShadow, setDisplayInnerShadow] =
    useState<CoreTextArea.DisplayInnerShadow>(null);
  const [hasFocus, setHasFocus] = useState(false);
  const handleFocus = useCallback<NonNullable<typeof onFocus>>(
    (evt) => {
      setHasFocus(true);
      onFocus?.(evt);
    },
    [onFocus]
  );
  const handleBlur = useCallback<NonNullable<typeof onBlur>>(
    (evt) => {
      setHasFocus(false);
      onBlur?.(evt);
    },
    [onBlur]
  );

  const styles = useStateStyles({
    hasFocus,
    isDisabled: disabled,
    isReadOnly: readonly,
    autoGrow: resolvedAutoGrow,
    autoGrowMaxLines,
    isCompact,
  });

  const [length, setLength] = useState(
    (inputProps.value || inputProps.defaultValue)?.length || 0
  );
  const handleChangeText = useCallback(
    (newValue: string) => {
      setLength(newValue.length);
      onChangeText?.(newValue);
    },
    [onChangeText]
  );

  const handleScroll = useCallback(
    (evt: NativeSyntheticEvent<NativeScrollEvent>) => {
      const { contentOffset, layoutMeasurement, contentSize } = evt.nativeEvent;

      const innerShadowToDisplay = CoreTextArea.determineInnerShadowToDisplay(
        contentOffset.y,
        contentSize.height,
        layoutMeasurement.height
      );
      setDisplayInnerShadow(innerShadowToDisplay);

      onScroll?.(evt);
    },
    [onScroll]
  );

  const hasInitialText = Boolean(inputProps.value || inputProps.defaultValue);

  useImperativeHandle(ref, () => inputRef.current as TextInputInstance, []);

  // On iOS the TextInput shadow node never records its base text attributes
  // when it mounts empty, which permanently disables multiline auto-grow
  // (https://github.com/react/react-native/issues/52854). This only affects
  // uncontrolled inputs - a controlled one records them as soon as its value
  // becomes non-empty. Writing one character and clearing it records them once.
  useEffect(() => {
    if (Platform.OS !== "ios" || hasInitialText) {
      return;
    }

    inputRef.current?.setNativeProps({ text: " " });
    inputRef.current?.setNativeProps({ text: "" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const simpleA11yProps = useSimpleA11yProps(props);

  return (
    <InputWrapper
      gap={showCounter ? 4 : 8}
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <OuterField
          hasError={hasError}
          hasFocus={hasFocus}
          isActive={hasFocus}
          isDisabled={disabled}
          isReadOnly={readonly}
        >
          <InnerShadow
            testID={`${testID}-top-innershadow`}
            type="TOP"
            show={displayInnerShadow === "TOP" || displayInnerShadow === "BOTH"}
          />

          <InnerShadow
            testID={`${testID}-bottom-innershadow`}
            type="BOTTOM"
            show={
              displayInnerShadow === "BOTTOM" || displayInnerShadow === "BOTH"
            }
          />

          <ScrollView
            testID={`${testID}-scrollview`}
            ref={scrollViewRef}
            onScroll={handleScroll}
            scrollEventThrottle={10}
            style={styles.scrollView}
            contentContainerStyle={styles.scrollViewContent}
            scrollEnabled={true}
            overScrollMode="never"
          >
            <ScreenReaderAlertNotifier alert={alertProps}>
              <KeyboardExtendedInput
                {...inputProps}
                {...simpleA11yProps}
                textAlign={inputProps.textAlign as "left" | "center" | "right"}
                autoComplete={inputProps.autoComplete as never}
                tintType="none"
                onFocusChange={(isFocused) => {
                  setHasFocus(isFocused);
                }}
                ref={inputRef}
                testID={testID}
                style={styles.input}
                selectionColor={tokens.textInput.selectionColor}
                placeholderTextColor={tokens.textInput.color.placeholder}
                editable={!disabled && !readonly}
                onChangeText={handleChangeText}
                onFocus={handleFocus}
                onBlur={handleBlur}
                scrollEnabled={false}
                allowFontScaling={false}
                multiline
              />
            </ScreenReaderAlertNotifier>
          </ScrollView>
        </OuterField>
      </InputLabelTop>
      {showCounter ? (
        <CharactersCounter
          length={length}
          maxLength={maxLength}
          testID={`${testID}-characters-counter`}
        />
      ) : undefined}
    </InputWrapper>
  );
});

TextArea.displayName = "TextArea";

export default TextArea;
