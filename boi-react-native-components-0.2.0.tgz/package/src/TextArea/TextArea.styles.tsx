import { StyleSheet, useWindowDimensions } from "react-native";
import { CoreTypography } from "@boi/components-core";
import {
  parseSizeToken,
  useDesignTokens,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";
import { OuterFieldProps } from "../OuterField/OuterField";

const scrollViewMargin = {
  horizontal: 8,
  vertical: 2,
};

function styleSheetFactory(tokens: ThemeTokens, fontScale: number) {
  const { textArea, typography } = tokens;

  const typographyVariant: CoreTypography.Variant = textArea.typography.variant;

  const scrollView = StyleSheet.create({
    base: {
      height: textArea.minHeight,
      marginHorizontal: scrollViewMargin.horizontal,
      marginVertical: scrollViewMargin.vertical,
    },
  });

  const scrollViewContent = StyleSheet.create({
    base: {
      width: "100%",
    },
  });

  const input = StyleSheet.create({
    base: {
      minHeight: textArea.minHeight,
      width: "100%",
      backgroundColor: "transparent",
      borderColor: "transparent",

      paddingVertical: textArea.paddingVertical - scrollViewMargin.vertical,
      paddingHorizontal:
        textArea.paddingHorizontal - scrollViewMargin.horizontal,

      textAlignVertical: "top",
      color: textArea.color.base,
      fontFamily: typography.fontFamily[typographyVariant],
      fontSize: parseSizeToken(
        typography.fontSize[typographyVariant],
        fontScale
      ),
      lineHeight:
        parseSizeToken(typography.lineHeight[typographyVariant], fontScale) - 2, // TODO: Find out why we need a -2 here for it to look right
    },
    // KeyboardExtendedInput never receives an explicit containerStyle, so its
    // native wrapper has no size of its own - height:"100%" against it only
    // resolves for the fixed (non-autoGrow) box, where the ScrollView parent
    // has a real, explicit height. When autoGrow is on, this is intentionally
    // omitted so the TextInput sizes itself from minHeight + real content.
    fixedHeight: {
      height: "100%",
    },
    isReadOnly: {
      color: textArea.color.readOnly,
    },
    isDisabled: {
      color: textArea.color.disabled,
    },
  });

  return {
    input,
    scrollView,
    scrollViewContent,
  };
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

type StylesProps = OuterFieldProps & {
  autoGrow?: boolean;
  autoGrowMaxLines?: number;
  isCompact?: boolean;
};

export function useStateStyles({
  isDisabled,
  isReadOnly,
  autoGrow,
  autoGrowMaxLines,
  isCompact,
}: StylesProps) {
  const { input, scrollView, scrollViewContent } = useStyles();
  const { fontScale } = useWindowDimensions();
  const { tokens } = useDesignTokens();
  const { typography, textInput, textArea } = tokens;

  const typographyVariant: CoreTypography.Variant = textArea.typography.variant;

  const lineHeight = parseSizeToken(
    typography.lineHeight[typographyVariant],
    fontScale
  );

  // Matches TextInput's fixed height so a compact TextArea looks the same at
  // 100% font size. The ScrollView's own marginVertical (unlike TextInput's
  // container, which has none) adds to the auto-sized OuterField, so it must
  // be subtracted here to land on the same total height.
  const compactHeight = textInput.height - scrollViewMargin.vertical * 2;

  return {
    input: [
      input.base,
      !autoGrow && input.fixedHeight,
      isCompact && { minHeight: compactHeight },
      isReadOnly && input.isReadOnly,
      isDisabled && input.isDisabled,
    ],
    scrollView: [
      scrollView.base,
      isCompact && { height: compactHeight },
      autoGrow
        ? {
            height: undefined,
          }
        : undefined,
      autoGrowMaxLines
        ? {
            maxHeight: autoGrowMaxLines * lineHeight,
          }
        : undefined,
    ],
    scrollViewContent: scrollViewContent.base,
  };
}

export default useStyles;
