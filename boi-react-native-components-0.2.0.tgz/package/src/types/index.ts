import { ComponentProps } from "react";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

export type KeyboardPressableProps = ComponentProps<typeof KeyboardPressable>;

export type FocusableComponent = { focus?: () => void };
