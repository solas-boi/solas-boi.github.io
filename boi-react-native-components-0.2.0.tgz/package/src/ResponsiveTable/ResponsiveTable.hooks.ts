import { useRef, useState, useLayoutEffect, type RefObject } from "react";
import { type LayoutChangeEvent, type ViewInstance } from "react-native";

export function useWidth(): {
  ref: RefObject<ViewInstance | null>;
  width: number;
  handleLayout: (event: LayoutChangeEvent) => void;
} {
  const ref = useRef<ViewInstance>(null);

  const [width, setWidth] = useState(0);

  useLayoutEffect(() => {
    ref.current?.measure((_x: number, _y: number, refWidth: number) => {
      setWidth(refWidth);
    });
  }, []);

  function handleLayout(event: LayoutChangeEvent) {
    setWidth(event.nativeEvent.layout.width);
  }

  return { ref, width, handleLayout };
}
