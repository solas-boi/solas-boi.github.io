import { Ref, useRef, useState, cloneElement } from "react";
import { Platform, View, type AccessibilityProps } from "react-native";
import {
  Pressable as KeyboardPressable,
  type KeyboardFocus,
} from "react-native-external-keyboard";
import {
  CoreCombobox,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { ChevronDownIcon } from "@boi/react-native-icons";
import { useMergeRefs } from "@boi/react-utils";

import { OuterField } from "../../OuterField";
import { ComboboxModal } from "../../ComboboxModal";
import { InputLabelTopProps } from "../../InputLabelTop";
import useStyles, { useStateStyles } from "./CountryComboboxBase.styles";
import { ModalProps } from "../../Modal";
import { useA11yRoleWorkaround } from "../../hooks";

const isAndroid = Platform.OS === "android";

export type CountryComboboxBaseProps<T extends CoreCombobox.ComboboxItem> =
  PropsWithOptionalTestID &
    Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
    AccessibilityProps & {
      labelProps: InputLabelTopProps;
      isOpen: boolean;
      selectedItem?: T | null | undefined;
      defaultInputValue?: string;
      items: T[];
      disabledKeys?: string[];
      placeholder?: string;
      hasError?: boolean;
      isDisabled?: boolean;
      onInputChange?: (inputValue: string) => void;
      onChange: (selectedItem: T | null | undefined) => void;
      onFocus: () => void;
      onBlur: () => void;
      pressableRef?: Ref<KeyboardFocus>;
    };

function CountryComboboxBase<T extends CoreCombobox.ComboboxItem>(
  props: CountryComboboxBaseProps<T>
) {
  const {
    items,
    disabledKeys,
    placeholder,
    isDisabled,
    hasError,
    isOpen,
    selectedItem,
    labelProps,
    defaultInputValue,
    onInputChange,
    onChange,
    onFocus,
    onBlur,
    supportedOrientations,
    onCloseAnimationComplete,
    testID = "country-combobox",
    pressableRef,
    role,
    accessibilityRole,
    ...accessibilityProps
  } = props;

  const localPressableRef = useRef<KeyboardFocus>(null);
  const mergedRefs = useMergeRefs([localPressableRef, pressableRef]);

  const styles = useStyles();
  const stateStyles = useStateStyles({ isDisabled });

  const accessibilityLabel = useA11yRoleWorkaround(
    role || accessibilityRole || "combobox",
    accessibilityProps.accessibilityLabel || labelProps.label
  );

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <>
      <OuterField
        isDisabled={isDisabled}
        hasFocus={hasKeyboardFocus}
        isActive={isOpen}
        hasError={hasError}
      >
        <KeyboardPressable
          ref={mergedRefs}
          onPress={onFocus}
          onFocusChange={handleKeyboardFocusChange}
          tintType="none"
          enableA11yFocus
          pointerEvents={isDisabled ? "none" : "auto"}
          style={styles.button}
          testID={testID}
          accessibilityValue={{
            text: `${!isAndroid && !isOpen ? "collapsed, " : ""}${
              selectedItem?.title || placeholder
            }`,
          }}
          accessibilityState={{
            expanded: isAndroid && isOpen,
            disabled: Boolean(isDisabled),
          }}
          accessibilityHint={labelProps.labelHint}
          {...accessibilityProps}
          accessibilityLabel={accessibilityLabel}
        >
          {selectedItem && selectedItem.icon && (
            <View>
              {cloneElement(selectedItem.icon, {
                ...selectedItem.icon.props,
                style: stateStyles.buttonIcon,
              })}
            </View>
          )}

          <ComboboxChevron isOpen={isOpen} isDisabled={isDisabled} />
        </KeyboardPressable>
      </OuterField>
      <ComboboxModal
        testID={`${testID}-modal`}
        isOpen={isOpen}
        title={
          labelProps.label || labelProps["aria-label"] || placeholder || ""
        }
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        defaultInputValue={defaultInputValue}
        onInputChange={onInputChange}
        onChange={onChange}
        onRequestClose={onBlur}
        supportedOrientations={supportedOrientations}
        onCloseAnimationComplete={() => {
          localPressableRef.current?.focus();
          onCloseAnimationComplete?.();
        }}
      />
    </>
  );
}

function ComboboxChevron(props: { isOpen: boolean; isDisabled?: boolean }) {
  const { tokens } = useDesignTokens();
  const { width, height, color } = tokens.select.button.icon;

  return (
    <ChevronDownIcon
      width={width}
      height={height}
      color={props.isDisabled ? color.disabled : color.base}
      style={props.isOpen && { transform: [{ rotate: "180deg" }] }}
    />
  );
}

export default CountryComboboxBase;
