import type { ReactNode, Ref } from "react";
import type { ViewInstance } from "react-native";

export type FocusableRef = {
  focus?: () => void;
};

export type WithFocusControlStoryArgs<TProps> = TProps & {
  showFocusButton: boolean;
};

export type FocusControlWrapperProps<
  RefType extends FocusableRef = ViewInstance,
> = {
  showFocusButton?: boolean;
  children: (ref: Ref<RefType> | undefined) => ReactNode;
};
