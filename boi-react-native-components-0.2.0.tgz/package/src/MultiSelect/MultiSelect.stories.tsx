import { useCallback, useEffect, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";
import { CoreMultiSelect } from "@boi/components-core";
import { type KeyboardFocus } from "react-native-external-keyboard";

import MultiSelect, { type MultiSelectProps } from "./MultiSelect";
import {
  FocusControlWrapper,
  withFocusControlStoryArgs,
} from "../storybookHelpers";

const ControlledMultiSelect = (props: MultiSelectProps) => {
  const { onChange, selectedItems, ...rest } = props;

  const [item, setItem] =
    useState<MultiSelectProps["selectedItems"]>(selectedItems);

  const handleChange: MultiSelectProps["onChange"] = useCallback(
    (newSelectedItems) => {
      setItem(newSelectedItems);
      onChange(newSelectedItems);
    },
    [onChange]
  );

  useEffect(() => {
    setItem(selectedItems);
  }, [selectedItems]);

  return (
    <FocusControlWrapper<KeyboardFocus> {...rest}>
      {(ref) => (
        <MultiSelect
          pressableRef={ref}
          selectedItems={item}
          onChange={handleChange}
          {...rest}
        />
      )}
    </FocusControlWrapper>
  );
};

const meta = {
  title: "Inputs/MultiSelect",
  component: MultiSelect,
  render: function Render(args) {
    const [{ selectedItems }, updateArgs] = useArgs();

    function handleChange(newSelectedItems: any) {
      action("onChange")(newSelectedItems);
      updateArgs({ selectedItems: newSelectedItems });
    }

    return (
      <ControlledMultiSelect
        {...args}
        selectedItems={selectedItems}
        onChange={handleChange}
        supportedOrientations={["landscape", "portrait"]}
      />
    );
  },
  argTypes: {
    hasError: { control: "boolean" },
  },
  args: {
    hasError: false,
    isDisabled: false,
    items: CoreMultiSelect.mockItems,
  },
} satisfies Meta<MultiSelectProps>;

export default meta;
type Story = StoryObj<MultiSelectProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "MultiSelect",
    },
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "MultiSelect with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "MultiSelect with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithError: Story = {
  args: {
    hasError: true,
    labelProps: {
      label: "MultiSelect with Error",
    },
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};

export const WithFocus = withFocusControlStoryArgs(WithError);

export const DisabledItems: Story = {
  args: {
    disabledKeys: CoreMultiSelect.mockItems.slice(1, 3).map(({ id }) => id),
    labelProps: {
      label: "MultiSelect with Disabled Items",
    },
  },
};

export const ItemsWithCustomAriaLabel: Story = {
  args: {
    items: CoreMultiSelect.mockItemsWithAriaLabel,
    labelProps: {
      label: "MultiSelect with ariaLabel on items",
    },
  },
};
