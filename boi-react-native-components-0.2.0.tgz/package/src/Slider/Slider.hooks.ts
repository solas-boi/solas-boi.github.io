import { CoreSlider } from "@boi/components-core";
import { useCallback, useMemo } from "react";
import type {
  SliderProps,
  SliderNotches,
  UseAccessibilitySliderInfo,
} from "./Slider.types";
import {
  nextStep,
  prevStep,
  safeSliderNotches,
  resolveTooltipForValue,
  isTooltipNotches,
} from "./utils";
import { OnKeyPress } from "react-native-external-keyboard";
import { Platform } from "react-native";

const ANDROID_KEY_CODE_LEFT = 21;
const ANDROID_KEY_CODE_RIGHT = 22;

const isAndroid = Platform.OS === "android";

export const useSliderTooltip = (
  notches: SliderNotches | undefined,
  value: number,
  minValue: number,
  maxValue: number
) => {
  const safeNotches = useMemo(
    () => safeSliderNotches(notches, minValue, maxValue),
    [notches, minValue, maxValue]
  );

  const tooltipText = useMemo(() => {
    if (!safeNotches?.length || !isTooltipNotches(safeNotches)) {
      return undefined;
    }
    return resolveTooltipForValue(value, safeNotches);
  }, [value, safeNotches]);

  return { safeNotches, tooltipText };
};

export const useSliderHandlers = (
  props: SliderProps,
  valueRef: React.MutableRefObject<number>
) => {
  const {
    onChange,
    minValue = CoreSlider.DEFAULT_MIN_VALUE,
    maxValue = CoreSlider.DEFAULT_MAX_VALUE,
    step = CoreSlider.DEFAULT_STEP,
  } = props;

  const decrement = useCallback(() => {
    const v = valueRef.current;
    // To match the web Slider behavior, when decreasing the value, it snaps to the minValue
    const next = Math.max(minValue, prevStep(v, step));

    if (next !== v) {
      onChange(next);
    }
  }, [valueRef, minValue, step, onChange]);

  const increment = useCallback(() => {
    const v = valueRef.current;
    const next = nextStep(v, step);

    // Should not snap to maxValue, if the new value is greater than maxValue, cancel increment.
    if (next > maxValue) {
      return;
    }
    if (next !== v) {
      onChange(next);
    }
  }, [valueRef, maxValue, step, onChange]);

  return {
    decrement,
    increment,
  };
};

export const useAccessibilitySliderInfo = ({
  increment,
  decrement,
}: UseAccessibilitySliderInfo) => {
  const onAccessibilityAction = useCallback(
    ({ nativeEvent }: { nativeEvent: { actionName: string } }) => {
      if (nativeEvent.actionName === "increment") {
        increment();
      }
      if (nativeEvent.actionName === "decrement") {
        decrement();
      }
    },
    [increment, decrement]
  );

  const onKeyPressAndroidHandler = useCallback(
    (e: OnKeyPress) => {
      if (e.nativeEvent.keyCode === ANDROID_KEY_CODE_LEFT) {
        decrement();
      } else if (e.nativeEvent.keyCode === ANDROID_KEY_CODE_RIGHT) {
        increment();
      }
    },
    [decrement, increment]
  );

  const onKeyPressHandler = isAndroid ? onKeyPressAndroidHandler : undefined;

  return { onAccessibilityAction, onKeyPressHandler };
};
