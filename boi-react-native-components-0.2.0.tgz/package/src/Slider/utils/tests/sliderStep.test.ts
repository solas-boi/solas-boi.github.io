import { snapToStep, nextStep, prevStep } from "../sliderStep";

describe("nextStep", () => {
  it("returns the next step which is the current value plus the step size", () => {
    expect(nextStep(49, 10)).toBe(59);
  });
});

describe("prevStep", () => {
  it("returns the previous step which is the current value minus the step size", () => {
    expect(prevStep(51, 10)).toBe(41);
  });
});

describe("snapToStep", () => {
  it("snaps to the nearest step multiple", () => {
    expect(snapToStep(54, 0, 100, 10)).toBe(50);
    expect(snapToStep(56, 0, 100, 10)).toBe(60);
  });

  it("snaps to minValue when closer to min than to the nearest step", () => {
    expect(snapToStep(2, 0, 100, 10)).toBe(0);
  });

  it("snaps to maxValue when closer to max than to the nearest step", () => {
    expect(snapToStep(98, 0, 100, 10)).toBe(100);
  });

  it("returns the value unchanged when it falls exactly on a step", () => {
    expect(snapToStep(30, 0, 100, 10)).toBe(30);
  });
});
