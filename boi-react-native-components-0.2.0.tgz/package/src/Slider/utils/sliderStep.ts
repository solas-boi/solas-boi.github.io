export function snapToStep(
  raw: number,
  minVal: number,
  maxVal: number,
  stepVal: number
): number {
  "worklet";
  const absoluteSnap = Math.round(raw / stepVal) * stepVal;

  const distToMin = Math.abs(raw - minVal);
  const distToMax = Math.abs(raw - maxVal);
  const distToStep = Math.abs(raw - absoluteSnap);

  if (distToMin <= distToMax && distToMin <= distToStep) {
    return minVal;
  }
  if (distToMax <= distToStep) {
    return maxVal;
  }
  return absoluteSnap;
}

export function nextStep(value: number, step: number): number {
  return value + step;
}

export function prevStep(value: number, step: number): number {
  return value - step;
}
