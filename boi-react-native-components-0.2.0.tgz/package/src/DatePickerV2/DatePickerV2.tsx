import {
  forwardRef,
  type ForwardRefExoticComponent,
  type RefAttributes,
} from "react";
import {
  TextInputProps,
  type BlurEvent,
  type TextInputInstance,
} from "react-native";
import { DateType } from "react-native-ui-datepicker";
import {
  CoreDatePicker,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { DATE_MASKS, DEFAULT_KEYBOARD_TYPE } from "./DatePickerV2.constants";
import { useSelectionControl, useDateControl } from "./hooks";
import {
  applyMask,
  normalizeSegments,
  segmentsToDate,
  segmentsToString,
  caretToTextIndex,
} from "./utils";
import { DatePickerV2Calendar } from "./DatePickerV2Calendar";
import { TextInput } from "../TextInput";
import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";
import { type ModalProps } from "../Modal";

export type CommonProps = {
  locale?: CoreDatePicker.Locale;
  date?: Date | undefined | null;
  onChange: (date: Date | undefined | null) => void;
};

export type DatePickerV2Props = PropsWithOptionalTestID &
  CommonProps & {
    labelProps: Omit<InputLabelTopProps, "children">;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    hasError?: boolean;
    isDisabled?: boolean;
    withCalendar?: boolean;
    inputAccessoryViewID?: string;
    maximumDate?: DateType;
    minimumDate?: DateType;
    disabledDates?: DateType[] | ((date: DateType) => boolean);
    title?: string;
    startMonth?: number;
    startYear?: number;
  } & Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
  Omit<
    TextInputProps,
    | "value"
    | "defaultValue"
    | "onChange"
    | "allowFontScaling"
    | "maxLength"
    | "placeholder"
    | "placeholderTextColor"
    | "style"
  >;

export const DEFAULT_INPUT_ACCESSORY_VIEW_ID =
  "DEFAULT_INPUT_ACCESSORY_VIEW_ID";

const DatePickerV2: ForwardRefExoticComponent<
  DatePickerV2Props & RefAttributes<TextInputInstance>
> = forwardRef<TextInputInstance, DatePickerV2Props>((props, ref) => {
  const {
    labelProps,
    alertProps,
    hasError,
    withCalendar,
    locale = CoreDatePicker.DEFAULT_LOCALE,
    date,
    onChange,
    onChangeText,
    keyboardType = DEFAULT_KEYBOARD_TYPE,
    inputAccessoryViewID,
    testID = "date-picker",
    onBlur,
    onFocus,
    maximumDate,
    minimumDate,
    disabledDates,
    title,
    supportedOrientations, // supportedOrientations by default is ['portrait']; any other orientations are not configured in Xcode for iOS in the react-native-banking app, which may cause the app to crash.
    onCloseAnimationComplete,
    startMonth,
    startYear,
    isDisabled,
    ...textInputProps
  } = props;

  const { tokens } = useDesignTokens();
  const { datePicker } = tokens;

  const { selection, refreshSelection } = useSelectionControl();
  const { value, segments, onSegmentsChanged } = useDateControl({
    locale,
    date,
    onChange,
    onChangeText,
  });

  function handleBlur(evt: BlurEvent) {
    const normalized = normalizeSegments(segments);

    if (normalized && segmentsToDate(normalized, locale)) {
      onSegmentsChanged(normalized);
    }

    onBlur?.(evt);
  }

  function handleChangeText(nativeText: string) {
    if (nativeText === value) {
      return;
    }

    const next = applyMask(segments, nativeText);

    if (segmentsToString(next.segments) !== nativeText) {
      refreshSelection(caretToTextIndex(next.segments, next.caret));
    }

    onSegmentsChanged(next.segments);
  }

  return (
    <TextInput
      {...textInputProps}
      ref={ref}
      disabled={isDisabled}
      keyboardType={keyboardType}
      inputAccessoryViewID={
        inputAccessoryViewID || DEFAULT_INPUT_ACCESSORY_VIEW_ID
      }
      labelProps={labelProps}
      alertProps={alertProps}
      hasError={hasError}
      noCounter
      maxLength={DATE_MASKS[locale].length}
      placeholder={DATE_MASKS[locale]}
      value={value}
      onChangeText={handleChangeText}
      selection={selection}
      placeholderTextColor={datePicker.input.segment.placeholderColor}
      onFocus={onFocus}
      onBlur={handleBlur}
      buttonSlot={
        withCalendar ? (
          <DatePickerV2Calendar
            title={title ?? labelProps?.label}
            locale={locale}
            date={date}
            onChange={onChange}
            testID={testID}
            maximumDate={maximumDate}
            minimumDate={minimumDate}
            disabledDates={disabledDates || []}
            supportedOrientations={supportedOrientations}
            onCloseAnimationComplete={onCloseAnimationComplete}
            startMonth={startMonth}
            startYear={startYear}
            isDisabled={isDisabled}
          />
        ) : undefined
      }
      testID={testID}
    />
  );
});

DatePickerV2.displayName = "DatePickerV2";

export default DatePickerV2;
