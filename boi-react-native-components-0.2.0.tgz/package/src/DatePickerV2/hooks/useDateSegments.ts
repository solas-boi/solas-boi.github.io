import { useEffect, useRef, useState } from "react";

import { dateToSegments, segmentsToString } from "../utils";

/**
 * Holds the value as three segments — day, month, year — each keeping its digits as
 * typed: `{ day: "31", month: "0", year: "" }` reads as `"31 / 0"`.
 *
 * While typing, the value is often not a valid date: `31 / 0` is unfinished, and
 * `31 / 02 / 2020` does not exist. A `Date` cannot represent either, so the segments
 * store what was typed and the text is rendered from them.
 */
export const useDateSegments = (date: Date | undefined | null) => {
  const [segments, setSegments] = useState(() => dateToSegments(date));

  const dateValueRef = useRef(date && date.getTime());

  useEffect(() => {
    const dateValue = date && date.getTime();

    if (dateValue === dateValueRef.current) {
      return;
    }

    dateValueRef.current = dateValue;

    if (date !== undefined) {
      setSegments(dateToSegments(date));
    }
  }, [date]);

  return {
    segments,
    value: segmentsToString(segments),
    setSegments,
  };
};
