import { act, renderHook } from "@testing-library/react-native";

import { useSelectionControl } from "../useSelectionControl";

type Selection = { start: number; end: number } | undefined;

function setup() {
  const renders: Selection[] = [];

  const view = renderHook(() => {
    const control = useSelectionControl();

    renders.push(control.selection);

    return control;
  });

  return { ...view, renders };
}

describe("useSelectionControl", () => {
  it("should leave the cursor alone until something asks for it", () => {
    const { result } = setup();

    expect(result.current.selection).toBeUndefined();
  });

  it("should hand the caret over for exactly one render", () => {
    const { result, renders } = setup();

    act(() => result.current.refreshSelection(5));

    expect(renders).toStrictEqual([undefined, { start: 5, end: 5 }, undefined]);
  });

  it("should hand the caret over again when it lands where it already was", () => {
    const { result, renders } = setup();

    act(() => result.current.refreshSelection(5));
    act(() => result.current.refreshSelection(5));

    expect(renders.filter(Boolean)).toEqual([
      { start: 5, end: 5 },
      { start: 5, end: 5 },
    ]);
  });

  it("should clear the selection again after re-issuing the same caret", () => {
    const { result } = setup();

    act(() => result.current.refreshSelection(5));
    act(() => result.current.refreshSelection(5));

    expect(result.current.selection).toBeUndefined();
  });
});
