import { act, renderHook } from "@testing-library/react-native";

import { useDateSegments } from "../useDateSegments";

type Props = { date: Date | undefined | null };

function setup(date: Date | undefined | null) {
  return renderHook(({ date: next }: Props) => useDateSegments(next), {
    initialProps: { date },
  });
}

describe("useDateSegments", () => {
  it("should start from the date it is given", () => {
    const { result } = setup(new Date(2020, 0, 31));

    expect(result.current.value).toBe("31 / 01 / 2020");
  });

  it("should start empty for undefined", () => {
    const { result } = setup(undefined);

    expect(result.current.value).toBe("");
  });

  it("should start empty for null", () => {
    const { result } = setup(null);

    expect(result.current.value).toBe("");
  });

  it("should start empty for an Invalid Date", () => {
    const { result } = setup(new Date("not-a-date"));

    expect(result.current.value).toBe("");
  });

  it("should adopt a genuinely different date", () => {
    const { result, rerender } = setup(new Date(2020, 0, 31));

    rerender({ date: new Date(1999, 11, 25) });

    expect(result.current.value).toBe("25 / 12 / 1999");
  });

  it("should clear what is held when the date becomes null", () => {
    const { result, rerender } = setup(new Date(2020, 0, 31));

    rerender({ date: null });

    expect(result.current.value).toBe("");
  });

  it("should keep what is held when the date becomes undefined", () => {
    const { result, rerender } = setup(new Date(2020, 0, 31));

    rerender({ date: undefined });

    expect(result.current.value).toBe("31 / 01 / 2020");
  });

  it("should keep an unfinished edit when a new object for the same instant arrives", () => {
    const { result, rerender } = setup(new Date(2020, 0, 31));

    act(() =>
      result.current.setSegments({ day: "31", month: "01", year: "202" })
    );
    rerender({ date: new Date(2020, 0, 31) });

    expect(result.current.value).toBe("31 / 01 / 202");
  });

  it("should drop an unfinished edit when a different date arrives", () => {
    const { result, rerender } = setup(new Date(2020, 0, 31));

    act(() =>
      result.current.setSegments({ day: "31", month: "01", year: "202" })
    );
    rerender({ date: new Date(1999, 11, 25) });

    expect(result.current.value).toBe("25 / 12 / 1999");
  });
});
