import { act, renderHook } from "@testing-library/react-native";
import { CoreDatePicker } from "@boi/components-core";

import { useDateControl } from "../useDateControl";

const LOCALE = CoreDatePicker.DEFAULT_LOCALE;

type Options = { date?: Date | undefined | null };

function setup(options: Options = {}) {
  const mockOnChange = jest.fn();
  const mockOnChangeText = jest.fn();

  const { result } = renderHook(() =>
    useDateControl({
      locale: LOCALE,
      date: undefined,
      onChange: mockOnChange,
      onChangeText: mockOnChangeText,
      ...options,
    })
  );

  return { result, mockOnChange, mockOnChangeText };
}

describe("useDateControl", () => {
  it("should report the text once every segment is filled", () => {
    const { result, mockOnChangeText } = setup();

    act(() =>
      result.current.onSegmentsChanged({
        day: "31",
        month: "01",
        year: "2020",
      })
    );

    expect(mockOnChangeText).toHaveBeenCalledWith("31 / 01 / 2020");
  });

  it("should report the date once every segment is filled", () => {
    const { result, mockOnChange } = setup();

    act(() =>
      result.current.onSegmentsChanged({
        day: "31",
        month: "01",
        year: "2020",
      })
    );

    expect(mockOnChange).toHaveBeenCalledWith(new Date(2020, 0, 31));
  });

  it("should hold the value it was given", () => {
    const { result } = setup();

    act(() =>
      result.current.onSegmentsChanged({
        day: "31",
        month: "01",
        year: "2020",
      })
    );

    expect(result.current.value).toBe("31 / 01 / 2020");
  });

  it("should report no date while the value is unfinished", () => {
    const { result, mockOnChange, mockOnChangeText } = setup();

    act(() =>
      result.current.onSegmentsChanged({ day: "31", month: "01", year: "202" })
    );

    expect(mockOnChangeText).toHaveBeenCalledWith("31 / 01 / 202");
    expect(mockOnChange).toHaveBeenCalledWith(undefined);
  });

  it("should report no date for a value that is not a real date", () => {
    const { result, mockOnChange } = setup();

    act(() =>
      result.current.onSegmentsChanged({ day: "31", month: "02", year: "2020" })
    );

    expect(mockOnChange).toHaveBeenCalledWith(undefined);
  });

  it("should stay quiet when the value has not actually changed", () => {
    const { result, mockOnChange, mockOnChangeText } = setup({
      date: new Date(2020, 0, 31),
    });

    act(() =>
      result.current.onSegmentsChanged({
        day: "31",
        month: "01",
        year: "2020",
      })
    );

    expect(mockOnChangeText).not.toHaveBeenCalled();
    expect(mockOnChange).not.toHaveBeenCalled();
  });
});
