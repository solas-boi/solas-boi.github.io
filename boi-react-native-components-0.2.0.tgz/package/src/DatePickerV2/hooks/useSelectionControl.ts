import { useCallback, useEffect, useState } from "react";

type Selection = { start: number; end: number };

/**
 * Drives the text input's `selection`, so editing one segment leaves the cursor where
 * the user is typing instead of at the end of the field.
 */
export const useSelectionControl = () => {
  const [pendingSelection, setPendingSelection] = useState<
    Selection | undefined
  >(undefined);

  // iOS drops the cursor at the end of the field when the text is replaced, so
  // `selection` puts it back. Held any longer than one render it would pin the
  // cursor there and the user could not tap or arrow away.
  useEffect(() => {
    if (pendingSelection === undefined) {
      return;
    }

    setPendingSelection((current) =>
      current === pendingSelection ? undefined : current
    );
  }, [pendingSelection]);

  /**
   * Puts the cursor at `caret` for one render. Call it after every text change, so
   * the cursor follows the segment that was edited.
   */
  const refreshSelection = useCallback((caret: number) => {
    setPendingSelection({ start: caret, end: caret });
  }, []);

  return { selection: pendingSelection, refreshSelection };
};
