import { useCallback } from "react";
import { CoreDatePicker } from "@boi/components-core";

import {
  isComplete,
  segmentsToDate,
  segmentsToString,
  type DateSegments,
} from "../utils";
import { useDateSegments } from "./useDateSegments";

type DispatchDateOptions = {
  locale: CoreDatePicker.Locale;
  date: Date | undefined | null;
  onChange: (date: Date | undefined | null) => void;
  onChangeText?: (text: string) => void;
};

/**
 * Controls the date state: stores each edit, then reports it — the text through
 * `onChangeText`, the date through `onChange`.
 *
 * Any real date is reported, including one the calendar would refuse: whether it sits
 * inside `minimumDate`/`maximumDate` is the consumer's to validate, and it can only do
 * that if the date arrives as a date rather than as `undefined`.
 */
export const useDateControl = ({
  locale,
  date,
  onChange,
  onChangeText,
}: DispatchDateOptions) => {
  const { segments, value, setSegments } = useDateSegments(date);

  const onSegmentsChanged = useCallback(
    (dateSegments: DateSegments) => {
      const text = segmentsToString(dateSegments);

      if (text === value) {
        return;
      }

      setSegments(dateSegments);
      onChangeText?.(text);

      const nextDate = isComplete(dateSegments)
        ? segmentsToDate(dateSegments, locale)
        : undefined;

      onChange(nextDate);
    },
    [locale, onChange, onChangeText, setSegments, value]
  );

  return { segments, onSegmentsChanged, value };
};
