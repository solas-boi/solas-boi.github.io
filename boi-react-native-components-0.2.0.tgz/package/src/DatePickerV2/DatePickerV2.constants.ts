import { enIE, enGB } from "date-fns/locale";

export const DATE_FNS_LOCALES = {
  "en-IE": enIE,
  "en-GB": enGB,
} as const;

// TODO: CP-106735 Add month-first format support when required.
export const DATE_FORMATS = {
  "en-IE": "dd / MM / yyyy",
  "en-GB": "dd / MM / yyyy",
} as const;

// TODO: CP-106735 Add month-first format support when required.
export const DATE_MASKS = {
  "en-IE": "DD / MM / YYYY",
  "en-GB": "DD / MM / YYYY",
} as const;

// TODO: CP-106735 Add month-first format support when required.
export const SEGMENT_ORDER = ["day", "month", "year"] as const;

export type SegmentName = (typeof SEGMENT_ORDER)[number];

export const SEGMENT_WIDTHS = {
  day: 2,
  month: 2,
  year: 4,
} as const satisfies Record<SegmentName, number>;

export const SEGMENT_RANGES = {
  day: { min: 1, max: 31 },
  month: { min: 1, max: 12 },
  year: { min: 1, max: 9999 },
} as const satisfies Record<SegmentName, { min: number; max: number }>;

export const SEPARATOR = " / ";

export const DEFAULT_KEYBOARD_TYPE = "number-pad";
