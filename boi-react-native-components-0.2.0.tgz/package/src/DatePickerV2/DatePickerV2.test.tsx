import { useState } from "react";
import {
  fireEvent,
  render,
  screen,
  userEvent,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreDatePicker } from "@boi/components-core";

import DatePickerV2, { type DatePickerV2Props } from "./DatePickerV2";
import { DATE_MASKS } from "./DatePickerV2.constants";

jest.useFakeTimers();

const PLACEHOLDER = DATE_MASKS[CoreDatePicker.DEFAULT_LOCALE];

function WrappedDatePicker(props: DatePickerV2Props) {
  return (
    <DesignTokensProvider>
      <DatePickerV2 {...props} />
    </DesignTokensProvider>
  );
}

function ControlledDatePicker({ onChange, ...props }: DatePickerV2Props) {
  const [date, setDate] = useState<Date | undefined | null>(undefined);

  function handleChange(next: Date | undefined | null) {
    setDate(next);
    onChange(next);
  }

  return <WrappedDatePicker {...props} date={date} onChange={handleChange} />;
}

function getInput() {
  return screen.getByTestId("date-picker");
}

function edit(mutate: (value: string) => string) {
  const input = getInput();

  fireEvent.changeText(input, mutate(input.props.value as string));
}

function typeAt(caret: number, text: string) {
  edit((value) => value.slice(0, caret) + text + value.slice(caret));
}

function backspaceAt(caret: number) {
  edit((value) => value.slice(0, caret - 1) + value.slice(caret));
}

function blur() {
  fireEvent(getInput(), "blur", { nativeEvent: {} });
}

describe("DatePickerV2", () => {
  let baseProps: DatePickerV2Props;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        "aria-label": "DatePickerV2 Label",
      },
      onChange: jest.fn(),
    };
  });

  it("should render an empty field with the date format as its placeholder", () => {
    render(<WrappedDatePicker {...baseProps} />);

    expect(screen.getByPlaceholderText(PLACEHOLDER)).toBeDefined();
    expect(getInput()).toHaveDisplayValue("");
  });

  it("should render the date prop formatted", () => {
    render(<WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />);

    expect(getInput()).toHaveDisplayValue("31 / 01 / 2020");
  });

  it("should render an alert when alertProps are provided", () => {
    render(
      <WrappedDatePicker
        {...baseProps}
        alertProps={{ severity: "error", children: "Something went wrong" }}
      />
    );

    expect(screen.getByTestId("date-picker-alerts")).toHaveTextContent(
      "Something went wrong"
    );
  });

  it("should render with a custom testID", () => {
    render(<WrappedDatePicker {...baseProps} testID="custom-date-picker" />);

    expect(screen.getByTestId("custom-date-picker")).toBeDefined();
  });

  it("should default the keyboard to a numeric keypad, and let the caller override it", () => {
    const { rerender } = render(<WrappedDatePicker {...baseProps} />);

    expect(getInput().props.keyboardType).toBe("number-pad");

    rerender(<WrappedDatePicker {...baseProps} keyboardType="numeric" />);

    expect(getInput().props.keyboardType).toBe("numeric");
  });

  it("should call the custom onFocus and onBlur handlers", async () => {
    const user = userEvent.setup();
    const mockOnFocus = jest.fn();
    const mockOnBlur = jest.fn();

    render(
      <WrappedDatePicker
        {...baseProps}
        onFocus={mockOnFocus}
        onBlur={mockOnBlur}
      />
    );

    await user.type(getInput(), "31");

    expect(mockOnFocus).toHaveBeenCalledTimes(1);
    expect(mockOnBlur).toHaveBeenCalledTimes(1);
  });

  describe("reporting what is typed", () => {
    it("should report the masked text as each segment is filled", async () => {
      const user = userEvent.setup();
      const mockOnChangeText = jest.fn();

      render(
        <WrappedDatePicker {...baseProps} onChangeText={mockOnChangeText} />
      );

      await user.type(getInput(), "31");

      expect(mockOnChangeText).toHaveBeenLastCalledWith("31");

      await user.type(getInput(), "012020");

      expect(mockOnChangeText).toHaveBeenLastCalledWith("31 / 01 / 2020");
    });

    it("should report the date once it is complete", async () => {
      const user = userEvent.setup();
      const mockOnChange = jest.fn();

      render(<WrappedDatePicker {...baseProps} onChange={mockOnChange} />);

      await user.type(getInput(), "31012020");

      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 0, 31));
    });

    it("should report undefined for an impossible date", () => {
      const mockOnChange = jest.fn();

      render(<WrappedDatePicker {...baseProps} onChange={mockOnChange} />);

      // Every segment is in range, so only the combination is impossible.
      typeAt(0, "31022020");

      expect(getInput()).toHaveDisplayValue("31 / 02 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });

    it("should report a complete date being broken up", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2020, 0, 31)}
          onChange={mockOnChange}
        />
      );

      backspaceAt(14);

      expect(mockOnChange).toHaveBeenCalledTimes(1);
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });

    it("should report a date that arrived from the prop being broken up", () => {
      const mockOnChange = jest.fn();

      const { rerender } = render(
        <WrappedDatePicker {...baseProps} onChange={mockOnChange} />
      );

      rerender(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2020, 0, 31)}
          onChange={mockOnChange}
        />
      );

      backspaceAt(14);

      expect(mockOnChange).toHaveBeenCalledTimes(1);
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });

    it("should keep the value when one of two identical month digits is deleted", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2028, 10, 13)}
          onChange={mockOnChange}
        />
      );

      backspaceAt(6);

      expect(getInput()).toHaveDisplayValue("13 / 1 / 2028");
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });

    it("should ignore characters that are not digits, and leave no controlled selection", () => {
      render(<WrappedDatePicker {...baseProps} />);

      typeAt(0, "3");
      typeAt(1, "a");

      expect(getInput()).toHaveDisplayValue("3");
      expect(getInput().props.selection).toBeUndefined();
    });
  });

  describe("adopting the date prop", () => {
    it("should adopt a genuinely different date", () => {
      const { rerender } = render(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      rerender(
        <WrappedDatePicker {...baseProps} date={new Date(1999, 11, 25)} />
      );

      expect(getInput()).toHaveDisplayValue("25 / 12 / 1999");
    });

    it("should clear the value when the date is null", () => {
      const { rerender } = render(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      rerender(<WrappedDatePicker {...baseProps} date={null} />);

      expect(getInput()).toHaveDisplayValue("");
    });

    it("should clear the value when the date is an Invalid Date", () => {
      const { rerender } = render(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      rerender(
        <WrappedDatePicker {...baseProps} date={new Date("not-a-date")} />
      );

      expect(getInput()).toHaveDisplayValue("");
    });

    it("should keep the value when the date becomes undefined", () => {
      const { rerender } = render(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      rerender(<WrappedDatePicker {...baseProps} date={undefined} />);

      expect(getInput()).toHaveDisplayValue("31 / 01 / 2020");
    });

    it("should keep in-progress input when a new object for the same day arrives", () => {
      const { rerender } = render(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      backspaceAt(14);
      rerender(
        <WrappedDatePicker {...baseProps} date={new Date(2020, 0, 31)} />
      );

      expect(getInput()).toHaveDisplayValue("31 / 01 / 202");
    });

    it("should survive a controlled parent echoing back the date just typed", async () => {
      const user = userEvent.setup();
      const mockOnChange = jest.fn();

      const { rerender } = render(
        <WrappedDatePicker {...baseProps} onChange={mockOnChange} />
      );

      await user.type(getInput(), "31012020");

      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 0, 31));

      const callsWhileTyping = mockOnChange.mock.calls.length;

      rerender(
        <WrappedDatePicker
          {...baseProps}
          onChange={mockOnChange}
          date={new Date(2020, 0, 31)}
        />
      );

      expect(getInput()).toHaveDisplayValue("31 / 01 / 2020");
      expect(mockOnChange).toHaveBeenCalledTimes(callsWhileTyping);
    });
  });

  // The calendar's bounds restrict what can be picked from the calendar, not what can
  // be typed. A typed date that is real is reported even when it falls outside them, so
  // the consumer can validate it and say why it is wrong; reporting `undefined` instead
  // would leave them unable to tell an out-of-range date from an unfinished one.
  describe("reporting typed dates the calendar would refuse", () => {
    it("should report a date before minimumDate", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          minimumDate={new Date(2020, 5, 15)}
          onChange={mockOnChange}
        />
      );

      typeAt(0, "13062020");

      expect(getInput()).toHaveDisplayValue("13 / 06 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 5, 13));
    });

    it("should report a date after maximumDate", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          maximumDate={new Date(2020, 5, 12)}
          onChange={mockOnChange}
        />
      );

      typeAt(0, "13062020");

      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 5, 13));
    });

    it("should report a date listed in disabledDates", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          disabledDates={[new Date(2020, 5, 13)]}
          onChange={mockOnChange}
        />
      );

      typeAt(0, "13062020");

      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 5, 13));
    });

    it("should still report no date for a value that is not a real date", () => {
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          minimumDate={new Date(2020, 5, 15)}
          onChange={mockOnChange}
        />
      );

      typeAt(0, "31022020");

      expect(getInput()).toHaveDisplayValue("31 / 02 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });
  });

  describe("settling the value on blur", () => {
    it("should pad a half-typed value out to full width and report it", () => {
      const mockOnChange = jest.fn();
      const mockOnChangeText = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2020, 0, 31)}
          onChange={mockOnChange}
          onChangeText={mockOnChangeText}
        />
      );

      backspaceAt(2);

      expect(getInput()).toHaveDisplayValue("3 / 01 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);

      blur();

      expect(getInput()).toHaveDisplayValue("03 / 01 / 2020");
      expect(mockOnChangeText).toHaveBeenLastCalledWith("03 / 01 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 0, 3));
    });

    it("should leave a value alone when padding it would not be a real date", () => {
      const mockOnChange = jest.fn();

      render(<WrappedDatePicker {...baseProps} onChange={mockOnChange} />);

      typeAt(0, "31022020");
      backspaceAt(6);

      expect(getInput()).toHaveDisplayValue("31 / 2 / 2020");

      blur();

      expect(getInput()).toHaveDisplayValue("31 / 2 / 2020");
      expect(mockOnChange).toHaveBeenLastCalledWith(undefined);
    });

    it("should not re-notify when the value is already in full format", () => {
      const mockOnChangeText = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2020, 0, 31)}
          onChangeText={mockOnChangeText}
        />
      );

      blur();

      expect(getInput()).toHaveDisplayValue("31 / 01 / 2020");
      expect(mockOnChangeText).not.toHaveBeenCalled();
    });
  });

  describe("with calendar", () => {
    function pressCalendarButton(user: ReturnType<typeof userEvent.setup>) {
      return user.press(screen.getByRole("button", { name: "Calendar" }));
    }

    it("should open a modal from the calendar button", async () => {
      const user = userEvent.setup();

      render(<WrappedDatePicker {...baseProps} withCalendar />);

      expect(screen.queryByTestId("date-picker-modal")).toBeNull();

      await pressCalendarButton(user);

      expect(screen.getByTestId("date-picker-modal")).toBeDefined();
    });

    it("should report a date picked from the calendar to the parent", async () => {
      const user = userEvent.setup();
      const mockOnChange = jest.fn();

      render(
        <WrappedDatePicker
          {...baseProps}
          onChange={mockOnChange}
          withCalendar
          startMonth={5}
          startYear={2020}
        />
      );

      await pressCalendarButton(user);
      await user.press(screen.getByText("15"));

      expect(mockOnChange).toHaveBeenCalledTimes(1);
      expect(mockOnChange).toHaveBeenLastCalledWith(new Date(2020, 5, 15));
    });

    it("should reach the same value whether the date is typed or picked", async () => {
      const user = userEvent.setup();
      const mockTyped = jest.fn();
      const mockPicked = jest.fn();

      const typed = render(
        <ControlledDatePicker {...baseProps} onChange={mockTyped} />
      );

      typeAt(0, "15062020");

      expect(getInput()).toHaveDisplayValue("15 / 06 / 2020");

      typed.unmount();

      render(
        <ControlledDatePicker
          {...baseProps}
          onChange={mockPicked}
          withCalendar
          startMonth={5}
          startYear={2020}
        />
      );

      await pressCalendarButton(user);
      await user.press(screen.getByText("15"));

      expect(getInput()).toHaveDisplayValue("15 / 06 / 2020");
      expect(mockPicked.mock.lastCall).toEqual(mockTyped.mock.lastCall);
    });

    it("should open at the given startMonth", async () => {
      const user = userEvent.setup();

      render(<WrappedDatePicker {...baseProps} startMonth={8} withCalendar />);

      await pressCalendarButton(user);

      expect(screen.getByText(/September/i)).toBeDefined();
    });

    it("should open at the given startYear", async () => {
      const user = userEvent.setup();

      render(
        <WrappedDatePicker {...baseProps} startYear={2020} withCalendar />
      );

      await pressCalendarButton(user);

      expect(screen.getByText(/2020/)).toBeDefined();
    });

    it("should open with a valid date in the date prop", async () => {
      const user = userEvent.setup();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date(2024, 5, 16)}
          withCalendar
        />
      );

      await pressCalendarButton(user);

      expect(screen.getByTestId("date-picker-modal")).toBeDefined();
    });

    it("should open with no date in the date prop", async () => {
      const user = userEvent.setup();

      render(
        <WrappedDatePicker {...baseProps} date={undefined} withCalendar />
      );

      await pressCalendarButton(user);

      expect(screen.getByTestId("date-picker-modal")).toBeDefined();
    });

    it("should open with an invalid Date in the date prop", async () => {
      const user = userEvent.setup();

      render(
        <WrappedDatePicker
          {...baseProps}
          date={new Date("invalid-date-string")}
          withCalendar
        />
      );

      await pressCalendarButton(user);

      expect(screen.getByTestId("date-picker-modal")).toBeDefined();
    });
  });
});
