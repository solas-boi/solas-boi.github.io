import { type SegmentName } from "../DatePickerV2.constants";

export type DateSegments = Readonly<Record<SegmentName, string>>;

export type Caret = Readonly<{ segment: SegmentName; offset: number }>;

export type SegmentState = Readonly<{ segments: DateSegments; caret: Caret }>;

export type TextChange = Readonly<{
  start: number;
  deleteCount: number;
  insert: string;
  digits: string;
}>;
