import {
  SEGMENT_ORDER,
  SEGMENT_RANGES,
  SEGMENT_WIDTHS,
  type SegmentName,
} from "../DatePickerV2.constants";
import {
  caretToDigitIndex,
  clamp,
  digitIndexToCaret,
  textIndexToCaret,
} from "./caret";
import {
  EMPTY_SEGMENTS,
  copySegments,
  getSegmentRanges,
  segmentsToString,
} from "./segments";
import { type DateSegments, type SegmentState, type TextChange } from "./types";

const NON_DIGIT = /\D/g;

/**
 * Where digits spill when a segment overfills. Hard-codes day-first order, the same
 * locale assumption `SEGMENT_ORDER` makes: every supported locale renders as
 * `DD / MM / YYYY` (see converters.ts). A month-first locale would need both changed.
 */
// TODO: CP-106735 Add month-first format support when required.
const NEXT_SEGMENT = {
  day: "month",
  month: "year",
  year: undefined,
} as const satisfies Record<SegmentName, SegmentName | undefined>;

/**
 * Compares the two strings and says what changed between them: from `start`, remove
 * `deleteCount` characters, then put `insert` in their place.
 *
 * ```
 * "15 / 06 / 202" -> "15 / 06 / 2027"   { start: 13, deleteCount: 0, insert: "7" }
 * "15 / 06"       -> "15 / 0"           { start: 6,  deleteCount: 1, insert: ""  }
 * ```
 */
export function diffText(previous: string, next: string): TextChange {
  const maxPrefix = Math.min(previous.length, next.length);
  let prefix = 0;

  while (prefix < maxPrefix && previous[prefix] === next[prefix]) {
    prefix += 1;
  }

  let suffix = 0;

  while (
    suffix < previous.length - prefix &&
    suffix < next.length - prefix &&
    previous[previous.length - 1 - suffix] === next[next.length - 1 - suffix]
  ) {
    suffix += 1;
  }

  const insert = next.slice(prefix, next.length - suffix);

  return {
    start: prefix,
    deleteCount: previous.length - prefix - suffix,
    insert,
    digits: insert.replace(NON_DIGIT, ""),
  };
}

type DigitCell = Readonly<{
  segment: SegmentName;
  offset: number;
  textIndex: number;
  digit: string;
}>;

/**
 * Every digit with both of its coordinates: the index it sits at in the text, and the
 * segment it belongs to.
 *
 * Needed because a deletion arrives as a range of text indices while the value is kept
 * per segment. The list is what lets that range pick out digits, and the ones it misses
 * go back into the segments they came from.
 */
function getDigitCells(segments: DateSegments): DigitCell[] {
  const cells: DigitCell[] = [];

  for (const range of getSegmentRanges(segments)) {
    for (let offset = 0; offset < range.digits.length; offset += 1) {
      cells.push({
        segment: range.name,
        offset,
        textIndex: range.start + offset,
        digit: range.digits.charAt(offset),
      });
    }
  }

  return cells;
}

/** Rebuilds a value from surviving digits, each landing back in its own segment. */
function segmentsFromCells(cells: readonly DigitCell[]): DateSegments {
  const result = copySegments(EMPTY_SEGMENTS);

  for (const cell of cells) {
    result[cell.segment] += cell.digit;
  }

  return result;
}

/**
 * Picks which digits a deletion takes. Nothing is deleted here — the caller rebuilds
 * the value from the cells this does *not* return.
 *
 * Usually that is every digit sitting inside the deleted range. A backspace over a
 * separator covers none, though: in `31 / 01 / 2020` the character before the `0` is a
 * space, so the range holds no digits at all. Taking nothing would leave the key dead
 * and the cursor stuck on the ` / `, so the digit in front of the range goes instead —
 * the `1` of `31`, leaving `3 / 01 / 2020`.
 *
 * Empty when there is genuinely nothing to take: an empty range, or a backspace at the
 * very start of the value.
 */
function getDeletedCells(
  cells: readonly DigitCell[],
  start: number,
  deleteCount: number
): DigitCell[] {
  if (deleteCount <= 0) {
    return [];
  }

  const end = start + deleteCount;
  const covered = cells.filter(
    (cell) => cell.textIndex >= start && cell.textIndex < end
  );

  if (covered.length > 0) {
    return covered;
  }

  const preceding = cells.filter((cell) => cell.textIndex < start);
  const digitBeforeRange = preceding[preceding.length - 1];

  return digitBeforeRange ? [digitBeforeRange] : [];
}

/**
 * Removes the digits the deleted range covered, and parks the caret where the first of
 * them was — where {@link applyMask} then types the edit's new digits.
 */
function erase(
  segments: DateSegments,
  start: number,
  deleteCount: number
): SegmentState {
  const cells = getDigitCells(segments);
  const deleted = getDeletedCells(cells, start, deleteCount);
  const [first] = deleted;

  if (!first) {
    return { segments, caret: textIndexToCaret(segments, start) };
  }

  return {
    segments: segmentsFromCells(
      cells.filter((cell) => !deleted.includes(cell))
    ),
    caret: { segment: first.segment, offset: first.offset },
  };
}

/** The segments once the digits have moved, and whether any fell off the end. */
type Spill = Readonly<{ segments: DateSegments; overflowed: boolean }>;

/**
 * Makes room for a digit typed into a segment that is already full, by trimming each
 * segment back to its width and pushing what no longer fits to the front of the next
 * one: typing `0` at the front of a `15` day gives `01` and moves the `5` to the month.
 *
 * The year has nowhere to push into, so digits leaving it are `overflowed` — the
 * caller's cue to refuse the edit rather than lose them.
 */
function spillForward(segments: DateSegments): Spill {
  const next = copySegments(segments);
  let overflowed = false;

  for (const name of SEGMENT_ORDER) {
    const width = SEGMENT_WIDTHS[name];

    if (next[name].length <= width) {
      continue;
    }

    const spill = next[name].slice(width);
    next[name] = next[name].slice(0, width);

    const following = NEXT_SEGMENT[name];

    if (following) {
      next[following] = spill + next[following];
    } else {
      overflowed = true;
    }
  }

  return { segments: next, overflowed };
}

/**
 * Whether a segment could still turn into a valid one. A part-typed segment always
 * could — `3` is on its way to `31` — so only a full segment is held to its range.
 */
function couldSegmentBeValid(name: SegmentName, digits: string): boolean {
  if (digits.length < SEGMENT_WIDTHS[name]) {
    return true;
  }

  const value = Number(digits);
  const { min, max } = SEGMENT_RANGES[name];

  return value >= min && value <= max;
}

/**
 * Whether every segment could still turn into a valid one. Not a check that the value
 * is a date: `31 / 02 / 2020` passes, because each segment on its own is in range.
 */
function couldBeValid(segments: DateSegments): boolean {
  return SEGMENT_ORDER.every((name) =>
    couldSegmentBeValid(name, segments[name])
  );
}

/**
 * Pads a one-digit day or month that can only mean one thing — a `4` in the month can
 * only be `04`, since `40` is past the end of the range — so the user does not have to
 * type the leading zero. Returns `null` when the digit could still grow into a
 * two-digit value.
 */
function padSegment(
  segments: DateSegments,
  name: SegmentName
): DateSegments | null {
  const digits = segments[name];

  if (SEGMENT_WIDTHS[name] !== 2 || digits.length !== 1) {
    return null;
  }

  if (Number(digits) * 10 <= SEGMENT_RANGES[name].max) {
    return null;
  }

  const next = copySegments(segments);
  next[name] = `0${digits}`;

  return next;
}

/**
 * Settles a segment the cursor is leaving before the next digit goes in, so typing
 * `4` then `5` in the month gives `04` and then a `5` in the year rather than `45`.
 * Only applies at the end of a segment — editing in the middle of one is not leaving.
 */
function autoFill(state: SegmentState): SegmentState {
  const { segments, caret } = state;

  if (caret.offset !== segments[caret.segment].length) {
    return state;
  }

  const padded = padSegment(segments, caret.segment);

  if (!padded) {
    return state;
  }

  const following = NEXT_SEGMENT[caret.segment];

  return {
    segments: padded,
    caret: following
      ? { segment: following, offset: 0 }
      : { segment: caret.segment, offset: SEGMENT_WIDTHS[caret.segment] },
  };
}

/**
 * Types one digit at the caret, and returns where the caret ends up.
 *
 * `null` means the digit was refused rather than swallowed: it would have pushed digits
 * off the end of the year, or made a segment that can never be valid (`35` for a day).
 */
function insertDigit(state: SegmentState, digit: string): SegmentState | null {
  const { segments, caret } = autoFill(state);
  const target = caret.segment;
  const offset = clamp(caret.offset, 0, segments[target].length);

  const digitIndexBeforeInsert = caretToDigitIndex(segments, caret);

  const withInsert = copySegments(segments);
  withInsert[target] =
    segments[target].slice(0, offset) + digit + segments[target].slice(offset);

  const spilled = spillForward(withInsert);

  if (spilled.overflowed || !couldBeValid(spilled.segments)) {
    return null;
  }

  const caretAfterInsert = digitIndexToCaret(
    spilled.segments,
    digitIndexBeforeInsert + 1
  );

  const padded = padSegment(spilled.segments, caretAfterInsert.segment);

  if (!padded) {
    return { segments: spilled.segments, caret: caretAfterInsert };
  }

  return {
    segments: padded,
    caret: {
      segment: caretAfterInsert.segment,
      offset: SEGMENT_WIDTHS[caretAfterInsert.segment],
    },
  };
}

/**
 * Updates the date segments to match the text the input now reports, and says where
 * the caret should go.
 */
export function applyMask(
  current: DateSegments,
  nativeText: string
): SegmentState {
  const change = diffText(segmentsToString(current), nativeText);

  let state = erase(current, change.start, change.deleteCount);

  for (const digit of change.digits) {
    const next = insertDigit(state, digit);

    if (!next) {
      break;
    }

    state = next;
  }

  return state;
}
