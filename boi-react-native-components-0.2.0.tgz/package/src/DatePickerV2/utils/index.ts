export {
  type Caret,
  type DateSegments,
  type SegmentState,
  type TextChange,
} from "./types";
export {
  EMPTY_SEGMENTS,
  isComplete,
  normalizeSegments,
  segmentsToString,
} from "./segments";
export { caretToTextIndex, textIndexToCaret } from "./caret";
export { dateToSegments, segmentsToDate } from "./converters";
export { applyMask, diffText } from "./mask";
