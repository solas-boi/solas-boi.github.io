import { parse, isValid } from "date-fns";
import { CoreDatePicker } from "@boi/components-core";

import {
  DATE_FNS_LOCALES,
  DATE_FORMATS,
  SEGMENT_WIDTHS,
} from "../DatePickerV2.constants";
import { EMPTY_SEGMENTS, segmentsToString } from "./segments";
import { type DateSegments } from "./types";

const isValidDate = (value?: unknown): value is Date =>
  value instanceof Date && isValid(value);

/**
 * The segments a date is edited as, each padded to its full width. Anything that is
 * not a usable date — including the `null` that clears the field — gives empty
 * segments.
 *
 * No locale is involved: every supported one is day-month-year, which is the order
 * `SEGMENT_ORDER` fixes. {@link segmentsToDate} reads them back through the locale's
 * format, so adding a month-first locale would break that pair.
 */
export function dateToSegments(date: Date | undefined | null): DateSegments {
  if (!isValidDate(date)) {
    return EMPTY_SEGMENTS;
  }

  return {
    day: String(date.getDate()).padStart(SEGMENT_WIDTHS.day, "0"),
    month: String(date.getMonth() + 1).padStart(SEGMENT_WIDTHS.month, "0"),
    year: String(date.getFullYear()).padStart(SEGMENT_WIDTHS.year, "0"),
  };
}

/**
 * The date the segments spell out, or `undefined` when they spell out one that does
 * not exist: `31 / 02 / 2020` is a well-formed value and not a date. Segments that
 * are not full parse as `undefined` too, so this doubles as a completeness check —
 * though `isComplete` says so more cheaply.
 */
export function segmentsToDate(
  segments: DateSegments,
  locale: CoreDatePicker.Locale
): Date | undefined {
  const parsed = parse(
    segmentsToString(segments),
    DATE_FORMATS[locale],
    new Date(),
    { locale: DATE_FNS_LOCALES[locale] }
  );

  return isValidDate(parsed) ? parsed : undefined;
}
