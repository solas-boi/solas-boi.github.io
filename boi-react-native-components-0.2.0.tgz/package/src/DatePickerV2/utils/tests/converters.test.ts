import { CoreDatePicker } from "@boi/components-core";

import { DATE_FORMATS } from "../../DatePickerV2.constants";
import { dateToSegments, segmentsToDate } from "../converters";
import { EMPTY_SEGMENTS, isComplete } from "../segments";

const LOCALE = CoreDatePicker.DEFAULT_LOCALE;

describe("dateToSegments", () => {
  it("should read a date into the segments it is edited as", () => {
    expect(dateToSegments(new Date(2020, 0, 31))).toEqual({
      day: "31",
      month: "01",
      year: "2020",
    });
  });

  it("should give an empty value for undefined", () => {
    expect(dateToSegments(undefined)).toEqual(EMPTY_SEGMENTS);
  });

  it("should give an empty value for null", () => {
    expect(dateToSegments(null)).toEqual(EMPTY_SEGMENTS);
  });

  it("should give an empty value for an Invalid Date", () => {
    expect(dateToSegments(new Date("not-a-date"))).toEqual(EMPTY_SEGMENTS);
  });

  it("should pad a year that is not four digits", () => {
    const date = new Date(2020, 0, 31);

    date.setFullYear(31);

    expect(dateToSegments(date)).toEqual({
      day: "31",
      month: "01",
      year: "0031",
    });
  });

  it("should agree with segmentsToDate in every supported locale", () => {
    const locales = Object.keys(DATE_FORMATS) as CoreDatePicker.Locale[];
    const date = new Date(2020, 0, 31);

    expect(locales.length).toBeGreaterThan(0);

    locales.forEach((locale) => {
      expect(segmentsToDate(dateToSegments(date), locale)).toEqual(date);
    });
  });
});

describe("segmentsToDate", () => {
  it("should round-trip a date back out of the segments it was read into", () => {
    const date = new Date(2020, 0, 31);

    expect(segmentsToDate(dateToSegments(date), LOCALE)).toEqual(date);
  });

  it("should give undefined for a well-formed value that is not a real date", () => {
    expect(
      segmentsToDate({ day: "31", month: "02", year: "2020" }, LOCALE)
    ).toBeUndefined();
  });

  it("should give undefined when a segment is left empty", () => {
    expect(
      segmentsToDate({ day: "31", month: "", year: "2020" }, LOCALE)
    ).toBeUndefined();
  });

  it("should give undefined when nothing is typed", () => {
    expect(segmentsToDate(EMPTY_SEGMENTS, LOCALE)).toBeUndefined();
  });

  it("should parse a half-typed segment, so isComplete is what says a value is done", () => {
    const partial = { day: "3", month: "01", year: "2020" };

    expect(isComplete(partial)).toBe(false);
    expect(segmentsToDate(partial, LOCALE)).toEqual(new Date(2020, 0, 3));
  });
});
