import { SEGMENT_ORDER } from "../../DatePickerV2.constants";
import {
  EMPTY_SEGMENTS,
  isComplete,
  normalizeSegments,
  segmentsToString,
} from "../segments";

describe("segmentsToString", () => {
  it("should render nothing until something is typed", () => {
    expect(segmentsToString(EMPTY_SEGMENTS)).toBe("");
  });

  it("should render only the day when nothing else is typed", () => {
    expect(segmentsToString({ day: "31", month: "", year: "" })).toBe("31");
  });

  it("should stop after the last segment holding digits", () => {
    expect(segmentsToString({ day: "31", month: "0", year: "" })).toBe(
      "31 / 0"
    );
  });

  it("should leave a gap when the month was emptied but the year remains", () => {
    expect(segmentsToString({ day: "31", month: "", year: "2020" })).toBe(
      "31 /  / 2020"
    );
  });

  it("should leave a gap when only the year remains", () => {
    expect(segmentsToString({ day: "", month: "", year: "2020" })).toBe(
      " /  / 2020"
    );
  });

  it("should leave a gap when the day was emptied but the month remains", () => {
    expect(segmentsToString({ day: "", month: "01", year: "" })).toBe(" / 01");
  });

  it("should never render a value longer than a complete date", () => {
    SEGMENT_ORDER.forEach((name) => {
      const segments = { ...EMPTY_SEGMENTS, [name]: "9999" };

      expect(segmentsToString(segments).length).toBeLessThanOrEqual(14);
    });
  });
});

describe("isComplete", () => {
  it("should report a full value as complete", () => {
    expect(isComplete({ day: "31", month: "01", year: "2020" })).toBe(true);
  });

  it("should report a half-typed day as incomplete", () => {
    expect(isComplete({ day: "3", month: "01", year: "2020" })).toBe(false);
  });

  it("should report an empty month as incomplete", () => {
    expect(isComplete({ day: "31", month: "", year: "2020" })).toBe(false);
  });

  it("should report nothing typed as incomplete", () => {
    expect(isComplete(EMPTY_SEGMENTS)).toBe(false);
  });
});

describe("normalizeSegments", () => {
  it("should fill a half-typed day and month out to full width", () => {
    expect(normalizeSegments({ day: "4", month: "1", year: "2020" })).toEqual({
      day: "04",
      month: "01",
      year: "2020",
    });
  });

  it("should return null when a segment is empty", () => {
    expect(
      normalizeSegments({ day: "10", month: "", year: "2025" })
    ).toBeNull();
  });

  it("should return null when the year is not fully typed", () => {
    expect(normalizeSegments({ day: "4", month: "1", year: "20" })).toBeNull();
  });

  it("should return null when the value is already in full format", () => {
    expect(
      normalizeSegments({ day: "04", month: "01", year: "2020" })
    ).toBeNull();
  });

  it("should return null when nothing has been typed", () => {
    expect(normalizeSegments(EMPTY_SEGMENTS)).toBeNull();
  });

  it("should pad a value even when it is not a real date", () => {
    expect(normalizeSegments({ day: "31", month: "2", year: "2020" })).toEqual({
      day: "31",
      month: "02",
      year: "2020",
    });
  });
});
