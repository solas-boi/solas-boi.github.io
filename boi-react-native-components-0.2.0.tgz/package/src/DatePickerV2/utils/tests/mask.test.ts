import { caretToTextIndex } from "../caret";
import { applyMask, diffText } from "../mask";
import { EMPTY_SEGMENTS, segmentsToString } from "../segments";
import { type DateSegments } from "../types";

type Outcome = {
  state: DateSegments;
  text: string;
  caret: number;
  rewrite: boolean;
};

function stateOf(segments: Partial<DateSegments>): DateSegments {
  return { ...EMPTY_SEGMENTS, ...segments };
}

/** Runs the text a platform would report back through the mask. */
function reconcile(segments: DateSegments, nativeText: string): Outcome {
  const next = applyMask(segments, nativeText);
  const text = segmentsToString(next.segments);

  return {
    state: next.segments,
    text,
    caret: caretToTextIndex(next.segments, next.caret),
    rewrite: text !== nativeText,
  };
}

/** Simulates the platform inserting `input` at `caret`, then reconciling. */
function type(segments: DateSegments, caret: number, input: string): Outcome {
  const text = segmentsToString(segments);

  return reconcile(segments, text.slice(0, caret) + input + text.slice(caret));
}

/** Simulates a backspace, where `caret` sits immediately after the doomed character. */
function backspace(segments: DateSegments, caret: number): Outcome {
  const text = segmentsToString(segments);

  return reconcile(segments, text.slice(0, caret - 1) + text.slice(caret));
}

describe("diffText", () => {
  it("should describe an append", () => {
    expect(diffText("31", "310")).toEqual({
      start: 2,
      deleteCount: 0,
      insert: "0",
      digits: "0",
    });
  });

  it("should describe a prepend", () => {
    expect(diffText("31", "031")).toEqual({
      start: 0,
      deleteCount: 0,
      insert: "0",
      digits: "0",
    });
  });

  it("should describe a backspace", () => {
    expect(diffText("310", "31")).toEqual({
      start: 2,
      deleteCount: 1,
      insert: "",
      digits: "",
    });
  });

  it("should describe a select-all replace", () => {
    expect(diffText("31 / 01 / 2020", "5")).toEqual({
      start: 0,
      deleteCount: 14,
      insert: "5",
      digits: "5",
    });
  });

  it("should describe no change", () => {
    expect(diffText("31", "31")).toEqual({
      start: 2,
      deleteCount: 0,
      insert: "",
      digits: "",
    });
  });

  it("should stay a pure insertion when a digit repeats the one already there", () => {
    // Turning this into a replacement is what used to let a stale caret hint eat
    // a digit from a neighbouring segment.
    expect(diffText("12 / 1 / 2000", "12 / 11 / 2000")).toEqual({
      start: 6,
      deleteCount: 0,
      insert: "1",
      digits: "1",
    });
  });

  it("should strip the non-digits a paste brings in", () => {
    expect(diffText("", "2020-06-15")).toEqual({
      start: 0,
      deleteCount: 0,
      insert: "2020-06-15",
      digits: "20200615",
    });
  });
});

describe("typing a date from empty", () => {
  it("should only rewrite the text to add a separator, and never shorten it", () => {
    const steps: Array<[string, string, number, boolean]> = [
      ["3", "3", 1, false],
      ["1", "31", 2, false],
      ["0", "31 / 0", 6, true],
      ["1", "31 / 01", 7, false],
      ["2", "31 / 01 / 2", 11, true],
      ["0", "31 / 01 / 20", 12, false],
      ["2", "31 / 01 / 202", 13, false],
      ["0", "31 / 01 / 2020", 14, false],
    ];

    let state = EMPTY_SEGMENTS;
    let caret = 0;

    steps.forEach(([digit, text, expectedCaret, expectedRewrite]) => {
      const previousLength = segmentsToString(state).length;
      const outcome = type(state, caret, digit);

      expect(outcome.text).toBe(text);
      expect(outcome.caret).toBe(expectedCaret);
      expect(outcome.rewrite).toBe(expectedRewrite);
      expect(outcome.text.length).toBeGreaterThan(previousLength);

      state = outcome.state;
      caret = outcome.caret;
    });

    expect(segmentsToString(state)).toBe("31 / 01 / 2020");
  });
});

describe("the reported bug", () => {
  it("should never drag the year's leading digit into the month", () => {
    const cleared = backspace(
      backspace(stateOf({ day: "31", month: "01", year: "2020" }), 7).state,
      6
    );

    expect(cleared.text).toBe("31 /  / 2020");
    expect(cleared.caret).toBe(5);
    expect(cleared.rewrite).toBe(false);

    const first = type(cleared.state, cleared.caret, "1");

    expect(first.text).toBe("31 / 1 / 2020");
    expect(first.caret).toBe(6);

    const second = type(first.state, first.caret, "2");

    expect(second.text).toBe("31 / 12 / 2020");
    expect(second.caret).toBe(7);
    expect(second.state.year).toBe("2020");
  });

  it("should leave the month and year alone when the day is retyped", () => {
    const cleared = backspace(
      backspace(stateOf({ day: "31", month: "01", year: "2020" }), 2).state,
      1
    );

    expect(cleared.text).toBe(" / 01 / 2020");

    const retyped = type(cleared.state, cleared.caret, "2");

    expect(retyped.text).toBe("2 / 01 / 2020");
    expect(retyped.state.month).toBe("01");
    expect(retyped.state.year).toBe("2020");
  });

  it("should add a second month digit without disturbing the day", () => {
    const outcome = type(stateOf({ day: "11", month: "1" }), 6, "1");

    expect(outcome.text).toBe("11 / 11");
    expect(outcome.caret).toBe(7);
    expect(outcome.rewrite).toBe(false);
  });
});

describe("keeping each segment in range", () => {
  it("should complete a leading 4 in the day, which cannot start a valid pair", () => {
    expect(type(EMPTY_SEGMENTS, 0, "4").text).toBe("04");
  });

  it("should complete a leading 9 in the day", () => {
    expect(type(EMPTY_SEGMENTS, 0, "9").text).toBe("09");
  });

  it("should leave a leading 3 in the day open, since 31 is valid", () => {
    expect(type(EMPTY_SEGMENTS, 0, "3").text).toBe("3");
  });

  it("should leave a leading 0 in the day open", () => {
    expect(type(EMPTY_SEGMENTS, 0, "0").text).toBe("0");
  });

  it("should complete a month that cannot take a second digit", () => {
    const outcome = type(stateOf({ day: "31" }), 2, "9");

    expect(outcome.text).toBe("31 / 09");
    expect(outcome.caret).toBe(7);
  });

  it("should refuse a day over 31", () => {
    expect(type(stateOf({ day: "3" }), 1, "5").text).toBe("3");
  });

  it("should refuse a zero day", () => {
    expect(type(stateOf({ day: "0" }), 1, "0").text).toBe("0");
  });

  it("should refuse a month over 12", () => {
    expect(type(stateOf({ day: "31", month: "1" }), 6, "3").text).toBe(
      "31 / 1"
    );
  });

  it("should refuse a zero month", () => {
    expect(type(stateOf({ day: "31", month: "0" }), 6, "0").text).toBe(
      "31 / 0"
    );
  });

  it("should refuse a zero year", () => {
    expect(
      type(stateOf({ day: "31", month: "01", year: "000" }), 13, "0").text
    ).toBe("31 / 01 / 000");
  });

  it("should not be able to hold 44 / 44", () => {
    let state = EMPTY_SEGMENTS;
    let caret = 0;

    "4444".split("").forEach((digit) => {
      const outcome = type(state, caret, digit);

      state = outcome.state;
      caret = outcome.caret;
    });

    expect(segmentsToString(state)).toBe("04 / 04 / 44");
  });

  it("should step past a segment a deletion left unable to take another digit", () => {
    expect(type(stateOf({ day: "9" }), 1, "1").text).toBe("09 / 1");
  });
});

describe("typing with the cursor parked on a separator", () => {
  it("should finish the month from either side of the separator after it", () => {
    const segments = stateOf({ month: "1", year: "111" });

    [4, 5, 6].forEach((caret) => {
      expect(type(segments, caret, "2").text).toBe(" / 12 / 111");
    });
  });

  it("should finish the day from inside the separator after it", () => {
    expect(type(stateOf({ day: "1", month: "06" }), 2, "5").text).toBe(
      "15 / 06"
    );
  });

  it("should start the next segment once the one before is full", () => {
    expect(type(stateOf({ day: "15", month: "06" }), 3, "1").text).toBe(
      "15 / 10 / 6"
    );
  });
});

describe("deleting", () => {
  it("should remove a digit and its separator in a single press", () => {
    const outcome = backspace(stateOf({ day: "31", month: "0" }), 6);

    expect(outcome.text).toBe("31");
    expect(outcome.caret).toBe(2);
  });

  it("should leave a gap, not a shift, when a later segment still has digits", () => {
    const outcome = backspace(
      stateOf({ day: "31", month: "0", year: "2020" }),
      6
    );

    expect(outcome.text).toBe("31 /  / 2020");
    expect(outcome.caret).toBe(5);
    expect(outcome.rewrite).toBe(false);
  });

  it("should not rewrite the text when one of two identical digits is deleted", () => {
    const outcome = backspace(
      stateOf({ day: "13", month: "11", year: "2028" }),
      6
    );

    expect(outcome.text).toBe("13 / 1 / 2028");
    expect(outcome.rewrite).toBe(false);
  });

  it("should take the preceding digit when the caret is inside a separator", () => {
    const outcome = backspace(
      stateOf({ day: "31", month: "01", year: "2020" }),
      5
    );

    expect(outcome.text).toBe("3 / 01 / 2020");
    expect(outcome.caret).toBe(1);
  });

  it("should empty every segment when backspaced from the end", () => {
    let state = stateOf({ day: "31", month: "01", year: "2020" });
    let caret = 14;

    for (let press = 0; press < 8; press += 1) {
      const outcome = backspace(state, caret);

      state = outcome.state;
      caret = outcome.caret;
    }

    expect(segmentsToString(state)).toBe("");
    expect(caret).toBe(0);
  });

  it("should clear everything when the whole value is selected and deleted", () => {
    const outcome = reconcile(
      stateOf({ day: "31", month: "01", year: "2020" }),
      ""
    );

    expect(outcome.text).toBe("");
    expect(outcome.caret).toBe(0);
  });
});

describe("pasting", () => {
  it("should accept a date written with slashes", () => {
    expect(type(EMPTY_SEGMENTS, 0, "31/01/2020").text).toBe("31 / 01 / 2020");
  });

  it("should accept a date written as bare digits", () => {
    expect(type(EMPTY_SEGMENTS, 0, "31012020").text).toBe("31 / 01 / 2020");
  });

  it("should accept a date already in the displayed format", () => {
    expect(type(EMPTY_SEGMENTS, 0, "31 / 01 / 2020").text).toBe(
      "31 / 01 / 2020"
    );
  });

  it("should fill digits left to right regardless of the order they were written in", () => {
    expect(type(EMPTY_SEGMENTS, 0, "2020-01-31").text).toBe("20 / 02 / 0013");
  });

  it("should ignore a paste with no digits in it", () => {
    expect(type(EMPTY_SEGMENTS, 0, "abc").text).toBe("");
  });

  it("should ignore an empty paste", () => {
    expect(type(EMPTY_SEGMENTS, 0, "").text).toBe("");
  });

  it("should drop the excess rather than the digits already on screen", () => {
    expect(type(EMPTY_SEGMENTS, 0, "3101202099999").text).toBe(
      "31 / 01 / 2020"
    );
  });
});

describe("rejecting input", () => {
  it("should ignore letters and ask for the text to be rewritten", () => {
    const outcome = type(
      stateOf({ day: "31", month: "1", year: "2020" }),
      6,
      "a"
    );

    expect(outcome.text).toBe("31 / 1 / 2020");
    expect(outcome.caret).toBe(6);
    expect(outcome.rewrite).toBe(true);
  });

  it("should refuse a digit that has nowhere to go instead of losing one", () => {
    const outcome = type(
      stateOf({ day: "3", month: "11", year: "2000" }),
      6,
      "1"
    );

    expect(outcome.state).toEqual({ day: "3", month: "11", year: "2000" });
    expect(outcome.caret).toBe(6);
  });

  it("should never lose a digit that is already displayed", () => {
    const state = stateOf({ day: "31", month: "01", year: "2020" });

    for (let caret = 0; caret <= 14; caret += 1) {
      // A complete date has no room, so every segment must come back untouched.
      expect(type(state, caret, "7").state).toEqual(state);
    }
  });
});

describe("canonical values are stable", () => {
  it("should leave a value untouched when fed its own rendering", () => {
    const values: DateSegments[] = [
      EMPTY_SEGMENTS,
      { day: "31", month: "", year: "" },
      { day: "31", month: "0", year: "" },
      { day: "31", month: "", year: "2020" },
      { day: "", month: "", year: "2020" },
      { day: "31", month: "01", year: "2020" },
    ];

    values.forEach((segments) => {
      expect(applyMask(segments, segmentsToString(segments)).segments).toEqual(
        segments
      );
    });
  });
});
