import { caretToTextIndex, textIndexToCaret } from "../caret";
import { EMPTY_SEGMENTS } from "../segments";
import { type DateSegments } from "../types";

describe("caretToTextIndex", () => {
  it("should place a caret at the start of the day", () => {
    expect(
      caretToTextIndex(
        { day: "31", month: "01", year: "2020" },
        { segment: "day", offset: 0 }
      )
    ).toBe(0);
  });

  it("should skip the separator when placing a caret in the month", () => {
    expect(
      caretToTextIndex(
        { day: "31", month: "01", year: "2020" },
        { segment: "month", offset: 0 }
      )
    ).toBe(5);
  });

  it("should skip both separators when placing a caret in the year", () => {
    expect(
      caretToTextIndex(
        { day: "31", month: "01", year: "2020" },
        { segment: "year", offset: 4 }
      )
    ).toBe(14);
  });

  it("should place a caret from an unrendered segment at the end of the text", () => {
    expect(
      caretToTextIndex(
        { day: "31", month: "", year: "" },
        { segment: "month", offset: 0 }
      )
    ).toBe(2);
  });

  it("should place a caret at the start when nothing is rendered", () => {
    expect(
      caretToTextIndex(EMPTY_SEGMENTS, { segment: "day", offset: 0 })
    ).toBe(0);
  });
});

describe("textIndexToCaret", () => {
  it("should round-trip every reachable caret", () => {
    const segments: DateSegments = { day: "31", month: "0", year: "" };

    (["day", "month"] as const).forEach((segment) => {
      for (let offset = 0; offset <= segments[segment].length; offset += 1) {
        const index = caretToTextIndex(segments, { segment, offset });

        expect(textIndexToCaret(segments, index)).toEqual({ segment, offset });
      }
    });
  });

  it("should give a separator to the segment that follows a full one", () => {
    const segments: DateSegments = { day: "31", month: "01", year: "2020" };

    [3, 4, 5].forEach((index) => {
      expect(textIndexToCaret(segments, index).segment).toBe("month");
    });
  });

  it("should give a separator back to the segment before it while it has room", () => {
    const segments: DateSegments = { day: "", month: "1", year: "111" };

    [5, 6].forEach((index) => {
      expect(textIndexToCaret(segments, index)).toEqual({
        segment: "month",
        offset: 1,
      });
    });
  });

  it("should put the gap left by an emptied segment inside that segment", () => {
    expect(textIndexToCaret({ day: "31", month: "", year: "2020" }, 5)).toEqual(
      { segment: "month", offset: 0 }
    );
  });

  it("should give the year the separator that follows an emptied month", () => {
    expect(textIndexToCaret({ day: "31", month: "", year: "2020" }, 8)).toEqual(
      { segment: "year", offset: 0 }
    );
  });

  it("should land after the last digit for an index past the end of the text", () => {
    expect(textIndexToCaret({ day: "31", month: "", year: "" }, 99)).toEqual({
      segment: "day",
      offset: 2,
    });
  });

  it("should fall back to the start of the day when nothing is rendered", () => {
    expect(textIndexToCaret(EMPTY_SEGMENTS, 5)).toEqual({
      segment: "day",
      offset: 0,
    });
  });
});
