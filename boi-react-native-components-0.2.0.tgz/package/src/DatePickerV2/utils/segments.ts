import {
  SEGMENT_ORDER,
  SEGMENT_WIDTHS,
  SEPARATOR,
  type SegmentName,
} from "../DatePickerV2.constants";
import { type DateSegments } from "./types";
export const EMPTY_SEGMENTS: DateSegments = { day: "", month: "", year: "" };

/**
 * A writable copy of a value. Segments are read-only so that nothing edits the value
 * in place behind the field's back; every step that changes one builds a copy here
 * and returns it instead.
 */
export function copySegments(
  segments: DateSegments
): Record<SegmentName, string> {
  return { day: segments.day, month: segments.month, year: segments.year };
}

/**
 * How many segments to render: up to and including the last one holding digits.
 *
 * `{ day: "15", month: "06", year: "" }` gives 2, so the text reads `15 / 06` and not
 * `15 / 06 / `. An empty segment before a filled one still counts:
 * `{ day: "15", month: "", year: "2020" }` gives 3, and reads `15 /  / 2020`.
 */
function getRenderedCount(segments: DateSegments): number {
  let count = 0;

  SEGMENT_ORDER.forEach((name, index) => {
    if (segments[name].length > 0) {
      count = index + 1;
    }
  });

  return count;
}

/**
 * Segments to text: `{ day: "15", month: "06", year: "2020" }` gives `15 / 06 / 2020`.
 */
export function segmentsToString(segments: DateSegments): string {
  return SEGMENT_ORDER.slice(0, getRenderedCount(segments))
    .map((name) => segments[name])
    .join(SEPARATOR);
}

/**
 * Whether every segment is full. A complete value is well-formed, not necessarily a
 * real date — `31 / 02 / 2020` is complete.
 */
export function isComplete(segments: DateSegments): boolean {
  return SEGMENT_ORDER.every(
    (name) => segments[name].length === SEGMENT_WIDTHS[name]
  );
}

export type SegmentRange = Readonly<{
  name: SegmentName;
  start: number;
  end: number;
  digits: string;
}>;

/**
 * Where each rendered segment sits in the displayed string.
 *
 * `15 / 06 / 2020` gives:
 *
 * ```
 * { name: "day",   start: 0,  end: 2,  digits: "15"   }
 * { name: "month", start: 5,  end: 7,  digits: "06"   }
 * { name: "year",  start: 10, end: 14, digits: "2020" }
 * ```
 *
 * The gaps — 2 to 5, and 7 to 10 — are the ` / ` separators. Skipping over them is
 * what turns a segment and offset into an index into the text, and back.
 */
export function getSegmentRanges(segments: DateSegments): SegmentRange[] {
  const ranges: SegmentRange[] = [];
  let cursor = 0;

  SEGMENT_ORDER.slice(0, getRenderedCount(segments)).forEach((name, index) => {
    if (index > 0) {
      cursor += SEPARATOR.length;
    }

    const digits = segments[name];

    ranges.push({ name, start: cursor, end: cursor + digits.length, digits });
    cursor += digits.length;
  });

  return ranges;
}

/**
 * Pads a value out to full width, so `1 / 2 / 2026` settles as `01 / 02 / 2026`.
 * Returns `null` when there is nothing to settle — `01 / / 2026`, `/ / 2026`, etc.
 */
export function normalizeSegments(segments: DateSegments): DateSegments | null {
  if (SEGMENT_ORDER.some((name) => segments[name].length === 0)) {
    return null;
  }

  if (segments.year.length !== SEGMENT_WIDTHS.year) {
    return null;
  }

  const normalized = copySegments(segments);

  for (const name of SEGMENT_ORDER) {
    normalized[name] = segments[name].padStart(SEGMENT_WIDTHS[name], "0");
  }

  const unchanged = SEGMENT_ORDER.every(
    (name) => normalized[name] === segments[name]
  );

  return unchanged ? null : normalized;
}
