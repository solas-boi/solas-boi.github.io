import { SEGMENT_ORDER, SEGMENT_WIDTHS } from "../DatePickerV2.constants";
import {
  getSegmentRanges,
  segmentsToString,
  type SegmentRange,
} from "./segments";
import { type Caret, type DateSegments } from "./types";

// TODO: CP-106735 Add month-first format support when required.
const INITIAL_CARET: Caret = { segment: "day", offset: 0 };

/** Keeps `value` within `[min, max]`. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/**
 * A caret as an index into the displayed string, separators counted — which is what
 * the text input has to be told to put the cursor back. A caret in a segment that is
 * not rendered yet lands at the end of the text.
 */
export function caretToTextIndex(segments: DateSegments, caret: Caret): number {
  const range = getSegmentRanges(segments).find(
    (candidate) => candidate.name === caret.segment
  );

  if (!range) {
    return segmentsToString(segments).length;
  }

  return range.start + clamp(caret.offset, 0, range.digits.length);
}

/** Whether a rendered segment could still take another digit. */
function hasRoom(range: SegmentRange | undefined): range is SegmentRange {
  return !!range && range.digits.length < SEGMENT_WIDTHS[range.name];
}

/**
 * The caret an index into the displayed string points at — the inverse of
 * {@link caretToTextIndex}. An index past the end of the text lands after the last
 * digit.
 */
export function textIndexToCaret(
  segments: DateSegments,
  textIndex: number
): Caret {
  const ranges = getSegmentRanges(segments);
  let previous: SegmentRange | undefined;

  for (const range of ranges) {
    if (textIndex <= range.end) {
      if (textIndex < range.start && hasRoom(previous)) {
        return { segment: previous.name, offset: previous.digits.length };
      }

      return {
        segment: range.name,
        offset: clamp(textIndex - range.start, 0, range.digits.length),
      };
    }

    previous = range;
  }

  const last = ranges[ranges.length - 1];

  return last
    ? { segment: last.name, offset: last.digits.length }
    : INITIAL_CARET;
}

/**
 * A caret as a count of digits from the start of the value, separators and segment
 * boundaries ignored. Digits inserted earlier in the value shift the ones after them
 * between segments, so this is the form that survives an edit — the caret is converted
 * to it before the edit and back afterwards.
 */
// TODO: CP-106735 Add month-first format support when required.
export function caretToDigitIndex(
  segments: DateSegments,
  caret: Caret
): number {
  let total = 0;

  for (const name of SEGMENT_ORDER) {
    if (name === caret.segment) {
      return total + clamp(caret.offset, 0, segments[name].length);
    }

    total += segments[name].length;
  }

  return total;
}

/**
 * The caret a digit count from the start of the value lands on — the inverse of
 * {@link caretToDigitIndex}, read against whatever the segments hold now.
 */
// TODO: CP-106735 Add month-first format support when required.
export function digitIndexToCaret(
  segments: DateSegments,
  digitIndex: number
): Caret {
  let remaining = Math.max(digitIndex, 0);

  for (const name of SEGMENT_ORDER) {
    if (remaining <= segments[name].length) {
      return { segment: name, offset: remaining };
    }

    remaining -= segments[name].length;
  }

  return { segment: "year", offset: segments.year.length };
}
