import {
  memo,
  cloneElement,
  useState,
  RefObject,
  MutableRefObject,
} from "react";
import { View, type ListViewToken, type FlatList } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { CoreCombobox } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { TickIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./ComboboxItem.styles";
import { Typography } from "../../Typography";
import {} from "react-native-gesture-handler";

const TAB_KEYCODE = 61;

export type ComboboxItemProps = {
  item: CoreCombobox.ComboboxItem;
  isFirst: boolean;
  isLast: boolean;
  isLastPromoted: boolean;
  isSelected: boolean;
  isDisabled: boolean;
  onPress: () => void;
  flatlistRef: RefObject<FlatList | null>;
  flatlistViewableInfoRef: MutableRefObject<
    | {
        viewableItems: ListViewToken[];
      }
    | undefined
  >;
};

const ComboboxItem = memo((props: ComboboxItemProps) => {
  const {
    item,
    onPress,
    isSelected,
    isDisabled,
    isFirst,
    isLast,
    isLastPromoted,
    flatlistRef,
    flatlistViewableInfoRef,
  } = props;

  const { tokens } = useDesignTokens();
  const { select } = tokens;

  const styles = useStyles();
  const stateStyles = useStateStyles(
    isFirst,
    isLast,
    isLastPromoted,
    isDisabled
  );

  const [pressed, setPressed] = useState(false);
  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <KeyboardPressable
      style={stateStyles.container}
      enableA11yFocus
      accessibilityRole="radio"
      role="radio"
      accessibilityLabel={item.title}
      accessibilityHint={!isSelected ? "Selects the item" : undefined}
      accessibilityState={{ selected: isSelected }}
      disabled={isDisabled}
      onFocusChange={handleKeyboardFocusChange}
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      onKeyDownPress={(e) => {
        if (e.nativeEvent.keyCode === TAB_KEYCODE) {
          if (isLast) {
            // Scrolls to the top of the list as the focus will move to the close button
            flatlistRef?.current?.scrollToIndex({
              index: 0,
              animated: true,
            });
          } else if (flatlistViewableInfoRef?.current) {
            const secondLastRenderedItem =
              flatlistViewableInfoRef.current.viewableItems.slice(-2)[0];

            const isSecondLastRenderedItem =
              secondLastRenderedItem?.item === item;

            // If the TAB key is pressed while the focus is on the second last item rendered on screen
            // Then scroll to it so more items are rendered below, hence ensuring the focus order using the TAB key is correct
            // This fixes ticked CP-98327
            if (isSecondLastRenderedItem && secondLastRenderedItem.index) {
              flatlistRef?.current?.scrollToIndex({
                index: secondLastRenderedItem.index,
                animated: true,
              });
            }
          }
        }
      }}
    >
      <View style={stateStyles.contentWrapper(pressed || hasKeyboardFocus)}>
        <View style={styles.content}>
          <View style={styles.tickIconWrapper}>
            {isSelected && (
              <TickIcon
                color={select.menu.option.inner.tickIcon.color}
                width={select.menu.option.inner.tickIcon.width}
                height={select.menu.option.inner.tickIcon.height}
              />
            )}
          </View>

          {item.icon && (
            <View style={styles.iconWrapper}>
              {cloneElement(item.icon, {
                ...item.icon.props,
                style: stateStyles.icon,
              })}
            </View>
          )}

          <View style={styles.typographyWrapper}>
            <Typography
              variant={select.menu.option.inner.text.typography.variant}
              fontFamily={select.menu.option.inner.text.typography.fontFamily}
              style={stateStyles.text}
            >
              {item.title}
            </Typography>
          </View>
        </View>
      </View>
    </KeyboardPressable>
  );
});

export default ComboboxItem;
