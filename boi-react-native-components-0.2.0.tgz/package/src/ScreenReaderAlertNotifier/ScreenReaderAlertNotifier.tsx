import { forwardRef } from "react";
import { A11y, type IndexCommands } from "react-native-a11y-order";
import { ScreenReaderAlertNotifierProps } from "./ScreenReaderAlertNotifier.types";
import { alertAnnouncementHandler } from "./ScreenReaderAlertNotifier.utils";

const ScreenReaderAlertNotifier = forwardRef<
  IndexCommands,
  ScreenReaderAlertNotifierProps
>((props, ref) => {
  const { testID = "screen-reader-alert-notifier" } = props;

  const announceAlertOnFocus = alertAnnouncementHandler(props.alert);

  return (
    <A11y.View
      {...props}
      ref={ref}
      testID={testID}
      children={props.children}
      onScreenReaderDescendantFocusChanged={announceAlertOnFocus}
    />
  );
});

export default ScreenReaderAlertNotifier;
