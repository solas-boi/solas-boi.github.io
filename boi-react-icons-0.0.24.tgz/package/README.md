# React icons

React components for the `@boi/icons` files.

## Installation

```console
npm i @boi/react-icons
```

## Usage

```jsx
import { CloseIcon, ErrorIcon } from "@boi/react-icons";
```

To change the color of standard icons, use the `color` prop:

```jsx
<CloseIcon color={modal.icons.close.color} />
```

To change the color of multicolor icons, use the `primaryColor` and `secondaryColor` props:

```jsx
<ErrorIcon
  primaryColor={modal.icons.error.primaryColor}
  secondaryColor={modal.icons.error.secondaryColor}
/>
```

Alternatively, you can use the `data-primary-color` and `data-secondary-color` attributes:

```js
export const StyledErrorIcon = styled(ErrorIcon)`
  ${() => {
    const { tokens } = useDesignTokens();
    const { modal } = tokens;

    return css`
      & [data-primary-color] {
        color: ${modal.icons.error.primaryColor};
      }

      & [data-secondary-color] {
        color: ${modal.icons.error.secondaryColor};
      }
    `;
  }}
`;
```
