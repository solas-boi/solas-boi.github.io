import type { Brand } from "./types.js";

export const DEFAULT_BRAND = "boi" satisfies Brand;
export const DEFAULT_THEME = "light";

export const BRANDS = ["boi", "newIreland", "davy"] as const;
export const PLATFORMS = ["web", "reactNative", "android", "ios"] as const;

export const BOI_THEMES = ["light", "dark", "pride"] as const;
export const NEW_IRELAND_THEMES = ["light", "dark"] as const;
export const DAVY_THEMES = ["light", "dark"] as const;
