# Country assets

Country data, including SVG flags, used throughout Bank of Ireland.

## Installation

```console
npm i @boi/country-assets
```

## Usage

```jsx
import { countriesData } from "@boi/country-assets"; // get countries data
import IE from "@boi/country-assets/src/IE.svg"; // gets Ireland flag svg
```
