# React Native design tokens

React Native components for the `@boi/design-tokens` files.

## Installation

```console
npm i @react-native-async-storage/async-storage
npm i @boi/react-native-design-tokens
```

## Usage

### Initialising design tokens

Render the `DesignTokensProvider` at the root of your application:

```jsx
import {
  DesignTokensProvider,
  BOI_THEME_TOKENS,
} from "@boi/react-native-design-tokens";

import Layout from "./Layout";

export default function App() {
  return (
    <DesignTokensProvider themeTokens={BOI_THEME_TOKENS}>
      <Layout />
    </DesignTokensProvider>
  );
}
```

### Using design tokens

Then use the design tokens inside your components:

```jsx
import { View } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

export default function Layout() {
  const { tokens } = useDesignTokens();
  const { themeColor, color } = tokens;

  return (
    <>
      <View style={{ backgroundColor: themeColor.core100 }}>
        The colour of this will automatically change if your app's theme changes
      </View>
      <View style={{ backgroundColor: color.white }}>
        If you're app is not using themes, then you can use the colours directly
        like this
      </View>
    </>
  );
}
```

### Updating the theme

To update the theme, use `updateTheme` in your React component, like so:

```jsx
import { useDesignTokens } from "@boi/react-design-tokens";

export default function MyComponent() {
  const { updateTheme } = useDesignTokens();

  return (
    <button onClick={() => updateTheme("dark")}>Change to dark theme</button>
  );
}
```
