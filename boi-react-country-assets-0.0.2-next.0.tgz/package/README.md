# React country assets

The `@boi/country-assets` packaged for React applications.

## Installation

```console
npm i @boi/react-country-assets
```

## Usage

```jsx
import { countriesData } from "@boi/react-country-assets";

{
  countriesData.map(
    ({ code, label, callingCode, component: FlagComponent }) => {
      return (
        <>
          Country code: {code}
          Country name: {label}
          Country calling code: {callingCode}
          Country flag: <FlagComponent />
        </>
      );
    }
  );
}
```
