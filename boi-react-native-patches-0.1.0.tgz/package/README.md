# React Native Patches

Collection of patches applied to react-native and its ecosystem dependencies.
The change in each patch is described in the corresponding md file.

## Numbering

The number in a file name (`<package>+<version>+<number>+<name>.patch`) determines
the order patches are applied in, and is a stable ID: it is never reused or shifted.
Gaps in the sequence are expected and mean a patch was dropped because the fix
landed upstream.

## Installation

```console
npm i @boi/react-native-patches
```

## Usage

After installing. Add the postinstall script to your `package.json`

```json
"postinstall": "patch-package --patch-dir ./node_modules/@boi/react-native-patches/src",
```
