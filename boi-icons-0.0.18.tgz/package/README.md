# Icons

Set of SVG icons used throughout Bank of Ireland.

## Installation

```console
npm i @boi/icons
```

## Usage

```jsx
import closeIcon from "@boi/icons/src/close_icon.svg";
```
