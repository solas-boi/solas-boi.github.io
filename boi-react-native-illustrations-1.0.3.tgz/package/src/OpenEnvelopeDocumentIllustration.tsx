import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const OpenEnvelopeDocumentIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_13934_4455)" />
      <Path
        d="M60.1 26.5481C59.8368 26.5481 59.5737 26.6286 59.3486 26.7881L21.9437 53.4508C21.4852 53.7784 21.3067 54.2188 21.3067 54.9649C21.3066 55.6446 21.3066 55 21.3067 55.8H97.506C98.0689 55.8 98.529 55.4351 98.7004 54.8991C98.7004 54.125 98.7156 53.7784 98.2572 53.4508L60.8512 26.7881C60.6265 26.6286 60.3633 26.5481 60.1 26.5481ZM60.1 27.8427L97.506 54.5055H22.6949L60.1 27.8427Z"
        fill={colors.stroke}
      />
      <Path
        d="M38.1 15.8H72L84 27.8V64.4001L72 74L63.9 80.5001L59.9 78.0001L56.4 80.5001L48 74L36 64.4001V17.9L36.0584 15.8H38.1Z"
        fill={colors.highlight}
      />
      <Path
        d="M72 15.8V26.3C72 26.6979 72.158 27.0794 72.4393 27.3607C72.7206 27.642 73.1022 27.8 73.5 27.8H83.5688"
        stroke={colors.stroke}
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M64.5 39.8H77.1"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M53.9004 39.8H61.7004"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 39.8H50.3141"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 32.3H53.3329"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54 45.8H77.1"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 45.8H50.3141"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M66 51.8H77.1"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 51.8H62.3141"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54 57.8H77.1"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 57.8H50.3141"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 63.8H77.1004"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.9004 69.8H65.3329"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M36.6436 16.3428C36.8138 16.1726 37.0447 16.077 37.2854 16.077H71.7138L83.4239 27.787V80.3077C83.4239 80.5485 83.3283 80.7793 83.158 80.9496C82.9878 81.1198 82.7569 81.2154 82.5162 81.2154H68.95C68.949 81.2154 68.948 81.2154 68.947 81.2154L37.2854 81.2154C37.0447 81.2154 36.8138 81.1198 36.6436 80.9496C36.4734 80.7793 36.3777 80.5485 36.3777 80.3077V32.3631V32.0616V16.9846C36.3777 16.7439 36.4734 16.513 36.6436 16.3428ZM35.1777 32.0616V16.9846C35.1777 16.4257 35.3998 15.8896 35.7951 15.4943C36.1903 15.099 36.7264 14.877 37.2854 14.877H71.9623C72.1215 14.877 72.2741 14.9402 72.3866 15.0527L84.4482 27.1142C84.5607 27.2268 84.6239 27.3794 84.6239 27.5385V80.3077C84.6239 80.8667 84.4018 81.4028 84.0066 81.7981C83.6113 82.1934 83.0752 82.4154 82.5162 82.4154H68.947H37.2854C36.7264 82.4154 36.1903 82.1934 35.7951 81.7981C35.3998 81.4028 35.1777 80.8667 35.1777 80.3077V32.3631V32.0616Z"
        fill={colors.stroke}
      />
      <Path
        d="M22.4004 55L56.9004 80L59.9004 78L62.9004 80L98.4004 55V102H22.4004V55Z"
        fill={colors.fill}
      />
      <Path
        d="M22.5952 54.7135C22.3925 54.7135 22.1892 54.7608 22.0022 54.857C21.5718 55.0794 21.3008 55.0165 21.3008 55.5001V101.507C21.3008 102.222 21.8804 102.8 22.5952 102.8H97.4064C98.1212 102.8 98.7008 102.222 98.7008 101.507V55.0001C98.7008 54.5165 98.4299 55.0794 97.9993 54.857C97.8124 54.7608 97.6091 54.7135 97.4064 54.7135C97.1418 54.7135 96.8786 54.7938 96.6554 54.9531L62.9698 79.0158L60.0004 77.7781L57.1463 79.0158L23.3464 54.9531C23.1229 54.7938 22.8597 54.7135 22.5952 54.7135ZM97.4064 56.0064V101.507H22.5952V56.0064L56.8274 80.5225L60.0004 78.5315L62.9698 80.5225L97.4064 56.0064Z"
        fill={colors.stroke}
      />
      <Path
        d="M60.0004 77.4646C59.7671 77.4646 59.5339 77.5263 59.3274 77.6526L21.9217 100.404C21.4265 100.705 21.1923 101.298 21.349 101.857C21.5055 102.414 22.0147 102.8 22.5952 102.8H97.4064C97.9867 102.8 98.4961 102.414 98.6525 101.856C98.8093 101.298 98.5751 100.705 98.08 100.404L60.6736 77.6526C60.4669 77.5263 60.2335 77.4646 60.0004 77.4646ZM60.0004 78.756L97.4064 101.507H22.5952L60.0004 78.756Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_13934_4455"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default OpenEnvelopeDocumentIllustration;
