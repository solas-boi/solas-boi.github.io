import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
  Mask,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentTickIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14694_4825)" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM82.5 100C88.299 100 93 95.299 93 89.5C93 83.701 88.299 79 82.5 79C76.701 79 72 83.701 72 89.5C72 95.299 76.701 100 82.5 100Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M88.6847 86.2488L88.2679 84.7354L87.8118 84.8685L87.8089 84.8694C85.7723 85.4979 84.0375 86.8165 82.5852 88.5999C81.8654 89.4838 81.2603 90.4275 80.7641 91.3705L80.6634 91.565L80.653 91.5857L77.6098 88.5423L76.502 89.6501L81.1957 94.3438L81.6258 93.2177L81.7144 93.0045L81.8187 92.7715L81.8192 92.7706C81.9143 92.564 82.0248 92.3391 82.1506 92.0999C82.6017 91.2425 83.1514 90.3857 83.8 89.5892C85.1359 87.9487 86.7 86.7953 88.4919 86.3019L88.6847 86.2488Z"
        fill={colors.stroke}
      />
      <Mask id="path-18-inside-1_14694_4825" fill="white">
        <Path d="M82.5 78C76.1487 78 71 83.1487 71 89.5C71 95.8513 76.1487 101 82.5 101C88.8513 101 94 95.8513 94 89.5C94 83.1487 88.8513 78 82.5 78Z" />
      </Mask>
      <Path
        d="M82.5 76.6C75.3755 76.6 69.6 82.3755 69.6 89.5H72.4C72.4 83.9219 76.9219 79.4 82.5 79.4V76.6ZM69.6 89.5C69.6 96.6245 75.3755 102.4 82.5 102.4V99.6C76.9219 99.6 72.4 95.0781 72.4 89.5H69.6ZM82.5 102.4C89.6245 102.4 95.4 96.6245 95.4 89.5H92.6C92.6 95.0781 88.0781 99.6 82.5 99.6V102.4ZM95.4 89.5C95.4 82.3755 89.6245 76.6 82.5 76.6V79.4C88.0781 79.4 92.6 83.9219 92.6 89.5H95.4Z"
        fill={colors.stroke}
        mask="url(#path-18-inside-1_14694_4825)"
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14694_4825"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentTickIllustration;
