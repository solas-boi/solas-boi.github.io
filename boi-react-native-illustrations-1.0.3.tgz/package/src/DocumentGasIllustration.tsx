import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentGasIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM83 99.9999C87.4183 99.9999 91 95.9705 91 90.9999C91 88.1578 90.5 84.9998 89 83.4998C84.8334 84.7498 84.1389 84.2637 83.4445 83.7777C83.3056 83.6805 83.1667 83.5833 83 83.5C81.6337 82.6802 81.4342 81.1487 81.3047 80.154C81.1972 79.3287 81.1378 78.873 80.5 79.5001C76.5 82.5001 75 88.2959 75 90.9999C75 95.9705 78.5817 99.9999 83 99.9999Z"
        fill={colors.highlight}
      />
      <Path
        d="M75.5566 90.7938C75.5566 92.4689 75.9442 94.0072 76.7194 95.4087C77.4945 96.8099 78.5365 97.8611 79.8452 98.5623C79.678 98.2724 79.554 97.9713 79.473 97.6593C79.3919 97.3469 79.3513 97.0272 79.3513 96.7C79.3513 96.1279 79.4494 95.5856 79.6457 95.0733C79.8419 94.5612 80.1176 94.1003 80.4726 93.6908L83.1459 90.6534L85.8436 93.6908C86.1986 94.1003 86.4702 94.5612 86.6585 95.0733C86.8465 95.5856 86.9406 96.1279 86.9406 96.7C86.9406 97.0272 86.9 97.3469 86.8188 97.6593C86.7379 97.9713 86.6138 98.2724 86.4466 98.5623C87.7553 97.8611 88.7973 96.8099 89.5725 95.4087C90.3476 94.0072 90.7352 92.4689 90.7352 90.7938C90.7352 89.5785 90.5402 88.4301 90.1502 87.3485C89.7602 86.2669 89.1963 85.3007 88.4584 84.45C88.0368 84.766 87.5941 85.003 87.1303 85.161C86.6665 85.319 86.1922 85.398 85.7073 85.398C84.384 85.398 83.2428 84.8997 82.2836 83.9032C81.3244 82.9066 80.7791 81.6605 80.6478 80.1647C79.8256 80.9481 79.0983 81.7712 78.4659 82.6341C77.8334 83.4969 77.3011 84.3813 76.8689 85.2871C76.4368 86.193 76.11 87.1077 75.8887 88.0313C75.6673 88.955 75.5566 89.8758 75.5566 90.7938ZM83.1459 92.6896L81.3435 94.7313C81.1116 94.9987 80.9324 95.3025 80.8059 95.6428C80.6794 95.983 80.6162 96.3355 80.6162 96.7C80.6162 97.4778 80.8639 98.1462 81.3593 98.7053C81.8547 99.2643 82.4502 99.5438 83.1459 99.5438C83.8416 99.5438 84.4371 99.2643 84.9326 98.7053C85.428 98.1462 85.6757 97.4778 85.6757 96.7C85.6757 96.3112 85.6124 95.9527 85.4859 95.6245C85.3595 95.2964 85.1803 94.9987 84.9484 94.7313L83.1459 92.6896ZM81.881 77.3604V79.5646C81.881 80.8023 82.2504 81.8408 82.9891 82.6804C83.7278 83.5199 84.6338 83.9396 85.7073 83.9396C86.103 83.9396 86.4886 83.8625 86.864 83.7081C87.2393 83.554 87.594 83.332 87.9281 83.042L88.473 82.5487C89.5789 83.4947 90.4432 84.6969 91.066 86.1552C91.6887 87.6135 92.0001 89.1597 92.0001 90.7938C92.0001 93.6395 91.1414 96.0523 89.4241 98.0322C87.7069 100.012 85.6141 101.002 83.1459 101.002C80.6777 101.002 78.585 100.012 76.8677 98.0322C75.1504 96.0523 74.2917 93.6395 74.2917 90.7938C74.2917 88.294 74.9725 85.8494 76.3339 83.4602C77.6951 81.0707 79.5442 79.0374 81.881 77.3604Z"
        fill={colors.stroke}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 42H61.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 29.5H50.0315"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 52H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 62H65.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 72H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 82H67.354"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 92H64.034"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentGasIllustration;
