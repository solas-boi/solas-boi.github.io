import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const PoundIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_12478_2294)" />
      <Circle cx="60" cy="61" r="43.875" fill={colors.highlight} />
      <Path
        d="M62.0415 33.0993C66.8117 33.143 70.4277 34.5434 73.5611 37.5635L73.6483 37.6485L70.1612 41.079L70.1194 41.0376C67.6268 38.5939 65.5978 37.6405 61.8202 37.6405C54.6368 37.6405 50.5387 42.2646 50.5387 50.3625V58.4199H61.8706V62.2552H50.5283V82.3453H73.7759V86.9015H45.3297V62.2552H40.5898V58.4199H45.3297V49.6207C45.3297 39.6102 51.984 33.0983 61.8098 33.0983L62.0415 33.0993Z"
        fill={colors.fill}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M105 61.016C104.991 85.8621 84.8464 105.999 60 105.999C35.1364 105.979 14.9932 85.8136 15 60.9502C15.0272 36.1041 35.1865 15.9819 60.0329 16C84.8792 16.0182 105.009 36.1698 105 61.016ZM100.094 44.4065C93.3811 28.187 77.5566 17.6101 60.0027 17.6101C36.0702 17.6375 16.6683 37.0171 16.6133 60.9494C16.5931 78.5032 27.1518 94.3398 43.3637 101.071C59.5756 107.803 78.2463 104.103 90.6659 91.6977C103.086 79.2924 106.807 60.6261 100.094 44.4065Z"
        fill={colors.stroke}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M44.0508 49.3198C44.0508 38.7816 51.3586 31.8377 61.6326 31.7H61.9449C67.2895 31.7 72 33.5 75.6 37.5L70.1 42.8C68.6 41.3 65.7301 38.81 61.9556 38.81C55.0008 38.81 51.8008 44 51.8008 50.0832V57.3H63.0008L63.0004 63.4L51.8008 63.4V81.1768L75.0693 81.1772V88.2H44.0508V63.4L39.4004 63.4V57.3H44.0508V49.3198ZM73.5615 37.5635C70.4281 34.5434 66.8121 33.143 62.0419 33.0993L61.8102 33.0983C51.9843 33.0983 45.3301 39.6102 45.3301 49.6206V58.4199H40.5902V62.2552H45.3301V86.9015H73.7762V82.3452H50.5287V62.2552H61.871V58.4199H50.5391V50.3625C50.5391 42.2646 54.6372 37.6405 61.8206 37.6405C65.5982 37.6405 67.6272 38.5939 70.1197 41.0376L70.1616 41.079L73.6487 37.6485L73.5615 37.5635Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_12478_2294"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default PoundIllustration;
