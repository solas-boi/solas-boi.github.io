import Svg, {
  Circle,
  ClipPath,
  G,
  Path,
  Rect,
  Defs,
  LinearGradient,
  Mask,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const BankIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      viewBox="0 0 120 120"
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      fill="none"
      {...svgProps}
    >
      <G clipPath="url(#clip0_13934_4276)">
        <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_13934_4276)" />
        <Path d="M14.5 33L60 14L105.5 33H60H14.5Z" fill={colors.highlight} />
        <Path
          d="M14.5 39.5H24.5L23 43.8347L23.5 94.1653L24.5 98H14.5L15.5 94.1653L16 43.8347L14.5 39.5Z"
          fill={colors.fill}
        />
        <Path
          d="M41 39.5H51.1L49.6 43.8347L50.1 94.1653L51.5 98H41L42.1 94.1653L42.6 43.8347L41 39.5Z"
          fill={colors.fill}
        />
        <Path
          d="M69 39.5H79L77.5 43.8347L78 94.1653L79 98H68.5L69.8223 94.1653L70.5 43.8347L69 39.5Z"
          fill={colors.fill}
        />
        <Path
          d="M95.5 39.5H105.5L104 43.8347L104.5 94.1653L105.5 98H95.5L96.5 94.1653L97 43.8347L95.5 39.5Z"
          fill={colors.fill}
        />
        <Rect x="83.5" y="66" width="6" height="23" fill={colors.highlight} />
        <Rect x="29" y="66" width="6" height="23" fill={colors.highlight} />
        <Rect x="29" y="45" width="6" height="13" fill={colors.highlight} />
        <Rect
          x="53.6367"
          y="44.6792"
          width="12.727"
          height="13.884"
          rx="6.36349"
          fill={colors.highlight}
        />
        <Rect x="83.5" y="45" width="6" height="13" fill={colors.highlight} />
        <Rect
          x="11.869"
          y="101.835"
          width="96.2622"
          height="3.70239"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M77.9336 93.8516L79.0906 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M15.3454 93.9672L15.9572 43.4628H23.0428L23.6644 93.9672H15.3454Z"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M41.9684 93.9672L42.5802 43.4628H49.6658L50.2875 93.9672H41.9684Z"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M69.7184 93.9672L70.3302 43.4628H77.4158L78.0375 93.9672H69.7184Z"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M96.4684 93.9672L97.0802 43.4628H104.166L104.787 93.9672H96.4684Z"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M69.8347 93.8516L68.6777 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M104.545 93.8516L105.702 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M96.4461 93.8516L95.2891 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M50.166 93.8516L51.323 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M42.0672 93.8516L40.9102 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M49.5879 43.7866L51.3234 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M42.6457 43.7866L40.9102 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M22.9766 43.7866L24.7121 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M16.0343 43.7866L14.2988 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M77.3555 43.7866L79.091 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M70.4132 43.7866L68.6777 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M103.967 43.7866L105.702 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M97.0246 43.7866L95.2891 39.1586"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M23.5547 93.8516L24.7117 97.9011"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M15.4558 93.8516L14.2988 97.9011M14.2988 97.9011V101.372M14.2988 97.9011H105.702V101.372"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M12.7942 39.2743L10.0174 35.5719H109.982L107.205 39.2743H12.7942Z"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Rect
          x="14.1835"
          y="33.101"
          width="91.6342"
          height="2.4744"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M13 30.5L14 33L60 14L106 33L107 30.5L60 10.5L13 30.5Z"
          stroke={colors.stroke}
          strokeWidth="0.8"
        />
        <Path
          d="M66.9406 98.3638V72.447H53.0566V98.3638"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M59.998 97.901V72.447"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Mask id="path-38-inside-1_13934_4276" fill="white">
          <Path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M69.4582 73.6041C68.3983 69.4949 64.5803 66.4307 59.9989 66.4307C55.4175 66.4307 51.5996 69.4949 50.5396 73.6041H49.5859C50.6649 68.9669 54.9174 65.5051 59.9989 65.5051C65.0805 65.5051 69.3329 68.9669 70.4119 73.6041H69.4582Z"
          />
        </Mask>
        <Path
          d="M69.4582 73.6041L68.3379 73.8931L68.5618 74.7611H69.4582V73.6041ZM50.5396 73.6041V74.7611H51.436L51.6599 73.8931L50.5396 73.6041ZM49.5859 73.6041L48.459 73.3419L48.1288 74.7611H49.5859V73.6041ZM70.4119 73.6041V74.7611H71.869L71.5388 73.3419L70.4119 73.6041ZM70.5785 73.3151C69.3857 68.6905 65.1035 65.2737 59.9989 65.2737V67.5877C64.0572 67.5877 67.4109 70.2992 68.3379 73.8931L70.5785 73.3151ZM59.9989 65.2737C54.8944 65.2737 50.6122 68.6905 49.4193 73.3151L51.6599 73.8931C52.587 70.2992 55.9406 67.5877 59.9989 67.5877V65.2737ZM49.5859 74.7611H50.5396V72.4471H49.5859V74.7611ZM59.9989 64.3481C54.3864 64.3481 49.6615 68.1739 48.459 73.3419L50.7128 73.8663C51.6683 69.7598 55.4484 66.6621 59.9989 66.6621V64.3481ZM71.5388 73.3419C70.3363 68.1739 65.6115 64.3481 59.9989 64.3481V66.6621C64.5494 66.6621 68.3295 69.7598 69.285 73.8663L71.5388 73.3419ZM69.4582 74.7611H70.4119V72.4471H69.4582V74.7611Z"
          fill={colors.stroke}
          mask="url(#path-38-inside-1_13934_4276)"
        />
        <Rect
          x="29.2245"
          y="65.9679"
          width="6.01639"
          height="23.3714"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M29.3398 71.8687H35.1248M29.3398 77.6536H35.1248M29.3398 83.4386H35.1248"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Rect
          x="83.6034"
          y="65.9679"
          width="6.01639"
          height="23.3714"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M83.7188 71.8687H89.5037M83.7188 77.6536H89.5037M83.7188 83.4386H89.5037"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Rect
          x="29.2245"
          y="45.142"
          width="6.01639"
          height="12.9584"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M29 51.6958H35.5"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Rect
          x="54.0995"
          y="45.142"
          width="11.8014"
          height="12.9584"
          rx="5.90069"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M59.9998 58.5633V45.2578M54.2148 51.6213H59.9998H65.7848"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Rect
          x="83.6034"
          y="45.142"
          width="6.01639"
          height="12.9584"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
        <Path
          d="M83.7188 51.6211H89.5037"
          stroke={colors.stroke}
          strokeWidth="0.925598"
        />
      </G>
      <Defs>
        <LinearGradient
          id="paint0_linear_13934_4276"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
        <ClipPath id="clip0_13934_4276">
          <Rect width="120" height="120" fill={colors.highlight} />
        </ClipPath>
      </Defs>
    </Svg>
  );
};

export default BankIllustration;
