import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const PadlockIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M23 46L18 48L16 51.5V100.5L17.5 103.5L21.5 106H98L102.5 104L104.5 99.5V52.5L102 48L96.5 46H23ZM59.7885 60.8974C58.8733 60.9369 56.8995 61.0223 55 63.5001C54.1854 64.5802 53.7464 65.8972 53.75 67.2501C53.757 68.4626 54.1148 69.6473 54.7802 70.6609C55.4457 71.6746 56.3903 72.474 57.5 72.9626V88.5001C57.5 89.1631 57.7634 89.799 58.2323 90.2679C58.7011 90.7367 59.337 91.0001 60 91.0001C60.6631 91.0001 61.299 90.7367 61.7678 90.2679C62.2366 89.799 62.5 89.1631 62.5 88.5001V72.9626C63.2868 72.6586 64.0038 72.1984 64.608 71.6099C65.2122 71.0213 65.691 70.3166 66.0156 69.5381C66.3402 68.7596 66.5039 67.9235 66.4968 67.0801C66.4897 66.2366 66.3119 65.4034 65.9742 64.6305C65.6365 63.8576 65.1459 63.161 64.5318 62.5828C63.9178 62.0045 63.1931 61.5566 62.4013 61.2658C61.6095 60.9751 60.7671 60.8476 59.9248 60.8911C59.8824 60.8933 59.837 60.8953 59.7885 60.8974Z"
        fill={colors.fill}
      />
      <Path
        d="M38 31L38.5 26.5L40.5 21.5L43.5 17.5L46 15L49 13L52 12L55 11.5L57.5 11H60H62L64.5 11.5L67 12L69.5 13L72 14.5L74.5 16L76.5 18L78 19.5L79.5 22L80.5 24L81 26L81.5 27.5L82 29L82.5 32V35.5V46H75V32.5L74 29.5L73.5 27.5L72.5 26L71 24L69.5 22L67 20.5L65 19.5L62.5 18.5H60H57L54.5 19L51.5 20.5L48.5 23L46.5 26L45 31V46H38V31Z"
        fill={colors.highlight}
      />
      <Path
        d="M104.5 98.6188C104.5 102.694 101.013 106 96.7063 106H23.2938C18.9875 106 15.5 102.694 15.5 98.6188V53.3812C15.5 49.3062 18.9875 46 23.2938 46H96.7063C101.013 46 104.5 49.3062 104.5 53.3812V98.6188Z"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M37.5 34.75C37.5 35.2 37.5 35.5437 37.5 36V46"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M40 23C38 27 37.5 32 37.5 35"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M82.5 46V36C82.5 21 73.75 11 60 11C49.1188 11 43.4062 15.4875 40 22.9563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M75 45.9997V35.9997C75 25.9997 68.75 18.4997 59.9125 18.5372C48.75 18.5872 45 26.0372 45 35.9997V45.9997"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M98 102H22"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M55 63.5001C57 60.8911 59.0825 60.9346 59.9248 60.8911C60.7671 60.8476 61.6095 60.9751 62.4013 61.2658C63.1931 61.5566 63.9178 62.0045 64.5318 62.5828C65.1459 63.161 65.6365 63.8576 65.9742 64.6305C66.3119 65.4034 66.4897 66.2366 66.4968 67.0801C66.5039 67.9235 66.3402 68.7596 66.0156 69.5381C65.691 70.3166 65.2122 71.0213 64.608 71.6099C64.0038 72.1984 63.2868 72.6586 62.5 72.9626V88.5001C62.5 89.1631 62.2366 89.799 61.7678 90.2679C61.299 90.7367 60.6631 91.0001 60 91.0001C59.337 91.0001 58.7011 90.7367 58.2323 90.2679C57.7634 89.799 57.5 89.1631 57.5 88.5001V72.9626C56.3903 72.474 55.4457 71.6746 54.7802 70.6609C54.1148 69.6473 53.757 68.4626 53.75 67.2501C53.7464 65.8972 54.1854 64.5802 55 63.5001Z"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default PadlockIllustration;
