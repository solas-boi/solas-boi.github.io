import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentEuroIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14135_5068)" />
      <Path
        d="M20.5 5.5L22 5H80V23.5L81.5 25H100V107H20V7L20.5 5.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M86.5847 79.0977C84.4703 78.5724 82.246 78.7034 80.208 79.4735C78.1699 80.2435 76.4146 81.616 75.1759 83.4082C74.198 84.8231 73.5786 86.4465 73.361 88.1393L71.5011 88.1376C71.1006 88.1372 70.7758 88.4615 70.7754 88.8619C70.775 89.2623 71.0993 89.5872 71.4997 89.5876L73.2739 89.5892C73.2782 90.1527 73.327 90.7125 73.4185 91.2637L72.1261 91.2626C71.7256 91.2622 71.4008 91.5865 71.4004 91.9869C71.4 92.3873 71.7243 92.7122 72.1247 92.7126L73.7645 92.7141C74.0852 93.7371 74.5593 94.7122 75.1759 95.6043C76.4146 97.3965 78.1699 98.769 80.208 99.539C82.246 100.309 84.4703 100.44 86.5847 99.9148C88.6992 99.3894 90.6034 98.2325 92.0441 96.5982C92.3089 96.2978 92.28 95.8397 91.9796 95.5749C91.6793 95.3101 91.2211 95.339 90.9563 95.6393C89.7105 97.0528 88.0636 98.0532 86.2351 98.5076C84.4065 98.9619 82.483 98.8486 80.7204 98.1826C78.9579 97.5167 77.44 96.3298 76.3687 94.7798C75.9236 94.1358 75.5643 93.4419 75.2965 92.7155L85.8747 92.7251C86.2751 92.7254 86.6 92.4011 86.6004 92.0007C86.6008 91.6003 86.2765 91.2754 85.876 91.2751L74.8918 91.2651C74.7857 90.7156 74.7291 90.1553 74.7239 89.5905L85.2497 89.6001C85.6501 89.6004 85.975 89.2761 85.9754 88.8757C85.9758 88.4753 85.6515 88.1504 85.251 88.1501L74.8246 88.1406C75.0327 86.743 75.5584 85.405 76.3687 84.2327C77.44 82.6827 78.9579 81.4958 80.7204 80.8299C82.483 80.1639 84.4065 80.0506 86.2351 80.5049C88.0636 80.9593 89.7105 81.9597 90.9563 83.3732C91.2211 83.6735 91.6793 83.7024 91.9796 83.4376C92.28 83.1729 92.3089 82.7147 92.0441 82.4143C90.6034 80.78 88.6992 79.6231 86.5847 79.0977Z"
        fill={colors.stroke}
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14135_5068"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentEuroIllustration;
