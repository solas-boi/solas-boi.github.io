import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentPoundIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14135_5188)" />
      <Path
        d="M20.5 5.5L22 5H80V23.5L81.5 25H100V107H20V7L20.5 5.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M83.2558 78.05C81.2773 78.05 79.6305 78.6509 78.4837 79.8749C77.3434 81.092 76.7891 82.8278 76.7891 84.9195V87.6897C76.7819 87.7306 76.7781 87.7726 76.7781 87.8154V89.491H74.9584C74.5639 89.491 74.2441 89.8108 74.2441 90.2053C74.2441 90.5997 74.5639 90.9195 74.9584 90.9195H76.7781V99.0358C76.7781 99.4303 77.0979 99.75 77.4924 99.75H87.1864C87.5809 99.75 87.9007 99.4303 87.9007 99.0358C87.9007 98.6413 87.5809 98.3215 87.1864 98.3215H78.2066V90.9195H82.5602C82.9547 90.9195 83.2745 90.5997 83.2745 90.2053C83.2745 89.8108 82.9547 89.491 82.5602 89.491H78.2177V84.9195C78.2177 83.0681 78.7067 81.7263 79.5262 80.8516C80.3394 79.9837 81.5687 79.4786 83.2558 79.4786C84.3298 79.4786 85.0583 79.6608 85.6209 79.927C86.1903 80.1963 86.637 80.5727 87.1369 81.0462C87.4233 81.3174 87.8754 81.3051 88.1467 81.0187C88.418 80.7323 88.4057 80.2802 88.1192 80.0089C87.5923 79.5099 87.0122 79.0047 86.2318 78.6356C85.4446 78.2632 84.5005 78.05 83.2558 78.05Z"
        fill={colors.stroke}
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14135_5188"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentPoundIllustration;
