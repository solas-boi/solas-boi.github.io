import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
  Mask,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentQuestionIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14681_5147)" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM71 89.5C71 83.1487 76.1487 78 82.5 78C88.8513 78 94 83.1487 94 89.5C94 95.8513 88.8513 101 82.5 101C76.1487 101 71 95.8513 71 89.5Z"
        fill={colors.highlight}
      />
      <Mask id="path-3-inside-1_14681_5147" fill="white">
        <Path d="M82.5 78C76.1487 78 71 83.1487 71 89.5C71 95.8513 76.1487 101 82.5 101C88.8513 101 94 95.8513 94 89.5C94 83.1487 88.8513 78 82.5 78Z" />
      </Mask>
      <Path
        d="M82.5 76.6C75.3755 76.6 69.6 82.3755 69.6 89.5H72.4C72.4 83.9219 76.9219 79.4 82.5 79.4V76.6ZM69.6 89.5C69.6 96.6245 75.3755 102.4 82.5 102.4V99.6C76.9219 99.6 72.4 95.0781 72.4 89.5H69.6ZM82.5 102.4C89.6245 102.4 95.4 96.6245 95.4 89.5H92.6C92.6 95.0781 88.0781 99.6 82.5 99.6V102.4ZM95.4 89.5C95.4 82.3755 89.6245 76.6 82.5 76.6V79.4C88.0781 79.4 92.6 83.9219 92.6 89.5H95.4Z"
        fill={colors.stroke}
        mask="url(#path-3-inside-1_14681_5147)"
      />
      <Path
        d="M81.2031 91.5156V91.0234C81.2031 90.638 81.2474 90.3021 81.3359 90.0156C81.4245 89.7292 81.5729 89.4609 81.7812 89.2109C81.9896 88.9557 82.2708 88.6901 82.625 88.4141C82.9896 88.1276 83.2786 87.8802 83.4922 87.6719C83.7109 87.4635 83.8672 87.2552 83.9609 87.0469C84.0599 86.8333 84.1094 86.5859 84.1094 86.3047C84.1094 85.862 83.9583 85.526 83.6562 85.2969C83.3594 85.0625 82.9401 84.9453 82.3984 84.9453C81.9193 84.9453 81.4688 85.013 81.0469 85.1484C80.625 85.2839 80.2083 85.4531 79.7969 85.6562L79.1484 84.2812C79.6224 84.0208 80.1354 83.8125 80.6875 83.6562C81.2448 83.4948 81.8568 83.4141 82.5234 83.4141C83.5859 83.4141 84.4062 83.6719 84.9844 84.1875C85.5677 84.7031 85.8594 85.3828 85.8594 86.2266C85.8594 86.6901 85.7865 87.0885 85.6406 87.4219C85.4948 87.75 85.2786 88.0547 84.9922 88.3359C84.7109 88.612 84.3698 88.9036 83.9688 89.2109C83.6406 89.4714 83.388 89.6979 83.2109 89.8906C83.0391 90.0781 82.9193 90.2682 82.8516 90.4609C82.7891 90.6536 82.7578 90.8854 82.7578 91.1562V91.5156H81.2031ZM80.9062 94.0312C80.9062 93.6042 81.0156 93.3047 81.2344 93.1328C81.4583 92.9557 81.7318 92.8672 82.0547 92.8672C82.3672 92.8672 82.6354 92.9557 82.8594 93.1328C83.0833 93.3047 83.1953 93.6042 83.1953 94.0312C83.1953 94.4479 83.0833 94.75 82.8594 94.9375C82.6354 95.1198 82.3672 95.2109 82.0547 95.2109C81.7318 95.2109 81.4583 95.1198 81.2344 94.9375C81.0156 94.75 80.9062 94.4479 80.9062 94.0312Z"
        fill={colors.stroke}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14681_5147"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentQuestionIllustration;
