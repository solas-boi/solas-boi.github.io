import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentWaterIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM83 100.5C86.866 100.5 90.5 96.866 90.5 93C90.5 89.134 85.5 81.5 83 78.5C80.5 81 75.5 89.134 75.5 93C75.5 96.866 79.134 100.5 83 100.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 42H61.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 29.5H50.0315"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 52H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 62H65.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 72H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 82H67.354"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M83 77.875L83.5 77.5C83.4999 77.4999 83.5 77.5 83 77.875ZM82.5 77.5L83 77.875C82.5 77.5 82.5001 77.4999 82.5 77.5ZM82.5 77.5L82.4939 77.5082L82.477 77.5308L82.4128 77.6175C82.3569 77.6934 82.2752 77.8047 82.1715 77.9479C81.9642 78.2342 81.6686 78.648 81.3143 79.1599C80.6059 80.183 79.6605 81.6011 78.7141 83.1784C77.7688 84.7539 76.8159 86.4993 76.0974 88.1757C75.3856 89.8365 74.875 91.4945 74.875 92.875C74.875 95.5446 75.8823 97.5927 77.4285 98.9671C78.9632 100.331 80.9918 101 83 101C85.0082 101 87.0368 100.331 88.5715 98.9671C90.1177 97.5927 91.125 95.5446 91.125 92.875C91.125 91.4945 90.6144 89.8365 89.9026 88.1757C89.1841 86.4993 88.2312 84.7539 87.2859 83.1784C86.3395 81.6011 85.3941 80.183 84.6857 79.1599C84.3314 78.648 84.0358 78.2342 83.8285 77.9479C83.7248 77.8047 83.6431 77.6934 83.5872 77.6175L83.523 77.5308L83.5061 77.5082L83.5 77.5M82.5 77.5C82.618 77.3426 82.8033 77.25 83 77.25C83.1967 77.25 83.382 77.3426 83.5 77.5M83 78.9365C82.8192 79.189 82.5961 79.5044 82.342 79.8714C81.6441 80.8795 80.7145 82.2739 79.7859 83.8216C78.8562 85.3711 77.9341 87.0632 77.2463 88.6681C76.5519 90.2885 76.125 91.7555 76.125 92.875C76.125 95.2054 76.9927 96.9073 78.259 98.0329C79.5368 99.1687 81.2582 99.75 83 99.75C84.7418 99.75 86.4632 99.1687 87.741 98.0329C89.0073 96.9073 89.875 95.2054 89.875 92.875C89.875 91.7555 89.4481 90.2885 88.7537 88.6681C88.0659 87.0632 87.1438 85.3711 86.2141 83.8216C85.2855 82.2739 84.3559 80.8795 83.658 79.8714C83.4039 79.5044 83.1808 79.189 83 78.9365ZM83.3412 81.1014C83.6304 81.2898 83.7121 81.677 83.5237 81.9662C82.0188 84.276 80.782 86.7496 79.8371 89.3393C79.7188 89.6636 79.36 89.8305 79.0358 89.7122C78.7115 89.5939 78.5445 89.2351 78.6628 88.9108C79.6403 86.232 80.9197 83.6732 82.4763 81.2839C82.6647 80.9947 83.0519 80.913 83.3412 81.1014ZM87.8834 95.7386C88.0842 95.4578 88.0193 95.0674 87.7385 94.8666C87.4577 94.6659 87.0673 94.7307 86.8666 95.0115C86.389 95.6795 85.8044 96.264 85.1365 96.7416C84.8557 96.9424 84.7908 97.3328 84.9916 97.6136C85.1923 97.8944 85.5827 97.9592 85.8635 97.7585C86.6433 97.2009 87.3258 96.5184 87.8834 95.7386Z"
        fill={colors.stroke}
      />
      <Path
        d="M32.644 92H64.034"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentWaterIllustration;
