import Svg, {
  Circle,
  Path,
  Rect,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DevicesIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_12478_1982)" />
      <Rect
        x="80"
        y="48.5"
        width="32.5"
        height="42.5"
        fill={colors.highlight}
      />
      <Rect x="83" y="51.5" width="26.5" height="11.5" fill={colors.fill} />
      <Rect x="5" y="57.5" width="22.5" height="37.5" fill={colors.highlight} />
      <Rect x="7.5" y="61" width="17.5" height="11.5" fill={colors.fill} />
      <Path
        d="M20 28H100V45C100 45 79 44 78 45.5C77 47 77.5 75 77.5 75H27.5C27.5 75 27.5 62 27.5 56C27.3013 54.7745 27.1769 53.6769 26.8 53.3C26.1153 52.6153 24.9133 52.6607 24 52.5C21.7604 52.5 20 52.5 20 52.5V28Z"
        fill={colors.highlight}
      />
      <Rect x="23" y="30.5" width="74" height="12" fill={colors.fill} />
      <Path
        d="M77.5 83C77.7761 83 78 82.7761 78 82.5C78 82.2239 77.7761 82 77.5 82V83ZM77.5 82H27.5V83H77.5V82Z"
        fill={colors.stroke}
      />
      <Path
        d="M82.5 19.9999H103.6C104.105 19.9925 104.606 20.0846 105.075 20.2709C105.544 20.4572 105.972 20.7341 106.335 21.0858C106.697 21.4376 106.986 21.8572 107.186 22.3207C107.386 22.7842 107.493 23.2826 107.5 23.7874V44.4999"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M12.5 51.9999V23.7874C12.5073 23.2826 12.614 22.7842 12.814 22.3207C13.014 21.8572 13.3033 21.4376 13.6655 21.0858C14.0276 20.7341 14.4555 20.4572 14.9247 20.2709C15.3939 20.0846 15.8952 19.9925 16.4 19.9999H82.5"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M42.7509 27.5H22.5009C21.8379 27.5 20.5009 27.5 20 27.5001C20.0001 28 20.0009 29.337 20.0009 30V52"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M100 44.5V30C100 29.337 100 28 100 27.5001C99.5 27.5 98.163 27.5 97.5 27.5C76.0212 27.5 63.9788 27.5 42.5 27.5"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M23.0002 37.75V40.75C23.0002 41.0815 22.9998 42 23.0001 42.5C23.0001 42.5 23.9187 42.5 24.2502 42.5H48.2502C48.5818 42.5 97 42.5 97 42.5C97 42 97 41.0815 97 40.75V31.75C97 31.4185 97 31 97 30.5001C96.5 30.5 48.5818 30.5 48.2502 30.5H24.2502C23.9187 30.5 23.5002 30.5 23.0009 30.5C23.0002 31.0001 23.0002 31.4185 23.0002 31.75V38"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M23.0065 52.5003L23 45.7504C23 45.4188 23.0057 45.5001 23.0064 45C23.5057 45 24.0154 45.0001 24.3469 45.0001H48.25C48.5815 45.0001 80.5 45 81 45.0001C78 45 77.626 46.5 77.626 46.9999C77.5 48.6279 77.5 53.5241 77.5 56.0003C77.5 56.0003 48.5815 56.0003 48.25 56.0003H27.4992"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path d="M27.5 75H77.5" stroke={colors.stroke} strokeLinejoin="round" />
      <Path
        d="M64.9996 83V92.5L70.6246 97.5C71.3933 98.3375 71.1308 100 69.9996 100H49.9996C48.8683 100 48.6183 98.3375 49.3746 97.5L54.9996 92.5V83"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M85 100H80C79.337 100 78.7011 99.7366 78.2322 99.2678C77.7634 98.7989 77.5 98.163 77.5 97.5V47.5C77.5 46.837 77.7634 46.2011 78.2322 45.7322C78.7011 45.2634 79.337 45 80 45H112.5C113.163 45 113.799 45.2634 114.268 45.7322C114.737 46.2011 115 46.837 115 47.5V97.5C115 98.163 114.737 98.7989 114.268 99.2678C113.799 99.7366 113.163 100 112.5 100H84.5"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80.0002 55.75V89.75C80.0002 90.0815 79.9998 90.5 80.0001 91C80.0001 91 80.9187 91 81.2502 91H111.25C111.582 91 112.5 91 112.5 91C112.5 90.5 112.5 90.0815 112.5 89.75V49.75C112.5 49.4185 112.5 49 112.5 48.5001C112 48.5 111.582 48.5 111.25 48.5H81.2502C80.9187 48.5 80.5002 48.5 80.0009 48.5C80.0002 49.0001 80.0002 49.4185 80.0002 49.75V56"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M83.0002 58.75V61.75C83.0002 62.0815 82.9998 62.5 83.0001 63C83.0001 63 83.9187 63 84.2502 63H108.25C108.582 63 109.5 63 109.5 63C109.5 62.5 109.5 62.0815 109.5 61.75V52.75C109.5 52.4185 109.5 52 109.5 51.5001C109 51.5 108.582 51.5 108.25 51.5H84.2502C83.9187 51.5 83.5002 51.5 83.0009 51.5C83.0002 52.0001 83.0002 52.4185 83.0002 52.75V59"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M83.0002 72.75V71.75C83.0002 72.0815 82.9998 72.5 83.0001 73M83.0001 73C83.0001 73 83.9187 73 84.2502 73H108.25C108.582 73 109.5 73 109.5 73C109.5 72.5 109.5 72.0815 109.5 71.75V66.75C109.5 66.4185 109.5 66 109.5 65.5001C109 65.5 108.582 65.5 108.25 65.5H84.2502C83.9187 65.5 83.5002 65.5 83.0009 65.5C83.0002 66.0001 83.0002 66.4185 83.0002 66.75L83.0001 73Z"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M96.25 96.25C96.9404 96.25 97.5 95.6904 97.5 95C97.5 94.3096 96.9404 93.75 96.25 93.75C95.5596 93.75 95 94.3096 95 95C95 95.6904 95.5596 96.25 96.25 96.25Z"
        fill={colors.stroke}
      />
      <Path
        d="M5 95.5V57"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M27.5 57V95.5"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M5 95H27.5V97.5C27.5 98.163 27.2366 98.7989 26.7678 99.2678C26.2989 99.7366 25.663 100 25 100H7.5C6.83696 100 6.20107 99.7366 5.73223 99.2678C5.26339 98.7989 5 98.163 5 97.5V95Z"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M7.5 52.5H25C25.663 52.5 26.2989 52.7634 26.7678 53.2322C27.2366 53.7011 27.5 54.337 27.5 55V57.5H5V55C5 54.337 5.26339 53.7011 5.73223 53.2322C6.20107 52.7634 6.83696 52.5 7.5 52.5Z"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M7.50023 67.75V70.75C7.50023 71.0815 7.49983 71.5 7.50008 72C7.50008 72 8.41871 72 8.75023 72H23.7502C24.0818 72 25 72 25 72C25 71.5 25 71.0815 25 70.75V61.75C25 61.4185 25 61 25 60.5001C24.5 60.5 24.0818 60.5 23.7502 60.5H8.75023C8.41871 60.5 8.00023 60.5 7.50093 60.5C7.50022 61.0001 7.50023 61.4185 7.50023 61.75V68"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M7.50023 78.75C7.50023 79.0815 7.49983 79.5 7.50008 80C7.50008 80 8.41871 80 8.75023 80H23.7502C24.0818 80 25 80 25 80C25 79.5 25 79.0815 25 78.75V75.75C25 75.4185 25 75 25 74.5001C24.5 74.5 24.0818 74.5 23.7502 74.5H8.75023C8.41871 74.5 8.00023 74.5 7.50093 74.5C7.50022 75.0001 7.50023 75.4185 7.50023 75.75V79"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M12.5 97.5H20"
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_12478_1982"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DevicesIllustration;
