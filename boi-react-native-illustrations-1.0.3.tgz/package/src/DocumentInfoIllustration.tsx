import Svg, {
  Circle,
  Path,
  Rect,
  Defs,
  LinearGradient,
  Mask,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentInfoIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14694_4976)" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM82.5 100C88.299 100 93 95.299 93 89.5C93 83.701 88.299 79 82.5 79C76.701 79 72 83.701 72 89.5C72 95.299 76.701 100 82.5 100Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Mask id="path-17-inside-1_14694_4976" fill="white">
        <Path d="M82.5 78C76.1487 78 71 83.1487 71 89.5C71 95.8513 76.1487 101 82.5 101C88.8513 101 94 95.8513 94 89.5C94 83.1487 88.8513 78 82.5 78Z" />
      </Mask>
      <Path
        d="M82.5 76.6C75.3755 76.6 69.6 82.3755 69.6 89.5H72.4C72.4 83.9219 76.9219 79.4 82.5 79.4V76.6ZM69.6 89.5C69.6 96.6245 75.3755 102.4 82.5 102.4V99.6C76.9219 99.6 72.4 95.0781 72.4 89.5H69.6ZM82.5 102.4C89.6245 102.4 95.4 96.6245 95.4 89.5H92.6C92.6 95.0781 88.0781 99.6 82.5 99.6V102.4ZM95.4 89.5C95.4 82.3755 89.6245 76.6 82.5 76.6V79.4C88.0781 79.4 92.6 83.9219 92.6 89.5H95.4Z"
        fill={colors.stroke}
        mask="url(#path-17-inside-1_14694_4976)"
      />
      <Mask
        id="path-19-outside-2_14694_4976"
        maskUnits="userSpaceOnUse"
        x="80.2129"
        y="81.9993"
        width="4"
        height="14"
        fill="black"
      >
        <Rect
          fill={colors.highlight}
          x="80.2129"
          y="81.9993"
          width="4"
          height="14"
        />
        <Path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M82.4921 82.9993C82.7233 82.9993 82.9411 83.0608 83.1292 83.169C83.3163 83.2778 83.478 83.4353 83.5933 83.635C83.9264 84.2121 83.7608 84.9483 83.2126 85.327C82.7961 85.6148 82.2648 85.623 81.8486 85.3843C81.4343 85.143 81.1762 84.6791 81.2171 84.175C81.271 83.5108 81.8258 82.9993 82.4921 82.9993ZM83.7731 87.7179V94.2994V94.994V94.9951H81.2159V94.9939V94.2982V88.4136L81.2204 87.7179H83.7731Z"
        />
      </Mask>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M82.4921 82.9993C82.7233 82.9993 82.9411 83.0608 83.1292 83.169C83.3163 83.2778 83.478 83.4353 83.5933 83.635C83.9264 84.2121 83.7608 84.9483 83.2126 85.327C82.7961 85.6148 82.2648 85.623 81.8486 85.3843C81.4343 85.143 81.1762 84.6791 81.2171 84.175C81.271 83.5108 81.8258 82.9993 82.4921 82.9993ZM83.7731 87.7179V94.2994V94.994V94.9951H81.2159V94.9939V94.2982V88.4136L81.2204 87.7179H83.7731Z"
        fill={colors.stroke}
      />
      <Path
        d="M83.1292 83.169L83.1552 83.1243L83.155 83.1242L83.1292 83.169ZM83.5933 83.635L83.5485 83.6609L83.5933 83.635ZM83.2126 85.327L83.1832 85.2845L83.2126 85.327ZM81.8486 85.3843L81.8226 85.429L81.8229 85.4291L81.8486 85.3843ZM81.2171 84.175L81.2687 84.1792L81.2171 84.175ZM83.7731 87.7179H83.8248V87.6661H83.7731V87.7179ZM83.7731 94.9951V95.0468H83.8248V94.9951H83.7731ZM81.2159 94.9951H81.1641V95.0468H81.2159V94.9951ZM81.2159 88.4136L81.1641 88.4133V88.4136H81.2159ZM81.2204 87.7179V87.6661H81.169L81.1687 87.7175L81.2204 87.7179ZM83.155 83.1242C82.9592 83.0116 82.7326 82.9475 82.4921 82.9475V83.051C82.714 83.051 82.9229 83.1101 83.1034 83.2139L83.155 83.1242ZM83.6381 83.6091C83.5181 83.4014 83.3499 83.2375 83.1552 83.1243L83.1032 83.2137C83.2827 83.3181 83.4378 83.4692 83.5485 83.6609L83.6381 83.6091ZM83.242 85.3696C83.8124 84.9755 83.9847 84.2096 83.6381 83.6091L83.5485 83.6609C83.8682 84.2146 83.7092 84.921 83.1832 85.2845L83.242 85.3696ZM81.8229 85.4291C82.2559 85.6775 82.8086 85.669 83.242 85.3696L83.1832 85.2845C82.7836 85.5605 82.2738 85.5685 81.8743 85.3394L81.8229 85.4291ZM81.1656 84.1708C81.123 84.6954 81.3916 85.178 81.8226 85.429L81.8746 85.3396C81.477 85.108 81.2294 84.6629 81.2687 84.1792L81.1656 84.1708ZM82.4921 82.9475C81.7988 82.9475 81.2217 83.4798 81.1656 84.1708L81.2687 84.1792C81.3204 83.5419 81.8527 83.051 82.4921 83.051V82.9475ZM83.8248 94.2994V87.7179H83.7213V94.2994H83.8248ZM83.8248 94.994V94.2994H83.7213V94.994H83.8248ZM83.8248 94.9951V94.994H83.7213V94.9951H83.8248ZM81.2159 95.0468H83.7731V94.9434H81.2159V95.0468ZM81.1641 94.9939V94.9951H81.2676V94.9939H81.1641ZM81.1641 94.2982V94.9939H81.2676V94.2982H81.1641ZM81.1641 88.4136V94.2982H81.2676V88.4136H81.1641ZM81.1687 87.7175L81.1641 88.4133L81.2676 88.4139L81.2721 87.7182L81.1687 87.7175ZM83.7731 87.6661H81.2204V87.7696H83.7731V87.6661Z"
        fill={colors.stroke}
        mask="url(#path-19-outside-2_14694_4976)"
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14694_4976"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentInfoIllustration;
