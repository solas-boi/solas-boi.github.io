import { SvgProps } from "react-native-svg";
import { type CoreIllustration } from "@boi/components-core";

export type IllustrationProps = CoreIllustration.BaseProps & SvgProps;
