import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentContractTickIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14135_5433)" />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM73 86L77 93.5V99.5L78.5 101L82.5 99.5L86.5 101L88 99.5V93.5L92 86L87 78.5H78L73 86Z"
        fill={colors.highlight}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M37.8936 33.9298H38.1064C38.3053 31.279 48 31.5372 48 28.7817V26.4741C47.8484 26.4741 47.7985 26.4321 47.7767 26.5787C47.4591 28.7201 38.1088 28.962 38.1064 31.3046H37.8936C37.8912 28.962 28.5409 28.7201 28.2245 26.5787C28.2026 26.4321 28.1503 26.4741 28 26.4741V28.7817C28 31.5372 37.6947 31.279 37.8936 33.9298Z"
        fill={colors.stroke}
      />
      <Path
        d="M37.8936 27.6922H38.1064C38.3053 25.0426 48 25.3008 48 22.5441V20.2365C47.8481 20.2365 47.799 20.1947 47.7767 20.3411C47.4591 22.4837 38.1088 22.7244 38.1064 25.0682H37.8936C37.8912 22.7244 28.5409 22.4837 28.2245 20.3411C28.2022 20.1947 28.1506 20.2365 28 20.2365V22.5441C28 25.3008 37.6947 25.0426 37.8936 27.6922Z"
        fill={colors.stroke}
      />
      <Path
        d="M37.8936 21.4557L38.1064 21.4557C38.3053 18.8049 48 19.0631 48 16.3076L48 13.9999C47.8484 13.9999 47.7985 13.958 47.7767 14.1046C47.4591 16.246 38.1088 16.4879 38.1064 18.8305L37.8936 18.8305C37.8912 16.4879 28.5409 16.246 28.2245 14.1046C28.2026 13.958 28.1503 13.9999 28 13.9999L28 16.3076C28 19.0631 37.6947 18.8049 37.8936 21.4557Z"
        fill={colors.stroke}
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M82.4992 100.355L79.3072 101.46C79.1896 101.503 79.0745 101.531 78.962 101.545C78.8494 101.558 78.7368 101.565 78.6242 101.565C78.0677 101.565 77.5808 101.368 77.1636 100.975C76.7462 100.582 76.5375 100.083 76.5375 99.4781V93.4322L72.782 87.3788C72.6694 87.1966 72.5891 87.0132 72.5411 86.8285C72.4929 86.6438 72.4688 86.4579 72.4688 86.2708C72.4688 86.0838 72.4929 85.8979 72.5411 85.7132C72.5891 85.5284 72.6694 85.345 72.782 85.1629L76.6767 78.8538C76.8638 78.5324 77.1138 78.2889 77.4268 78.1233C77.7398 77.9578 78.081 77.875 78.4505 77.875H86.5479C86.9173 77.875 87.2585 77.9578 87.5716 78.1233C87.8846 78.2889 88.1346 78.5324 88.3217 78.8538L92.2164 85.1629C92.329 85.345 92.4093 85.5284 92.4573 85.7132C92.5055 85.8979 92.5296 86.0838 92.5296 86.2708C92.5296 86.4579 92.5055 86.6438 92.4573 86.8285C92.4093 87.0132 92.329 87.1966 92.2164 87.3788L88.4609 93.4322V99.4781C88.4609 100.083 88.2522 100.582 87.8347 100.975C87.4175 101.368 86.9307 101.565 86.3742 101.565C86.2616 101.565 86.149 101.558 86.0364 101.545C85.9238 101.531 85.8088 101.503 85.6912 101.46L82.4992 100.355ZM82.4992 98.9589L86.1259 100.174C86.3909 100.256 86.631 100.223 86.8463 100.074C87.0616 99.9253 87.1692 99.71 87.1692 99.4284V94.6667H77.8292V99.4284C77.8292 99.71 77.9368 99.9253 78.1521 100.074C78.3674 100.223 78.6075 100.256 78.8725 100.174L82.4992 98.9589ZM78.4505 93.375H86.5479C86.6805 93.375 86.8047 93.3418 86.9206 93.2755C87.0366 93.2094 87.136 93.1184 87.2186 93.0024L91.1385 86.6932C91.2212 86.5606 91.2625 86.4198 91.2625 86.2708C91.2625 86.1219 91.2212 85.9811 91.1385 85.8485L87.2186 79.5393C87.136 79.4233 87.0366 79.3322 86.9206 79.2661C86.8047 79.1998 86.6805 79.1667 86.5479 79.1667H78.4505C78.3178 79.1667 78.1936 79.1998 78.0778 79.2661C77.9618 79.3322 77.8624 79.4233 77.7798 79.5393L73.8599 85.8485C73.7772 85.9811 73.7359 86.1219 73.7359 86.2708C73.7359 86.4198 73.7772 86.5606 73.8599 86.6932L77.7798 93.0024C77.8624 93.1184 77.9618 93.2094 78.0778 93.2755C78.1936 93.3418 78.3178 93.375 78.4505 93.375ZM81.1429 88.8044L86.1682 83.7472C86.2889 83.6213 86.4359 83.5596 86.6089 83.5622C86.782 83.5646 86.9314 83.6263 87.0572 83.7472C87.1997 83.873 87.268 84.0266 87.2622 84.208C87.2564 84.3893 87.1905 84.5428 87.0646 84.6685L81.8734 89.8849C81.6646 90.0937 81.4211 90.1981 81.1429 90.1981C80.8648 90.1981 80.6213 90.0937 80.4125 89.8849L77.9412 87.4382C77.7987 87.3125 77.7274 87.1631 77.7274 86.99C77.7274 86.8169 77.7987 86.6592 77.9412 86.5169C78.0835 86.3744 78.2371 86.3031 78.402 86.3031C78.5667 86.3031 78.7202 86.3744 78.8625 86.5169L81.1429 88.8044Z"
        fill={colors.stroke}
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14135_5433"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentContractTickIllustration;
