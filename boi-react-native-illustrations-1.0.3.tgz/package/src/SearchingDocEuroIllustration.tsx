import Svg, {
  Circle,
  Path,
  Rect,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const SearchingDocEuroIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_12478_2803)" />
      <Rect
        x="80.168"
        y="85.4172"
        width="9.61514"
        height="23.6805"
        rx="2"
        transform="rotate(-26.8819 80.168 85.4172)"
        fill={colors.highlight}
      />
      <Circle
        cx="71"
        cy="57"
        r="18.25"
        fill={colors.highlight}
        stroke={colors.fill}
        strokeWidth="4.5"
      />
      <Path d="M77 15L85 23L93 30.5H77V15Z" fill={colors.fill} />
      <Path
        d="M26.668 26.6666V16.25C26.668 15.6974 26.8875 15.1675 27.2782 14.7768C27.6689 14.3861 28.1988 14.1666 28.7513 14.1666H76.668L93.3346 30.8333V46.9791"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M85.0013 105.833H28.7513C28.1988 105.833 27.6689 105.614 27.2782 105.223C26.8875 104.832 26.668 104.302 26.668 103.75V26.1666"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M93.332 66.7709V82.9167"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M76.668 14.1666V28.75C76.668 29.3025 76.8875 29.8324 77.2782 30.2231C77.6689 30.6138 78.1988 30.8333 78.7513 30.8333H93.3346"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35 62.0834H45.4167"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35 72.5H49.5833"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35 82.9167H71.9792"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35 93.3333L76.6667 93.3437"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35 32.3854L46.4583 32.3958"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35.5195 34.9896L46.9779 35"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M51.6648 38.4323C50.5454 39.7022 49.0658 40.6011 47.4229 41.0093C45.78 41.4175 44.0517 41.3156 42.4681 40.7173C40.8845 40.119 39.5207 39.0526 38.5582 37.66C37.5957 36.2674 37.0801 34.6147 37.0801 32.9218C37.0801 31.229 37.5957 29.5763 38.5582 28.1837C39.5207 26.7911 40.8845 25.7247 42.4681 25.1263C44.0517 24.528 45.78 24.4262 47.4229 24.8344C49.0658 25.2426 50.5454 26.1415 51.6648 27.4114"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M97.8918 102.932L92.4855 105.682C92.2975 105.778 92.0924 105.837 91.8819 105.853C91.6713 105.87 91.4596 105.845 91.2588 105.78C91.058 105.714 90.872 105.61 90.7116 105.473C90.5512 105.335 90.4195 105.168 90.3241 104.979L81.1001 86.8594C81.0038 86.671 80.9457 86.4655 80.9289 86.2546C80.9121 86.0437 80.9371 85.8315 81.0024 85.6303C81.0677 85.429 81.1721 85.2427 81.3095 85.0818C81.4469 84.9209 81.6147 84.7887 81.8032 84.6927L87.2095 81.9427C87.5895 81.7499 88.0304 81.7157 88.4356 81.8475C88.8408 81.9793 89.1771 82.2664 89.3709 82.6459L92.4959 88.7604L93.1887 90.1302L98.6053 100.771C98.7004 100.96 98.7574 101.165 98.773 101.376C98.7886 101.587 98.7625 101.799 98.6963 101.999C98.63 102.2 98.5249 102.386 98.3868 102.546C98.2488 102.706 98.0806 102.837 97.8918 102.932Z"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80.4336 75.3125L84.5065 83.3177"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M68.4936 36.4323C76 35.4894 81.9125 38.6199 85.6119 42.3881C89.3114 46.1564 91.4074 51.2112 91.46 56.4916C91.5126 61.772 89.5177 66.8675 85.894 70.7087C82.2703 74.5499 77.2996 76.8381 72.025 77.093C66.7505 77.3479 61.5822 75.5498 57.605 72.076C53.6278 68.6022 51.1507 63.7228 50.6938 58.462C50.2369 53.2011 51.8356 47.9677 55.1544 43.8602C58.4732 39.7528 63.2541 37.0905 68.4936 36.4323Z"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M71.0677 73.1407C80.028 73.1407 87.2917 65.8769 87.2917 56.9167C87.2917 47.9565 80.028 40.6927 71.0677 40.6927C62.1075 40.6927 54.8438 47.9565 54.8438 56.9167C54.8438 65.8769 62.1075 73.1407 71.0677 73.1407Z"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M87.5723 85.1824L93.0618 95.974"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M79.1348 47.5835C80.3436 48.6273 81.3362 49.8977 82.0566 51.3231"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M65.4746 45.9374C67.1917 45.0609 69.0907 44.5999 71.0185 44.5918C72.9464 44.5836 74.8492 45.0285 76.5736 45.8905"
        stroke={colors.stroke}
        strokeWidth="1.04167"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_12478_2803"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default SearchingDocEuroIllustration;
