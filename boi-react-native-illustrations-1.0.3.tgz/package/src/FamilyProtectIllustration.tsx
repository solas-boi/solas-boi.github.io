import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const FamilyProtectIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        d="M16.0027 33.4787L25.6816 29.6072L36.3283 24.7677L46.9751 17.0246L53.2664 12.1852L57.5 8.5H60L69.5 15.5L80.8513 22.8319L93.5 30L102.145 33.4787L102.5 35.5L102.145 45.0934L99.5 61L95.3696 74.1301L89.5 86.5L80.5 98L71.1724 106.07L59.5577 112.846L53 110L46.0072 106.07L39.5 100.5L33.4247 94.4558L29 88.5L24.7137 81.8732L21 73L17.9384 61.5475L15.7513 42.8457V34.8457L16.0027 33.4787Z"
        fill={colors.fill}
      />
      <Path
        d="M33.1732 36.5355L36.5 33.9998L40.9163 33.6318L49.6273 34.5997L52 36.4998L54.4668 39.4392L55 44.4998L54 50.4998L55.4347 52.0217L55 55.4998L52.5 57.9998L50.5 61.4998L47.6915 64.6043V71.3795L44.7879 73.3153H40.9163L38 72.9998L36.0769 71.3795L35.5 65.4998L33.5 62.4998L31.2374 58.797L29 56.4998L28 53.4998L28.3337 51.0538L29.5 50.4998L29 43.9998L29.5 38.9998L33.1732 36.5355Z"
        fill={colors.highlight}
      />
      <Path
        d="M64.1456 39.441L67.4999 36.5L70.9208 34.6016L76.4999 34.5L82.5355 34.6016L85.4999 36L88.3428 38.4731L90.4999 41.5L91.2465 45.2483V52.9915L94.1502 58.7988L94.4999 62.5L93.9999 66.5L91.9999 70.5L89.4999 73.5L82.9999 71.5H82.5355L78.9999 75L76.9999 76.5L75.4999 76L71.4999 72.3493L70.9999 70.5L63.4999 72L60.274 67.5098L59.3062 63.6382V60.1786L60.274 56.863L61.9999 53.5L62.2098 50.0878L62.4999 43.5L64.1456 39.441Z"
        fill={colors.highlight}
      />
      <Path
        d="M90.0626 28.2417C94.041 30.083 96.3793 31.743 100.863 33.0596C101.884 33.3649 102.581 34.3094 102.561 35.3684C101.779 93.441 65.9253 110.099 59.7622 112.426C59.2184 112.636 58.6173 112.636 58.0735 112.426C54.3337 111.014 38.964 104.327 27.2675 86.3334"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M27.4297 86.6297C19.7974 75.6582 15.4937 52.5607 15.2647 35.3784C15.2552 34.3194 15.9517 33.3654 16.9629 33.0696C38.0378 26.8397 52.3016 13.2255 57.3008 8.67476C58.2167 7.84474 59.6096 7.84474 60.5255 8.67476C64.1032 11.9376 77.854 21.9934 90.6 28.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M53.6514 50.5052C53.6514 50.5052 60.2743 33.633 42.8523 33.633C34.8348 32.4072 31.6694 37.6837 31.6694 37.6837C27.0975 38.6611 29.5657 50.5052 29.5657 50.5052C28.4227 50.2898 27.3956 52.0457 28.4227 55.1931C29.4497 58.3405 31.0731 58.1748 31.0731 58.1748C34.5683 67.385 41.6085 67.385 41.6085 67.385C41.6085 67.385 48.6487 67.385 52.144 58.1748C52.144 58.1748 53.7673 58.3405 54.7944 55.1931C55.8214 52.0457 54.7944 50.2898 53.6514 50.5052Z"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54.5 46.5002C53.5321 42.6287 48.0688 42.5702 42.8508 43.034C37.6162 43.5144 33.1733 40.4087 33.1733 40.4087C33.1733 40.4087 33.0449 45.124 29.5 49.0002"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M25.0433 73.5637C32.1001 70.5488 35.645 70.5488 35.645 70.5488"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M48.2292 70.7112C55.8479 71.6286 58.5001 74 58.5001 74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M59.5 74.0002C65.5 71.0002 70.489 70.5488 70.489 70.5488"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M47.7001 70.5C47.3688 72.3719 44.8718 73.5639 41.5919 73.5639C38.312 73.5639 35.7113 72.2056 35.7113 70.549V65"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M88.2228 52.6084C89.3161 52.4096 90.2934 54.0496 89.3161 56.9981C88.3388 59.9467 86.7816 59.7977 86.7816 59.7977C83.452 68.4115 76.7266 68.4115 76.7266 68.4115C76.7266 68.4115 70.0011 68.4115 66.6715 59.7977C66.6715 59.7977 65.1144 59.9633 64.1371 56.9981C63.1597 54.0496 64.1371 52.4096 65.2304 52.6084L66.0816 49.119L70.5001 48.2998"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70.465 48.3017C70.6141 48.3017 73.6123 47.9372 77.0082 46.6948C79.1948 45.8997 81.2986 44.8561 83.2698 43.5972C83.949 46.1482 85.854 47.5728 88.1234 47.7053V52.6086"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M91.2467 74.2841C87.3752 72.3484 82.5357 71.3805 82.5357 71.3805C82.5357 72.9708 76.6934 76.7275 76.6934 76.7275C76.6934 76.7275 71.111 72.8844 71.111 71.2941V66.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M89.5 73.5C95 68.5 95.8096 60.7754 92.977 56.5348C92.1322 55.2593 91.5689 53.8181 91.3536 52.3107C91.2873 51.8137 91.2376 51.3002 91.2376 50.7701V46.0159C91.2376 39.4727 85.9202 34.1553 79.377 34.1553H74.1093C67.5661 34.1553 62.2486 39.4727 62.2486 46.0159V50.7701C62.2486 52.8407 61.6357 54.8286 60.4927 56.5513C56.4177 64.4363 61.711 69.0514 63.5 72"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M47.6917 70.4131C47.6917 70.4131 47.6917 66.8339 47.6917 65"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M82.5356 71.3812C82.5356 71.3812 82.5356 67.8344 82.5356 66.0005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50.5 81.4998L52 77.4998L54.9347 75.2521L59.7741 74.2842L64.5 75.9998L67 78.9998L67.5 81.9998L68.5 85.9998V88.4998L65.5 92.9998L62.9543 95.4395V100.279L61.5 101L56.8704 101.385L54.6581 100.279V95.4395L51.5 90.4998L49.8187 89.2174L49.1273 85.7606L50.5 84.9998V81.4998Z"
        fill={colors.highlight}
      />
      <Path
        d="M62.678 99.0269C62.678 100.17 61.6722 101.386 58.8064 101.386C55.9406 101.386 54.9348 100.186 54.9348 99.0269"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M59.0438 74.2266C69.0657 74.2266 67.7074 85.1595 67.7074 85.1595C68.5191 85.0105 69.2645 86.2363 68.5356 88.456C67.8068 90.6757 66.6306 90.5598 66.6306 90.5598C64.1127 97.0367 59.0438 97.0368 59.0438 97.0368H59.0769C59.0769 97.0368 54.008 97.0367 51.4901 90.5598C51.4901 90.5598 50.314 90.6757 49.5851 88.456C48.8562 86.2363 49.5851 85.0105 50.4134 85.1595C50.4134 85.1595 49.055 74.2266 59.0769 74.2266"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5173 82.0277C64.9829 79.2445 61.71 79.124 61.71 79.124C61.71 79.124 59.6464 80.4233 55.9027 80.092C52.1589 79.7607 50.5 82.0002 50.5 82.0002"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M47.5 103C50.6183 101.064 54.9348 100.418 54.9348 100.418"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M62.5 100.5C66.0749 100.879 70 103 70 103"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54.9348 100.418C54.9348 100.418 54.9348 97.3339 54.9348 95.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M62.6779 100.418C62.6779 100.418 62.6779 97.8339 62.6779 96"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M18.5 36.5005C18.5 36.5005 27.6453 33.2316 38.6457 27.0004C49.6462 20.7691 54.4608 16.0041 54.4608 16.0041"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Path
        d="M99.4576 20.7491C99.7837 20.7245 100.071 20.9478 100.134 21.2597L100.146 21.3394L100.617 27.5909C100.644 27.9436 100.379 28.2511 100.026 28.2777C99.6995 28.3023 99.412 28.079 99.3488 27.7671L99.3378 27.6874L98.8661 21.436C98.8394 21.0833 99.1043 20.7758 99.4576 20.7491Z"
        fill={colors.stroke}
      />
      <Path
        d="M112.994 31.0201C113.327 30.9022 113.694 31.0772 113.812 31.411C113.921 31.7169 113.783 32.05 113.503 32.1942L113.423 32.2287L107.51 34.3174C107.176 34.4352 106.81 34.2602 106.691 33.9265C106.582 33.6205 106.72 33.2874 107.001 33.1432L107.081 33.1087L112.994 31.0201Z"
        fill={colors.stroke}
      />
      <Path
        d="M112.366 40.4003C112.688 40.5486 112.828 40.9297 112.68 41.2515C112.544 41.5464 112.214 41.6891 111.912 41.5966L111.83 41.5655L106.137 38.9364C105.816 38.788 105.675 38.4069 105.823 38.0852C105.959 37.7902 106.29 37.6475 106.592 37.74L106.673 37.7712L112.366 40.4003Z"
        fill={colors.stroke}
      />
      <Path
        d="M107.49 23.7396C107.68 23.4415 108.077 23.3544 108.376 23.5449C108.651 23.7208 108.747 24.0718 108.611 24.3592L108.571 24.4296L105.196 29.7101C105.005 30.0082 104.609 30.0953 104.31 29.9048C104.035 29.7289 103.939 29.3779 104.075 29.0905L104.114 29.0201L107.49 23.7396Z"
        fill={colors.stroke}
      />
      <Path
        d="M18.5 36.5C18.5 36.5 19 61.5 26.5 78"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Path
        d="M90.4935 78.347C90.4935 78.347 85.4999 88.9998 75.9999 98C71.0671 102.673 67.8868 104.92 65.969 106L59.4273 109.285C59.1571 109.421 58.8399 109.427 58.5647 109.302L53.5 107"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default FamilyProtectIllustration;
