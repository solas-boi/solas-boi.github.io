import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const PhoneWarningIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_12658_3896)" />
      <Path
        d="M38 18C38 15.7909 39.7909 14 42 14H80C82.2091 14 84 15.7909 84 18V23H38V18Z"
        fill={colors.fill}
      />
      <Path
        d="M38 102C38 104.209 39.7909 106 42 106H80C82.2091 106 84 104.209 84 102V97H38V102Z"
        fill={colors.fill}
      />
      <Circle cx="61.1992" cy="101.5" r="2.5" fill={colors.highlight} />
      <Path
        d="M53.9951 17.6375H67.8695V18.5661H53.9951V17.6375Z"
        fill={colors.stroke}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M61.2145 104.365C62.3427 104.369 63.3621 103.693 63.7964 102.652C64.2307 101.61 63.994 100.41 63.1971 99.6114C62.4001 98.8128 61.2001 98.5738 60.158 99.0061C59.1159 99.4383 58.4374 100.456 58.4396 101.585C58.4396 103.118 59.6811 104.362 61.2145 104.365ZM61.2142 99.7275C61.9659 99.7253 62.6447 100.176 62.9339 100.87C63.2231 101.564 63.0655 102.364 62.5348 102.896C62.0041 103.428 61.2049 103.588 60.5102 103.301C59.8156 103.014 59.3625 102.336 59.3625 101.585C59.3611 101.093 59.5555 100.62 59.9029 100.272C60.2504 99.9233 60.7222 99.7275 61.2142 99.7275Z"
        fill={colors.stroke}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M42.8065 13H79.1698C80.7154 12.9986 82.1981 13.6009 83.2915 14.6745C84.3849 15.748 84.9992 17.2046 84.9992 18.7236V23H85.0033V97.1666H84.9992V100.971C84.9932 104.113 82.411 106.663 79.214 106.684H42.8286C39.6143 106.687 37.0053 104.13 36.9992 100.971V97.0555H36.9965V48.1051H35.8398V37.2452H36.9965V35.7459H35.8398V24.8686H36.9965V22.8947H36.9992V18.7236C36.9992 15.5689 39.5966 13.009 42.8065 13ZM37.9197 96.4911H84.1792V23.2036H37.9197V96.4911ZM37.9219 22.275H84.0377L84.0598 18.7236C84.0598 16.0796 81.8821 13.9346 79.1918 13.9286H42.8064C41.511 13.9257 40.2678 14.4298 39.3513 15.3295C38.4348 16.2292 37.9204 17.4505 37.9219 18.7236V22.275ZM36.9972 25.8528H36.7691L36.7528 34.756H36.9972V25.8528ZM36.7691 38.212H36.9972V47.1153H36.7528L36.7691 38.212ZM37.9434 97.4197H84.0592V100.971C84.0592 103.615 81.8815 105.76 79.1912 105.766H42.8279C40.1385 105.76 37.9624 103.614 37.9655 100.971L37.9434 97.4197Z"
        fill={colors.stroke}
      />
      <Path
        d="M61.0043 46C53.1599 46 46.8008 52.3591 46.8008 60.2035C46.8008 68.0478 53.1599 74.4069 61.0043 74.4069C68.8486 74.4069 75.2077 68.0478 75.2077 60.2035C75.2077 52.3591 68.8486 46 61.0043 46Z"
        fill={colors.highlight}
      />
      <Path
        d="M61.0043 45.575C52.9252 45.575 46.3758 52.1244 46.3758 60.2035H47.2258C47.2258 52.5938 53.3946 46.425 61.0043 46.425V45.575ZM46.3758 60.2035C46.3758 68.2825 52.9252 74.8319 61.0043 74.8319V73.9819C53.3946 73.9819 47.2258 67.8131 47.2258 60.2035H46.3758ZM61.0043 74.8319C69.0833 74.8319 75.6327 68.2825 75.6327 60.2035H74.7827C74.7827 67.8131 68.6139 73.9819 61.0043 73.9819V74.8319ZM75.6327 60.2035C75.6327 52.1244 69.0833 45.575 61.0043 45.575V46.425C68.6139 46.425 74.7827 52.5938 74.7827 60.2035H75.6327Z"
        fill={colors.stroke}
      />
      <Path
        d="M62 53V64C60.9497 64 60.9497 64 60 64L60 53.0001C60.7771 52.9999 61.2951 53.0001 62 53Z"
        fill={colors.stroke}
      />
      <Path
        d="M61 68C61.5523 68 62 67.5523 62 67C62 66.4477 61.5523 66 61 66C60.4477 66 60 66.4477 60 67C60 67.5523 60.4477 68 61 68Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_12658_3896"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default PhoneWarningIllustration;
