import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentContractIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14135_5305)" />
      <Path
        d="M20.5 5.5L22 5H80V23.5L81.5 25H100V107H20V7L20.5 5.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M37.8936 33.9298H38.1064C38.3053 31.279 48 31.5372 48 28.7817V26.4741C47.8484 26.4741 47.7985 26.4321 47.7767 26.5787C47.4591 28.7201 38.1088 28.962 38.1064 31.3046H37.8936C37.8912 28.962 28.5409 28.7201 28.2245 26.5787C28.2026 26.4321 28.1503 26.4741 28 26.4741V28.7817C28 31.5372 37.6947 31.279 37.8936 33.9298Z"
        fill={colors.stroke}
      />
      <Path
        d="M37.8936 27.6922H38.1064C38.3053 25.0426 48 25.3008 48 22.5441V20.2365C47.8481 20.2365 47.799 20.1947 47.7767 20.3411C47.4591 22.4837 38.1088 22.7244 38.1064 25.0682H37.8936C37.8912 22.7244 28.5409 22.4837 28.2245 20.3411C28.2022 20.1947 28.1506 20.2365 28 20.2365V22.5441C28 25.3008 37.6947 25.0426 37.8936 27.6922Z"
        fill={colors.stroke}
      />
      <Path
        d="M37.8936 21.4557L38.1064 21.4557C38.3053 18.8049 48 19.0631 48 16.3076L48 13.9999C47.8484 13.9999 47.7985 13.958 47.7767 14.1046C47.4591 16.246 38.1088 16.4879 38.1064 18.8305L37.8936 18.8305C37.8912 16.4879 28.5409 16.246 28.2245 14.1046C28.2026 13.958 28.1503 13.9999 28 13.9999L28 16.3076C28 19.0631 37.6947 18.8049 37.8936 21.4557Z"
        fill={colors.stroke}
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H87.357"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 92H70.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14135_5305"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentContractIllustration;
