import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Mask,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentIssueIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14681_4998)" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM82.5 100C88.299 100 93 95.299 93 89.5C93 83.701 88.299 79 82.5 79C76.701 79 72 83.701 72 89.5C72 95.299 76.701 100 82.5 100Z"
        fill={colors.highlight}
      />
      <Mask id="path-3-inside-1_14681_4998" fill="white">
        <Path d="M82.5 78C76.1487 78 71 83.1487 71 89.5C71 95.8513 76.1487 101 82.5 101C88.8513 101 94 95.8513 94 89.5C94 83.1487 88.8513 78 82.5 78Z" />
      </Mask>
      <Path
        d="M82.5 76.6C75.3755 76.6 69.6 82.3755 69.6 89.5H72.4C72.4 83.9219 76.9219 79.4 82.5 79.4V76.6ZM69.6 89.5C69.6 96.6245 75.3755 102.4 82.5 102.4V99.6C76.9219 99.6 72.4 95.0781 72.4 89.5H69.6ZM82.5 102.4C89.6245 102.4 95.4 96.6245 95.4 89.5H92.6C92.6 95.0781 88.0781 99.6 82.5 99.6V102.4ZM95.4 89.5C95.4 82.3755 89.6245 76.6 82.5 76.6V79.4C88.0781 79.4 92.6 83.9219 92.6 89.5H95.4Z"
        fill={colors.stroke}
        mask="url(#path-3-inside-1_14681_4998)"
      />
      <Path
        d="M83.3068 83.6677V92.574C82.4565 92.574 82.4565 92.574 81.6875 92.574L81.6875 83.6678C82.3167 83.6677 82.7361 83.6678 83.3068 83.6677Z"
        fill={colors.stroke}
      />
      <Path
        d="M82.4972 95.8127C82.9443 95.8127 83.3068 95.4502 83.3068 95.003C83.3068 94.5559 82.9443 94.1934 82.4972 94.1934C82.05 94.1934 81.6875 94.5559 81.6875 95.003C81.6875 95.4502 82.05 95.8127 82.4972 95.8127Z"
        fill={colors.stroke}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14681_4998"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentIssueIllustration;
