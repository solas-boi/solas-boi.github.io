import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const ClosedEnvelopeIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_13934_4894)" />
      <Path
        d="M22.4004 37L56.9004 62L59.9004 60L62.9004 62L98.4004 37V84H22.4004V37Z"
        fill={colors.fill}
      />
      <Path
        d="M22.5952 36.7135C22.3925 36.7135 22.1892 36.7608 22.0022 36.857C21.5718 37.0794 21.3008 36.0165 21.3008 36.5001V83.5072C21.3008 84.2218 21.8804 84.8 22.5952 84.8H97.4064C98.1212 84.8 98.7008 84.2218 98.7008 83.5072V36.0001C98.7008 35.5165 98.4299 37.0794 97.9993 36.857C97.8124 36.7608 97.6091 36.7135 97.4064 36.7135C97.1418 36.7135 96.8786 36.7938 96.6554 36.9531L62.9698 61.5001L60.0004 59.7781L57.0008 61.5001L23.5008 37.5001C23.2774 37.3408 22.8597 36.7135 22.5952 36.7135ZM97.4064 38.0064V83.5072H22.5952V38.0064L56.8274 62.5225L60.0004 60.5315L62.9698 62.5225L97.4064 38.0064Z"
        fill={colors.stroke}
      />
      <Path
        d="M60.0004 59.4646C59.7671 59.4646 59.5339 59.5263 59.3274 59.6526L21.9217 82.4037C21.4265 82.705 21.1923 83.2977 21.349 83.8573C21.5055 84.414 22.0147 84.8 22.5952 84.8H97.4064C97.9867 84.8 98.4961 84.4141 98.6525 83.8559C98.8093 83.2977 98.5751 82.705 98.08 82.4037L60.6736 59.6526C60.4669 59.5263 60.2335 59.4646 60.0004 59.4646ZM60.0004 60.756L97.4064 83.5072H22.5952L60.0004 60.756Z"
        fill={colors.stroke}
      />
      <Path d="M22 36H98V36.5L60 64L22 36.5V36Z" fill={colors.highlight} />
      <Path
        d="M59.9078 64.4519C60.171 64.4519 60.4341 64.3714 60.6592 64.2119L98.0642 37.5491C98.5226 37.2215 98.7012 36.7812 98.7012 36.0351C98.7012 35.5 98.3764 35.2 98.0012 35.2L22.5019 35.1999C21.9389 35.1999 21.4789 35.5649 21.3074 36.1008C21.3074 37.0127 21.2922 37.2215 21.7507 37.5491L59.1566 64.2119C59.3813 64.3714 59.6446 64.4519 59.9078 64.4519ZM59.9078 63.1573L22.5019 36.4945L97.313 36.4945L59.9078 63.1573Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_13934_4894"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default ClosedEnvelopeIllustration;
