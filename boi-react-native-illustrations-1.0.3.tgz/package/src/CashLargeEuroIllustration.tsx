import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const CashLargeEuroIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14063_4588)" />
      <Path
        d="M30 40.5L44.5 33L88 56.5V88L73.5 96.5L73 65.5L30 40.5Z"
        fill={colors.fill}
      />
      <Path
        d="M19.5 56.5L39 46L65 60.5L45 72L19.5 56.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M54 38.5L74 27.5L100 41L80 52.5L54 38.5Z"
        fill={colors.highlight}
      />
      <Path
        d="M88.2125 56.5812L73.1437 65.3312L30 40.625L44.375 33.125L88.2125 56.5812Z"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M65.1941 60.8188L45.1566 72.2375L19.4941 56.7688L39.0001 46"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54.2246 38.175L74.0684 27.5437L100.25 40.825L80.4996 51.9999"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M45.9562 33.9812L72.6062 20L115 41.025L46.3562 80.8875L5 55.4688L31.5687 41.525"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M38.6007 62.4624L44.3757 59.2499M36.107 60.9812L41.8757 57.7937M50.2507 59.0437C50.5695 61.3687 47.5257 63.0749 43.457 62.8374C39.3882 62.5999 35.8445 60.4812 35.532 58.1624C35.2195 55.8437 38.2382 54.1999 42.307 54.4499"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeMiterlimit="10"
        strokeLinecap="round"
      />
      <Path
        d="M73.8153 43.2715L79.3016 40.2196M71.4463 41.8643L76.9266 38.8362M84.8828 40.0237C85.1857 42.2324 82.2941 43.8533 78.4288 43.6277C74.5635 43.4021 71.1969 41.3893 70.9 39.1865C70.6031 36.9837 73.471 35.4221 77.3363 35.6596"
        stroke={colors.stroke}
        strokeWidth="1.1875"
        strokeMiterlimit="10"
        strokeLinecap="round"
      />
      <Path
        d="M73.1 84.7313L46.3562 100.262L5 74.8438"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M115 60.3999L88.25 75.9374"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.1 79.8938L46.3562 95.4187L5 70"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M115 55.5L88.2559 71.0875"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.0937 70.2062L46.3562 85.7312L5 60.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M114.999 45.8687L88.2305 61.4187"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.1187 75.0375L46.3562 90.575L5 65.1562"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M115 50.7124L88.2188 66.2687"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.1 94.3938L46.3562 109.919L5 84.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M115 70.5L88.2559 86.0875"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.1187 89.5412L46.3562 105.079L5 79.6599"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M115 65.7124L88.2188 81.2687"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M73.1445 65.3313V96.6063L88.2133 87.8125V56.5813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14063_4588"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default CashLargeEuroIllustration;
