import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const CalendarIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      viewBox="0 0 120 120"
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      fill="none"
      {...svgProps}
    >
      <Circle
        cx={60}
        cy={60}
        r={60}
        fill="url(#calendar_illustration_svg__a)"
      />
      <Path fill={colors.fill} d="M20 48h79v12H20z" />
      <Path
        fill={colors.highlight}
        fillRule="evenodd"
        d="M23 22a3 3 0 0 0-3 3v23h79V25a3 3 0 0 0-3-3H85v6.5s1 0 1 1.5-2 2-2 2-1.5 0-1.5-1.5 1-1.5 1-1.5v-7H73v6.5s1 0 1 1.5c0 1.533-1.127 1.938-2 2.022V32s-1.5 0-1.5-1.5 1-1.5 1-1.5v-7H61v6.5s1 0 1 1.5c0 2.5-3 2-3 2s-1.5 0-1.5-1.5 1-1.5 1-1.5v-7H48v6.5s1 0 1 1.5c0 2.5-3 2-3 2s-1 0-1-1.5.75-1.5.75-1.5l-.25-7H36v6.5s1 0 1 1.5c0 2.5-3 2-3 2s-1-.5-1-2 1-1.5 1-1.5V22H23Z"
        clipRule="evenodd"
      />
      <Path
        stroke={colors.stroke}
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M85.5 22.29h11.593c1.087 0 1.975.891 1.975 1.978V95.4a1.98 1.98 0 0 1-1.975 1.975H22.014a1.982 1.982 0 0 1-1.977-1.975V24.268c0-1.087.89-1.977 1.977-1.977H33.89M20.037 35.634V24.761"
      />
      <Path
        stroke={colors.stroke}
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M99.068 24.76v73.11a1.98 1.98 0 0 1-1.975 1.975H22.014a1.982 1.982 0 0 1-1.977-1.975V38.06"
      />
      <Path
        stroke={colors.stroke}
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M99.068 55.75v45.01c0 .855-.7 1.555-1.555 1.555H21.594a1.56 1.56 0 0 1-1.557-1.555V69.055M73.402 22.29h9.88m-22.724 0h10.87m-23.71 0h10.865m-22.48 0h9.88m.411 25.692v49.65m13.172-49.65v49.65m-26.344-49.65v49.65m39.516-49.65v49.65m13.172-49.65v49.65m-65.848-49.65h79.275M20.062 85.028h79.275M20.062 72.68h79.275M20.062 60.332h79.275"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M49.687 40.574h19.757m-25.684-2.47h31.613m7.91-17.79v8.891m1.974-8.892v8.892m-1.975-.725c-.592.343-.987.98-.987 1.713a1.974 1.974 0 1 0 3.95 0 1.98 1.98 0 0 0-.988-1.713"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M85.258 29.205a.989.989 0 0 1-1.975 0m0-8.892a.989.989 0 0 1 1.975 0m-51.368 0-.002 8.892m1.977-8.892-.002 8.892m-1.975-.725a1.976 1.976 0 1 0 1.977 0"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M35.862 29.205a.989.989 0 0 1-1.975 0m-.002-8.892a.989.989 0 0 1 1.977 0m9.88 0-.003 8.892m1.977-8.892-.002 8.892m-1.975-.725a1.976 1.976 0 1 0 1.977 0"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M47.717 29.205a.988.988 0 0 1-1.975 0m0-8.892a.987.987 0 1 1 1.975 0m10.867 0-.002 8.892m1.977-8.892-.002 8.892m-1.975-.725a1.976 1.976 0 1 0 1.977 0"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M60.56 29.205a.989.989 0 0 1-1.978 0m0-8.892a.989.989 0 0 1 1.977 0m10.867 0v8.892m1.975-8.892-.002 8.892m-1.973-.725c-.592.343-.987.98-.987 1.712a1.974 1.974 0 1 0 3.95 0 1.98 1.98 0 0 0-.988-1.712"
      />
      <Path
        stroke={colors.stroke}
        strokeLinecap="round"
        strokeMiterlimit={10}
        strokeWidth={0.988}
        d="M73.403 29.205a.989.989 0 0 1-1.975 0m0-8.892a.987.987 0 1 1 1.975 0"
      />
      <Defs>
        <LinearGradient
          id="calendar_illustration_svg__a"
          x1={60}
          x2={60}
          y1={0}
          y2={120}
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset={1} stopColor={colors.fill} stopOpacity={0} />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default CalendarIllustration;
