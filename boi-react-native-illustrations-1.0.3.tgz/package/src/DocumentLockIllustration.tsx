import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentLockIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM79.5 86.5H76.5L76 87V99.5L76.5 100H91.5L92 99.5V87L91.5 86.5H88.5H79.5Z"
        fill={colors.highlight}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M75.6069 100.396C76.0116 100.801 76.5017 101.003 77.0771 101.003H90.9229C91.4983 101.003 91.9884 100.801 92.3931 100.396C92.7977 99.9916 93 99.5015 93 98.9261V87.6517C93 87.0764 92.7977 86.5863 92.3931 86.1815C91.9884 85.7769 91.4983 85.5746 90.9229 85.5746H89.1429V83.0032C89.1429 81.5707 88.6438 80.3555 87.6456 79.3576C86.6477 78.3594 85.4325 77.8604 84 77.8604C82.5675 77.8604 81.3523 78.3594 80.3544 79.3576C79.3562 80.3555 78.8571 81.5707 78.8571 83.0032V85.5746H77.0771C76.5017 85.5746 76.0116 85.7769 75.6069 86.1815C75.2023 86.5863 75 87.0764 75 87.6517V98.9261C75 99.5015 75.2023 99.9916 75.6069 100.396ZM91.4919 99.4951C91.3434 99.6434 91.1537 99.7175 90.9229 99.7175H77.0771C76.8463 99.7175 76.6566 99.6434 76.5081 99.4951C76.3599 99.3466 76.2857 99.1569 76.2857 98.9261V87.6517C76.2857 87.4209 76.3599 87.2313 76.5081 87.0828C76.6566 86.9345 76.8463 86.8604 77.0771 86.8604H90.9229C91.1537 86.8604 91.3434 86.9345 91.4919 87.0828C91.6401 87.2313 91.7143 87.4209 91.7143 87.6517V98.9261C91.7143 99.1569 91.6401 99.3466 91.4919 99.4951ZM87.8571 83.0032V85.5746H80.1429V83.0032C80.1429 81.9318 80.5179 81.0211 81.2679 80.2711C82.0179 79.5211 82.9286 79.1461 84 79.1461C85.0714 79.1461 85.9821 79.5211 86.7321 80.2711C87.4821 81.0211 87.8571 81.9318 87.8571 83.0032ZM85.4226 93.4148C85.2834 93.5558 85.133 93.6714 84.9713 93.7614C84.9901 93.8379 85 93.9179 85 94.0002V96.0002C85 96.5525 84.5523 97.0002 84 97.0002C83.4477 97.0002 83 96.5525 83 96.0002V94.0002C83 93.9167 83.0102 93.8355 83.0295 93.758C82.8713 93.6702 82.7234 93.5584 82.5859 93.4229C82.1953 93.0376 82 92.5662 82 92.0085C82 91.4506 82.1926 90.9764 82.5778 90.5861C82.9628 90.1955 83.4342 90.0002 83.9922 90.0002C84.5498 90.0002 85.0239 90.1929 85.4145 90.5781C85.8048 90.963 86 91.4344 86 91.9924C86 92.5501 85.8075 93.0242 85.4226 93.4148Z"
        fill={colors.stroke}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 42H61.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 29.5H50.0315"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 52H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 62H65.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 72H45.0003"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 82H67.354"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.644 92H64.034"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentLockIllustration;
