import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const HomeProtectIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Path
        d="M16.0027 33.4787L25.6816 29.6072L36.3283 24.7677L46.9751 17.0246L53.2664 12.1852L57.5 8.5H60L69.5 15.5L80.8513 22.8319L93.5 30L102.145 33.4787L102.5 35.5L102.145 45.0934L99.5 61L95.3696 74.1301L89.5 86.5L80.5 98L71.1724 106.07L59.5577 112.846L53 110L46.0072 106.07L39.5 100.5L33.4247 94.4558L29 88.5L24.7137 81.8732L21 73L17.9384 61.5475L15.7513 42.8457V34.8457L16.0027 33.4787Z"
        fill={colors.fill}
      />
      <Path
        d="M60.0008 40.5361L78.4487 50.2725H76.9113L77.4238 79.4817H71.2745V70.2577H65.1252V79.4817H43.0902V50.2725H42.0653L43.6026 49.2476L45.14 48.2228V43.0983H48.727L48.7911 46.6214L51.033 45.4043L60.0008 40.5361Z"
        fill={colors.highlight}
      />
      <Path
        d="M90.0626 28.2417C94.041 30.083 96.3793 31.743 100.863 33.0596C101.884 33.3649 102.581 34.3094 102.561 35.3684C101.779 93.441 65.9253 110.099 59.7622 112.426C59.2184 112.636 58.6173 112.636 58.0735 112.426C54.3337 111.014 38.964 104.327 27.2675 86.3334"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M27.4297 86.6297C19.7974 75.6582 15.4937 52.5607 15.2647 35.3784C15.2552 34.3194 15.9517 33.3654 16.9629 33.0696C38.0378 26.8397 52.3016 13.2255 57.3008 8.67476C58.2167 7.84474 59.6096 7.84474 60.5255 8.67476C64.1032 11.9376 77.854 21.9934 90.6 28.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M18.5 36.5005C18.5 36.5005 27.6453 33.2316 38.6457 27.0004C49.6462 20.7691 54.4608 16.0041 54.4608 16.0041"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Path
        d="M99.4576 20.7491C99.7837 20.7245 100.071 20.9478 100.134 21.2597L100.146 21.3394L100.617 27.5909C100.644 27.9436 100.379 28.2511 100.026 28.2777C99.6995 28.3023 99.412 28.079 99.3488 27.7671L99.3378 27.6874L98.8661 21.436C98.8394 21.0833 99.1043 20.7758 99.4576 20.7491Z"
        fill={colors.stroke}
      />
      <Path
        d="M112.994 31.0201C113.327 30.9022 113.694 31.0772 113.812 31.411C113.921 31.7169 113.783 32.05 113.503 32.1942L113.423 32.2287L107.51 34.3174C107.176 34.4352 106.81 34.2602 106.691 33.9265C106.582 33.6205 106.72 33.2874 107.001 33.1432L107.081 33.1087L112.994 31.0201Z"
        fill={colors.stroke}
      />
      <Path
        d="M112.366 40.4003C112.688 40.5486 112.828 40.9297 112.68 41.2515C112.544 41.5464 112.214 41.6891 111.912 41.5966L111.83 41.5655L106.137 38.9364C105.816 38.788 105.675 38.4069 105.823 38.0852C105.959 37.7902 106.29 37.6475 106.592 37.74L106.673 37.7712L112.366 40.4003Z"
        fill={colors.stroke}
      />
      <Path
        d="M107.49 23.7396C107.68 23.4415 108.077 23.3544 108.376 23.5449C108.651 23.7208 108.747 24.0718 108.611 24.3592L108.571 24.4296L105.196 29.7101C105.005 30.0082 104.609 30.0953 104.31 29.9048C104.035 29.7289 103.939 29.3779 104.075 29.0905L104.114 29.0201L107.49 23.7396Z"
        fill={colors.stroke}
      />
      <Path
        d="M18.5 36.5C18.5 36.5 19 61.5 26.5 78"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Path
        d="M90.4935 78.347C90.4935 78.347 85.4999 88.9998 75.9999 98C71.0671 102.673 67.8868 104.92 65.969 106L59.4273 109.285C59.1571 109.421 58.8399 109.427 58.5647 109.302L53.5 107"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M40.1672 51.3082H42.0979V80.1943H65.8795V70.69H70.495V80.1943H77.8201V51.3082H79.7508L79.7674 49.9493L59.9797 39.0942L49.481 44.8639V41.8287H43.9292V47.915L40.1672 49.9824V51.3082ZM43.5149 78.7857V51.3082H76.4031V78.7857H71.912V69.273H64.4709V78.7857H43.5149ZM76.6601 49.8914H43.2912L59.9798 40.7184L76.6601 49.8914ZM45.3462 43.2456V47.1071L48.0641 45.6238V43.2456H45.3462Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default HomeProtectIllustration;
