import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentCarIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14694_5107)" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M22 5L20.5 5.5L20 7V107H100V25H81.5L80 23.5V5H22ZM82 88H74V95H92V88H83.5H82Z"
        fill={colors.highlight}
      />
      <Path
        d="M74.5384 95.75V97.4806C74.5384 97.6944 74.4634 97.876 74.3134 98.0256C74.1632 98.1752 73.9808 98.25 73.7663 98.25C73.5519 98.25 73.3706 98.1752 73.2225 98.0256C73.0742 97.876 73 97.6944 73 97.4806V88.7837C73 88.67 73.0065 88.5561 73.0194 88.4422C73.0321 88.3284 73.0574 88.2152 73.0953 88.1025L75.2284 82.1009C75.3614 81.7007 75.6023 81.3755 75.9513 81.1253C76.3002 80.8751 76.6906 80.75 77.1225 80.75H88.8775C89.3094 80.75 89.6998 80.8751 90.0487 81.1253C90.3977 81.3755 90.6386 81.7007 90.7716 82.1009L92.9047 88.1025C92.9426 88.2152 92.9679 88.3284 92.9806 88.4422C92.9935 88.5561 93 88.67 93 88.7837V97.4806C93 97.6944 92.9249 97.876 92.7747 98.0256C92.6247 98.1752 92.4424 98.25 92.2278 98.25C92.0134 98.25 91.8321 98.1752 91.6838 98.0256C91.5356 97.876 91.4616 97.6944 91.4616 97.4806V95.75H74.5384ZM74.7694 87.1922H91.2306L89.5819 82.5047C89.5177 82.3445 89.4215 82.2203 89.2931 82.1322C89.165 82.0441 89.0128 82 88.8366 82H77.1634C76.9872 82 76.835 82.0441 76.7069 82.1322C76.5785 82.2203 76.4823 82.3445 76.4181 82.5047L74.7694 87.1922ZM77.2844 92.8653C77.6733 92.8653 78.002 92.7293 78.2703 92.4572C78.5389 92.1849 78.6731 91.8544 78.6731 91.4656C78.6731 91.0767 78.537 90.748 78.2647 90.4797C77.9926 90.2111 77.6621 90.0769 77.2731 90.0769C76.8844 90.0769 76.5557 90.213 76.2872 90.4853C76.0189 90.7574 75.8847 91.0879 75.8847 91.4769C75.8847 91.8656 76.0207 92.1943 76.2928 92.4628C76.5651 92.7311 76.8956 92.8653 77.2844 92.8653ZM88.7269 92.8653C89.1156 92.8653 89.4443 92.7293 89.7128 92.4572C89.9811 92.1849 90.1153 91.8544 90.1153 91.4656C90.1153 91.0767 89.9793 90.748 89.7072 90.4797C89.4349 90.2111 89.1044 90.0769 88.7156 90.0769C88.3267 90.0769 87.998 90.213 87.7297 90.4853C87.4611 90.7574 87.3269 91.0879 87.3269 91.4769C87.3269 91.8656 87.463 92.1943 87.7353 92.4628C88.0074 92.7311 88.3379 92.8653 88.7269 92.8653ZM74.25 94.5H91.75V88.4422H74.25V94.5Z"
        fill={colors.stroke}
      />
      <Path
        d="M20 107H100V113.5L98.5 115H21.5L20 113.5V107Z"
        fill={colors.fill}
      />
      <Path
        d="M75 115H22.5C21.837 115 21.2011 114.737 20.7322 114.268C20.2634 113.799 20 113.163 20 112.5V32.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 33V7.5C20 6.83696 20.2634 6.20107 20.7322 5.73223C21.2011 5.26339 21.837 5 22.5 5H80L100 25V112.5C100 113.163 99.7366 113.799 99.2678 114.268C98.7989 114.737 98.163 115 97.5 115H74"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M80 5V22.5C80 23.163 80.2634 23.7989 80.7322 24.2678C81.2011 24.7366 81.837 25 82.5 25H99.2813"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M67.5 42H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 42H61.5005"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 29.5H50.032"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 52H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 52H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70 62H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 62H65.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M50 72H87.3563"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 72H45.0008"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 82H67.3545"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M32.6445 92H64.0345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M20 107H100"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14694_5107"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentCarIllustration;
