import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const TickIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14191_5496)" />
      <Circle cx="60" cy="61.6875" r="43.875" fill={colors.highlight} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M105 61.7035C104.991 86.5496 84.8464 106.687 60 106.687C35.1364 106.666 14.9932 86.5011 15 61.6377C15.0272 36.7916 35.1865 16.6694 60.0329 16.6875C84.8792 16.7057 105.009 36.8573 105 61.7035ZM100.094 45.094C93.3811 28.8745 77.5566 18.2976 60.0027 18.2976C36.0702 18.325 16.6683 37.7046 16.6133 61.6369C16.5931 79.1907 27.1518 95.0273 43.3637 101.759C59.5756 108.49 78.2463 104.791 90.6659 92.3852C103.086 79.9799 106.807 61.3136 100.094 45.094Z"
        fill={colors.stroke}
      />
      <Path
        d="M40.5 58L51 68.5L79.5 40L86.5 47L51 82.5L33.5 64.5L40.5 58Z"
        fill={colors.fill}
      />
      <Path
        d="M78.7129 54.925L86.5254 47.0687M86.5254 47.0687L79.4566 40L51.1254 68.3312L40.4691 57.675L33.4004 64.75L51.0754 82.425L51.1254 82.3812L51.1691 82.425L86.5254 47.0687Z"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14191_5496"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default TickIllustration;
