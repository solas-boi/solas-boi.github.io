import { useId } from "react";
import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const ChatBubbleIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  const backgroundId = useId();

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill={`url(#${backgroundId})`} />
      <Circle cx="60" cy="61.6875" r="43.875" fill={colors.highlight} />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M105 61.7035C104.991 86.5496 84.8464 106.687 60 106.687C35.1364 106.666 14.9932 86.5011 15 61.6377C15.0272 36.7916 35.1865 16.6694 60.0329 16.6875C84.8792 16.7057 105.009 36.8573 105 61.7035ZM100.094 45.094C93.3811 28.8745 77.5566 18.2976 60.0027 18.2976C36.0702 18.325 16.6683 37.7046 16.6133 61.6369C16.5931 79.1907 27.1518 95.0273 43.3637 101.759C59.5756 108.49 78.2463 104.791 90.6659 92.3852C103.086 79.9799 106.807 61.3136 100.094 45.094Z"
        fill={colors.stroke}
      />
      <Path
        d="M95.6265 86.1686C95.6265 86.1686 105.856 99.1908 102.746 102.407C99.6355 105.622 85.968 96.1346 85.968 96.1346L95.6265 86.1686Z"
        fill={colors.highlight}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M95.1555 86.9551L87 95.5002C87 95.5002 87 95.5002 85.8545 96.6003C89.6809 99.1286 100.444 105.884 103.293 102.897C106.141 99.9104 99.0995 89.2055 96.4 85.5002C95.2626 86.6905 95.1555 86.9551 95.1555 86.9551ZM95.1555 86.9551L87 95.5002C87.2502 95.6643 87.5177 95.8395 87.8148 96.0296C89.2822 96.9689 91.2632 98.1764 93.3402 99.267C95.4358 100.367 97.5464 101.305 99.2908 101.755C99.953 101.926 101.53 102.399 102.121 101.779C102.712 101.159 102.169 99.6055 101.967 98.9501C101.437 97.2281 100.405 95.1631 99.21 93.1208C98.026 91.0967 96.73 89.174 95.7251 87.7518C95.5218 87.4639 95.3308 87.1973 95.1555 86.9551Z"
        fill={colors.stroke}
      />
      <Path
        d="M47 61.5C47 65.0899 43.866 68 40 68C36.134 68 33 65.0899 33 61.5C33 57.9101 36.134 55 40 55C43.866 55 47 57.9101 47 61.5Z"
        fill={colors.fill}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M40 66.5C43.1442 66.5 45.5 64.1587 45.5 61.5C45.5 58.8413 43.1442 56.5 40 56.5C36.8558 56.5 34.5 58.8413 34.5 61.5C34.5 64.1587 36.8558 66.5 40 66.5ZM40 68C43.866 68 47 65.0899 47 61.5C47 57.9101 43.866 55 40 55C36.134 55 33 57.9101 33 61.5C33 65.0899 36.134 68 40 68Z"
        fill={colors.stroke}
      />
      <Path
        d="M67 61.5C67 65.0899 63.866 68 60 68C56.134 68 53 65.0899 53 61.5C53 57.9101 56.134 55 60 55C63.866 55 67 57.9101 67 61.5Z"
        fill={colors.fill}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M60 66.5C63.1442 66.5 65.5 64.1587 65.5 61.5C65.5 58.8413 63.1442 56.5 60 56.5C56.8558 56.5 54.5 58.8413 54.5 61.5C54.5 64.1587 56.8558 66.5 60 66.5ZM60 68C63.866 68 67 65.0899 67 61.5C67 57.9101 63.866 55 60 55C56.134 55 53 57.9101 53 61.5C53 65.0899 56.134 68 60 68Z"
        fill={colors.stroke}
      />
      <Path
        d="M87 61.5C87 65.0899 83.866 68 80 68C76.134 68 73 65.0899 73 61.5C73 57.9101 76.134 55 80 55C83.866 55 87 57.9101 87 61.5Z"
        fill={colors.fill}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M80 66.5C83.1442 66.5 85.5 64.1587 85.5 61.5C85.5 58.8413 83.1442 56.5 80 56.5C76.8558 56.5 74.5 58.8413 74.5 61.5C74.5 64.1587 76.8558 66.5 80 66.5ZM80 68C83.866 68 87 65.0899 87 61.5C87 57.9101 83.866 55 80 55C76.134 55 73 57.9101 73 61.5C73 65.0899 76.134 68 80 68Z"
        fill={colors.stroke}
      />
      <Defs>
        <LinearGradient
          id={backgroundId}
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default ChatBubbleIllustration;
