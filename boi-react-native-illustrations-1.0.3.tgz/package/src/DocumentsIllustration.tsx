import Svg, {
  Circle,
  Path,
  Defs,
  LinearGradient,
  Stop,
} from "react-native-svg";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CoreIllustration } from "@boi/components-core";

import type { IllustrationProps } from "./Illustration.types";

const DocumentsIllustration = (props: IllustrationProps) => {
  const { colorPalette = "hueB", ...svgProps } = props;

  const { tokens } = useDesignTokens();
  const { illustration } = tokens;

  const colors = illustration[colorPalette];

  return (
    <Svg
      width={CoreIllustration.DEFAULT_WIDTH}
      height={CoreIllustration.DEFAULT_HEIGHT}
      viewBox="0 0 120 120"
      fill="none"
      {...svgProps}
    >
      <Circle cx="60" cy="60" r="60" fill="url(#paint0_linear_14135_4850)" />
      <Path
        d="M21.5352 13.9744L22.995 13.367L76.5003 8.5L77.5003 25L78.5003 26.5L80.0003 27L96.5003 25.5L102.5 102L28.5003 108L21.1453 15.5067L21.5352 13.9744Z"
        fill={colors.highlight}
      />
      <Path
        d="M28.6436 107.869L102.526 101.888L103.001 107.869L101.422 110.001L30.846 115.72L29.1583 114.349L28.6436 107.869Z"
        fill={colors.fill}
      />
      <Path
        d="M82.0003 111.5L31.769 115.646C31.108 115.699 30.4533 115.486 29.9488 115.056C29.4443 114.626 29.1314 114.013 29.0789 113.352L22.7441 35.603"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M22.8285 36.1257L21.2052 15.6901C21.1527 15.0291 21.3649 14.3744 21.7952 13.8699C22.2254 13.3654 22.8385 13.0525 23.4994 13L76.4994 8.49994L96.3066 25.0929L102.839 107.334C102.892 107.995 102.68 108.65 102.249 109.154C101.819 109.659 101.206 109.971 100.545 110.024L81.1063 111.568"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M76.7868 8.7395L77.5005 24.5001C77.553 25.161 77.8659 25.7741 78.3704 26.2043C78.8749 26.6345 79.5296 26.8468 80.1906 26.7943L96.2055 25.4654"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M70.8477 41.312L85.661 40.1353"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M36.0999 44.0721L64.1621 41.8395"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M35.1113 31.6113L52.4442 30.2345"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M33.5459 19.3112C33.66 20.8216 33.3265 22.1393 32.5454 23.2645C31.7644 24.3897 31.5765 24.937 30.3313 25.031C29.0862 25.1251 28.8155 24.6124 27.869 23.6177C26.9226 22.623 26.3923 21.3704 26.2782 19.8601L25.6207 11.1541C25.5411 10.0995 25.7735 9.18025 26.3181 8.39652C26.8627 7.61294 27.1607 7.21922 28.0335 7.15331C28.9062 7.08739 29.2561 7.43218 29.9122 8.12508C30.5684 8.81813 30.9363 9.69199 31.016 10.7467C30.1273 10.8138 30.5384 10.7634 30.1894 10.7898C30.1277 10.0152 29.8576 9.37474 29.3791 8.86834C28.9008 8.36192 28.7536 8.10176 28.1088 8.15047C27.4689 8.19879 27.3594 8.48159 26.9589 9.0609C26.5584 9.64004 26.3874 10.317 26.4459 11.0918L27.1034 19.7978C27.1932 21.0292 27.6253 22.0518 28.3996 22.8656C29.1737 23.6794 29.2444 24.1103 30.2618 24.0334C31.2646 23.9577 31.2592 23.5219 31.8957 22.6016C32.5323 21.6812 32.8073 20.6052 32.7208 19.3735L32.5499 17.1107C32.5392 16.9694 32.5698 16.848 32.6417 16.7465C32.7137 16.645 32.8082 16.5898 32.9252 16.5809C33.0423 16.5721 33.1438 16.6125 33.23 16.7021C33.316 16.7917 33.3644 16.9071 33.375 17.0484L33.5459 19.3112Z"
        fill={colors.stroke}
        stroke={colors.stroke}
      />
      <Path
        d="M25.5 111L25.2271 111.055C24.0456 111.291 22.9248 110.436 22.8398 109.234L16.2077 15.4377C16.0924 13.8065 17.3047 12.3835 18.9335 12.238L72 7.5"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M22 108V108C20.9578 108.26 19.9336 107.515 19.8615 106.443L13.6973 14.9287C13.5876 13.301 14.7988 11.884 16.4237 11.739L69.5 7"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M29 113.778L28.1118 113.847C27.0094 113.931 26.0475 113.105 25.9644 112.003L18.7223 15.9481C18.599 14.313 19.8114 12.8818 21.4446 12.7347L74 8"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M54.1934 52.6663L86.4518 50.1039"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M36.8926 54.0408L49.21 53.0624"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M74.9219 61.0513L87.2431 60.0726"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M37.6836 64.0093L69.9382 61.4472"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M55.7773 72.6035L88.0357 70.0411"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M38.4766 73.9778L50.794 72.9994"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M39.2676 83.9465L88.8215 80.0103"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M40.0605 93.915L77.3307 90.9546"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M28.644 107.869L102.001 102"
        stroke={colors.stroke}
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Defs>
        <LinearGradient
          id="paint0_linear_14135_4850"
          x1="60"
          y1="0"
          x2="60"
          y2="120"
          gradientUnits="userSpaceOnUse"
        >
          <Stop stopColor={colors.fill} />
          <Stop offset="1" stopColor={colors.fill} stopOpacity="0" />
        </LinearGradient>
      </Defs>
    </Svg>
  );
};

export default DocumentsIllustration;
