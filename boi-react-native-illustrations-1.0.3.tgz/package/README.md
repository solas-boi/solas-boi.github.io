# React Native illustrations

React Native SVG illustration components.

## Installation

```console
npm i react-native-svg
npm i @boi/react-native-design-tokens
npm i @boi/react-native-illustrations
```

## Usage

### Initialising design tokens

Render the `DesignTokensProvider` at the root of your application:

```jsx
import {
  DesignTokensProvider,
  BOI_THEME_TOKENS,
} from "@boi/react-native-design-tokens";

import Layout from "./Layout";

export default function App() {
  return (
    <DesignTokensProvider themeTokens={BOI_THEME_TOKENS}>
      <Layout />
    </DesignTokensProvider>
  );
}
```

### Using an illustration

Then render the illustration with an optional `colorPalette` prop:

```jsx
import { CalculatorIllustration } from "@boi/react-native-illustrations";

export default function Layout() {
  return <CalculatorIllustration colorPalette="hueA" />;
}
```
