# React illustrations

React SVG illustration components.

## Installation

```console
npm i @boi/react-design-tokens
npm i @boi/react-illustrations
```

## Usage

### Initialising design tokens

Render the `DesignTokensProvider` at the root of your application:

```jsx
import {
  DesignTokensProvider,
  DesignTokensGlobalStyles,
  BOI_THEME_TOKENS,
} from "@boi/react-design-tokens";

import Layout from "./Layout";

export default function App() {
  return (
    <DesignTokensProvider themeTokens={BOI_THEME_TOKENS}>
      <DesignTokensGlobalStyles />
      <Layout />
    </DesignTokensProvider>
  );
}
```

### Using an illustration

Then render the illustration with an optional `colorPalette` prop:

```jsx
import { CalculatorIllustration } from "@boi/react-illustrations";

export default function Layout() {
  return <CalculatorIllustration colorPalette="hueA" />;
}
```
