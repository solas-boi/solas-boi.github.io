import type { Meta, StoryObj } from "@storybook/react";
import {
  CoreAlert,
  ALERT_SEVERITIES,
  HEADING_LEVELS,
} from "@boi/components-core";

import Alert from "./Alert";
import { Link } from "../Link";

const meta = {
  title: "Feedback/Alert",
  component: Alert,
  argTypes: {
    severity: {
      control: { type: "select" },
      options: ALERT_SEVERITIES,
    },
    heading: { control: { type: "text" } },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
    withRole: { control: { type: "boolean" } },
    children: { control: { disable: true } },
  },
  args: {
    severity: CoreAlert.DEFAULT_SEVERITY,
    heading: "Alert heading",
    headingLevel: CoreAlert.DEFAULT_HEADING_LEVEL,
    withRole: true,
  },
} satisfies Meta<typeof Alert>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Dismissible: Story = {
  args: {
    onRequestClose: () => {},
  },
};

export const WithBody: Story = {
  args: {
    children: (
      <>
        <Alert.Typography>Body message text and</Alert.Typography>
        <Link onPress={() => {}}>text link if necessary</Link>
      </>
    ),
  },
};

export const WithBodyDismissible: Story = {
  args: {
    children: (
      <>
        <Alert.Typography>Body message text and</Alert.Typography>
        <Link onPress={() => {}}>text link if necessary</Link>
      </>
    ),
    onRequestClose: () => {},
  },
};
