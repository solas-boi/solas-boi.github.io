import { type PropsWithChildren } from "react";
import { View } from "react-native";
import {
  CoreAlert,
  type AlertSeverity,
  type HeadingLevel,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import {
  ErrorIcon,
  WarningIcon,
  SuccessIcon,
  InfoIcon,
  CloseIcon,
} from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./Alert.styles";
import { Typography, type TypographyProps } from "../Typography";
import { IconButton } from "../IconButton";

export type AlertProps = PropsWithOptionalTestID &
  PropsWithChildren<{
    severity?: AlertSeverity;
    heading: string;
    headingLevel?: HeadingLevel;
    onRequestClose?: () => void;
    withRole?: boolean;
  }>;

function Alert(props: AlertProps) {
  const {
    severity = CoreAlert.DEFAULT_SEVERITY,
    heading,
    headingLevel = CoreAlert.DEFAULT_HEADING_LEVEL,
    onRequestClose,
    children,
    testID = "alert",
    withRole = true,
  } = props;

  const { tokens } = useDesignTokens();
  const { alert } = tokens;

  const hasBody = Boolean(children);
  const isDismissible = Boolean(onRequestClose);

  const styles = useStyles();
  const stateStyles = useStateStyles({
    severity,
    hasBody,
    isDismissible,
  });

  const iconProps = {
    width: alert.icon.width,
    height: alert.icon.height,
    primaryColor: alert.icon.primaryColor[severity],
    secondaryColor: alert.icon.secondaryColor[severity],
  };

  const alertRole = {
    error: "alert",
    warning: "alert",
    success: undefined,
    info: undefined,
  } as const;

  const alertIcon = {
    error: <ErrorIcon {...iconProps} />,
    warning: <WarningIcon {...iconProps} />,
    success: <SuccessIcon {...iconProps} />,
    info: <InfoIcon {...iconProps} />,
  };

  /** Some accessibilityRole/role have no effect on both iOS and Android (https://github.com/facebook/react-native/issues/50123).
   * This is a bug fix until the bug is fixed in React Native.
   * TODO: Once this issue is resolved, we can remove hiddenContainer
   */

  return (
    <>
      <View
        accessible
        importantForAccessibility="yes"
        accessibilityLabel={
          withRole
            ? `${heading}, ${
                alertRole[severity] !== undefined ? alertRole[severity] : ""
              }`
            : heading
        }
        accessibilityHint={withRole ? `${severity} alert` : undefined}
        style={styles.hiddenContainer}
      />
      <View
        role={withRole ? alertRole[severity] : undefined}
        accessibilityRole={withRole ? alertRole[severity] : undefined}
        style={stateStyles.container}
        testID={testID}
      >
        <View style={stateStyles.contentContainer}>
          <View style={styles.iconWrapper}>{alertIcon[severity]}</View>

          <View style={styles.textContainer}>
            <Typography
              component={`h${headingLevel}`}
              color={alert.heading.typography.color}
              variant={alert.heading.typography.variant}
              fontFamily={alert.heading.typography.fontFamily}
              testID={`${testID}-heading`}
            >
              {heading}
            </Typography>

            {children && <View testID={`${testID}-body`}>{children}</View>}
          </View>
        </View>

        {isDismissible && (
          <View style={stateStyles.closeIconButtonWrapper}>
            <IconButton onPress={onRequestClose} aria-label="Close">
              <CloseIcon />
            </IconButton>
          </View>
        )}
      </View>
    </>
  );
}

Alert.Typography = function AlertTypography(props: TypographyProps) {
  const { tokens } = useDesignTokens();
  const { alert } = tokens;

  return (
    <Typography
      color={alert.body.typography.color}
      variant={alert.body.typography.variant}
      fontFamily={alert.body.typography.fontFamily}
      {...props}
    />
  );
};

export default Alert;
