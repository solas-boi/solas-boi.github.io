import { useEffect } from "react";
import { AccessibilityInfo, View } from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import {
  type AlertSeverity,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import {
  ErrorIcon,
  WarningIcon,
  SuccessIcon,
  InfoIcon,
} from "@boi/react-native-icons";

import useStyles from "./InlineAlert.styles";
import { Typography } from "../Typography";

export type InlineAlertProps = PropsWithOptionalTestID & {
  severity: AlertSeverity;
  children: string;
  announceForAccessibility?: boolean;
  withRole?: boolean;
};

function InlineAlert(props: InlineAlertProps) {
  const {
    severity,
    children,
    announceForAccessibility = true,
    testID = "inline-alert",
    withRole = true,
  } = props;

  const { tokens } = useDesignTokens();
  const { inlineAlert } = tokens;

  const styles = useStyles();

  const iconProps = {
    width: inlineAlert.icon.width,
    height: inlineAlert.icon.height,
    primaryColor: inlineAlert.icon.primaryColor[severity],
    secondaryColor: inlineAlert.icon.secondaryColor[severity],
  };

  const alertRole = {
    error: "alert",
    warning: "alert",
    success: undefined,
    info: undefined,
  } as const;

  const alertIcon = {
    error: <ErrorIcon {...iconProps} />,
    warning: <WarningIcon {...iconProps} />,
    success: <SuccessIcon {...iconProps} />,
    info: <InfoIcon {...iconProps} />,
  };

  useEffect(() => {
    if (announceForAccessibility) {
      AccessibilityInfo.announceForAccessibilityWithOptions?.(children, {
        queue: severity !== "error", // Polite announcement if it's not an error
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [announceForAccessibility, children]);

  /** Some accessibilityRole/role have no effect on both iOS and Android (https://github.com/facebook/react-native/issues/50123).
   * This is a temporary fix until the bug is fixed in React Native.
   * TODO: Once this issue is resolved, we can remove next props from container: accessible, accessibilityLabel, accessibilityHint
   */

  return (
    <View
      accessible
      role={withRole ? alertRole[severity] : undefined}
      accessibilityRole={withRole ? alertRole[severity] : undefined}
      accessibilityLabel={
        withRole
          ? `${children}, ${
              alertRole[severity] !== undefined ? alertRole[severity] : ""
            }`
          : children
      }
      accessibilityHint={withRole ? `${severity} alert` : undefined}
      style={styles.container}
      testID={testID}
    >
      <View style={styles.iconWrapper}>{alertIcon[severity]}</View>
      <View style={styles.textWrapper}>
        <Typography color={inlineAlert.color[severity]}>{children}</Typography>
      </View>
    </View>
  );
}

export default InlineAlert;
