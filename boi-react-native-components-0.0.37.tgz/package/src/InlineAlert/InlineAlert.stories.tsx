import type { Meta, StoryObj } from "@storybook/react";
import { ALERT_SEVERITIES } from "@boi/components-core";

import InlineAlert from "./InlineAlert";

const meta = {
  title: "Feedback/InlineAlert",
  component: InlineAlert,
  argTypes: {
    severity: {
      control: { type: "select" },
      options: ALERT_SEVERITIES,
    },
    withRole: { control: { type: "boolean" } },
    children: { control: { type: "text" } },
  },
  args: {
    severity: "info",
    children: "Alert message text",
    withRole: true,
  },
} satisfies Meta<typeof InlineAlert>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
