import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { type AlertSeverity } from "@boi/components-core";

import InlineAlert, { type InlineAlertProps } from "./InlineAlert";

function WrappedInlineAlert(props: InlineAlertProps) {
  return (
    <DesignTokensProvider>
      <InlineAlert {...props} />
    </DesignTokensProvider>
  );
}

describe("InlineAlert", () => {
  let baseProps: InlineAlertProps;

  beforeEach(() => {
    baseProps = {
      severity: "info",
      children: "Alert message text",
    };
  });

  it.each([
    ["error" as AlertSeverity, "alert"],
    ["warning" as AlertSeverity, "alert"],
    ["success" as AlertSeverity, undefined],
    ["info" as AlertSeverity, undefined],
  ])("should render with the correct role", (severity, role) => {
    render(<WrappedInlineAlert {...baseProps} severity={severity} />);

    const alert = screen.getByTestId("inline-alert");

    expect(alert.props.role).toEqual(role);
    expect(alert.props.accessibilityRole).toEqual(role);
  });

  it.each(["error", "warning", "success", "info"] as AlertSeverity[])(
    "should not render with alert role when withRole is false for %s",
    (severity) => {
      render(
        <WrappedInlineAlert
          {...baseProps}
          severity={severity}
          withRole={false}
        />
      );

      const alert = screen.getByTestId("inline-alert");

      expect(alert.props.role).toBeUndefined();
      expect(alert.props.accessibilityRole).toBeUndefined();
    }
  );

  it("should render with the correct children", () => {
    render(<WrappedInlineAlert {...baseProps} />);

    const children = screen.getByText(baseProps.children);

    expect(children).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedInlineAlert {...baseProps} />);

    expect(screen.getByTestId("inline-alert")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-inline-alert";

    render(<WrappedInlineAlert {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
