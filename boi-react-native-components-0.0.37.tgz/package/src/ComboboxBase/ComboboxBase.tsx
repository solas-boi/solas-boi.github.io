import { Ref, useRef, useState } from "react";
import { Platform, View, type AccessibilityProps } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import {
  CoreCombobox,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { ChevronDownIcon } from "@boi/react-native-icons";

import { OuterField } from "../OuterField";
import { Typography } from "../Typography";
import { ComboboxModal } from "../ComboboxModal";
import { InputLabelTopProps } from "../InputLabelTop";

import useStyles from "./ComboboxBase.styles";
import { ModalProps } from "../Modal";
import { useA11yRoleWorkaround, useMergeRefs } from "../hooks";
import {
  ScreenReaderAlertNotifier,
  ScreenReaderAlertNotifierProps,
} from "../ScreenReaderAlertNotifier";

const isAndroid = Platform.OS === "android";
const isOlderThanAndroid16 = isAndroid && Number(Platform.Version) < 36;

export type ComboboxBaseProps<T extends CoreCombobox.ComboboxItem> =
  PropsWithOptionalTestID &
    Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
    AccessibilityProps & {
      labelProps: InputLabelTopProps;
      isOpen: boolean;
      alertProps?: ScreenReaderAlertNotifierProps["alert"];
      selectedItem?: T | null | undefined;
      defaultInputValue?: string;
      items: T[];
      disabledKeys?: string[];
      placeholder?: string;
      hasError?: boolean;
      isDisabled?: boolean;
      onInputChange?: (inputValue: string) => void;
      onChange: (selectedItem: T | null | undefined) => void;
      onFocus: () => void;
      onBlur: () => void;
      pressableRef?: Ref<View>;
    };

function ComboboxBase<T extends CoreCombobox.ComboboxItem>(
  props: ComboboxBaseProps<T>
) {
  const {
    items,
    disabledKeys,
    placeholder,
    isDisabled,
    hasError,
    isOpen,
    selectedItem,
    labelProps,
    defaultInputValue,
    onInputChange,
    onChange,
    onFocus,
    onBlur,
    supportedOrientations,
    onCloseAnimationComplete,
    testID = "combobox",
    pressableRef,
    role,
    accessibilityRole,
    alertProps,
    ...accessibilityProps
  } = props;

  const localPressableRef = useRef<View>(null);
  const mergedRefs = useMergeRefs([localPressableRef, pressableRef]);

  const styles = useStyles();
  const accessibilityLabel = useA11yRoleWorkaround(
    role || accessibilityRole || "combobox",
    accessibilityProps.accessibilityLabel || labelProps.label
  );

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  return (
    <>
      <OuterField
        isDisabled={isDisabled}
        hasFocus={hasKeyboardFocus}
        isActive={isOpen}
        hasError={hasError}
      >
        <ScreenReaderAlertNotifier alert={alertProps}>
          <KeyboardPressable
            ref={mergedRefs}
            onPress={onFocus}
            onFocusChange={handleKeyboardFocusChange}
            tintType="none"
            pointerEvents={isDisabled ? "none" : "auto"}
            style={styles.button}
            testID={testID}
            enableA11yFocus
            accessibilityValue={{
              text: `${
                (!isAndroid || isOlderThanAndroid16) && !isOpen
                  ? "collapsed, "
                  : ""
              }${selectedItem?.title ?? placeholder}`,
            }}
            accessibilityState={{
              expanded: isAndroid && !isOlderThanAndroid16 ? isOpen : undefined,
              disabled: Boolean(isDisabled),
            }}
            accessibilityHint={labelProps.labelHint}
            {...accessibilityProps}
            accessibilityLabel={accessibilityLabel}
          >
            {selectedItem ? (
              <Typography
                fontFamily={styles.buttonText.fontFamily}
                variant={styles.buttonText.fontVariant}
                style={[
                  styles.buttonText,
                  isDisabled && styles.buttonTextDisabled,
                ]}
                noWrap
              >
                {selectedItem.title}
              </Typography>
            ) : (
              <Typography
                fontFamily={styles.buttonText.fontFamily}
                variant={styles.buttonText.fontVariant}
                style={[
                  styles.buttonPlaceholder,
                  isDisabled && styles.buttonPlaceholderDisabled,
                ]}
                noWrap
              >
                {placeholder}
              </Typography>
            )}

            <ComboboxChevron isOpen={isOpen} isDisabled={isDisabled} />
          </KeyboardPressable>
        </ScreenReaderAlertNotifier>
      </OuterField>
      <ComboboxModal
        testID={`${testID}-modal`}
        isOpen={isOpen}
        title={
          labelProps.label || labelProps["aria-label"] || placeholder || ""
        }
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        defaultInputValue={defaultInputValue}
        onInputChange={onInputChange}
        onChange={onChange}
        onRequestClose={onBlur}
        supportedOrientations={supportedOrientations}
        onCloseAnimationComplete={() => {
          localPressableRef.current?.focus();
          onCloseAnimationComplete?.();
        }}
      />
    </>
  );
}

function ComboboxChevron(props: { isOpen: boolean; isDisabled?: boolean }) {
  const { tokens } = useDesignTokens();
  const { width, height, color } = tokens.select.button.icon;

  return (
    <ChevronDownIcon
      width={width}
      height={height}
      color={props.isDisabled ? color.disabled : color.base}
      style={props.isOpen && { transform: [{ rotate: "180deg" }] }}
    />
  );
}

export default ComboboxBase;
