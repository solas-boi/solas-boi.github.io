import { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";
import { CoreToggle } from "@boi/components-core";

import Toggle from "./Toggle";
import { Text, View } from "react-native";
import { Typography } from "../Typography";
import { ToggleBase } from "../ToggleBase";

const meta = {
  title: "Inputs/Toggle",
  component: Toggle,
  render: function Render(args: any) {
    const [, updateArgs] = useArgs();

    function handleChange(checked: boolean) {
      action("onChange")({ checked });
      updateArgs({ checked });
    }

    return <Toggle {...args} onChange={handleChange} />;
  },
  argTypes: {
    checked: { control: "boolean" },
    disabled: { control: "boolean" },
    toggleSize: {
      control: { type: "select" },
      options: CoreToggle.SIZES,
    },
  },
  args: {
    checked: true,
    disabled: false,
  },
} satisfies Meta<typeof Toggle>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    accessibilityLabel: "Moose",
    accessibilityHint: "Toggles the moose",
  },
};

export const DisabledChecked: Story = {
  ...Basic,
  args: {
    disabled: true,
    checked: true,
  },
};

export const DisabledUnchecked: Story = {
  ...Basic,
  args: {
    disabled: true,
    checked: false,
  },
};

export const Small: Story = {
  ...Basic,
  args: {
    toggleSize: "small",
  },
};

export const BaseStates: Story = {
  ...Basic,
  render: function Render() {
    const rowStyle = {
      flexDirection: "row",
      paddingVertical: 8,
      gap: 8,
    } as const;
    return (
      <View style={{ gap: 10 }}>
        <Text>
          BaseStates is a non-interactive, demonstrational component. It
          showcases the different visual states of ToggleBase.
        </Text>
        <View style={rowStyle}>
          <ToggleBase checked={false} />
          <Typography> default</Typography>
        </View>
        <View style={rowStyle}>
          <ToggleBase checked={true} />
          <Typography> checked</Typography>
        </View>
        <View style={rowStyle}>
          <ToggleBase checked={false} hasFocus={true} />
          <Typography> with focus</Typography>
        </View>
        <View style={rowStyle}>
          <ToggleBase checked={true} hasFocus={true} />
          <Typography> checked with focus</Typography>
        </View>
      </View>
    );
  },
};
