import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import { HEADING_LEVELS } from "@boi/components-core";

import InformationModal from "./InformationModal";
import { Button } from "../Button";

const meta = {
  title: "Surfaces/InformationModal",
  component: InformationModal,
  render: function Render(args) {
    const [{ isOpen }, updateArgs] = useArgs();

    function openModalPressHandler() {
      updateArgs({ isOpen: true });
      action("openModal")();
    }

    function modalClosedHandler() {
      updateArgs({ isOpen: false });
      action("modalClosed")();
    }

    return (
      <>
        <Button
          variant="primary"
          text="Open Modal"
          disabled={isOpen}
          onPress={openModalPressHandler}
        />

        <InformationModal
          {...args}
          onRequestClose={modalClosedHandler}
          isOpen={isOpen}
          primaryButtonsProps={[
            {
              text: "Login",
              onPress: modalClosedHandler,
            },
          ]}
          secondaryButtonsProps={[
            {
              text: "Contact us",
              onPress: modalClosedHandler,
            },
          ]}
        />
      </>
    );
  },
  argTypes: {
    heading: { control: { type: "text" } },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
    primaryButtonsProps: { control: { disable: true } },
    secondaryButtonsProps: { control: { disable: true } },
    tabletWidth: { control: { type: "number" } },
    children: { control: { disable: true } },
  },
  args: {
    isOpen: false,
  },
} satisfies Meta<typeof InformationModal>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    heading: "We cannot complete your request just now",
    children: (
      <InformationModal.Typography variant="bodyM">
        Sorry about that. You could try again later or you can access your
        account through 365 phone banking by contacting us.
      </InformationModal.Typography>
    ),
  },
};
