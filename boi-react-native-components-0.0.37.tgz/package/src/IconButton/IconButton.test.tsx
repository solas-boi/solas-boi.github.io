import { View } from "react-native";
import { act, render, screen, within } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import IconButton, { type IconButtonProps } from "./IconButton";

jest.mock("react-native-external-keyboard", () => {
  const actual = jest.requireActual("react-native-external-keyboard");
  const { Pressable } = require("react-native");
  return {
    ...actual,
    Pressable,
  };
});

function WrappedIconButton(props: IconButtonProps) {
  return (
    <DesignTokensProvider>
      <IconButton {...props} />
    </DesignTokensProvider>
  );
}

describe("IconButton", () => {
  let baseProps: IconButtonProps;

  beforeEach(() => {
    baseProps = {
      children: <View testID="mock-icon" />,
      "aria-label": "Calendar button",
    };
  });

  it("should render with the correct role by default", () => {
    render(<WrappedIconButton {...baseProps} />);

    const button = screen.getByRole("button");

    expect(button).toBeDefined();
  });

  it.each(["button", "switch"] as const)(
    "should render with the %s role",
    (role) => {
      render(
        <WrappedIconButton
          {...baseProps}
          role={role}
          accessibilityRole={role}
        />
      );

      const button = screen.getByRole(role);

      expect(button).toBeDefined();
    }
  );

  it("should render with the correct icon", () => {
    render(<WrappedIconButton {...baseProps} />);

    const button = screen.getByRole("button");
    const icon = within(button).getByTestId("mock-icon");

    expect(icon).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedIconButton {...baseProps} />);

    expect(screen.getByTestId("icon-button")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-icon-button";

    render(<WrappedIconButton {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  describe("focus ring", () => {
    it("should not render the focus ring by default", () => {
      render(<WrappedIconButton {...baseProps} />);

      expect(screen.queryByTestId("icon-button-focus-ring")).toBeNull();
    });

    it("should render the focus ring when keyboard focus is gained", () => {
      render(<WrappedIconButton {...baseProps} />);

      const button = screen.getByRole("button");

      act(() => {
        button.props.onFocusChange?.(true);
      });

      expect(screen.getByTestId("icon-button-focus-ring")).toBeDefined();
    });

    it("should hide the focus ring when keyboard focus is lost", () => {
      render(<WrappedIconButton {...baseProps} />);

      const button = screen.getByRole("button");

      act(() => {
        button.props.onFocusChange?.(true);
      });

      act(() => {
        button.props.onFocusChange?.(false);
      });

      expect(screen.queryByTestId("icon-button-focus-ring")).toBeNull();
    });

    it("should use the custom testID for the focus ring", () => {
      const testID = "custom-icon-button";

      render(<WrappedIconButton {...baseProps} testID={testID} />);

      const button = screen.getByRole("button");

      act(() => {
        button.props.onFocusChange?.(true);
      });

      expect(screen.getByTestId(`${testID}-focus-ring`)).toBeDefined();
    });
  });
});
