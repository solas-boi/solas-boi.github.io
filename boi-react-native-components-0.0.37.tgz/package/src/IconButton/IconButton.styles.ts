import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { CoreIconButton } from "@boi/components-core";

import { createThemedStyleSheet } from "../themedStylesheet";

const calculateFocusRingOffset = (
  focusRing: ThemeTokens["iconButton"]["inner"]["focusRing"],
  variant: CoreIconButton.Variant
) => {
  return -1 * (focusRing.offset[variant] + focusRing.width);
};

function styleSheetFactory(tokens: ThemeTokens) {
  const { iconButton } = tokens;

  const focusRingOffsetDefault = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default"
  );
  const focusRingOffsetDefault16 = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default16"
  );
  const focusRingOffsetDefault20 = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default20"
  );

  const focusRingOffsetDefault32 = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default32"
  );
  const focusRingOffsetContained = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "contained"
  );

  return StyleSheet.create({
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
    wrapperVariantDefault: {
      padding: iconButton.padding.default,
    },
    wrapperVariantDefault16: {
      padding: iconButton.padding.default16,
    },
    wrapperVariantDefault20: {
      padding: iconButton.padding.default20,
    },
    wrapperVariantDefault32: {
      padding: iconButton.padding.default32,
    },
    wrapperVariantContained: {
      padding: iconButton.padding.contained,
    },
    container: {
      position: "relative",
      opacity: iconButton.inner.opacity.base,
    },
    containerDisabled: {
      opacity: iconButton.inner.opacity.disabled,
    },
    containerVariantDefault: {
      borderRadius: iconButton.inner.radius.default,
      padding: iconButton.inner.padding.default,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault16: {
      borderRadius: iconButton.inner.radius.default16,
      padding: iconButton.inner.padding.default16,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault20: {
      borderRadius: iconButton.inner.radius.default20,
      padding: iconButton.inner.padding.default20,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault32: {
      borderRadius: iconButton.inner.radius.default32,
      padding: iconButton.inner.padding.default32,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefaultPressed: {
      backgroundColor: iconButton.inner.backgroundColor.default.active,
    },
    containerVariantDefault16Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default16.active,
    },
    containerVariantDefault20Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default20.active,
    },
    containerVariantDefault32Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default32.active,
    },
    containerVariantContained: {
      borderRadius: iconButton.inner.radius.contained,
      padding: iconButton.inner.padding.contained,
      backgroundColor: iconButton.inner.backgroundColor.contained.base,
    },
    containerVariantContainedPressed: {
      backgroundColor: iconButton.inner.backgroundColor.contained.active,
      borderColor: iconButton.inner.stroke.contained.color.active,
    },
    containerBorderVariantContained: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      borderRadius: iconButton.inner.radius.contained,
      borderWidth: iconButton.inner.stroke.contained.width,
      borderStyle: iconButton.inner.stroke.contained.style,
      borderColor: iconButton.inner.stroke.contained.color.base,
    },
    containerBorderVariantContainedPressed: {
      borderColor: iconButton.inner.stroke.contained.color.active,
    },
    focusRing: {
      position: "absolute",
      borderWidth: iconButton.inner.focusRing.width,
      borderStyle: iconButton.inner.focusRing.style,
      borderColor: iconButton.inner.focusRing.color,
    },
    focusRingDefault: {
      borderRadius:
        iconButton.inner.radius.default +
        iconButton.inner.focusRing.offset.default +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault,
      top: focusRingOffsetDefault,
      right: focusRingOffsetDefault,
      bottom: focusRingOffsetDefault,
    },
    focusRingDefault16: {
      borderRadius:
        iconButton.inner.radius.default16 +
        iconButton.inner.focusRing.offset.default16 +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault16,
      top: focusRingOffsetDefault16,
      right: focusRingOffsetDefault16,
      bottom: focusRingOffsetDefault16,
    },
    focusRingDefault20: {
      borderRadius:
        iconButton.inner.radius.default20 +
        iconButton.inner.focusRing.offset.default20 +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault20,
      top: focusRingOffsetDefault20,
      right: focusRingOffsetDefault20,
      bottom: focusRingOffsetDefault20,
    },
    focusRingDefault32: {
      borderRadius:
        iconButton.inner.radius.default32 +
        iconButton.inner.focusRing.offset.default32 +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault32,
      top: focusRingOffsetDefault32,
      right: focusRingOffsetDefault32,
      bottom: focusRingOffsetDefault32,
    },
    focusRingContained: {
      borderRadius:
        iconButton.inner.radius.contained +
        iconButton.inner.focusRing.offset.contained +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetContained,
      top: focusRingOffsetContained,
      right: focusRingOffsetContained,
      bottom: focusRingOffsetContained,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant,
  disabled,
  isPressed,
}: {
  variant: CoreIconButton.Variant;
  disabled: boolean | null | undefined;
  isPressed: boolean | undefined;
}) {
  const styles = useStyles();

  const wrapperStyles = {
    default: styles.wrapperVariantDefault,
    default16: styles.wrapperVariantDefault16,
    default20: styles.wrapperVariantDefault20,
    default32: styles.wrapperVariantDefault32,
    contained: styles.wrapperVariantContained,
  };

  const containerStyles = {
    default: styles.containerVariantDefault,
    default16: styles.containerVariantDefault16,
    default20: styles.containerVariantDefault20,
    default32: styles.containerVariantDefault32,
    contained: styles.containerVariantContained,
  };

  const containerPressedStyles = {
    default: styles.containerVariantDefaultPressed,
    default16: styles.containerVariantDefault16Pressed,
    default20: styles.containerVariantDefault20Pressed,
    default32: styles.containerVariantDefault32Pressed,
    contained: styles.containerVariantContainedPressed,
  };

  const containerBorderStyles = {
    default: undefined,
    default16: undefined,
    default20: undefined,
    default32: undefined,
    contained: styles.containerBorderVariantContained,
  };

  const containerBorderPressedStyles = {
    default: undefined,
    default16: undefined,
    default20: undefined,
    default32: undefined,
    contained: styles.containerBorderVariantContainedPressed,
  };

  const variantWrapperStyles = wrapperStyles[variant];

  const focusRingStyles = {
    default: styles.focusRingDefault,
    default16: styles.focusRingDefault16,
    default20: styles.focusRingDefault20,
    default32: styles.focusRingDefault32,
    contained: styles.focusRingContained,
  };

  return {
    hitSlop: variantWrapperStyles.padding,
    wrapper: [styles.wrapper, variantWrapperStyles],
    container: [
      styles.container,
      containerStyles[variant],
      isPressed && containerPressedStyles[variant!],
      disabled && styles.containerDisabled,
    ],
    containerBorder: [
      containerBorderStyles[variant],
      isPressed && containerBorderPressedStyles[variant!],
    ],
    focusRing: [styles.focusRing, focusRingStyles[variant]],
  };
}

export default useStyles;
