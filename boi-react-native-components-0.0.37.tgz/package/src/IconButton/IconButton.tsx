import { forwardRef, useState } from "react";
import { View } from "react-native";
import {
  Pressable as KeyboardPressable,
  KeyboardFocus,
} from "react-native-external-keyboard";
import {
  CoreIconButton,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useStateStyles } from "./IconButton.styles";
import IconButtonIcon from "./IconButtonIcon";
import { KeyboardPressableProps } from "../types";

export type IconButtonProps = PropsWithOptionalTestID &
  Omit<
    KeyboardPressableProps,
    "role" | "accessibilityRole" | "style" | "children"
  > & {
    children: JSX.Element;
    variant?: CoreIconButton.Variant;
    "aria-label": string;
    role?: Extract<KeyboardPressableProps["role"], "button" | "switch">;
    accessibilityRole?: Extract<
      KeyboardPressableProps["accessibilityRole"],
      "button" | "switch"
    >;
  };

const IconButton = forwardRef<View | KeyboardFocus, IconButtonProps>(
  (props, ref) => {
    const {
      variant = CoreIconButton.DEFAULT_VARIANT,
      children,
      testID = "icon-button",
      role = "button",
      accessibilityRole = "button",
      onPressIn,
      onPressOut,
      ...otherProps
    } = props;

    const { disabled } = props;

    const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
    const [isPressed, setIsPressed] = useState(false);
    const stateStyles = useStateStyles({
      variant,
      disabled,
      isPressed,
    });
    const handlePressIn: typeof onPressIn = (evt) => {
      setIsPressed(true);
      onPressIn?.(evt);
    };
    const handlePressOut: typeof onPressOut = (evt) => {
      setIsPressed(false);
      onPressOut?.(evt);
    };
    const handleKeyboardFocusChange = (isFocused: boolean) => {
      setHasKeyboardFocus(isFocused);
      props.onFocusChange?.(isFocused);
    };

    return (
      <KeyboardPressable
        hitSlop={stateStyles.hitSlop}
        {...otherProps}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onFocusChange={handleKeyboardFocusChange}
        tintColor="none"
        haloEffect={false}
        ref={ref}
        enableA11yFocus
        role={role}
        accessibilityRole={accessibilityRole}
        containerStyle={stateStyles.wrapper}
        testID={testID}
      >
        <View style={stateStyles.container}>
          {hasKeyboardFocus && (
            <View
              pointerEvents="none"
              style={stateStyles.focusRing}
              testID={`${testID}-focus-ring`}
            />
          )}

          <IconButtonIcon
            icon={children}
            variant={variant}
            isPressed={isPressed}
          />
          <View style={stateStyles.containerBorder} />
        </View>
      </KeyboardPressable>
    );
  }
);

IconButton.displayName = "IconButton";

export default IconButton;
