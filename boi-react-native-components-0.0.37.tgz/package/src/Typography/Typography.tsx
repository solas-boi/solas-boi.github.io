import { forwardRef } from "react";
import { Text, type TextProps } from "react-native";
import { CoreTypography } from "@boi/components-core";

import useStyles, { useStateStyles } from "./Typography.styles";
import { TYPOGRAPHY_HEADING_LEVEL_MAP } from "./Typography.constants";
import type { TypographyComponent } from "./Typography.types";

type BaseProps = Omit<TextProps, "numberOfLines" | "aria-level"> & {
  component?: TypographyComponent;
  noWrap?: boolean;
  color?: string;
};

type HeadingVariantProps = BaseProps & {
  variant?: CoreTypography.HeadingVariant;
};

type StandardVariantProps = BaseProps & {
  variant?: CoreTypography.StandardVariant;
  fontFamily?: CoreTypography.FontFamily;
};

export type TypographyProps = HeadingVariantProps | StandardVariantProps;

function getColorFromStyle(
  style: TypographyProps["style"]
): string | undefined {
  if (!style || typeof style === "number") {
    return undefined;
  }
  if (style instanceof Array) {
    return style.reduce<string>((value, currentValue) => {
      const color = getColorFromStyle(currentValue as TypographyProps["style"]);
      return color || value;
    }, "");
  } else if (style instanceof Object) {
    return String(style.color);
  }
}

const isTestEnv =
  // eslint-disable-next-line turbo/no-undeclared-env-vars
  process.env.NODE_ENV === "test" || process.env.JEST_WORKER_ID !== undefined;

// CP-105517: Add an zero width space at the end of the text so to prevent the bug where the text gets cut.
// Ignore this trailing character on jest unit tests to avoid breaking tests and snapshots
// TODO: Retest when upgrading react native version
const __TRAILING_CHAR_WORKAROUND = !isTestEnv ? "\u200B" : "";

const Typography = forwardRef<Text, TypographyProps>((props, ref) => {
  const {
    variant = CoreTypography.DEFAULT_VARIANT,
    component,
    noWrap,
    color,
    style,
    accessibilityRole = "text",
    children,
    ...otherProps
  }: TypographyProps = props;

  const headingLevel = component
    ? TYPOGRAPHY_HEADING_LEVEL_MAP[component]
    : TYPOGRAPHY_HEADING_LEVEL_MAP[variant];

  const fontFamily = "fontFamily" in props ? props.fontFamily : undefined;

  const styles = useStyles();
  const stateStyles = useStateStyles({ variant, fontFamily, style, color });

  const role = headingLevel ? "heading" : props?.role;
  const a11yRole = headingLevel ? "header" : accessibilityRole;

  return (
    <Text
      // Using the color as a key for the component to workaround a bug on iOS where the color doesn't get update unless fontFamily or children changes
      // This ensure that if the color changes, a new text component is going to get mount with the correct color
      key={
        color || (style && getColorFromStyle(style)) || styles[variant].color
      }
      ref={ref}
      allowFontScaling={false}
      {...otherProps}
      numberOfLines={noWrap ? 1 : undefined}
      role={role}
      accessibilityRole={a11yRole}
      aria-level={headingLevel}
      style={stateStyles.text}
      children={
        children && typeof children === "string"
          ? `${children}${__TRAILING_CHAR_WORKAROUND}`
          : children
      }
    />
  );
});

Typography.displayName = "Typography";

export default Typography;
