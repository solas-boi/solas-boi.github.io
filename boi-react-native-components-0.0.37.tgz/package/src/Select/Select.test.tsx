import {
  render,
  screen,
  userEvent,
  fireEvent,
  act,
} from "@testing-library/react-native";
import { Keyboard } from "react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { CoreSelect } from "@boi/components-core";

import Select, { type SelectProps } from "./Select";

jest.useFakeTimers();

function WrappedSelect(props: SelectProps<CoreSelect.SelectItem>) {
  return (
    <DesignTokensProvider>
      <Select {...props} />
    </DesignTokensProvider>
  );
}

describe("Select", () => {
  let baseProps: SelectProps<CoreSelect.SelectItem>;
  const isVisibleSpy = jest.spyOn(Keyboard, "isVisible");
  const dismissSpy = jest.spyOn(Keyboard, "dismiss");

  beforeEach(() => {
    baseProps = {
      placeholder: "Select...",
      items: CoreSelect.mockItems,
      onChange: jest.fn(),
      labelProps: {
        "aria-label": "Label",
      },
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should render with the correct role", async () => {
    render(<WrappedSelect {...baseProps} />);

    const combobox = await screen.findByTestId("select");
    expect(combobox).toBeDefined();
  });

  it("should render the correct number of select options", async () => {
    const user = userEvent.setup();
    const items = CoreSelect.mockItems.slice(0, 2);

    render(<WrappedSelect {...baseProps} items={items} />);

    const combobox = await screen.findByTestId("select");

    await act(async () => {
      await user.press(combobox);
    });

    const options = screen.getAllByRole("radio");
    expect(options).toHaveLength(items.length);
  });

  it("should trigger the onChange event when a select option is clicked", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(<WrappedSelect {...baseProps} onChange={mockOnChange} />);

    const combobox = await screen.findByTestId("select");

    await act(async () => {
      await user.press(combobox);
    });

    const firstOption = screen.getAllByRole("radio")[0]!;

    await act(async () => {
      await user.press(firstOption);
    });

    await screen.findByTestId("select-modal", { hidden: true });

    expect(mockOnChange).toHaveBeenCalledTimes(1);
    expect(mockOnChange).toHaveBeenCalledWith(CoreSelect.mockItems[0]);
  });

  it("should render with a default testID", () => {
    render(<WrappedSelect {...baseProps} />);

    expect(screen.getByTestId("select")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-select";

    render(<WrappedSelect {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  describe("keyboard dismiss", () => {
    it("should dismiss the keyboard when it is visible and the select is opened", async () => {
      isVisibleSpy.mockReturnValue(true);

      render(<WrappedSelect {...baseProps} />);

      const combobox = await screen.findByTestId("select");
      fireEvent.press(combobox);

      expect(dismissSpy).toHaveBeenCalledTimes(1);
    });

    it("should not dismiss the keyboard when it is not visible and the select is opened", async () => {
      isVisibleSpy.mockReturnValue(false);

      render(<WrappedSelect {...baseProps} />);

      const combobox = await screen.findByTestId("select");
      fireEvent.press(combobox);

      expect(dismissSpy).not.toHaveBeenCalled();
    });
  });
});
