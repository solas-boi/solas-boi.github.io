import { Platform, StyleSheet } from "react-native";
import { CoreTooltipIconButton } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

const calculateFocusRingOffset = (
  focusRing: ThemeTokens["iconButton"]["inner"]["focusRing"],
  variant: CoreTooltipIconButton.Variant
) => {
  return -1 * (focusRing.offset[variant] + focusRing.width);
};

function styleSheetFactory(tokens: ThemeTokens) {
  const { iconButton } = tokens;

  const focusRingOffsetDefault = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default"
  );
  const focusRingOffsetDefault16 = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default16"
  );
  const focusRingOffsetDefault20 = calculateFocusRingOffset(
    iconButton.inner.focusRing,
    "default20"
  );

  return StyleSheet.create({
    // TODO: CP-103763 Remove this workaround for iOS Keyboard focus order once a better solution is found
    __iOSFixForKeyboardOrder:
      Platform.OS === "ios" ? { marginTop: -1, paddingTop: 1 } : {},
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
    wrapperDefault: {
      padding: iconButton.padding.default,
    },
    wrapperDefault16: {
      padding: iconButton.padding.default16,
    },
    wrapperDefault20: {
      padding: iconButton.padding.default20,
    },
    containerDefault: {
      padding: iconButton.inner.padding.default,
    },
    containerDefault16: {
      padding: iconButton.inner.padding.default16,
    },
    containerDefault20: {
      padding: iconButton.inner.padding.default20,
    },
    iconHidden: {
      display: "none",
    },
    focusRing: {
      position: "absolute",
      borderWidth: iconButton.inner.focusRing.width,
      borderStyle: iconButton.inner.focusRing.style,
      borderColor: iconButton.inner.focusRing.color,
    },
    focusRingDefault: {
      borderRadius:
        iconButton.inner.radius.default +
        iconButton.inner.focusRing.offset.default +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault,
      top: focusRingOffsetDefault,
      right: focusRingOffsetDefault,
      bottom: focusRingOffsetDefault,
    },
    focusRingDefault16: {
      borderRadius:
        iconButton.inner.radius.default16 +
        iconButton.inner.focusRing.offset.default16 +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault16,
      top: focusRingOffsetDefault16,
      right: focusRingOffsetDefault16,
      bottom: focusRingOffsetDefault16,
    },
    focusRingDefault20: {
      borderRadius:
        iconButton.inner.radius.default20 +
        iconButton.inner.focusRing.offset.default20 +
        iconButton.inner.focusRing.width,
      left: focusRingOffsetDefault20,
      top: focusRingOffsetDefault20,
      right: focusRingOffsetDefault20,
      bottom: focusRingOffsetDefault20,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  isOpen,
  variant,
}: {
  isOpen: boolean;
  variant: CoreTooltipIconButton.Variant;
}) {
  const styles = useStyles();

  const wrapperStyles = {
    default: styles.wrapperDefault,
    default16: styles.wrapperDefault16,
    default20: styles.wrapperDefault20,
  };

  const containerStyles = {
    default: styles.containerDefault,
    default16: styles.containerDefault16,
    default20: styles.containerDefault20,
  };

  const focusRingStyles = {
    default: styles.focusRingDefault,
    default16: styles.focusRingDefault16,
    default20: styles.focusRingDefault20,
  };

  const variantWrapperStyles = wrapperStyles[variant];

  return {
    hitSlop: variantWrapperStyles.padding,
    wrapper: [styles.wrapper, variantWrapperStyles],
    container: containerStyles[variant],
    icon: [isOpen && styles.iconHidden],
    iconFilled: [!isOpen && styles.iconHidden],
    focusRing: [styles.focusRing, focusRingStyles[variant]],
  };
}

export default useStyles;
