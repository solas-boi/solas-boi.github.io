import { render, screen, fireEvent } from "@testing-library/react-native";
import { Keyboard } from "react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import TypographyTooltip, {
  type TypographyTooltipProps,
} from "./TypographyTooltip";

function WrappedTypographyTooltip(props: TypographyTooltipProps) {
  return (
    <DesignTokensProvider>
      <TypographyTooltip {...props} />
    </DesignTokensProvider>
  );
}

describe("TypographyTooltip", () => {
  let baseProps: TypographyTooltipProps;
  const isVisibleSpy = jest.spyOn(Keyboard, "isVisible");
  const dismissSpy = jest.spyOn(Keyboard, "dismiss");

  beforeEach(() => {
    baseProps = {
      typographyVariant: "bodyM",
      iconButtonProps: {
        "aria-label": "Open tooltip",
      },
      otherIconButtonProps: {
        variant: "default",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "Tooltip content",
      },
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("keyboard dismiss", () => {
    it("should dismiss the keyboard when it is visible and the icon button is pressed", async () => {
      isVisibleSpy.mockReturnValue(true);

      render(<WrappedTypographyTooltip {...baseProps} />);

      const iconButton = await screen.findByTestId("tooltipIconButton");

      fireEvent.press(iconButton);

      expect(dismissSpy).toHaveBeenCalledTimes(1);
    });

    it("should not dismiss the keyboard when it is not visible and the icon button is pressed", async () => {
      isVisibleSpy.mockReturnValue(false);

      render(<WrappedTypographyTooltip {...baseProps} />);

      const iconButton = await screen.findByTestId("tooltipIconButton");

      fireEvent.press(iconButton);

      expect(dismissSpy).not.toHaveBeenCalled();
    });
  });
});
