import {
  BRANDS,
  DEFAULT_BRAND,
  DEFAULT_THEME,
  getBrandThemes,
} from "@boi/react-native-design-tokens";

export const designTokensArgTypes = {
  brandTheme: {
    options: BRANDS.reduce((brandAccumulator, brand) => {
      return {
        ...brandAccumulator,
        ...getBrandThemes(brand).reduce((themeAccumulator, theme) => {
          return {
            ...themeAccumulator,
            [`${brand} (${theme})`]: `${brand}::${theme}`,
          };
        }, {}),
      };
    }, {}),
    control: { type: "radio" },
  },
};

export const designTokensArgs = {
  brandTheme: `${DEFAULT_BRAND}::${DEFAULT_THEME}`,
};
