import {
  useDesignTokens,
  type ThemeTokens,
} from "@boi/react-native-design-tokens";

type TokensWrapperProps = {
  children: (tokens: ThemeTokens) => JSX.Element;
};

export function TokensWrapper({ children }: TokensWrapperProps) {
  const { tokens } = useDesignTokens();

  return children(tokens);
}
