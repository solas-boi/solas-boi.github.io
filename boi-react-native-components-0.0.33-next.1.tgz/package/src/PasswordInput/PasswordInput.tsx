import { forwardRef, useRef, useState, useCallback } from "react";
import {
  View,
  TextInput as RNTextInput,
  type TextInputProps as RNTextInputProps,
} from "react-native";
import { KeyboardExtendedInput } from "react-native-external-keyboard";
import {
  CorePasswordInput,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { VisibleIcon, InvisibleIcon } from "@boi/react-native-icons";

import { useStateStyles } from "./PasswordInput.styles";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { OuterFieldV2 } from "../OuterFieldV2";
import { IconButton } from "../IconButton";
import { useMergeRefs } from "../hooks";

type InputType = CorePasswordInput.InputType;

export type PasswordInputProps = PropsWithOptionalTestID &
  Omit<RNTextInputProps, "style" | "editable" | "selectionColor"> & {
    labelProps?: Omit<InputLabelTopProps, "children">;
    alerts?: InputAlertsProps["alerts"];
    hasError?: boolean;
    disabled?: boolean;
  };

const PasswordInput = forwardRef<RNTextInput, PasswordInputProps>(
  (props, ref) => {
    const {
      labelProps,
      alerts,
      hasError,
      onFocus,
      onBlur,
      accessibilityLabel,
      accessibilityHint,
      testID = "password-input",
      ...otherProps
    } = props;

    const { disabled } = otherProps;

    const localRef = useRef<RNTextInput>(null);
    const mergedRefs = useMergeRefs([localRef, ref]);

    const { tokens } = useDesignTokens();
    const stateStyles = useStateStyles({ disabled });

    const [type, setType] = useState<InputType>("password");
    const [hasFocus, setHasFocus] = useState(false);

    const handleFocus = useCallback<NonNullable<typeof onFocus>>(
      (evt) => {
        setHasFocus(true);
        onFocus?.(evt);
      },
      [onFocus]
    );

    const handleBlur = useCallback<NonNullable<typeof onBlur>>(
      (evt) => {
        setHasFocus(false);
        onBlur?.(evt);
      },
      [onBlur]
    );

    const accessibilityHints =
      [
        accessibilityHint || labelProps?.labelHint,
        ...(alerts || []).map((alert) => alert.children),
      ]
        .filter(Boolean)
        .join(" ") || undefined;

    function handleButtonPress() {
      setType(type === "password" ? "text" : "password");
    }

    function focusElement() {
      localRef.current?.focus();
    }

    return (
      <InputWrapper alert={alerts && <InputAlerts alerts={alerts} />}>
        <InputLabelTop {...labelProps}>
          <OuterFieldV2
            hasFocus={hasFocus}
            hasError={hasError}
            isDisabled={disabled}
            isActive={hasFocus}
            buttonSlot={
              !disabled && (
                <View style={{ margin: -8 }}>
                  <IconButton
                    onPress={handleButtonPress}
                    aria-label={
                      type === "password" ? "Show password" : "Hide password"
                    }
                  >
                    {type === "password" ? <VisibleIcon /> : <InvisibleIcon />}
                  </IconButton>
                </View>
              )
            }
            focusElement={focusElement}
          >
            <KeyboardExtendedInput
              {...otherProps}
              tintType="none"
              onFocusChange={(isFocused) => {
                setHasFocus(isFocused);
              }}
              ref={mergedRefs}
              onFocus={handleFocus}
              onBlur={handleBlur}
              editable={!disabled}
              allowFontScaling={false}
              selectionColor={tokens.textInput.selectionColor}
              placeholderTextColor={tokens.textInput.color.placeholder}
              secureTextEntry={type === "password"}
              style={stateStyles.text}
              accessibilityLabel={accessibilityLabel || labelProps?.label}
              accessibilityHint={accessibilityHints}
              testID={testID}
            />
          </OuterFieldV2>
        </InputLabelTop>
      </InputWrapper>
    );
  }
);

PasswordInput.displayName = "PasswordInput";

export default PasswordInput;
