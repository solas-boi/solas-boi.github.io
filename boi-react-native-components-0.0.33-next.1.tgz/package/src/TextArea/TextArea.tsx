import { forwardRef, useCallback, useRef, useState } from "react";
import {
  View,
  TextInput as RNTextInput,
  ScrollView,
  type TextInputProps as RNTextInputProps,
  type NativeSyntheticEvent,
  type NativeScrollEvent,
} from "react-native";
import { KeyboardExtendedInput } from "react-native-external-keyboard";
import {
  CoreTextArea,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { useStateStyles } from "./TextArea.styles";
import { InnerShadow } from "./InnerShadow";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { OuterField } from "../OuterField";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { CharactersCounter } from "../CharactersCounter";
import { useSimpleA11yProps } from "../hooks";

export type TextAreaProps = PropsWithOptionalTestID &
  Omit<
    RNTextInputProps,
    "style" | "editable" | "selectionColor" | "numberOfLines"
  > & {
    noCounter?: boolean;
    hasError?: boolean;
    readonly?: boolean;
    disabled?: boolean;
    autoGrow?: boolean;
    autoGrowMaxLines?: number;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    labelProps: Omit<InputLabelTopProps, "children">;
  };

const TextArea = forwardRef<RNTextInput, TextAreaProps>((props, ref) => {
  const {
    testID = "textarea",
    labelProps,
    alertProps,
    autoGrow,
    autoGrowMaxLines,
    disabled,
    readonly,
    hasError,
    accessibilityLabel,
    accessibilityHint,
    onChangeText,
    onFocus,
    onBlur,
    onScroll,
    noCounter,
    ...inputProps
  } = props;
  const scrollViewRef = useRef<ScrollView>(null);

  const { maxLength } = inputProps;

  const showCounter = !noCounter && maxLength;

  const { tokens } = useDesignTokens();
  const [displayInnerShadow, setDisplayInnerShadow] =
    useState<CoreTextArea.DisplayInnerShadow>(null);
  const [hasFocus, setHasFocus] = useState(false);
  const handleFocus = useCallback<NonNullable<typeof onFocus>>(
    (evt) => {
      setHasFocus(true);
      onFocus?.(evt);
    },
    [onFocus]
  );
  const handleBlur = useCallback<NonNullable<typeof onBlur>>(
    (evt) => {
      setHasFocus(false);
      onBlur?.(evt);
    },
    [onBlur]
  );

  const styles = useStateStyles({
    hasFocus,
    isDisabled: disabled,
    isReadOnly: readonly,
    autoGrow,
    autoGrowMaxLines,
  });

  const [length, setLength] = useState(
    (inputProps.value || inputProps.defaultValue)?.length || 0
  );
  const handleChangeText = useCallback(
    (newValue: string) => {
      setLength(newValue.length);
      onChangeText?.(newValue);
    },
    [onChangeText]
  );

  const handleScroll = useCallback(
    (evt: NativeSyntheticEvent<NativeScrollEvent>) => {
      const { contentOffset, layoutMeasurement, contentSize } = evt.nativeEvent;

      const innerShadowToDisplay = CoreTextArea.determineInnerShadowToDisplay(
        contentOffset.y,
        contentSize.height,
        layoutMeasurement.height
      );
      setDisplayInnerShadow(innerShadowToDisplay);

      onScroll?.(evt);
    },
    [onScroll]
  );

  const simpleA11yProps = useSimpleA11yProps(props);

  return (
    <InputWrapper
      gap={showCounter ? 4 : 8}
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <OuterField
          hasError={hasError}
          hasFocus={hasFocus}
          isActive={hasFocus}
          isDisabled={disabled}
          isReadOnly={readonly}
        >
          <InnerShadow
            testID={`${testID}-top-innershadow`}
            type="TOP"
            show={displayInnerShadow === "TOP" || displayInnerShadow === "BOTH"}
          />

          <InnerShadow
            testID={`${testID}-bottom-innershadow`}
            type="BOTTOM"
            show={
              displayInnerShadow === "BOTTOM" || displayInnerShadow === "BOTH"
            }
          />

          <ScrollView
            testID={`${testID}-scrollview`}
            ref={scrollViewRef}
            onScroll={handleScroll}
            scrollEventThrottle={10}
            style={styles.scrollView}
            contentContainerStyle={styles.scrollViewContent}
            scrollEnabled={true}
            overScrollMode="never"
          >
            <KeyboardExtendedInput
              {...inputProps}
              {...simpleA11yProps}
              tintType="none"
              onFocusChange={(isFocused) => {
                setHasFocus(isFocused);
              }}
              ref={ref}
              testID={testID}
              style={styles.input}
              selectionColor={tokens.textInput.selectionColor}
              placeholderTextColor={tokens.textInput.color.placeholder}
              editable={!disabled && !readonly}
              onChangeText={handleChangeText}
              onFocus={handleFocus}
              onBlur={handleBlur}
              scrollEnabled={false}
              allowFontScaling={false}
              multiline
            />
          </ScrollView>
        </OuterField>
      </InputLabelTop>
      {showCounter ? (
        <CharactersCounter
          length={length}
          maxLength={maxLength}
          testID={`${testID}-characters-counter`}
        />
      ) : undefined}
    </InputWrapper>
  );
});

TextArea.displayName = "TextArea";

export default TextArea;
