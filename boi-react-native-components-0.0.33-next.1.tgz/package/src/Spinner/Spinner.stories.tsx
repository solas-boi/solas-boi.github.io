import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  getThemeTokens,
} from "@boi/react-native-design-tokens";
import { getColorSelectArgType } from "@boi/react-utils";

import Spinner from "./Spinner";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const {
  light: { color, spinner },
} = getThemeTokens("boi");

const meta = {
  title: "Data Display/Spinner",
  component: Spinner,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args: any) {
    return <Spinner {...args} />;
  },
  argTypes: {
    ...designTokensArgTypes,
    color: getColorSelectArgType(color),
    size: { control: { type: "number" } },
    variant: {
      control: { type: "select" },
      options: Object.keys(spinner.variants),
    },
  },
  args: {
    ...designTokensArgs,
    size: 108,
    variant: "default",
    "aria-label": "Loading...",
  },
} satisfies Meta<typeof Spinner>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
