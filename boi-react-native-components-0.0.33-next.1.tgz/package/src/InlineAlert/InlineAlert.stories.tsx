import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";
import { ALERT_SEVERITIES } from "@boi/components-core";

import InlineAlert from "./InlineAlert";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Feedback/InlineAlert",
  component: InlineAlert,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    severity: {
      control: { type: "select" },
      options: ALERT_SEVERITIES,
    },
    children: { control: { type: "text" } },
  },
  args: {
    ...designTokensArgs,
    severity: "info",
    children: "Alert message text",
  },
} satisfies Meta<typeof InlineAlert>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
