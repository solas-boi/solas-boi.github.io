import { ScrollView } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { capitalizeString } from "@boi/js-utils";
import { getColorSelectArgType } from "@boi/react-utils";
import {
  getThemeTokens,
  DesignTokensDecorator,
} from "@boi/react-native-design-tokens";
import { CoreTypography } from "@boi/components-core";

import Typography from "./Typography";
import { TYPOGRAPHY_COMPONENTS } from "./Typography.constants";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const {
  light: { color },
} = getThemeTokens("boi");

const meta = {
  title: "Data Display/Typography",
  component: Typography,
  decorators: [
    (Story, { args, globals }) => {
      // We can only change the fontFamily of non-heading text
      globals.isHeadingVariant = CoreTypography.HEADING_VARIANTS.includes(
        args.variant
      );
      return (
        <DesignTokensDecorator brandTheme={args.brandTheme}>
          <Story />
        </DesignTokensDecorator>
      );
    },
  ],
  argTypes: {
    ...designTokensArgTypes,
    variant: {
      control: { type: "select" },
      options: CoreTypography.VARIANTS,
    },
    fontFamily: {
      control: { type: "select" },
      options: CoreTypography.FONT_FAMILIES,
      if: {
        global: "isHeadingVariant",
        truthy: false,
      },
    },
    component: {
      control: { type: "select" },
      options: TYPOGRAPHY_COMPONENTS,
    },
    color: getColorSelectArgType(color),
    children: { control: { type: "text" } },
  },
  args: {
    ...designTokensArgs,
  },
} satisfies Meta<typeof Typography>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    testID: "fake-data-test-id",
    children: "This is some text",
  },
};

export const Examples: Story = {
  argTypes: {
    variant: { control: { disable: true } },
    component: { control: { disable: true } },
    color: { control: { disable: true } },
  },
  render: function Render(args: any) {
    const { children, ...rest } = args;

    return (
      <ScrollView>
        {CoreTypography.VARIANTS.map((variant) => (
          <Typography
            key={variant}
            variant={variant}
            children={children || capitalizeString(variant)}
            {...rest}
          />
        ))}
      </ScrollView>
    );
  },
};
