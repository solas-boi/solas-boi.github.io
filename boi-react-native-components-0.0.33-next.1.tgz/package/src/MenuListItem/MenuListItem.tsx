import { PropsWithChildren, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { type PropsWithOptionalTestID } from "@boi/components-core";

import useStyles, { useStateStyles } from "./MenuListItem.styles";
import { KeyboardPressableProps } from "../types";
import { MenuItem } from "../Menu/Menu.types";

export type MenuListItemProps<T extends MenuItem> = PropsWithOptionalTestID &
  PropsWithChildren &
  Pick<KeyboardPressableProps, "onPress"> & {
    data: T;
    isDisabled?: boolean;
  };

function MenuListItem<T extends MenuItem>(props: MenuListItemProps<T>) {
  const { data, onPress, isDisabled, testID, children } = props;

  const styles = useStyles();
  const stateStyles = useStateStyles();

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  return (
    <KeyboardPressable
      tintType="none"
      role="button"
      accessibilityRole="button"
      enableA11yFocus
      disabled={isDisabled}
      onFocusChange={handleKeyboardFocusChange}
      style={styles.listItem}
      onPress={onPress}
      testID={`${testID}-item-${data.id}`}
    >
      {({ pressed }) => (
        <View
          style={stateStyles.listItemContentWrapper(pressed, hasKeyboardFocus)}
        >
          {children}
        </View>
      )}
    </KeyboardPressable>
  );
}

export default MenuListItem;
