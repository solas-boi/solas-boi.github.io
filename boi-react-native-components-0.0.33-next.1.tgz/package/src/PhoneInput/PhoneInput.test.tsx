import { useState } from "react";
import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import PhoneInput, { type PhoneInputProps } from "./PhoneInput";
import { MOCK_COUNTRY_ITEMS } from "./PhoneInput.mocks";

jest.useFakeTimers();

const INITIAL_SELECTED_ITEM = MOCK_COUNTRY_ITEMS.find((item) => {
  return item.id === "IE";
});

function WrappedPhoneInput(props: PhoneInputProps) {
  return (
    <DesignTokensProvider>
      <PhoneInput {...props} />
    </DesignTokensProvider>
  );
}

describe("PhoneInput", () => {
  let baseProps: PhoneInputProps;

  beforeEach(() => {
    baseProps = {
      labelProps: {
        label: "PhoneInput label",
      },
    };
  });

  it("should render the correct label when provided", () => {
    render(
      <WrappedPhoneInput {...baseProps}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    const countryCombobox = screen.getAllByLabelText(/PhoneInput label/)[0];
    const numberInput = screen.getAllByLabelText(/PhoneInput label/)[1];

    expect(countryCombobox).toBeDefined();
    expect(numberInput).toBeDefined();
  });

  it("should render the correct label hint when provided", () => {
    render(
      <WrappedPhoneInput
        {...baseProps}
        labelProps={{
          ...baseProps.labelProps,
          labelHint: "Additional information",
        }}
      >
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    const countryCombobox = screen.getAllByHintText(
      /Additional information/
    )[0];

    const numberInput = screen.getAllByHintText(/Additional information/)[1];

    expect(countryCombobox).toBeDefined();
    expect(numberInput).toBeDefined();
  });

  it("should render the correct alerts when provided", () => {
    render(
      <WrappedPhoneInput
        {...baseProps}
        alertProps={{
          country: [
            {
              severity: "error",
              children: "Country: Something went wrong",
            },
          ],
          number: [
            {
              severity: "error",
              children: "Number: Something went wrong",
            },
          ],
        }}
      >
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    const countryCombobox = screen.getAllByHintText(
      /Country: Something went wrong/
    );

    const numberInput = screen.getAllByHintText(/Number: Something went wrong/);

    expect(countryCombobox).toBeDefined();
    expect(numberInput).toBeDefined();
  });

  it("should only accept numeric characters and spaces", async () => {
    const user = userEvent.setup();
    const mockOnChange = jest.fn();

    render(
      <WrappedPhoneInput {...baseProps}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number
          onChange={mockOnChange}
          testID="phone-input-number"
        />
      </WrappedPhoneInput>
    );

    const numberInput = screen.getByTestId("phone-input-number");

    await act(async () => {
      await user.type(numberInput, "- 3 abc 1 -");
    });

    expect(mockOnChange).toHaveBeenCalledWith(
      expect.objectContaining({
        nativeEvent: expect.objectContaining({
          text: " 3  1 ",
        }),
      })
    );
  });

  it("should update the prefix when the country changes", async () => {
    const user = userEvent.setup();

    function WrappedCountry() {
      const [selectedItem, setSelectedItem] = useState<any>(
        INITIAL_SELECTED_ITEM
      );

      return (
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={selectedItem}
          onChange={setSelectedItem}
        />
      );
    }

    render(
      <WrappedPhoneInput {...baseProps}>
        <WrappedCountry />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    const combobox = await screen.findByTestId("country-combobox");

    await act(async () => {
      await user.press(combobox);
    });

    const secondOption = screen.getAllByRole("radio")[1]!;

    await act(async () => {
      await user.press(secondOption);
    });

    await screen.findByTestId("country-combobox-modal", { hidden: true });

    const prefix = await screen.findByTestId("input-prefix");

    expect(prefix).toHaveTextContent("+44");
  });

  it("should render with a default testID", () => {
    render(
      <WrappedPhoneInput {...baseProps}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    expect(screen.getByTestId("phone-input")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-phone-input";

    render(
      <WrappedPhoneInput {...baseProps} testID={testID}>
        <PhoneInput.Country
          items={MOCK_COUNTRY_ITEMS}
          selectedItem={INITIAL_SELECTED_ITEM}
          onChange={() => {}}
        />
        <PhoneInput.Number />
      </WrappedPhoneInput>
    );

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
