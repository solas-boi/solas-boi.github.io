import { forwardRef } from "react";
import { View } from "react-native";
import { LinkWithIcon, LinkWithIconProps } from "../LinkWithIcon";

export type LinkProps = Omit<LinkWithIconProps, "startIcon" | "endIcon">;

const Link = forwardRef<View, LinkProps>((props, ref) => {
  return <LinkWithIcon {...props} ref={ref} />;
});
Link.displayName = "Link";

export default Link;
