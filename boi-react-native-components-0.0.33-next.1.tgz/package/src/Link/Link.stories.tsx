import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { CoreLink } from "@boi/components-core";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import Link from "./Link";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/Link",
  component: Link,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    variant: {
      control: { type: "select" },
      options: CoreLink.VARIANTS,
    },
    children: { control: { type: "text" } },
  },
  args: {
    ...designTokensArgs,
    variant: CoreLink.DEFAULT_VARIANT,
    children: "Text link label",
  },
} satisfies Meta<typeof Link>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
