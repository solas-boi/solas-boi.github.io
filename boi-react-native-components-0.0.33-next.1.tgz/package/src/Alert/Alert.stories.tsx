import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";
import {
  CoreAlert,
  ALERT_SEVERITIES,
  HEADING_LEVELS,
} from "@boi/components-core";

import Alert from "./Alert";
import { Link } from "../Link";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Feedback/Alert",
  component: Alert,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    severity: {
      control: { type: "select" },
      options: ALERT_SEVERITIES,
    },
    heading: { control: { type: "text" } },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
    children: { control: { disable: true } },
  },
  args: {
    ...designTokensArgs,
    severity: CoreAlert.DEFAULT_SEVERITY,
    heading: "Alert heading",
    headingLevel: CoreAlert.DEFAULT_HEADING_LEVEL,
  },
} satisfies Meta<typeof Alert>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Dismissible: Story = {
  args: {
    onRequestClose: () => {},
  },
};

export const WithBody: Story = {
  args: {
    children: (
      <>
        <Alert.Typography>Body message text and</Alert.Typography>
        <Link onPress={() => {}}>text link if necessary</Link>
      </>
    ),
  },
};

export const WithBodyDismissible: Story = {
  args: {
    children: (
      <>
        <Alert.Typography>Body message text and</Alert.Typography>
        <Link onPress={() => {}}>text link if necessary</Link>
      </>
    ),
    onRequestClose: () => {},
  },
};
