import { type TextInputProps } from "react-native";

import { type LabelProps } from "./useA11yHintPropWithAlerts";

export type A11yLabelProp = Pick<TextInputProps, "accessibilityLabel">;

type HookParams = A11yLabelProp & {
  labelProps?: LabelProps;
};

export const useA11yLabelProp = ({
  accessibilityLabel,
  labelProps,
}: HookParams): A11yLabelProp => ({
  accessibilityLabel: `${
    accessibilityLabel?.trim() || labelProps?.label?.trim() || ""
  }`,
});

export default useA11yLabelProp;
