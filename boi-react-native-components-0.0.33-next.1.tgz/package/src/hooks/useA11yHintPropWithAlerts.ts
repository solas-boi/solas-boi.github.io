import { type TextInputProps } from "react-native";

import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";

export type AlertProps =
  | InputAlertsProps["alerts"][number]
  | InputAlertsProps["alerts"]
  | undefined;

export type LabelProps = Omit<InputLabelTopProps, "children">;

export type A11yHintProp = Pick<TextInputProps, "accessibilityHint">;

type HookParams = A11yHintProp & {
  alertProps?: AlertProps;
  labelProps?: LabelProps;
};

export const useA11yHintPropWithAlerts = ({
  accessibilityHint,
  alertProps,
  labelProps,
}: HookParams): A11yHintProp => {
  const alertTexts = (
    Array.isArray(alertProps)
      ? `. ${alertProps.map((el) => el.children).join(" ")}`
      : alertProps
      ? `. ${alertProps.children}`
      : ""
  ).trim();

  const alertTextsWith1Hint = accessibilityHint
    ? `${alertTexts} ${accessibilityHint.trim()}`.trim()
    : alertTexts;

  const alertTextsWith2Hints = labelProps?.labelHint
    ? `${alertTextsWith1Hint} ${labelProps?.labelHint.trim()}`.trim()
    : alertTextsWith1Hint;

  return {
    accessibilityHint: alertTextsWith2Hints,
  };
};

export default useA11yHintPropWithAlerts;