import { renderHook } from "@testing-library/react-native";
import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";
import { useA11yHintPropWithAlerts } from "./useA11yHintPropWithAlerts";

type AlertProps =
  | InputAlertsProps["alerts"][number]
  | InputAlertsProps["alerts"]
  | undefined;

type LabelProps = Omit<InputLabelTopProps, "children">;

const testCase = (
  name: string,
  accessibilityHint: string | undefined,
  alertProps: AlertProps | undefined,
  labelPropHint: string | undefined,
  expectedAccessibilityHint: { expected: string } | undefined
): (string | undefined | AlertProps | LabelProps | { expected: string })[] => [
  name,
  accessibilityHint,
  alertProps,
  labelPropHint,
  expectedAccessibilityHint,
];

const testCases = [
  testCase(
    "the empty string when no accessibility hint or alert / label props are supplied",
    undefined,
    undefined,
    undefined,
    { expected: "" }
  ),
  testCase(
    "the supplied accessibility hint when an accessibility hint and no alert or label props are supplied",
    "accessibility hint",
    undefined,
    undefined,
    { expected: "accessibility hint" }
  ),
  testCase(
    "the accessibility hint concatenated with the label hint when an accessibility hint and a label hint and no alert are supplied with leading and trailing spaces",
    " accessibility hint ",
    undefined,
    " label prop hint ",
    { expected: "accessibility hint label prop hint" }
  ),

  testCase(
    "the alert message when only 1 alert is supplied",
    undefined,
    { severity: "error", children: "alert msg 1" },
    undefined,
    { expected: ". alert msg 1" }
  ),
  testCase(
    "the alert message concatenated with the accessibility hint when the accessibility hint and 1 alert are supplied",
    "accessibility hint",
    { severity: "error", children: "alert msg 1" },
    undefined,
    { expected: ". alert msg 1 accessibility hint" }
  ),
  testCase(
    "the alert message concatenated with the accessibility hint and the label hint when the accessibility hint and label hint and 1 alert are supplied",
    "accessibility hint",
    { severity: "error", children: "alert msg 1" },
    "label prop hint",
    { expected: ". alert msg 1 accessibility hint label prop hint" }
  ),

  testCase(
    "the alert message when only 2 alerts are supplied",
    undefined,
    [
      { severity: "error", children: "alert msg 1" },
      { severity: "error", children: "alert msg 2" },
    ],
    undefined,
    { expected: ". alert msg 1 alert msg 2" }
  ),

  testCase(
    "the alert message concatenated with the accessibility hint when the accessibility hint and 2 alerts are supplied",
    "accessibility hint",
    [
      { severity: "error", children: "alert msg 1" },
      { severity: "error", children: "alert msg 2" },
    ],
    undefined,
    { expected: ". alert msg 1 alert msg 2 accessibility hint" }
  ),

  testCase(
    "the alert message concatenated with the accessibility hint and the label hint when the accessibility hint and label hint and 2 alerts are supplied",
    "accessibility hint",
    [
      { severity: "error", children: "alert msg 1" },
      { severity: "error", children: "alert msg 2" },
    ],
    "label prop hint",
    { expected: ". alert msg 1 alert msg 2 accessibility hint label prop hint" }
  ),
];

const processTestCases = (
  _: any,
  accessibilityHint: any,
  alertProps: any,
  labelPropHint: any,
  expectedAccessibilityHint: any
) => {
  const { result } = renderHook(() =>
    useA11yHintPropWithAlerts({
      accessibilityHint: accessibilityHint as string | undefined,
      alertProps: alertProps as AlertProps,
      labelProps: { labelHint: labelPropHint } as LabelProps,
    })
  );

  expect(result.current).toEqual(
    expect.objectContaining({
      accessibilityHint: expectedAccessibilityHint.expected as string,
    })
  );
};

describe("useAccessibilityHintPropWithAlerts", () => {
  describe("returns object with property 'accessibilityHint' that is ", () => {
    test.each(testCases)("%p", processTestCases);
  });
});
