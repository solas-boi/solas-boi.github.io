import { forwardRef, type PropsWithChildren } from "react";
import { View } from "react-native";
import {
  CoreButtonGroup,
  type PropsWithOptionalTestID,
} from "@boi/components-core";

import { useStateStyles } from "./ButtonGroup.styles";
import type { Item } from "./ButtonGroup.types";
import { ButtonGroupItem, type ButtonGroupItemProps } from "./ButtonGroupItem";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { Fieldset, type FieldsetProps } from "../Fieldset";

export type ButtonGroupProps = PropsWithOptionalTestID &
  Pick<ButtonGroupItemProps, "typographyVariant"> &
  Omit<FieldsetProps, "children" | "role"> &
  PropsWithChildren<{
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    variant?: CoreButtonGroup.Variant;
    items: Item[];
    onChange: (items: Item[]) => void;
  }>;

const ButtonGroup = forwardRef<View, ButtonGroupProps>((props, ref) => {
  const {
    alertProps,
    variant = CoreButtonGroup.DEFAULT_VARIANT,
    items,
    legend,
    legendHint,
    legendTooltipProps,
    legendHintTooltipProps,
    onChange,
    typographyVariant,
    testID = "button-group",
  } = props;

  const stateStyles = useStateStyles({ variant });

  function handlePress(pressedItem: Item) {
    const updatedItems = items.map((item) => {
      if (item === pressedItem) {
        return { ...item, isChecked: true };
      }

      return { ...item, isChecked: false };
    });

    onChange(updatedItems);
  }

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <Fieldset
        legend={legend}
        legendHint={legendHint}
        legendTooltipProps={legendTooltipProps}
        legendHintTooltipProps={legendHintTooltipProps}
        role="radiogroup"
        testID={testID}
      >
        <View ref={ref} role="list" style={stateStyles.container}>
          {items.map((item, index) => (
            // eslint-disable-next-line react-native-a11y/has-accessibility-hint
            <ButtonGroupItem
              key={item.id}
              label={item.label}
              hasError={item.hasError}
              fullWidth={["stretch", "stacked"].includes(variant)}
              textAlign={variant === "stacked" ? "left" : "center"}
              typographyVariant={typographyVariant}
              value={item.value}
              isChecked={item.isChecked}
              onPress={() => handlePress(item)}
              testID={`${testID}-item-${item.id}`}
              accessibilityLabel={`${item.label}, ${index + 1} of ${
                items.length
              }`}
            />
          ))}
        </View>
      </Fieldset>
    </InputWrapper>
  );
});

ButtonGroup.displayName = "ButtonGroup";

export default ButtonGroup;
