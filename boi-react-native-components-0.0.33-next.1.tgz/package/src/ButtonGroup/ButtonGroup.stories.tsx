import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import { CoreButtonAlt, CoreButtonGroup } from "@boi/components-core";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import ButtonGroup from "./ButtonGroup";
import { mockButtonGroup, mockErrorButtonGroup } from "./ButtonGroup.mocks";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/ButtonGroup",
  component: ButtonGroup,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <Story />
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    function handleChange(items: any) {
      updateArgs({ items });
      action("onChange")();
    }

    return (
      <View style={{ padding: 10 }}>
        <ButtonGroup {...args} onChange={handleChange} />
      </View>
    );
  },
  argTypes: {
    ...designTokensArgTypes,
    alertProps: { control: { disable: true } },
    variant: {
      control: { type: "select" },
      options: CoreButtonGroup.VARIANTS,
    },
    items: { control: { disable: true } },
    typographyVariant: {
      control: { type: "select" },
      options: CoreButtonAlt.TYPOGRAPHY_VARIANTS,
    },
  },
  args: {
    ...designTokensArgs,
    variant: CoreButtonGroup.DEFAULT_VARIANT,
    items: mockButtonGroup.items,
    typographyVariant: CoreButtonAlt.DEFAULT_TYPOGRAPHY_VARIANT,
  },
} satisfies Meta<typeof ButtonGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const WithLegend: Story = {
  ...Basic,
  args: {
    legend: "ButtonGroup legend",
    legendTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    legend: "ButtonGroup legend",
    legendHint: "Additional information",
    legendHintTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithError: Story = {
  args: {
    items: mockErrorButtonGroup.items,
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};
