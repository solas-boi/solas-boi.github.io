import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import ResponsiveTable from "./ResponsiveTable";
import { mockResponsiveTableProps } from "./ResponsiveTable.mocks";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Data Display/ResponsiveTable",
  component: ResponsiveTable,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    minWidth: {
      control: "number",
      description:
        "The minimum width of the container, in pixels, needed to display the table in full.",
    },
  },
  args: {
    ...designTokensArgs,
  },
} satisfies Meta<typeof ResponsiveTable>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: { ...mockResponsiveTableProps },
};
