import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import AccordionGroup from "./AccordionGroup";
import { Typography } from "../Typography";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Surfaces/AccordionGroup",
  component: AccordionGroup,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    items: { control: { disable: true } },
  },
  args: {
    ...designTokensArgs,
    items: [
      {
        title: "What is a loan?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
      {
        title: "How do I apply for a loan?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
      {
        title: "What types of loan do Bank of Ireland offer?",
        content: (
          <Typography>
            You can apply online, over the phone or in your branch.
          </Typography>
        ),
      },
    ],
  },
} satisfies Meta<typeof AccordionGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Nested: Story = {
  args: {
    items: [
      {
        title: "What is the Bank of Ireland UK ISA?",
        content: [
          {
            title: "How does it work?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
          {
            title: "What does my holding account do?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
          {
            title: "Do I pay tax on my savings in an ISA?",
            content: (
              <Typography>
                You can apply online, over the phone or in your branch.
              </Typography>
            ),
          },
        ],
      },
    ],
  },
};
