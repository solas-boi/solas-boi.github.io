import { memo, useLayoutEffect, useRef, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { CoreSelect } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { TickIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./SelectItem.styles";
import { Typography } from "../../Typography";

export type SelectItemProps = {
  item: CoreSelect.SelectItem;
  isFirst: boolean;
  isLast: boolean;
  onPress: () => void;
  isSelected: boolean;
  isDisabled: boolean;
};

const SelectItem = memo((props: SelectItemProps) => {
  const { item, onPress, isSelected, isDisabled, isFirst, isLast } = props;

  const { tokens } = useDesignTokens();
  const { select } = tokens;

  const styles = useStyles();
  const stateStyles = useStateStyles(isFirst, isLast, isDisabled);

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) =>
    setHasKeyboardFocus(isFocused);

  // TODO: This workaround was added to fix the issue CP-82975. Ideally we should use the <Pressable /> component provided either by the "react-native" or "react-native-gesture-handler"
  // But the one provided by "react-native" was causing the issue reported on CP-82975
  // On the other hand, the one provided by "react-native-gesture-handler" had some layout problems and was not behaving as expected on Android by never returning the state `pressed` as true.
  // We should come back to this after a react-native version upgrade, revert the workaround changes and check it is still an issue. Last seen at version 0.74.5
  const [pressed, setPressed] = useState(false);
  const ref = useRef<View>(null);
  useLayoutEffect(() => {
    if (isSelected) {
      ref.current?.focus();
    }
  }, [isSelected]);

  return (
    <KeyboardPressable
      ref={ref}
      accessible
      enableA11yFocus
      style={stateStyles.container}
      accessibilityRole="radio"
      role="radio"
      accessibilityLabel={item.ariaLabel || item.title}
      accessibilityHint={!isSelected ? "Selects the item" : undefined}
      accessibilityState={{ selected: isSelected }}
      disabled={isDisabled}
      onAccessibilityTap={onPress}
      onFocusChange={handleKeyboardFocusChange}
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      <View style={stateStyles.contentWrapper(pressed || hasKeyboardFocus)}>
        <View style={styles.content}>
          <View style={styles.tickIconWrapper}>
            {isSelected && (
              <TickIcon
                color={select.menu.option.inner.tickIcon.color}
                width={select.menu.option.inner.tickIcon.width}
                height={select.menu.option.inner.tickIcon.height}
              />
            )}
          </View>

          <View style={styles.typographyWrapper}>
            <Typography style={stateStyles.text}>{item.title}</Typography>
          </View>
        </View>
      </View>
    </KeyboardPressable>
  );
});

export default SelectItem;
