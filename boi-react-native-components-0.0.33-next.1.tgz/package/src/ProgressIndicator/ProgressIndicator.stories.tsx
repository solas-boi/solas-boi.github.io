import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import ProgressIndicator from "./ProgressIndicator";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";
import { CoreProgressIndicator } from "@boi/components-core";

const meta = {
  title: "Data Display/ProgressIndicator",
  component: ProgressIndicator,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    totalSteps: { control: "number" },
    currentStep: { control: "number" },
    backgroundVariant: {
      control: "select",
      options: CoreProgressIndicator.BACKGROUND_VARIANTS,
    },
  },
  args: {
    ...designTokensArgs,
    totalSteps: 5,
    currentStep: 3,
    backgroundVariant: "alt",
  },
} satisfies Meta<typeof ProgressIndicator>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {},
};
