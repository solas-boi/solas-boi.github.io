import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";
import { CoreAccordion, HEADING_LEVELS } from "@boi/components-core";

import Accordion from "./Accordion";
import { Typography } from "../Typography";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Surfaces/Accordion",
  component: Accordion,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    content: { control: { disable: true } },
    variant: {
      control: { type: "select" },
      options: CoreAccordion.VARIANTS,
    },
    headingLevel: {
      control: { type: "select" },
      options: HEADING_LEVELS,
    },
  },
  args: {
    ...designTokensArgs,
    title: "How do I apply for a loan?",
    headingLevel: CoreAccordion.DEFAULT_HEADING_LEVEL,
    content: (
      <Typography>
        You can apply online, over the phone or in your branch.
      </Typography>
    ),
  },
} satisfies Meta<typeof Accordion>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};
