import { View, Text, Platform } from "react-native";
import { render, screen, waitFor } from "@testing-library/react-native";
import { useAccessibilityInfo } from "@react-native-community/hooks";
import DeviceInfo from "react-native-device-info";

import Modal, { type ModalProps } from "./Modal";
import { useEffect } from "react";
import type { FocusableComponent } from "../types";

const useMockStyles = (
  isOpen: boolean,
  setVisible: (visible: boolean) => void
) => {
  useEffect(() => {
    if (isOpen) {
      setVisible(true);
    } else {
      setVisible(false);
    }
  }, [isOpen, setVisible]);

  return {
    backdrop: { flex: 1 },
    container: { flex: 1 },
    sheet: { backgroundColor: "white" },
    avoidingViewContainer: { flex: 1 },
    hiddenContainer: { position: "absolute" },
  };
};

jest.mock("./Modal.styles", () => ({
  useStateStyles: jest.fn(useMockStyles),
}));

jest.mock("react-native-reanimated", () => ({
  ...jest.requireActual("react-native-reanimated/mock"),
  useSharedValue: jest.fn(() => ({ value: 0 })),
  useAnimatedStyle: jest.fn(() => ({})),
  withTiming: jest.fn((value, config, callback) => {
    if (callback) {
      callback(true);
    }
    return value;
  }),
  runOnJS: jest.fn((fn) => fn),
}));

jest.mock("@react-native-community/hooks", () => ({
  useAccessibilityInfo: jest.fn(() => ({ screenReaderEnabled: false })),
}));

jest.mock("react-native-device-info", () => ({
  isTablet: jest.fn(() => false),
}));

jest.mock("../utils/setAccessibilityFocus", () => ({
  setAccessibilityFocus: jest.fn(),
}));

const mockAnnounceForAccessibility = jest.fn();
jest
  .spyOn(require("react-native").AccessibilityInfo, "announceForAccessibility")
  .mockImplementation(mockAnnounceForAccessibility);

describe("Modal", () => {
  let baseProps: ModalProps;

  beforeEach(() => {
    jest.clearAllMocks();
    baseProps = {
      isOpen: false,
      children: (
        <View>
          <Text testID="modal-content">Modal Content</Text>
        </View>
      ),
    };
  });

  it("should render modal content when isOpen is true", () => {
    render(<Modal {...baseProps} isOpen />);

    expect(screen.getByTestId("modal-content")).toBeDefined();
  });

  it("should not render modal content when isOpen is false", () => {
    render(<Modal {...baseProps} isOpen={false} />);

    expect(screen.queryByTestId("modal-content")).toBeNull();
  });

  it("should render with accessibility label", () => {
    const accessibilityLabel = "Custom modal";

    render(
      <Modal
        {...baseProps}
        isOpen
        accessibilityHint=""
        accessibilityLabel={accessibilityLabel}
      />
    );

    expect(
      screen.getByLabelText(`${accessibilityLabel}, dialog`)
    ).toBeDefined();
  });

  it("should render children correctly", () => {
    const customContent = "Custom Modal Content";

    render(
      <Modal {...baseProps} isOpen>
        <Text testID="custom-content">{customContent}</Text>
      </Modal>
    );

    expect(screen.getByTestId("custom-content")).toHaveTextContent(
      customContent
    );
  });
  describe("Focus management", () => {
    it("should call setAccessibilityFocus on iOS when modal opens", async () => {
      const {
        setAccessibilityFocus,
      } = require("../utils/setAccessibilityFocus");

      render(<Modal {...baseProps} isOpen />);

      await waitFor(() => {
        expect(setAccessibilityFocus).toHaveBeenCalled();
      });
    });
  });

  describe("Platform-specific behavior", () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    it("should announce accessibility label on Android when modal opens", () => {
      const originalOS = Platform.OS;
      Object.defineProperty(Platform, "OS", {
        value: "android",
        writable: true,
      });
      const accessibilityLabel = "Test modal";

      render(
        <Modal
          {...baseProps}
          isOpen
          accessibilityLabel={accessibilityLabel}
          accessibilityHint="Modal announcement"
        />
      );

      expect(mockAnnounceForAccessibility).toHaveBeenCalledWith(
        `${accessibilityLabel}, dialog`
      );

      // Restore original Platform.OS
      Object.defineProperty(Platform, "OS", {
        value: originalOS,
        writable: true,
      });
    });
  });
});
