import { StyleSheet } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";
import { CoreIconButton } from "@boi/components-core";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { iconButton } = tokens;

  return StyleSheet.create({
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
    wrapperVariantDefault: {
      padding: iconButton.padding.default,
    },
    wrapperVariantDefault16: {
      padding: iconButton.padding.default16,
    },
    wrapperVariantDefault20: {
      padding: iconButton.padding.default20,
    },
    wrapperVariantDefault32: {
      padding: iconButton.padding.default32,
    },
    wrapperVariantContained: {
      padding: iconButton.padding.contained,
    },
    container: {
      position: "relative",
      opacity: iconButton.inner.opacity.base,
    },
    containerDisabled: {
      opacity: iconButton.inner.opacity.disabled,
    },
    containerVariantDefault: {
      borderRadius: iconButton.inner.radius.default,
      padding: iconButton.inner.padding.default,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault16: {
      borderRadius: iconButton.inner.radius.default16,
      padding: iconButton.inner.padding.default16,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault20: {
      borderRadius: iconButton.inner.radius.default20,
      padding: iconButton.inner.padding.default20,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefault32: {
      borderRadius: iconButton.inner.radius.default32,
      padding: iconButton.inner.padding.default32,
      backgroundColor: iconButton.inner.backgroundColor.default.base,
    },
    containerVariantDefaultPressed: {
      backgroundColor: iconButton.inner.backgroundColor.default.active,
    },
    containerVariantDefault16Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default16.active,
    },
    containerVariantDefault20Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default20.active,
    },
    containerVariantDefault32Pressed: {
      backgroundColor: iconButton.inner.backgroundColor.default32.active,
    },
    containerVariantContained: {
      borderRadius: iconButton.inner.radius.contained,
      padding: iconButton.inner.padding.contained,
      backgroundColor: iconButton.inner.backgroundColor.contained.base,
    },
    containerVariantContainedPressed: {
      backgroundColor: iconButton.inner.backgroundColor.contained.active,
      borderColor: iconButton.inner.stroke.contained.color.active,
    },
    containerBorderVariantContained: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      borderRadius: iconButton.inner.radius.contained,
      borderWidth: iconButton.inner.stroke.contained.width,
      borderStyle: iconButton.inner.stroke.contained.style,
      borderColor: iconButton.inner.stroke.contained.color.base,
    },
    containerBorderVariantContainedPressed: {
      borderColor: iconButton.inner.stroke.contained.color.active,
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  variant,
  disabled,
  isPressed,
}: {
  variant: CoreIconButton.Variant;
  disabled: boolean | null | undefined;
  isPressed: boolean | undefined;
}) {
  const styles = useStyles();

  const wrapperStyles = {
    default: styles.wrapperVariantDefault,
    default16: styles.wrapperVariantDefault16,
    default20: styles.wrapperVariantDefault20,
    default32: styles.wrapperVariantDefault32,
    contained: styles.wrapperVariantContained,
  };

  const containerStyles = {
    default: styles.containerVariantDefault,
    default16: styles.containerVariantDefault16,
    default20: styles.containerVariantDefault20,
    default32: styles.containerVariantDefault32,
    contained: styles.containerVariantContained,
  };

  const containerPressedStyles = {
    default: styles.containerVariantDefaultPressed,
    default16: styles.containerVariantDefault16Pressed,
    default20: styles.containerVariantDefault20Pressed,
    default32: styles.containerVariantDefault32Pressed,
    contained: styles.containerVariantContainedPressed,
  };

  const containerBorderStyles = {
    default: undefined,
    default16: undefined,
    default20: undefined,
    default32: undefined,
    contained: styles.containerBorderVariantContained,
  };

  const containerBorderPressedStyles = {
    default: undefined,
    default16: undefined,
    default20: undefined,
    default32: undefined,
    contained: styles.containerBorderVariantContainedPressed,
  };

  return {
    wrapper: [styles.wrapper, wrapperStyles[variant]],
    container: [
      styles.container,
      containerStyles[variant],
      isPressed && containerPressedStyles[variant!],
      disabled && styles.containerDisabled,
    ],
    containerBorder: [
      containerBorderStyles[variant],
      isPressed && containerBorderPressedStyles[variant!],
    ],
  };
}

export default useStyles;
