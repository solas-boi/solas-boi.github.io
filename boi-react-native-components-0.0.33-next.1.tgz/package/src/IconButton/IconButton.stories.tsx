import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";
import { CoreIconButton } from "@boi/components-core";
import * as Icons from "@boi/react-native-icons";
import { getIconSelectArgType } from "@boi/react-utils";

import IconButton from "./IconButton";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/IconButton",
  component: IconButton,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    variant: {
      control: { type: "select" },
      options: CoreIconButton.VARIANTS,
    },
    disabled: { control: { type: "boolean" } },
    children: getIconSelectArgType(Icons),
  },
  args: {
    ...designTokensArgs,
    children: <Icons.PlusIcon />,
    "aria-label": "Add button",
  },
} satisfies Meta<typeof IconButton>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Default: Story = {
  argTypes: {
    variant: { control: { disable: true } },
  },
};

export const Contained: Story = {
  argTypes: {
    variant: { control: { disable: true } },
  },
  args: {
    variant: "contained",
  },
};
