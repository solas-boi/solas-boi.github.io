import { type ReactNode, type PropsWithChildren } from "react";
import {
  StyleSheet,
  View,
  Pressable,
  type TextInputProps as RNTextInputProps,
} from "react-native";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import useStyles, { useStateStyles } from "./OuterFieldV2.styles";
import { Typography, type TypographyProps } from "../Typography";

export type OuterFieldV2Props = PropsWithChildren<{
  hasError?: boolean;
  hasFocus?: boolean;
  isActive?: boolean;
  isDisabled?: boolean;
  startSlot?: ReactNode;
  innerButtonSlot?: ReactNode;
  endSlot?: ReactNode;
  buttonSlot?: ReactNode;
  focusElement: () => void;
}> &
  Pick<RNTextInputProps, "hitSlop">;

const DEFAULT_HITSLOP: RNTextInputProps["hitSlop"] = 16;

function OuterFieldV2(props: OuterFieldV2Props) {
  const {
    hasError,
    hasFocus,
    isActive,
    isDisabled,
    startSlot,
    innerButtonSlot,
    endSlot,
    buttonSlot,
    focusElement,
    hitSlop = DEFAULT_HITSLOP,
    children,
  } = props;

  const styles = useStyles();
  const stateStyles = useStateStyles({
    hasError,
    hasFocus,
    isActive,
    isDisabled,
    innerButtonSlot,
    endSlot,
    buttonSlot,
  });

  function handlePress() {
    focusElement();
  }

  return (
    <View>
      <View style={stateStyles.innerContainer}>
        <Pressable
          focusable={false}
          accessible={false}
          importantForAccessibility="no"
          style={StyleSheet.absoluteFill}
          onPress={handlePress}
          hitSlop={hitSlop}
        />

        <View style={stateStyles.column01}>
          {startSlot && (
            <View style={styles.startSlotWrapper} pointerEvents="none">
              {startSlot}
            </View>
          )}

          {children}

          {innerButtonSlot && (
            <View style={styles.innerButtonSlotWrapper}>{innerButtonSlot}</View>
          )}

          {endSlot && (
            <View style={styles.endSlotWrapper} pointerEvents="none">
              {endSlot}
            </View>
          )}
        </View>

        {buttonSlot && <View style={styles.column02}>{buttonSlot}</View>}
      </View>

      <View style={stateStyles.stroke} pointerEvents="none" />
      <View style={stateStyles.focusRing} pointerEvents="none" />
    </View>
  );
}

OuterFieldV2.Typography = function OuterFieldV2Typography(
  props: TypographyProps
) {
  const { tokens } = useDesignTokens();
  const { outerField } = tokens;

  return <Typography color={outerField.column01.startSlot.color} {...props} />;
};

export default OuterFieldV2;
