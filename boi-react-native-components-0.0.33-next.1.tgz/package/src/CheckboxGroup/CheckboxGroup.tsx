import { forwardRef, type PropsWithChildren } from "react";
import { View } from "react-native";
import { produce } from "immer";
import {
  type PropsWithOptionalTestID,
  CoreCheckboxGroup,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { Fieldset, type FieldsetProps } from "../Fieldset";
import { Checkbox, type CheckboxProps } from "../Checkbox";
import useStyles from "./CheckboxGroup.styles";

export type CheckboxGroupInput = Omit<
  CheckboxProps,
  "alertProps" | "id" | "isChecked" | "disabled" | "onPress" | "children"
> & {
  id: CheckboxProps["id"];
  isChecked: CheckboxProps["isChecked"];
  children?: CheckboxGroupInput[];
};

export type CheckboxGroupProps = PropsWithOptionalTestID &
  Omit<FieldsetProps, "children" | "role"> & {
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    inputs: CheckboxGroupInput[];
    onChange: (inputs: CheckboxGroupInput[]) => void;
  };

const CheckboxGroup = forwardRef<View, CheckboxGroupProps>((props, ref) => {
  const {
    alertProps,
    legend,
    legendHint,
    legendTooltipProps,
    legendHintTooltipProps,
    inputs,
    onChange,
    testID = "checkbox-group",
  } = props;

  const { tokens } = useDesignTokens();
  const { checkboxGroup } = tokens;

  function handlePress(inputProps: CheckboxGroupInput) {
    const updatedInputs = produce(inputs, (draft) => {
      const targetId = inputProps.id;
      const checkedProperty = "isChecked";

      CoreCheckboxGroup.updateInputs(draft, targetId, checkedProperty);
    });

    onChange(updatedInputs);
  }

  return (
    <InputWrapper
      gap={checkboxGroup.gap}
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <Fieldset
        legend={legend}
        legendHint={legendHint}
        legendTooltipProps={legendTooltipProps}
        legendHintTooltipProps={legendHintTooltipProps}
        role="checkboxgroup"
        testID={testID}
      >
        <List ref={ref}>{getComponents(inputs, handlePress)}</List>
      </Fieldset>
    </InputWrapper>
  );
});

const List = forwardRef<View, PropsWithChildren>((props, ref) => {
  const styles = useStyles();
  return <View ref={ref} role="list" style={styles.list} {...props} />;
});

function ListItem(props: PropsWithChildren) {
  const styles = useStyles();
  return <View role="listitem" style={styles.listItem} {...props} />;
}

function NestedList(props: PropsWithChildren) {
  const styles = useStyles();
  return <View role="list" style={styles.nestedList} {...props} />;
}

function getComponents(
  inputs: CheckboxGroupInput[],
  handlePress: (inputProps: CheckboxGroupInput) => void
): JSX.Element[] {
  return inputs.map(({ children, ...inputProps }, index) => {
    return (
      <ListItem key={index}>
        {/* eslint-disable-next-line react-native-a11y/has-accessibility-hint*/}
        <Checkbox
          {...inputProps}
          accessibilityLabel={`${inputProps.labelProps.label}, ${
            index + 1
          } of ${inputs.length}`}
          onPress={() => handlePress(inputProps)}
        />
        {children && children.length > 0 ? (
          <NestedList>{getComponents(children, handlePress)}</NestedList>
        ) : undefined}
      </ListItem>
    );
  });
}

CheckboxGroup.displayName = "CheckboxGroup";

export default CheckboxGroup;
