import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";
import { ArrowLeftIcon } from "@boi/react-native-icons";
import { CoreButton } from "@boi/components-core";

import Button from "./Button";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/Button",
  component: Button,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    text: { control: { type: "text" } },
    variant: {
      control: { type: "select" },
      options: CoreButton.VARIANTS,
    },
    disabled: { control: { type: "boolean" } },
    isLoading: { control: { type: "boolean" } },
    fullWidth: { control: { type: "boolean" } },
    startIcon: { control: { disable: true } },
  },
  args: {
    ...designTokensArgs,
    text: "Button Text",
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const Primary: Story = {
  argTypes: {
    variant: { control: { disable: true } },
  },
  args: {
    variant: "primary",
  },
};

export const Secondary: Story = {
  ...Primary,
  args: {
    variant: "secondary",
  },
};

export const StartIcon: Story = {
  args: {
    startIcon: <ArrowLeftIcon />,
  },
};

export const Loading: Story = {
  ...Primary,
  args: {
    isLoading: true,
  },
};
