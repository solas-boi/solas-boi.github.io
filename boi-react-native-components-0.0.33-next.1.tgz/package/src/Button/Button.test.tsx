import { render, screen } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";
import { ArrowLeftIcon } from "@boi/react-native-icons";

import Button, { ButtonProps } from "./Button";

function WrappedButton(props: ButtonProps) {
  return (
    <DesignTokensProvider>
      <Button {...props} />
    </DesignTokensProvider>
  );
}

describe("Button", () => {
  let baseProps: ButtonProps;

  beforeEach(() => {
    baseProps = {
      text: "Button Text",
    };
  });

  it("should render with the correct role", () => {
    render(<WrappedButton {...baseProps} />);

    expect(screen.getByRole("button")).toBeDefined();
  });

  it("should render the correct text", () => {
    const { text } = baseProps;

    render(<WrappedButton {...baseProps} />);

    expect(screen.getByRole("button")).toHaveTextContent(text);
  });

  it("should render the startIcon component when provided", () => {
    const iconTestID = "start-icon";

    render(
      <WrappedButton
        {...baseProps}
        startIcon={<ArrowLeftIcon testID={iconTestID} />}
      />
    );

    expect(screen.getByTestId(iconTestID)).toBeDefined();
  });

  it("should render a spinner component when isLoading is true", () => {
    render(<WrappedButton {...baseProps} isLoading />);

    expect(screen.getByTestId("button-spinner")).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedButton {...baseProps} />);

    expect(screen.getByTestId("button")).toBeDefined();
    expect(screen.getByTestId("button-text")).toBeDefined();
  });

  it("should render with an optional testID", () => {
    const testID = "custom-button";

    render(<WrappedButton {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
    expect(screen.getByTestId(`${testID}-text`)).toBeDefined();
  });
});
