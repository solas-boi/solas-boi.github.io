import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import SearchInput from "./SearchInput";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/SearchInput",
  component: SearchInput,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    disabled: { control: "boolean" },
    hasError: { control: "boolean" },
  },
  args: {
    ...designTokensArgs,
    placeholder: "Search",
    disabled: false,
    hasError: false,
  },
} satisfies Meta<typeof SearchInput>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  args: {
    "aria-label": "SearchInput label",
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "SearchInput label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "SearchInput label",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    labelProps: {
      label: "SearchInput label",
    },
  },
};

export const Invalid: Story = {
  args: {
    hasError: true,
    labelProps: {
      label: "SearchInput label",
    },
    alerts: [
      {
        severity: "error",
        children: "Error description over two lines if required.",
      },
    ],
  },
};
