import { useState, useEffect, useCallback, forwardRef } from "react";
import { TextInputProps, TextInput as RNTextInput } from "react-native";
import { parse, format, isValid } from "date-fns";
import { mask, unMask } from "react-native-mask-text";
import { DateType } from "react-native-ui-datepicker";
import {
  CoreDatePicker,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import {
  MINIMUM_INPUT_LENGTH,
  DATE_FNS_LOCALES,
  DATE_FORMATS,
  DATE_MASKS,
} from "./DatePickerV2.constants";
import { DatePickerV2Calendar } from "./DatePickerV2Calendar";
import { TextInput } from "../TextInput";
import { type InputAlertsProps } from "../InputAlerts";
import { type InputLabelTopProps } from "../InputLabelTop";
import { type ModalProps } from "../Modal";

export type CommonProps = {
  locale?: CoreDatePicker.Locale;
  date?: Date | undefined | null;
  onChange: (date: Date | undefined | null) => void;
};

export type DatePickerV2Props = PropsWithOptionalTestID &
  CommonProps & {
    labelProps: Omit<InputLabelTopProps, "children">;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    hasError?: boolean;
    withCalendar?: boolean;
    inputAccessoryViewID?: string;
    maximumDate?: DateType;
    minimumDate?: DateType;
    disabledDates?: DateType[] | ((date: DateType) => boolean);
    title?: string;
    startMonth?: number;
    startYear?: number;
  } & Pick<ModalProps, "supportedOrientations" | "onCloseAnimationComplete"> &
  Omit<
    TextInputProps,
    | "value"
    | "defaultValue"
    | "onChange"
    | "allowFontScaling"
    | "maxLength"
    | "placeholder"
    | "placeholderTextColor"
    | "style"
  >;

export const DEFAULT_INPUT_ACCESSORY_VIEW_ID =
  "DEFAULT_INPUT_ACCESSORY_VIEW_ID";

const getMaskedValue = (value: string, locale: CoreDatePicker.Locale) =>
  mask(
    value,
    DATE_MASKS[locale],
    "date",
    {
      dateFormat: DATE_FORMATS[locale],
    },
    false
  );
const getUnMaskedValue = (value: string) => unMask(value, "custom");

const DatePickerV2 = forwardRef<RNTextInput, DatePickerV2Props>(
  (props, ref) => {
    const {
      labelProps,
      alertProps,
      hasError,
      withCalendar,
      locale = CoreDatePicker.DEFAULT_LOCALE,
      date,
      onChange,
      onChangeText,
      inputAccessoryViewID,
      testID = "date-picker",
      onBlur,
      onFocus,
      maximumDate,
      minimumDate,
      disabledDates,
      title,
      supportedOrientations, // supportedOrientations by default is ['portrait']; any other orientations are not configured in Xcode for iOS in the react-native-banking app, which may cause the app to crash.
      onCloseAnimationComplete,
      startMonth,
      startYear,
      ...textInputProps
    } = props;

    const { tokens } = useDesignTokens();
    const { datePicker } = tokens;

    const [maskedValue, setMaskedValue] = useState("");

    useEffect(() => {
      if (date && isValid(date)) {
        setMaskedValue(
          format(date, DATE_FORMATS[locale], {
            locale: DATE_FNS_LOCALES[locale],
          })
        );
      }

      if (date === null) {
        setMaskedValue("");
      }
    }, [date, locale]);

    const handleBlur = useCallback<NonNullable<typeof onBlur>>(
      (evt) => {
        const masked = getMaskedValue(maskedValue, locale);
        setMaskedValue(masked);

        onBlur?.(evt);
      },
      [onBlur, maskedValue, locale]
    );

    function handleOnChangeText(text: string) {
      if (maskedValue.length > text.length) {
        /*
      If new value length is less than previous value
      Then it means it's deleting characters
      So we don't try to mask the value as to prevent the bug where
      you can't delete a mask character
      */
        setMaskedValue(text);
        onChangeText?.(text);
        return;
      }
      const unmasked = getUnMaskedValue(text);
      const masked = getMaskedValue(unmasked, locale);

      if (masked === maskedValue) {
        return;
      }

      setMaskedValue(masked);
      onChangeText?.(masked);

      if (masked.length === MINIMUM_INPUT_LENGTH) {
        const parsedDate = parse(masked, DATE_FORMATS[locale], new Date(), {
          locale: DATE_FNS_LOCALES[locale],
        });

        if (isValid(parsedDate)) {
          return onChange(parsedDate);
        }
      }

      if (date !== undefined) {
        return onChange(undefined);
      }
    }

    return (
      <TextInput
        {...textInputProps}
        ref={ref}
        inputAccessoryViewID={
          inputAccessoryViewID || DEFAULT_INPUT_ACCESSORY_VIEW_ID
        }
        labelProps={labelProps}
        alertProps={alertProps}
        hasError={hasError}
        noCounter
        maxLength={DATE_MASKS[locale].length}
        placeholder={DATE_MASKS[locale]}
        value={maskedValue}
        onChangeText={handleOnChangeText}
        placeholderTextColor={datePicker.input.segment.placeholderColor}
        onFocus={onFocus}
        onBlur={handleBlur}
        buttonSlot={
          withCalendar ? (
            <DatePickerV2Calendar
              title={title ?? labelProps?.label}
              locale={locale}
              date={date}
              onChange={onChange}
              testID={testID}
              maximumDate={maximumDate}
              minimumDate={minimumDate}
              disabledDates={disabledDates || []}
              supportedOrientations={supportedOrientations}
              onCloseAnimationComplete={onCloseAnimationComplete}
              startMonth={startMonth}
              startYear={startYear}
            />
          ) : undefined
        }
        testID={testID}
      />
    );
  }
);

DatePickerV2.displayName = "DatePickerV2";

export default DatePickerV2;
