import { useState } from "react";
import { View } from "react-native";
import { CoreCombobox } from "@boi/components-core";

import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop } from "../InputLabelTop";
import { InputWrapper } from "../InputWrapper";
import { ComboboxBase, type ComboboxBaseProps } from "../ComboboxBase";

export type ComboboxProps<
  T extends CoreCombobox.ComboboxItem = CoreCombobox.ComboboxItem
> = Omit<ComboboxBaseProps<T>, "isOpen" | "onFocus" | "onBlur"> & {
  alertProps?: InputAlertsProps["alerts"][number] | InputAlertsProps["alerts"];
};

function Combobox<
  T extends CoreCombobox.ComboboxItem = CoreCombobox.ComboboxItem
>(props: ComboboxProps<T>) {
  const {
    labelProps,
    alertProps,
    testID = "combobox",
    ...comboboxBaseProps
  } = props;

  const [isOpen, setOpen] = useState(false);
  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps}>
        <ComboboxBase
          {...comboboxBaseProps}
          labelProps={labelProps}
          isOpen={isOpen}
          onFocus={() => setOpen(true)}
          onBlur={() => setOpen(false)}
          testID={testID}
        />
      </InputLabelTop>
    </InputWrapper>
  );
}

export default Combobox;
