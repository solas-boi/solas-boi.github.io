import { useCallback, useEffect, useState } from "react";
import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import Combobox, { type ComboboxProps } from "./Combobox";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

import { mockIconItems, mockItems, mockPromotedItems } from "./Combobox.mocks";

const ControlledCombobox = (props: ComboboxProps) => {
  const { onChange, selectedItem, onInputChange, ...rest } = props;

  const [item, setItem] = useState<ComboboxProps["selectedItem"]>(selectedItem);

  const handleChange: ComboboxProps["onChange"] = useCallback(
    (newComboboxedItem) => {
      setItem(newComboboxedItem);
      onChange(newComboboxedItem);
    },
    [onChange]
  );

  const handleInputValueChange = (value: string) => {
    onInputChange?.(value);
  };

  useEffect(() => {
    setItem(selectedItem);
  }, [selectedItem]);

  return (
    <Combobox
      selectedItem={item}
      onInputChange={handleInputValueChange}
      onChange={handleChange}
      supportedOrientations={["landscape", "portrait"]}
      {...rest}
    />
  );
};

const meta = {
  title: "Inputs/Combobox",
  component: Combobox,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args) {
    const [{ selectedItem }, updateArgs] = useArgs();

    function handleChange(newComboboxedItem: any) {
      action("onChange")(newComboboxedItem);
      updateArgs({ selectedItem: newComboboxedItem });
    }

    function handleInputValueChange(inputValue: string) {
      action("onInputChange")(inputValue);
    }

    return (
      <ControlledCombobox
        {...args}
        selectedItem={selectedItem}
        onChange={handleChange}
        onInputChange={handleInputValueChange}
      />
    );
  },
  argTypes: {
    ...designTokensArgTypes,
    hasError: { control: "boolean" },
    defaultInputValue: { control: "text" },
  },
  args: {
    ...designTokensArgs,
    hasError: false,
    isDisabled: false,
    items: mockItems,
    placeholder: "Search",
  },
} satisfies Meta<ComboboxProps>;

export default meta;
type Story = StoryObj<ComboboxProps>;

export const Basic: Story = {
  args: {
    labelProps: {
      "aria-label": "Combobox",
    },
  },
};

export const WithLabel: Story = {
  args: {
    labelProps: {
      label: "Combobox with Label",
      labelTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const WithHint: Story = {
  args: {
    labelProps: {
      label: "Combobox with Hint",
      labelHint: "Additional information",
      labelHintTooltipProps: {
        iconButtonProps: {
          "aria-label": "Button label",
        },
        tooltipProps: {
          heading: "Tooltip heading",
          text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
        },
      },
    },
  },
};

export const IconItems: Story = {
  args: {
    items: mockIconItems,
    labelProps: {
      label: "Combobox with Icon Items",
    },
  },
};

export const PromotedItems: Story = {
  args: {
    items: mockPromotedItems,
    labelProps: {
      label: "Combobox with Promoted Items",
    },
  },
};

export const DisabledItems: Story = {
  args: {
    disabledKeys: mockItems.slice(1, 3).map(({ id }) => id),
    labelProps: {
      label: "Combobox with Disabled Items",
    },
  },
};
