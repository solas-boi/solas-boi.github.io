import { useMemo, useRef, useState } from "react";
import { View, FlatList, TextInput as RNTextInput } from "react-native";

import {
  CoreCombobox,
  type PropsWithOptionalTestID,
} from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";
import { CloseIcon } from "@boi/react-native-icons";

import useStyles, { useStateStyles } from "./ComboboxModalBase.styles";
import { IconButton } from "../IconButton";
import { ComboboxItem } from "./ComboboxItem";
import { COMBOBOX_ITEM_HEIGHT } from "./ComboboxItem/ComboboxItem.styles";
import { TextInput } from "../TextInput";
import { InputLabelTop } from "../InputLabelTop";
import { ComboboxEmpty } from "./ComboboxEmpty";
import {
  ScrollShadowContainer,
  useScrollShadowContainer,
} from "../ScrollShadowContainer";

export type ComboboxModalBaseProps<T extends CoreCombobox.ComboboxItem> =
  PropsWithOptionalTestID & {
    title: string;
    selectedItem?: T | null | undefined;
    items: T[];
    disabledKeys?: string[];
    defaultInputValue?: string;
    onInputChange?: (inputValue: string) => void;
    onChange: (selectedItem: T | null | undefined) => void;
    onRequestClose: () => void;
  };

function ComboboxModalBase<T extends CoreCombobox.ComboboxItem>(
  props: ComboboxModalBaseProps<T>
) {
  const {
    title,
    selectedItem,
    items,
    testID,
    defaultInputValue,
    disabledKeys,
    onInputChange,
    onChange,
    onRequestClose,
  } = props;

  const { tokens } = useDesignTokens();
  const { standardModal } = tokens;

  const {
    topShadowVisible,
    bottomShadowVisible,
    contentWidth,
    setContentWidth,
    onScroll,
    onLayout,
    onContentChange,
  } = useScrollShadowContainer();

  const styles = useStyles();
  const stateStyles = useStateStyles(topShadowVisible);

  const [internalInputValue, setIntervalInputValue] = useState("");
  const filteredItems = useMemo(() => {
    let updatedItems = items;

    if (internalInputValue?.length > 0) {
      updatedItems = updatedItems.filter((item) => {
        const a = item.title.toLowerCase();
        const b = internalInputValue.trim().toLowerCase();

        return a.includes(b);
      });
    }

    return updatedItems.sort((a, b) => {
      if (a.isPromoted === b.isPromoted) {
        return 0;
      }

      return a.isPromoted ? -1 : 1;
    });
  }, [items, internalInputValue]);

  const textInputRef = useRef<RNTextInput>(null);

  return (
    <>
      <View
        style={stateStyles.header}
        onLayout={(evt) => setContentWidth(evt.nativeEvent.layout.width)}
      >
        <View style={styles.miniHeadingWrapper}>
          <View style={styles.miniHeadingLabelWrapper}>
            <View
              style={styles.labelWrapper}
              accessibilityRole={"header"}
              accessible={true}
            >
              <InputLabelTop label={title} />
            </View>

            <View style={styles.closeButtonWrapper}>
              <IconButton
                aria-label="Close modal"
                onPress={onRequestClose}
                testID={`${testID}-close-button`}
                variant={standardModal.header.closeButton.variant}
              >
                <CloseIcon />
              </IconButton>
            </View>
          </View>
          <View style={styles.miniHeadingInputWrapper}>
            <TextInput
              ref={textInputRef}
              testID={`${testID}-input`}
              defaultValue={
                selectedItem ? selectedItem.title : defaultInputValue
              }
              onChangeText={(text) => {
                setIntervalInputValue(text);
                onInputChange?.(text);
              }}
              icon={
                <View style={styles.clearFilterButton}>
                  <IconButton
                    aria-label="Clear filter"
                    onPress={() => {
                      setIntervalInputValue("");
                      textInputRef.current?.clear();
                      textInputRef.current?.focus();
                    }}
                    testID={`${testID}-clear-button`}
                    variant="default"
                  >
                    <CloseIcon />
                  </IconButton>
                </View>
              }
              labelProps={{}}
              accessibilityLabel={title}
              accessibilityHint="Filters the options displayed below"
              autoFocus
            />
          </View>
        </View>
      </View>
      <ScrollShadowContainer
        style={styles.scrollShadowContainer}
        bottomShadowVisible={bottomShadowVisible}
        topShadowVisible={topShadowVisible}
        contentWidth={contentWidth}
      >
        <FlatList
          keyboardShouldPersistTaps="always"
          onScroll={onScroll}
          onLayout={onLayout}
          onContentSizeChange={onContentChange}
          role="list"
          accessibilityRole="list"
          contentContainerStyle={styles.contentContainer}
          alwaysBounceVertical={false}
          ListEmptyComponent={<ComboboxEmpty testID={`${testID}-no-results`} />}
          initialScrollIndex={
            selectedItem ? filteredItems.indexOf(selectedItem) : undefined
          }
          data={filteredItems}
          keyExtractor={(item: T) =>
            typeof item === "string" ? item : item.id
          }
          snapToInterval={COMBOBOX_ITEM_HEIGHT}
          getItemLayout={(_, index) => {
            return {
              length: COMBOBOX_ITEM_HEIGHT,
              offset: COMBOBOX_ITEM_HEIGHT * index,
              index,
            };
          }}
          renderItem={({ item, index }) => {
            const isSelected = item === selectedItem;
            const isDisabled = disabledKeys
              ? disabledKeys.includes(item.id)
              : false;
            const nextItem = filteredItems[index + 1];
            const isLastPromoted = Boolean(
              item.isPromoted && nextItem && !nextItem.isPromoted
            );
            return (
              <ComboboxItem
                isSelected={isSelected}
                isDisabled={isDisabled}
                item={item}
                isFirst={index === 0}
                isLast={index === filteredItems.length - 1}
                isLastPromoted={isLastPromoted}
                onPress={() => {
                  onChange(item);
                  onRequestClose();
                }}
              />
            );
          }}
        />
      </ScrollShadowContainer>

      <View style={styles.footer} />
    </>
  );
}

export default ComboboxModalBase;
