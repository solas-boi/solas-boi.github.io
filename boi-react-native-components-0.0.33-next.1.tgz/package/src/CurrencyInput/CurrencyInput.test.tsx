import {
  render,
  screen,
  userEvent,
  waitFor,
} from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import CurrencyInput, { type CurrencyInputProps } from "./CurrencyInput";

jest.useFakeTimers();

function WrappedCurrencyInput(props: CurrencyInputProps) {
  return (
    <DesignTokensProvider>
      <CurrencyInput {...props} />
    </DesignTokensProvider>
  );
}

describe("CurrencyInput", () => {
  let baseProps: CurrencyInputProps;

  beforeEach(() => {
    baseProps = {
      labelProps: { label: "I am the label" },
    };
  });

  it("should correctly format an initial value (as locale en_IE) as an controlled input", () => {
    render(
      <WrappedCurrencyInput {...baseProps} locale={"en-IE"} value={12000.89} />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput).toHaveDisplayValue("12,000.89");
  });

  it("should correctly format an initial value (as locale en_IE) as an uncontrolled input", () => {
    render(
      <WrappedCurrencyInput
        {...baseProps}
        locale={"en-IE"}
        defaultValue={12000.89}
      />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput).toHaveDisplayValue("12,000.89");
  });

  it("should change a sub-minimum value to the minimum value", () => {
    render(
      <WrappedCurrencyInput
        {...baseProps}
        locale={"en-IE"}
        value={12000.89}
        minValue={12001}
      />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput).toHaveDisplayValue("12,001.00");
  });

  it("should render with accessibilityLabel containing number of decimal places allowed", () => {
    render(
      <WrappedCurrencyInput {...baseProps} locale={"en-IE"} value={12000.89} />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput.props.accessibilityLabel).toBe(
      "I am the label . you can only enter 2 decimal places"
    );
  });

  it("should render with accessibilityLabel containing decimal places allowed text and the original accessibilityLabel text", () => {
    render(
      <WrappedCurrencyInput
        {...baseProps}
        locale={"en-IE"}
        accessibilityLabel="original"
        accessibilityHint="original hint"
        value={12000.89}
      />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput.props.accessibilityLabel).toBe(
      "I am the label . original . you can only enter 2 decimal places"
    );
  });

  it("should change a value above the maximum value to the maximum value", () => {
    render(
      <WrappedCurrencyInput
        {...baseProps}
        locale={"en-IE"}
        value={12000.89}
        maxValue={11999}
      />
    );
    const currencyInput = screen.getByTestId("currency-input");
    expect(currencyInput).toHaveDisplayValue("11,999.00");
  });

  it("should fire the currency change event when the 'safe value' differs from that provided", () => {
    const mockOnChangeCurrency = jest.fn();

    render(
      <WrappedCurrencyInput
        {...baseProps}
        onChangeCurrency={mockOnChangeCurrency}
        locale={"en-IE"}
        value={12000.89}
        minValue={12001}
      />
    );
    expect(mockOnChangeCurrency).toHaveBeenCalled();
  });

  it("should fire the currency change event when the value of the currency input is changed", async () => {
    const user = userEvent.setup();
    const mockOnChangeCurrency = jest.fn();

    render(
      <WrappedCurrencyInput
        {...baseProps}
        onChangeCurrency={mockOnChangeCurrency}
      />
    );

    const currencyInput = screen.getByTestId("currency-input");

    await waitFor(async () => {
      await user.type(currencyInput, "23");
    });

    expect(mockOnChangeCurrency).toHaveBeenCalled();

    expect(currencyInput).toHaveDisplayValue("23.00");
  });

  it("should NOT fire the currency change event when the value of the currency input is modified and left with the same number value after ", async () => {
    const user = userEvent.setup();
    const mockOnChangeCurrency = jest.fn();

    render(
      <WrappedCurrencyInput
        {...baseProps}
        onChangeCurrency={mockOnChangeCurrency}
      />
    );

    const currencyInput = screen.getByTestId("currency-input");

    await waitFor(async () => {
      await user.type(currencyInput, "23");
    });

    mockOnChangeCurrency.mockClear();

    await waitFor(async () => {
      await user.type(currencyInput, ".0");
    });

    expect(mockOnChangeCurrency).not.toHaveBeenCalled();
  });

  it("should render with a default testID", () => {
    render(<WrappedCurrencyInput {...baseProps} />);

    expect(screen.getByTestId("currency-input")).toBeDefined();
  });

  it("should render with an optional testID", () => {
    const testID = "custom-currency-input";

    render(<WrappedCurrencyInput {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  it("should render with zero decimal places", () => {
    const testID = "custom-currency-input";

    render(
      <WrappedCurrencyInput
        {...baseProps}
        currencyFormat="NoDecimalPlaces"
        testID={testID}
      />
    );

    expect(screen.getByTestId(testID)).toBeDefined();
  });

  it("should fire the currency change event when the max number of fractional places are already filled", async () => {
    const user = userEvent.setup();
    const mockOnChangeCurrency = jest.fn();

    render(
      <WrappedCurrencyInput
        {...baseProps}
        onChangeCurrency={mockOnChangeCurrency}
      />
    );

    const currencyInput = screen.getByTestId("currency-input");

    await waitFor(async () => {
      await user.type(currencyInput, "23.1");
    });

    mockOnChangeCurrency.mockClear();

    await waitFor(async () => {
      await user.type(currencyInput, "5");
    });

    expect(mockOnChangeCurrency).not.toHaveBeenCalled();
  });
});
