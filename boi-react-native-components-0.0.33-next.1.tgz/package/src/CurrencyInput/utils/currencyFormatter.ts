import { CoreCurrencyInput } from "@boi/components-core";

import { getNumberSeparators, type NumberSeparators } from "@boi/js-utils";

export type CurrencyFormatterResponse = {
  textValue: string;
  currencyValue: number;
};

const safeSeparatorRegExp = (separator: string) =>
  RegExp(separator === "." ? `\\${separator}` : separator, "g");

const removeThousandSeparators = (
  value: string,
  thousandSeperator: string
): string => value.replace(safeSeparatorRegExp(thousandSeperator), "");

const removeIncorrectFractionSeparators = (
  value: string,
  fractionSeperator: string
): string => {
  const separatorPos = value.lastIndexOf(fractionSeperator);

  if (separatorPos < 0) {
    return value;
  }

  const preSeparatorValue = value
    .substring(0, separatorPos)
    .replace(safeSeparatorRegExp(fractionSeperator), "");

  const postSeparatorValue = value.substring(separatorPos);

  return `${preSeparatorValue}${postSeparatorValue}`;
};

const removeIncorrectMinusSigns = (value: string): string => {
  const firstMinusSignPos = value.indexOf("-");
  return firstMinusSignPos === 0
    ? `-${value.substring(1).replace(/-/g, "")}`
    : value.replace(/-/g, "");
};

const calculateNumber = (
  value: string,
  numDPs: number,
  minValue?: number,
  maxValue?: number
): number => {
  const actualValue = Number(
    Number(value.replace(/,/g, ".")).toFixed(numDPs)
  ).valueOf();

  if (maxValue && actualValue > maxValue) {
    return maxValue;
  }

  if (minValue && actualValue < minValue) {
    return minValue;
  }

  return actualValue;
};

const cleanTextValue = (
  value: string,
  numberSeparators: NumberSeparators
): string =>
  removeThousandSeparators(
    removeIncorrectFractionSeparators(
      removeIncorrectMinusSigns(value),
      numberSeparators.fraction
    ),
    numberSeparators.thousand
  );

export const currencyFormatter = (
  currencyFormat: CoreCurrencyInput.CurrencyFormat,
  value: string | undefined,
  locale?: string,
  minValue?: number,
  maxValue?: number
): CurrencyFormatterResponse => {
  if (!value) {
    return { textValue: "", currencyValue: 0 };
  }

  const numberSeparators = getNumberSeparators(locale);

  const formatOptions =
    currencyFormat === CoreCurrencyInput.TWO_DECIMAL_PLACES
      ? CoreCurrencyInput.TWO_DP_FORMAT_OPTIONS
      : CoreCurrencyInput.ZERO_DP_FORMAT_OPTIONS;

  const cleanValue = cleanTextValue(value, numberSeparators);

  const currencyValue = calculateNumber(
    cleanValue,
    formatOptions.maximumFractionDigits,
    minValue,
    maxValue
  );

  const textValue = currencyValue.toLocaleString(locale, formatOptions);
  return {
    textValue,
    currencyValue,
  };
};
