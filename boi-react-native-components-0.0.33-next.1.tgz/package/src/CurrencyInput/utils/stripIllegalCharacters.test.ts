import { stripIllegalCharacters } from "./stripIllegalCharacters";
import { getNumberSeparators } from "@boi/js-utils";

jest.mock("@boi/js-utils", () => {
  const actual = jest.requireActual("@boi/js-utils");
  return {
    ...actual,
    getNumberSeparators: jest.fn(),
  };
});

const mockGetNumberSeparators = jest.mocked(getNumberSeparators);

const setupLocale = (locale: string) =>
  mockGetNumberSeparators.mockReturnValue({
    thousand: locale === "de-DE" ? "." : ",",
    fraction: locale === "de-DE" ? "," : ".",
  });

const cases = [
  ["...,,", 2, "en-IE", 0, ""],
  ["98.999", 2, "en-IE", 0, "98.99"],
  ["98.99k", 2, "en-IE", 0, "98.99"],
  ["123389", 2, "en-IE", 2, "123389"],
  ["123389.", 0, "en-IE", 2, "123389"],
  ["123389", 2, "en-IE", -2, "123389"],
];

describe("stripIllegalCharacters", () => {
  beforeEach(jest.clearAllMocks);

  test.each(cases)(
    "given input of %p, with dp:%p, locale %p and a min value of %p, should return %p",
    (inputValue, numFracPlaces, locale, minValue, result) => {
      setupLocale(locale as string);

      expect(
        stripIllegalCharacters(
          inputValue as string,
          numFracPlaces as number,
          locale as string,
          minValue as number
        )
      ).toEqual(result);
    }
  );
});
