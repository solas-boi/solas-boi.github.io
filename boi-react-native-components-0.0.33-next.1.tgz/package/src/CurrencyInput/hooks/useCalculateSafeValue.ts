export const useCalculateSafeValue = (
  value?: number,
  defaultValue?: number,
  minValue?: number,
  maxValue?: number
): number | undefined => {
  if (!value && !defaultValue) {
    return undefined;
  }

  const specifiedValue = value ?? defaultValue ?? 0;

  if ((minValue === 0 || minValue) && specifiedValue < (minValue || 0)) {
    return minValue;
  }

  if ((maxValue === 0 || maxValue) && specifiedValue > (maxValue || 0)) {
    return maxValue;
  }

  return specifiedValue;
};
