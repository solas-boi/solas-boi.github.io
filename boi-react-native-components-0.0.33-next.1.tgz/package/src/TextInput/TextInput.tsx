import { forwardRef, useCallback, useRef, useState } from "react";
import {
  TextInput as RNTextInput,
  View,
  type TextInputProps as RNTextInputProps,
} from "react-native";
import { KeyboardExtendedInput } from "react-native-external-keyboard";
import { type PropsWithOptionalTestID } from "@boi/components-core";
import { useDesignTokens } from "@boi/react-native-design-tokens";

import { useStateStyles } from "./TextInput.styles";
import { CharactersCounter } from "../CharactersCounter";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelTop, type InputLabelTopProps } from "../InputLabelTop";
import { InputWrapper } from "../InputWrapper";
import { Typography } from "../Typography";
import { useMergeRefs, useSimpleA11yProps } from "../hooks";
import { useFixAndroidAccessibilityProps } from "./hooks/fixAndroidAccessibilityBug.hook";
import { OuterFieldV2 } from "../OuterFieldV2";
import { IconButton } from "../IconButton";
import { CloseIcon } from "@boi/react-native-icons";

export type TextInputProps = PropsWithOptionalTestID &
  Omit<RNTextInputProps, "style" | "editable" | "selectionColor"> & {
    noCounter?: boolean;
    hasError?: boolean;
    readonly?: boolean;
    disabled?: boolean;
    prefix?: JSX.Element | string;
    withClearButton?: boolean;
    icon?: JSX.Element;
    buttonSlot?: JSX.Element;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
    labelProps: Omit<InputLabelTopProps, "children">;
  };

const TextInput = forwardRef<RNTextInput, TextInputProps>((props, ref) => {
  const {
    testID = "input",
    labelProps,
    alertProps,
    disabled,
    readonly,
    hasError,
    prefix,
    icon,
    buttonSlot,
    withClearButton,
    hitSlop,
    onChangeText,
    onFocus,
    onBlur,
    noCounter,
    ...inputProps
  } = props;

  const { maxLength } = inputProps;

  const showCounter = !noCounter && maxLength;

  const localRef = useRef<RNTextInput>(null);
  const mergedRefs = useMergeRefs([localRef, ref]);

  const { tokens } = useDesignTokens();
  const [hasFocus, setHasFocus] = useState(false);
  const [hasBeenCleared, setHasBeenCleared] = useState(false);
  const handleFocus = useCallback<NonNullable<typeof onFocus>>(
    (evt) => {
      setHasFocus(true);
      onFocus?.(evt);
    },
    [onFocus]
  );
  const handleBlur = useCallback<NonNullable<typeof onBlur>>(
    (evt) => {
      setHasFocus(false);
      onBlur?.(evt);
    },
    [onBlur]
  );

  const styles = useStateStyles({
    hasFocus,
    isDisabled: disabled,
    isReadOnly: readonly,
  });

  const [length, setLength] = useState(
    (inputProps.value || inputProps.defaultValue)?.length || 0
  );
  const handleChangeText = useCallback(
    (newValue: string) => {
      setLength(newValue.length);
      onChangeText?.(newValue);
    },
    [onChangeText]
  );
  const focusElement = () => {
    localRef.current?.focus();
  };

  const handleClear = useCallback(() => {
    !hasBeenCleared && setHasBeenCleared(true);
    setLength(0);
    localRef.current?.clear();
    localRef.current?.focus();
    onChangeText?.("");
  }, [localRef, onChangeText, hasBeenCleared, setHasBeenCleared]);

  const simpleA11yProps = useSimpleA11yProps(props);
  const newProps = { ...inputProps, ...simpleA11yProps };
  const safeNewProps = useFixAndroidAccessibilityProps(newProps, length);

  return (
    <InputWrapper
      gap={showCounter ? 4 : 8}
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <InputLabelTop {...labelProps} testID={`${testID}-label`}>
        <OuterFieldV2
          hasError={hasError}
          hasFocus={hasFocus}
          isActive={hasFocus}
          isDisabled={disabled}
          focusElement={focusElement}
          hitSlop={hitSlop}
          startSlot={
            prefix && (
              <Typography
                style={styles.prefix}
                variant={tokens.textInput.prefix.typography.variant}
                fontFamily={tokens.textInput.prefix.typography.fontFamily}
                testID={`${testID}-prefix`}
              >
                {prefix}
              </Typography>
            )
          }
          innerButtonSlot={
            withClearButton &&
            length > 0 && (
              <IconButton
                aria-label="Clear text"
                onPress={handleClear}
                testID={`${testID}-clear-button`}
              >
                <CloseIcon />
              </IconButton>
            )
          }
          endSlot={
            icon && <View testID={`${testID}-icon-wrapper`}>{icon}</View>
          }
          buttonSlot={buttonSlot}
        >
          <KeyboardExtendedInput
            {...newProps}
            {...safeNewProps}
            defaultValue={
              props.defaultValue !== undefined && hasBeenCleared
                ? ""
                : props.defaultValue
            }
            tintType="none"
            onFocusChange={(isFocused) => {
              setHasFocus(isFocused);
            }}
            ref={mergedRefs}
            hitSlop={hitSlop}
            testID={testID}
            style={styles.input}
            containerStyle={styles.inputContainer}
            selectionColor={tokens.textInput.selectionColor}
            placeholderTextColor={tokens.textInput.color.placeholder}
            editable={!disabled && !readonly}
            onChangeText={handleChangeText}
            onFocus={handleFocus}
            onBlur={handleBlur}
            allowFontScaling={false}
          />
        </OuterFieldV2>
      </InputLabelTop>
      {showCounter ? (
        <CharactersCounter
          length={length}
          maxLength={maxLength}
          testID={`${testID}-characters-counter`}
        />
      ) : undefined}
    </InputWrapper>
  );
});
TextInput.displayName = "TextInput";

export default TextInput;
