import { Platform, type TextInputProps } from "react-native";

type NewPropsFragment = Pick<
  TextInputProps,
  "placeholder" | "accessibilityLabel" | "accessibilityHint"
>;

export const useFixAndroidAccessibilityProps = (
  props: TextInputProps,
  valueLength: number
): NewPropsFragment => {
  const { placeholder, accessibilityLabel, accessibilityHint } = props;

  if (Platform.OS !== "android") {
    return {
      placeholder,
      accessibilityHint,
      accessibilityLabel,
    };
  }

  const hackedPlaceholder = valueLength > 0 ? undefined : placeholder;

  const combinedHint =
    [accessibilityLabel, accessibilityHint].filter(Boolean).join(". ") ||
    undefined;

  const isWorksProperlyEdgeCase = !(valueLength > 0 || placeholder);

  return {
    placeholder: hackedPlaceholder,
    accessibilityHint: isWorksProperlyEdgeCase
      ? accessibilityHint
      : combinedHint,
    accessibilityLabel: isWorksProperlyEdgeCase
      ? accessibilityLabel
      : undefined,
  };
};
