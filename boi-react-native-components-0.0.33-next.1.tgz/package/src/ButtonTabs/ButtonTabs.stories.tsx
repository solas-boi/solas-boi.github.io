import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import { CoreButtonAlt, CoreButtonTabs } from "@boi/components-core";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import ButtonTabs from "./ButtonTabs";
import { mockButtonTabs, mockButtonTabsDisabled } from "./ButtonTabs.mocks";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Navigation/ButtonTabs",
  component: ButtonTabs,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <Story />
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args) {
    const [, updateArgs] = useArgs();

    function handleChange(activeItemId: string | number) {
      updateArgs({ activeItemId });
      action("onChange")();
    }

    return (
      <View style={{ padding: 10 }}>
        <ButtonTabs {...args} onChange={handleChange}>
          <View style={{ gap: 10 }}>
            <ButtonTabs.Items />
            <ButtonTabs.Panels />
          </View>
        </ButtonTabs>
      </View>
    );
  },
  argTypes: {
    ...designTokensArgTypes,
    variant: {
      control: { type: "select" },
      options: CoreButtonTabs.VARIANTS,
    },
    items: { control: { disable: true } },
    activeItemId: { control: { type: "text" } },
    typographyVariant: {
      control: { type: "select" },
      options: CoreButtonAlt.TYPOGRAPHY_VARIANTS,
    },
  },
  args: {
    ...designTokensArgs,
    variant: CoreButtonTabs.DEFAULT_VARIANT,
    items: mockButtonTabs.items,
    activeItemId: mockButtonTabs.activeItemId,
    typographyVariant: CoreButtonAlt.DEFAULT_TYPOGRAPHY_VARIANT,
  },
} satisfies Meta<typeof ButtonTabs>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const DisabledItems: Story = {
  args: { ...mockButtonTabsDisabled },
};
