import { StyleSheet, type PressableStateCallbackType } from "react-native";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { link } = tokens;

  const styles = StyleSheet.create({
    container: {
      display: "flex",
      alignSelf: "flex-start",
    },
    focusContainer: {
      outlineWidth: link.focusRing.width,
      outlineStyle: link.focusRing.style,
      outlineColor: link.focusRing.color,
      outlineOffset: link.focusRing.offset,
      borderRadius: link.focusRing.radius,
    },
    wrapper: {
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      gap: link.withIcon.gap,
    },
    textPressed: {
      backgroundColor: link.backgroundColor.active,
    },
    iconWrapper: {
      flexShrink: 0,
    },
  });

  return styles;
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles() {
  const styles = useStyles();

  return {
    text: ({ pressed }: PressableStateCallbackType) => [
      pressed && styles.textPressed,
    ],
  };
}

export default useStyles;
