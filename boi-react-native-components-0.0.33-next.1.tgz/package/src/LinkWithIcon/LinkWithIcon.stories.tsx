import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { CoreLink } from "@boi/components-core";
import * as Icons from "@boi/react-native-icons";
import { getIconSelectArgType } from "@boi/react-utils";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import LinkWithIcon from "./LinkWithIcon";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Inputs/LinkWithIcon",
  component: LinkWithIcon,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
    variant: {
      control: { type: "select" },
      options: CoreLink.VARIANTS,
    },
    startIcon: {
      ...getIconSelectArgType(Icons),
      if: { arg: "endIcon", truthy: false },
    },
    endIcon: {
      ...getIconSelectArgType(Icons),
      if: { arg: "startIcon", truthy: false },
    },
  },
  args: {
    ...designTokensArgs,
    variant: CoreLink.DEFAULT_VARIANT,
  },
} satisfies Meta<typeof LinkWithIcon>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const StartIcon: Story = {
  args: {
    children: "Download report",
    startIcon: <Icons.DownloadIcon />,
  },
};

export const EndIcon: Story = {
  args: {
    children: "Log in",
    endIcon: <Icons.LoginIcon />,
  },
};
