import { cloneElement, forwardRef } from "react";
import {
  View,
  type AccessibilityRole,
  type Role,
  useWindowDimensions,
} from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { CoreLink } from "@boi/components-core";
import {
  parseSizeToken,
  useDesignTokens,
} from "@boi/react-native-design-tokens";

import useStyles, { useStateStyles } from "./LinkWithIcon.styles";
import { Typography } from "../Typography";
import { KeyboardPressableProps } from "../types";

export type LinkWithIconProps = Omit<
  KeyboardPressableProps,
  "style" | "disabled" | "children"
> & {
  variant?: CoreLink.Variant;
  startIcon?: JSX.Element;
  endIcon?: JSX.Element;
  children: string;
  role?: Role;
  accessibilityRole?: AccessibilityRole;
};

const LinkWithIcon = forwardRef<View, LinkWithIconProps>((props, ref) => {
  const {
    variant = CoreLink.DEFAULT_VARIANT,
    startIcon,
    endIcon,
    children,
    testID = "link",
    role = "link",
    accessibilityRole = "link",
    ...pressableProps
  } = props;

  const styles = useStyles();
  const stateStyles = useStateStyles();

  const { fontScale } = useWindowDimensions();
  const { tokens } = useDesignTokens();
  const { link } = tokens;

  function cloneIcon(icon: JSX.Element, pressed: boolean) {
    return cloneElement(icon, {
      ...icon.props,
      width: parseSizeToken(link.withIcon.size[variant], fontScale),
      height: parseSizeToken(link.withIcon.size[variant], fontScale),
      color: link.color[pressed ? "active" : "base"],
    });
  }

  return (
    <KeyboardPressable
      {...pressableProps}
      ref={ref}
      role={role}
      accessibilityRole={accessibilityRole}
      containerStyle={styles.container}
      focusStyle={styles.focusContainer}
      style={styles.wrapper}
      tintType="none"
      enableA11yFocus
      testID={testID}
    >
      {({ pressed }) => (
        <>
          {startIcon && (
            <View
              style={styles.iconWrapper}
              testID={`${testID}-start-icon-wrapper`}
            >
              {cloneIcon(startIcon, pressed)}
            </View>
          )}

          <View pointerEvents="none">
            <Typography
              color={link.color[pressed ? "active" : "base"]}
              style={stateStyles.text({ pressed })}
              variant={variant}
              fontFamily={link.typography.fontFamily}
            >
              {children}
            </Typography>
          </View>

          {endIcon && (
            <View
              style={styles.iconWrapper}
              testID={`${testID}-end-icon-wrapper`}
            >
              {cloneIcon(endIcon, pressed)}
            </View>
          )}
        </>
      )}
    </KeyboardPressable>
  );
});
LinkWithIcon.displayName = "LinkWithIcon";

export default LinkWithIcon;
