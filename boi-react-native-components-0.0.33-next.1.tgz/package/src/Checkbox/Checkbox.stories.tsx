import { type GestureResponderEvent } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";

import Checkbox from "./Checkbox";
import * as RadioStories from "../Radio/Radio.stories";

const meta = {
  ...RadioStories.default,
  title: "Inputs/Checkbox",
  component: Checkbox,
  render: function Render(args: any) {
    const [{ isChecked }, updateArgs] = useArgs();

    function handlePress(event: GestureResponderEvent) {
      updateArgs({ isChecked: !isChecked });
      action("onPress")(event);
    }

    return <Checkbox {...args} onPress={handlePress} />;
  },
  argTypes: {
    ...RadioStories.default.argTypes,
    isIndeterminate: { control: "boolean" },
  },
  args: {
    ...RadioStories.default.args,
    isIndeterminate: false,
  },
} satisfies Meta<typeof Checkbox>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = RadioStories.Basic;

export const Disabled: Story = RadioStories.Disabled;

export const WithLabel: Story = RadioStories.WithLabel;

export const WithError: Story = RadioStories.WithError;

export const Indeterminate: Story = {
  ...Basic,
  args: {
    isIndeterminate: true,
    labelProps: {
      label: "Try Me!",
    },
  },
};
