import { forwardRef, useState } from "react";
import { View } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";

import { KeyboardPressableProps } from "../types";
import { InputWrapper } from "../InputWrapper";
import { InputAlerts, type InputAlertsProps } from "../InputAlerts";
import { InputLabelRight, type InputLabelRightProps } from "../InputLabelRight";
import { CheckboxBase, type CheckboxBaseProps } from "../CheckboxBase";
import useStyles from "./Checkbox.styles";
import { getCheckedAccessibilityState } from "./Checkbox.utils";

export type CheckboxProps = Omit<
  KeyboardPressableProps,
  | "role"
  | "accessibilityRole"
  | "accessibilityValue"
  | "accessibilityState"
  | "children"
  | "style"
  | "ref"
> &
  Omit<CheckboxBaseProps, "children"> & {
    value?: string;
    labelProps: Omit<InputLabelRightProps, "children" | "isDisabled">;
    alertProps?:
      | InputAlertsProps["alerts"][number]
      | InputAlertsProps["alerts"];
  };

const Checkbox = forwardRef<View, CheckboxProps>((props, ref) => {
  const { labelProps, alertProps, testID = "checkbox", ...inputProps } = props;
  const { disabled } = inputProps;

  const { isChecked, isIndeterminate, value } = inputProps;

  const styles = useStyles();

  const checkedAccessibilityState = getCheckedAccessibilityState(
    isChecked,
    isIndeterminate
  );

  const [hasKeyboardFocus, setHasKeyboardFocus] = useState(false);
  const handleKeyboardFocusChange = (isFocused: boolean) => {
    setHasKeyboardFocus(isFocused);
  };

  return (
    <InputWrapper
      alert={
        alertProps && (
          <View testID={`${testID}-alerts`}>
            <InputAlerts
              alerts={Array.isArray(alertProps) ? alertProps : [alertProps]}
            />
          </View>
        )
      }
    >
      <KeyboardPressable
        {...inputProps}
        ref={ref}
        onFocusChange={handleKeyboardFocusChange}
        haloEffect={false}
        tintType="none"
        enableA11yFocus
        role="checkbox"
        accessibilityRole="checkbox"
        accessibilityValue={{ text: value }}
        accessibilityState={{
          checked: checkedAccessibilityState,
          disabled: Boolean(disabled),
        }}
        containerStyle={styles.container}
        testID={testID}
      >
        <CheckboxBase {...inputProps} testID={`${testID}-base`}>
          {(checkboxComponent) => (
            <InputLabelRight
              isDisabled={Boolean(disabled)}
              hasFocus={hasKeyboardFocus}
              {...labelProps}
            >
              {checkboxComponent}
            </InputLabelRight>
          )}
        </CheckboxBase>
      </KeyboardPressable>
    </InputWrapper>
  );
});

export default Checkbox;
