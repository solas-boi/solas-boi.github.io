import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";
import { action } from "@storybook/addon-actions";
import { useArgs } from "@storybook/preview-api";
import type { Meta, StoryObj } from "@storybook/react";
import { View } from "react-native";

import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";
import RadioGroup, { type RadioGroupProps } from "./RadioGroup";

const meta = {
  title: "Inputs/RadioGroup",
  component: RadioGroup,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args: any) {
    const [, updateArgs] = useArgs();

    function handleChange(inputs: RadioGroupProps["inputs"]) {
      updateArgs({ inputs });
      action("onChange")(inputs);
    }

    return <RadioGroup {...args} onChange={handleChange} />;
  },
  argTypes: {
    ...designTokensArgTypes,
    legend: { control: "text" },
    legendHint: { control: "text" },
  },
  args: {
    ...designTokensArgs,
    legend: "RadioGroup legend",
    inputs: [
      {
        onPress: action("onPress"),
        labelProps: { label: "Bacon" },
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Cheese" },
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Onions" },
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Lettuce" },
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Tomato" },
      },
      {
        onPress: action("onPress"),
        labelProps: {
          label:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        },
      },
    ],
  },
} satisfies Meta<typeof RadioGroup>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {};

export const WithLegend: Story = {
  ...Basic,
  args: {
    legend: "RadioGroup legend",
    legendTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithHint: Story = {
  ...Basic,
  args: {
    legend: "RadioGroup legend",
    legendHint: "Additional information",
    legendHintTooltipProps: {
      iconButtonProps: {
        "aria-label": "Button label",
      },
      tooltipProps: {
        heading: "Tooltip heading",
        text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
      },
    },
  },
};

export const WithError: Story = {
  ...Basic,
  args: {
    inputs: [
      {
        onPress: action("onPress"),
        labelProps: { label: "Bacon" },
        hasError: true,
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Cheese" },
        hasError: true,
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Onions" },
        hasError: true,
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Lettuce" },
        hasError: true,
      },
      {
        onPress: action("onPress"),
        labelProps: { label: "Tomato" },
        hasError: true,
      },
    ],
    alertProps: {
      severity: "error",
      children: "Error description over two lines if required.",
    },
  },
};
