import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { useArgs } from "@storybook/preview-api";
import { action } from "@storybook/addon-actions";
import {
  DesignTokensDecorator,
  FontScaleDecorator,
} from "@boi/react-native-design-tokens";

import Tooltip, { type TooltipProps } from "./Tooltip";
import { TooltipIconButton } from "./TooltipIconButton";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Data Display/Tooltip",
  component: Tooltip,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <FontScaleDecorator>
          <View style={{ padding: 15 }}>
            <Story />
          </View>
        </FontScaleDecorator>
      </DesignTokensDecorator>
    ),
  ],
  render: function Render(args: any) {
    const [{ isOpen }, updateArgs] = useArgs();

    function handlePress() {
      updateArgs({ isOpen: !isOpen });
      action("onPress")(!isOpen);
    }

    function handleOpenChange(updatedIsOpen: boolean) {
      updateArgs({ isOpen: updatedIsOpen });
      action("onOpenChange")(updatedIsOpen);
    }

    return (
      <Tooltip
        {...args}
        onOpenChange={handleOpenChange}
        reference={
          <TooltipIconButton
            isOpen={isOpen}
            onPress={handlePress}
            aria-label="Button label"
          />
        }
      />
    );
  },
  argTypes: {
    ...designTokensArgTypes,
    heading: { control: { type: "text" } },
    isOpen: { control: { type: "boolean" } },
    text: { control: { type: "text" } },
  },
  args: {
    ...designTokensArgs,
    heading: "Tooltip Heading",
    isOpen: false,
    text: "APR stands for Annual Percentage Rate. It's the rate you will have to pay for the chosen loan amount.",
  },
} satisfies Meta<typeof Tooltip>;

export default meta;
type Story = StoryObj<TooltipProps>;

export const Basic: Story = {};
