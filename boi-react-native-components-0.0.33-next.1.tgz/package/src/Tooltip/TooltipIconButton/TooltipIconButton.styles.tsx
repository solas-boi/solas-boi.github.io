import { StyleSheet } from "react-native";
import { CoreTooltipIconButton } from "@boi/components-core";
import { type ThemeTokens } from "@boi/react-native-design-tokens";

import { createThemedStyleSheet } from "../../themedStylesheet";

function styleSheetFactory(tokens: ThemeTokens) {
  const { iconButton } = tokens;

  return StyleSheet.create({
    wrapper: {
      display: "flex",
      alignSelf: "flex-start",
    },
    wrapperDefault: {
      padding: iconButton.padding.default,
    },
    wrapperDefault16: {
      padding: iconButton.padding.default16,
    },
    wrapperDefault20: {
      padding: iconButton.padding.default20,
    },
    containerDefault: {
      padding: iconButton.inner.padding.default,
    },
    containerDefault16: {
      padding: iconButton.inner.padding.default16,
    },
    containerDefault20: {
      padding: iconButton.inner.padding.default20,
    },
    iconHidden: {
      display: "none",
    },
  });
}

const useStyles = createThemedStyleSheet(styleSheetFactory);

export function useStateStyles({
  isOpen,
  variant,
}: {
  isOpen: boolean;
  variant: CoreTooltipIconButton.Variant;
}) {
  const styles = useStyles();

  const wrapperStyles = {
    default: styles.wrapperDefault,
    default16: styles.wrapperDefault16,
    default20: styles.wrapperDefault20,
  };

  const containerStyles = {
    default: styles.containerDefault,
    default16: styles.containerDefault16,
    default20: styles.containerDefault20,
  };

  return {
    wrapper: [styles.wrapper, wrapperStyles[variant]],
    container: containerStyles[variant],
    icon: [isOpen && styles.iconHidden],
    iconFilled: [!isOpen && styles.iconHidden],
  };
}

export default useStyles;
