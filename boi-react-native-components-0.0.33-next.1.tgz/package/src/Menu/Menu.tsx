import { useState, useLayoutEffect } from "react";
import { View, ScrollView, StyleSheet, Modal, ModalProps } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { useFloating, offset } from "@floating-ui/react-native";
import { CoreMenu, type PropsWithOptionalTestID } from "@boi/components-core";

import useStyles, { useStateStyles } from "./Menu.styles";
import type { MenuItem } from "./Menu.types";
import { KeyboardPressableProps } from "../types";
import { MenuListItem } from "../MenuListItem";

type ReferenceProps = Pick<
  KeyboardPressableProps,
  "onPress" | "aria-expanded"
> & {
  ref: React.Ref<View>;
  isPressed: boolean;
};

export type MenuProps<T extends MenuItem> = PropsWithOptionalTestID &
  Pick<ModalProps, "supportedOrientations"> & {
    items: T[];
    offset?: number;
    padding?: number;
    placement?: CoreMenu.Placement;
    renderListItemContent: (item: T, isDisabled: boolean) => JSX.Element;
    children: (referenceProps: ReferenceProps) => JSX.Element;
    disabledKeys?: string[];
  };

function isView(reference: any): reference is View {
  return !!reference && "measure" in reference;
}

function Menu<T extends MenuItem>(props: MenuProps<T>) {
  const {
    items,
    offset: offsetValue = CoreMenu.DEFAULT_OFFSET,
    padding,
    placement = CoreMenu.DEFAULT_PLACEMENT,
    renderListItemContent,
    children,
    testID = "menu",
    supportedOrientations,
    disabledKeys,
  } = props;

  const [isOpen, setIsOpen] = useState(false);

  const { refs, floatingStyles, update } = useFloating({
    placement,
    middleware: [offset(offsetValue)],
  });

  const onRequestClose = () => {
    setIsOpen(false);

    setTimeout(() => {
      const elementToFocus = refs.reference.current;
      if (elementToFocus) {
        elementToFocus.focus?.();
      }
    }, 500);
  };

  const [anchorPosition, setAnchorPosition] = useState<{
    x: number;
    y: number;
  }>();

  const styles = useStyles();

  const stateStyles = useStateStyles({
    padding,
    anchorPosition,
    floatingStyles,
  });

  useLayoutEffect(() => {
    if (isOpen && isView(refs.reference.current)) {
      refs.reference.current.measureInWindow((x, y) => {
        setAnchorPosition({ x, y });
        // Force update the `useFloating` values
        // so to prevent the menu from jumping between renders
        update();
      });
    }
  }, [refs.reference, isOpen, update]);

  function handleClick(item: T) {
    item.onPress();
    setIsOpen(false);
  }

  return (
    <>
      {children({
        ref: refs.setReference,
        isPressed: isOpen,
        onPress: () => {
          setIsOpen(!isOpen);
        },
        "aria-expanded": isOpen,
      })}

      <Modal
        visible={isOpen}
        transparent
        onRequestClose={onRequestClose}
        supportedOrientations={supportedOrientations}
      >
        <KeyboardPressable
          containerStyle={StyleSheet.absoluteFill}
          style={StyleSheet.absoluteFill}
          onPress={onRequestClose}
          accessibilityLabel="Close menu"
          accessibilityHint="Close menu"
        />
        <View
          ref={refs.setFloating}
          style={stateStyles.outerListContainer}
          testID={testID}
          accessibilityRole="menu"
          accessibilityLabel="Menu"
          accessibilityHint="Menu"
          accessibilityState={{ expanded: isOpen }}
          aria-expanded={isOpen}
          accessibilityLiveRegion="polite"
          importantForAccessibility="yes"
          focusable={true}
        >
          <View style={styles.listContainer}>
            <View style={styles.maxHeightWrapper}>
              <ScrollView style={styles.scrollview}>
                <View style={styles.list}>
                  {items.map((item) => {
                    const isDisabled = disabledKeys
                      ? disabledKeys.includes(item.id)
                      : false;
                    return (
                      <MenuListItem
                        key={item.id}
                        testID={testID}
                        data={item}
                        onPress={() => handleClick(item)}
                        isDisabled={isDisabled}
                      >
                        {renderListItemContent(item, isDisabled)}
                      </MenuListItem>
                    );
                  })}
                </View>
              </ScrollView>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

export default Menu;
