import { Text } from "react-native";
import { Pressable as KeyboardPressable } from "react-native-external-keyboard";
import { render, screen, fireEvent } from "@testing-library/react-native";
import Menu, { type MenuProps } from "./Menu";

const useMockStyles = () => ({
  listContainer: { flex: 1 },
  maxHeightWrapper: { flex: 1 },
  scrollview: { flex: 1 },
  list: { flex: 1 },
});

const useMockStateStyles = () => ({
  outerListContainer: { flex: 1 },
});

jest.mock("./Menu.styles", () => ({
  __esModule: true,
  default: jest.fn(() => useMockStyles()),
  useStateStyles: jest.fn(() => useMockStateStyles()),
}));

jest.mock("@floating-ui/react-native", () => {
  const refs = {
    reference: { current: { measureInWindow: jest.fn() } },
    floating: { current: { focus: jest.fn() } },
    setReference: jest.fn(),
    setFloating: jest.fn(),
  };
  return {
    useFloating: jest.fn(() => ({
      refs,
      floatingStyles: { top: 0, left: 0 },
      update: jest.fn(),
    })),
    offset: jest.fn(),
  };
});

jest.mock("../MenuListItem", () => {
  const React = require("react");
  const { Pressable } = jest.requireActual("react-native-external-keyboard");
  return {
    __esModule: true,
    MenuListItem: ({ children, onPress, data, testID }: any) =>
      React.createElement(
        Pressable,
        { testID: `${testID}-item-${data.id}`, onPress },
        children
      ),
  };
});

describe("Menu", () => {
  let baseProps: Partial<MenuProps<any>> & {
    items: any[];
    renderListItemContent: (item: any) => JSX.Element;
  };

  beforeEach(() => {
    jest.clearAllMocks();

    baseProps = {
      items: [
        {
          id: "1",
          onPress: jest.fn(),
        },
      ],
      renderListItemContent: (item: any) => (
        <Text testID={`item-content-${item.id}`}>Item {item.id}</Text>
      ),
    };
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  it("should not render menu content initially", () => {
    render(
      <Menu {...(baseProps as MenuProps<any>)}>
        {({ onPress, ref, "aria-expanded": ariaExpanded }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
            aria-expanded={ariaExpanded}
          >
            <Text>Closed</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    expect(screen.queryByTestId("item-content-1")).toBeNull();
  });

  it("should render menu content when reference is pressed and set aria-expanded/accessibilityState", () => {
    render(
      <Menu {...(baseProps as MenuProps<any>)}>
        {({ onPress, ref, "aria-expanded": ariaExpanded }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
            aria-expanded={ariaExpanded}
          >
            <Text>Closed</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    fireEvent.press(screen.getByTestId("reference-button"));

    expect(screen.getByTestId("item-content-1")).toBeDefined();
    const reference = screen.getByTestId("reference-button");
    const expandedProp =
      reference.props["aria-expanded"] ??
      reference.props.accessibilityState?.expanded;
    expect(expandedProp).toBe(true);
  });

  it("should call item.onPress and close menu when item pressed", () => {
    const itemOnPress = baseProps.items[0].onPress as jest.Mock;

    render(
      <Menu {...(baseProps as MenuProps<any>)}>
        {({ onPress, ref }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
          >
            <Text>Toggle</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    fireEvent.press(screen.getByTestId("reference-button"));

    const menuItemTestId = "menu-item-1";
    expect(screen.getByTestId("item-content-1")).toBeDefined();

    fireEvent.press(screen.getByTestId(menuItemTestId));

    expect(itemOnPress).toHaveBeenCalledTimes(1);
    expect(screen.queryByTestId("item-content-1")).toBeNull();
  });

  it("overlay press closes menu and returns focus to reference after timeout", () => {
    jest.useFakeTimers();

    render(
      <Menu {...(baseProps as MenuProps<any>)}>
        {({ onPress, ref }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
          >
            <Text>Toggle</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    fireEvent.press(screen.getByTestId("reference-button"));

    // Access mocked useFloating return to set a focus mock on the reference element
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const floating = require("@floating-ui/react-native");
    const floatingReturn = (floating.useFloating as jest.Mock).mock.results[0]
      .value;
    floatingReturn.refs.reference.current.focus = jest.fn();

    const overlay = screen.getByLabelText("Close menu");
    fireEvent.press(overlay);

    expect(screen.queryByTestId("item-content-1")).toBeNull();

    jest.advanceTimersByTime(800);
    expect(floatingReturn.refs.reference.current.focus).toHaveBeenCalled();
  });

  it("children receives isPressed prop and toggles when pressing reference", () => {
    render(
      <Menu {...(baseProps as MenuProps<any>)}>
        {({ onPress, ref, isPressed }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
          >
            <Text testID="pressed-state">
              {isPressed ? "pressed" : "not-pressed"}
            </Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    expect(screen.getByTestId("pressed-state")).toHaveTextContent(
      "not-pressed"
    );

    fireEvent.press(screen.getByTestId("reference-button"));
    expect(screen.getByTestId("pressed-state")).toHaveTextContent("pressed");

    fireEvent.press(screen.getByTestId("reference-button"));
    expect(screen.getByTestId("pressed-state")).toHaveTextContent(
      "not-pressed"
    );
  });

  it("passes isDisabled to renderListItemContent when disabledKeys include item id", () => {
    const localProps = {
      items: [
        {
          id: "1",
          onPress: jest.fn(),
        },
      ],
      renderListItemContent: (item: any, isDisabled: boolean) => (
        <Text testID={`item-disabled-${item.id}-${isDisabled}`}>
          {String(isDisabled)}
        </Text>
      ),
    } as Partial<MenuProps<any>> & {
      items: any[];
      renderListItemContent: (item: any, isDisabled: boolean) => JSX.Element;
    };

    render(
      <Menu {...(localProps as MenuProps<any>)} disabledKeys={["1"]}>
        {({ onPress, ref }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
          >
            <Text>Toggle</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    fireEvent.press(screen.getByTestId("reference-button"));

    expect(screen.getByTestId("item-disabled-1-true")).toBeDefined();
  });

  it("renders multiple items from items.map", () => {
    const localProps = {
      items: [
        { id: "1", onPress: jest.fn() },
        { id: "2", onPress: jest.fn() },
      ],
      renderListItemContent: (item: any) => (
        <Text testID={`item-content-${item.id}`}>Item {item.id}</Text>
      ),
    } as Partial<MenuProps<any>> & {
      items: any[];
      renderListItemContent: (item: any) => JSX.Element;
    };

    render(
      <Menu {...(localProps as MenuProps<any>)}>
        {({ onPress, ref }) => (
          <KeyboardPressable
            testID="reference-button"
            onPress={onPress}
            ref={ref as any}
            accessibilityLabel="reference"
            accessibilityHint="Opens the menu"
          >
            <Text>Toggle</Text>
          </KeyboardPressable>
        )}
      </Menu>
    );

    fireEvent.press(screen.getByTestId("reference-button"));

    expect(screen.getByTestId("item-content-1")).toBeDefined();
    expect(screen.getByTestId("item-content-2")).toBeDefined();
  });
});
