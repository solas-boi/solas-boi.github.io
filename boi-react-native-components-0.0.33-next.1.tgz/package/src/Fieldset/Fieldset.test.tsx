import { produce } from "immer";
import { render, screen, userEvent, act } from "@testing-library/react-native";
import { DesignTokensProvider } from "@boi/react-native-design-tokens";

import Fieldset, { type FieldsetProps } from "./Fieldset";

jest.useFakeTimers();

function WrappedFieldset(props: FieldsetProps) {
  return (
    <DesignTokensProvider>
      <Fieldset {...props} />
    </DesignTokensProvider>
  );
}

describe("Fieldset", () => {
  let baseProps: FieldsetProps;

  beforeEach(() => {
    baseProps = {
      role: "checkboxgroup",
      legend: "Fieldset legend",
      legendHint: "Fieldset hint",
    };
  });

  it("should render with a legend and hint element", () => {
    render(<WrappedFieldset {...baseProps} />);

    const legend = screen.getByText("Fieldset legend");
    const hint = screen.getByText("Fieldset hint");

    expect(legend).toBeDefined();
    expect(hint).toBeDefined();
  });

  it("should render legend with tooltip button", () => {
    render(
      <WrappedFieldset
        {...baseProps}
        legendTooltipProps={{
          tooltipProps: { heading: "Test", text: "Lorem Ipsum" },
          iconButtonProps: { "aria-label": "Tooltip button label" },
        }}
      />
    );

    const tooltipButton = screen.getByLabelText("Tooltip button label");

    expect(tooltipButton).toBeDefined();
  });

  it("should render hint with tooltip button", () => {
    render(
      <WrappedFieldset
        {...baseProps}
        legendHintTooltipProps={{
          tooltipProps: { heading: "Test", text: "Lorem Ipsum" },
          iconButtonProps: { "aria-label": "Tooltip button label" },
        }}
      />
    );

    const tooltipButton = screen.getByLabelText("Tooltip button label");

    expect(tooltipButton).toBeDefined();
  });

  it("should render with a default testID", () => {
    render(<WrappedFieldset {...baseProps} />);

    expect(screen.getByTestId("fieldset")).toBeDefined();
  });

  it("should render with a custom testID", () => {
    const testID = "custom-fieldset";

    render(<WrappedFieldset {...baseProps} testID={testID} />);

    expect(screen.getByTestId(testID)).toBeDefined();
  });
});
