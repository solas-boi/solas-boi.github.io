import { View } from "react-native";
import type { Meta, StoryObj } from "@storybook/react";
import { DesignTokensDecorator } from "@boi/react-native-design-tokens";

import { Table } from "./Table";
import { MockTable } from "./Table.mocks";
import { designTokensArgTypes, designTokensArgs } from "../storybookHelpers";

const meta = {
  title: "Data Display/Table",
  component: Table,
  decorators: [
    (Story, { args }) => (
      <DesignTokensDecorator brandTheme={args.brandTheme}>
        <View style={{ padding: 15 }}>
          <Story />
        </View>
      </DesignTokensDecorator>
    ),
  ],
  argTypes: {
    ...designTokensArgTypes,
  },
  args: {
    ...designTokensArgs,
  },
} satisfies Meta<typeof Table>;

export default meta;
type Story = StoryObj<typeof meta.component>;

export const Basic: Story = {
  render: function Render(args) {
    return <MockTable {...args} />;
  },
};
