import { CoreCombobox } from "@boi/components-core";
import { Modal, type ModalProps } from "../Modal";
import {
  ComboboxModalBase,
  type ComboboxModalBaseProps,
} from "../ComboboxModalBase";

export type ComboboxModalProps<T extends CoreCombobox.ComboboxItem> = Omit<
  ModalProps,
  "children"
> &
  ComboboxModalBaseProps<T>;

function ComboboxModal<T extends CoreCombobox.ComboboxItem>(
  props: ComboboxModalProps<T>
) {
  const {
    title,
    selectedItem,
    items,
    disabledKeys,
    defaultInputValue,
    onInputChange,
    onChange,
    testID = "combobox-modal",
    ...modalProps
  } = props;

  return (
    <Modal {...modalProps} testID={testID}>
      <ComboboxModalBase
        testID={testID}
        title={title}
        onRequestClose={modalProps.onRequestClose}
        items={items}
        disabledKeys={disabledKeys}
        selectedItem={selectedItem}
        defaultInputValue={defaultInputValue}
        onInputChange={onInputChange}
        onChange={onChange}
      />
    </Modal>
  );
}

export default ComboboxModal;
