# React Native country assets

The `@boi/country-assets` packaged for React applications.

## Installation

```console
npm i @boi/react-native-country-assets
```

## Usage

```jsx
import { countriesData } from "@boi/react-native-country-assets";

{
  countriesData.map(
    ({ code, label, callingCode, component: FlagComponent }) => {
      return (
        <>
          Country code: {code}
          Country name: {label}
          Country calling code: {callingCode}
          Country flag: <FlagComponent />
        </>
      );
    }
  );
}
```
